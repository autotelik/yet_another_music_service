# Accessible in Development,
#
# View list of all possible previews - http://localhost:3000/rails/mailers/postoffice

class MailerPreviews < ActionMailer::Preview
  # Accessible in Development - from http://localhost:3000/rails/mailers/postoffice/add_conversion_database_failed
  def add_conversion_database_failed
    conv_job = ConversionJob.last || ConversionJob.new

    AddConversionDatabaseFailed.build_mail(conv_job, '/some/path/I/made/up')
  end
end
