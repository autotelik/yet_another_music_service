require 'rails_helper'

describe BaseMailer, type: :mailer do

  describe 'Mail Events and Options' do

    it 'can register a new associated MailEventOption for filtering' do
      expect {
        described_class.register_mail_event_option(:filter_receivers, DataSet, :name)
      }.to change(MailEventOption, :count).by(1)
    end

    it 'can register a MailEventOption for filtering on a specific category' do
      described_class.register_mail_event_option(:filter_receivers, DataSet, :name)
      option = MailEventOption.last
      expect(option.filter_receivers?).to be true
      expect(option.category).to eq 'filter_receivers'
      expect(option.optional_type).to eq 'DataSet'
      expect(option.optional_field).to eq 'name'
    end

    it 'validates the Type supplied is a valid class' do
      expect {
        described_class.register_mail_event_option(:filter_receivers, 'WhatTheHeckIsThis', :to_s)
      }.to raise_error ActiveRecord::RecordInvalid
    end

    it 'validates the Type and Field are valid and callable' do
      expect {
        described_class.register_mail_event_option(:filter_receivers, DataSet, :does_not_respond_to_this)
      }.to raise_error ActiveRecord::RecordInvalid
    end

    it 'validates the filtering category when registering a MailEventOption' do
      expect {
        described_class.register_mail_event_option(:no_such_category, DataSet, :name)
      }.to raise_error ActiveRecord::RecordInvalid
    end

    it 'supplies shortcut for filtering on a specific category' do
      described_class.register_filter_receivers_option(DataSet, :name)
      option = MailEventOption.last
      expect(option.filter_receivers?).to be true
      expect(option.category).to eq 'filter_receivers'
      expect(option.optional_type).to eq 'DataSet'
      expect(option.optional_field).to eq 'name'
    end

  end

end
