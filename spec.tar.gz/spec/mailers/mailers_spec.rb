require 'rails_helper'

RSpec.shared_examples 'Mailers' do |resend_support|

  before do
    # Creates associated Mail Event + Options
    described_class.register_mail_event
    described_class.register_mail_options

    allow(ConfigParameter).to receive(:get).with('delivery_team_email_string') { 'Delivery-Team Mapscape <noreply@mapscape.eu>' }
    allow(ConfigParameter).to receive(:get).with('default_database_expiry_in_days', anything) { 5 }
    allow(ConfigParameter).to receive(:get).with('process_data_directory', anything) { '/tmp' }
    allow(ConfigParameter).to receive(:get).with(:local_dakota_dir) { '/tmp' }
    allow(Job).to receive(:convert_raw_to_dir) { '/tmp' }
  end

  let(:user)        { create(:user) }
  let(:mailer)      { described_class }

  if resend_support

    let(:mail) { mailer.build_mail(*parameters, false).deliver_now }

    context 'resend off' do
      it 'assigns @resend and no update in body' do
        expect(mail.body.encoded).to_not match('UPDATE')
      end
    end

    context 'resend on' do
      let(:mail) { mailer.build_mail(*parameters, true).deliver_now }
      it 'assigns @resend and has update in body' do
        expect(mail.body.encoded).to match('UPDATE')
      end
    end

  else
    let(:mail) { mailer.build_mail(*parameters).deliver_now }
  end

  let(:mail_event) { MailEvent.where(name: described_class.name).first }

  it 'has an associated MailEvent based on the mailer class name matching event name' do
    expect(MailEvent.where(name: described_class.name).first).to be_a MailEvent
  end

  if described_class.options? # Mailer supporting options is optional!
    it 'has associated MailEventOptions through its MailEvent' do
      expect(mail_event.mail_event_options).to_not be_empty
      expect(mail_event.mail_event_options.first).to be_a MailEventOption
    end
  end

  it 'renders the subject' do
    expect(mail.subject).to match(subject)
  end

  it 'renders the sender email' do
    expect(mail.from).to eq(['noreply@mapscape.eu'])
  end

  it 'generates the body of the mail' do
    expect(mail.body.encoded).to match(body)
  end

end

resend_supported = true

context('Mailer Classes') do

  let(:email_user) { create(:TESTUSER) }

  describe AddConversionDatabaseFailed, type: :mailer do
    let(:parameters)  { [create(:conversion_job), '/tmp'] }
    let(:subject)     { /WebMIS Failed to add Conversion DB for Job ID\s+\d+/ }
    let(:body)        { 'no databases registered. Please cleanup manually' }
    it_should_behave_like 'Mailers'
  end

  describe ConversionFinished, type: :mailer do
    let(:conv) { create(:c_DEFAULT, :with_product_line) }
    let(:parameters) { conv }
    let(:subject)   { 'WebMIS Conversion Result' }
    let(:body)      { 'Conversion request' }

    it_should_behave_like 'Mailers', resend_supported do
      it 'sets additional addresses to the conversion.request_user email' do
        conv.update(request_user: user)
        expect(mail.to).to eq([user.email])
      end
    end
  end

  describe ConfirmReception, type: :mailer do
    let(:parameters) { create(:reception) }
    let(:subject)   { 'WebMIS Reception notification' }
    let(:body)      { '<h4>Reception Notification' }
    it_should_behave_like 'Mailers', resend_supported
  end

  describe DataIntakeRequest, type: :mailer do
    let(:parameters) { create(:reception) }
    let(:subject)   { 'Data Intake Request for' }
    let(:body)      { '<h4>Data intake request' }
    it_should_behave_like 'Mailers'
  end

  describe ConversionJobStatusChange, type: :mailer do
    let(:parameters)  { create(:conversion_job) }
    let(:subject)     { /Conversion Job\s+\d+/ }
    let(:body)        { /<h4>Conversion Job\s+\d+/ }
    it_should_behave_like 'Mailers'
  end

  describe ConversionJobFileMoveFailed, type: :mailer do
    let(:parameters)  { create(:cj_DEFAULT) }
    let(:subject)     { /WebMIS File move failed: Conversion Job\s+\d+/ }
    let(:body)        { '<h4>File move failed: Conversion Job' }
    it_should_behave_like 'Mailers'
  end

  describe ConversionDatabaseValidationFailed, type: :mailer do
    let(:parameters)  { create(:conversion_database) }
    let(:subject)     { /WebMIS Validation failed for database\s+\d+/ }
    let(:body)        { '<h4>Conversion Database' }
    it_should_behave_like 'Mailers'
  end

  describe ConversionDesignValidationFailed, type: :mailer do
    # (trace, conv_script_id, user = nil)
    let(:parameters)  { [true, create(:conv_script), email_user] }
    let(:subject)     { /WebMIS Validation failed for conv script\s+\S+/ }
    let(:body)        { '<h4>Conv script' }
    it_should_behave_like 'Mailers'
  end

  describe DataSetReviewRequest, type: :mailer do
    let(:parameters)  { [create(:data_set, :with_coverages_region), email_user, email_user] }
    let(:subject)     { 'Data set review request' }
    let(:body)        { '<h3>Data set review request</h3>' }
    it_should_behave_like 'Mailers'
  end

=begin This week the user's dont want this email, next week they might, so leaving for reference
  describe DataSetReviewRequester, type: :mailer do
    let(:parameters)  { [create(:data_set, :with_coverages_region), email_user] }
    let(:subject)     { 'You requested a Data set review' }
    let(:body)        { '<h3>Data set review requested</h3>' }
    it_should_behave_like 'Mailers'
  end
=end

  describe DataSetReviewResult, type: :mailer do
    let(:parameters)  { [create(:data_set, :with_coverages_region), email_user, email_user, true] }
    let(:subject)     { 'Data set' }
    let(:body)        { '<h3>Data set review result</h3>' }
    it_should_behave_like 'Mailers'
  end

  describe DirectApproval, type: :mailer do
    let(:parameters)  { create(:data_type) }
    let(:subject)     { 'directly approved by' }
    let(:body)        { '<p>Approval done by:' }
    it_should_behave_like 'Mailers'
  end

  describe ExpiryNotification, type: :mailer do
    let(:parameters)  { create(:production_order) }
    let(:subject)     { 'Expiry notification for production order' }
    let(:body)        { 'Once expired all non-persistent conversion databases generated' }
    it_should_behave_like 'Mailers'
  end

  describe InternalServerError, type: :mailer do
    let(:parameters)  { ['subject', 'details', 'trace', email_user] }
    let(:subject)     { 'WebMIS Internal server error' }
    let(:body)        { 'Internal server error</h4>' }
    it_should_behave_like 'Mailers'
  end

  describe InternalServerErrorHandled, type: :mailer do

    let(:exception) {
       WebMis::ParseError.new('Failed to read JSON field').tap {|e| e.set_backtrace(caller) }
    }

    let(:parameters)  { [exception, "DataSet::new", email_user] }
    let(:subject)     { /WebMIS Handled Internal Server Error - Failed to read JSON field/ }
    let(:body)        { /Internal server error raised but caught and handled by[\W\w]*DataSet::new/ }
    it_should_behave_like 'Mailers'
  end

  describe ReceptionRequest, type: :mailer do
    let(:parameters) { create(:reception) }
    let(:subject)   { 'WebMIS Reception Request' }
    let(:body)      { 'Reception Request Id ' }
    it_should_behave_like 'Mailers'
  end

  describe RejectReception, type: :mailer do
    let(:parameters) { create(:reception) }
    let(:subject)   { 'WebMIS REJECTED: Reception Request' }
    let(:body)      { /Reception Request with Id \d+ is rejected due to the following reason/ }
    it_should_behave_like 'Mailers'
  end

  describe ReviewRequest, type: :mailer do
    let(:parameters) { create(:data_type) }
    let(:subject)   { 'WebMIS Review Request for DataType' }
    let(:body)      { '<h4>Review request DataType' }
    it_should_behave_like 'Mailers'
  end

  describe NotifyDocumentOverwrite, type: :mailer do
    let(:parameters) { [email_user, create(:asset), create(:document)] }
    let(:subject)   { /Your document .* is overwritten/ }
    let(:body)      { 'This document is changed because' }
    it_should_behave_like 'Mailers'
  end

  describe ProductionOrderStatusChange, type: :mailer do
    let(:parameters)  { [create(:production_order), email_user] }
    let(:subject)     { /Production order \d+/ }
    let(:body)        { '<h4>Production order' }
    it_should_behave_like 'Mailers'
  end

  describe ProductionOrderlineStatusChange, type: :mailer do
    let(:parameters)  { [create(:production_orderline), email_user] }
    let(:subject)     { /Production Orderline \d+/ }
    let(:body)        { /Production Orderline \d+.*in status/ }
    it_should_behave_like 'Mailers'
  end

  describe ProductReleaseMail, type: :mailer do
    let(:outbound_order) { create(:outbound_order) }
    # (outbound_order, to_member, current_user, rel_notes_yn)
    let(:parameters)  { [outbound_order, email_user, email_user, true] }
    let(:subject)     { 'Mapscape delivery: ' }
    let(:body)        { '<p>The map data download package includes the following product' }
    it_should_behave_like 'Mailers'
  end

  describe ProductLocationExtStatusChange, type: :mailer do
    let(:parameters)  { create(:product_location) }
    let(:subject)     { /WebMIS Product Location\s+\d+/ }
    let(:body)        { ' View product location:' }
    it_should_behave_like 'Mailers'
  end

  describe ProductEditDuringActiveOrder, type: :mailer do
    let(:parameters)  { [create(:product), create(:production_order), email_user] }
    let(:subject)     { /WebMIS Forced edit notification of product/ }
    let(:body)        { '<p>Currently your production order' }
    it_should_behave_like 'Mailers'
  end

  describe ReviewUnwantedDir, type: :mailer, todo: true do

    let(:job) { create(:conversion_job) }

    let(:ls_output) do
      [
        'drwxrwxrwx 7 backoffice_test conversion 4096 May 19  2017 w_20170519-100312-313563-nar_tom_2016_12_20170515b_mnr_cnt/',
        'drwxr-xr-x 2 backoffice_test conversion 4096 Dec 29 15:28 o_20171229-152411-412888-eur_tom_2016_12_20171229b_mnr_nor_dryrun/',
        'drwxr-xr-x 2 backoffice_test conversion 4096 Dec 29 15:56 o_20171229-155210-412901-eur_tom_2016_12_20171229b_mnr_ukr_dryrun/'
      ]
    end

    let(:details)     { FindUnwantedPaths.call(job.run_server, ls_output) }
    let(:parameters)  { [job.project.id, details] }
    let(:subject)     { "Review unwanted directories on servers for Project #{job.project.name}" }
    let(:body)        { '<h4>Found rogue directories on servers for jobs of type ConversionJob, ValidationJob</h4>' }
    it_should_behave_like 'Mailers'
  end

  describe ResultTestRequest, type: :mailer do
    let(:parameters) { create(:test_request_maximal) }
    let(:subject)   { /Test Result \d+/ }
    let(:body)      { '<td>Test Database:</td>' }
    it_should_behave_like 'Mailers'
  end

  describe ShipmentRequest, type: :mailer do
    let(:parameters)  { create(:pol_line2) }
    let(:subject)     { /WebMIS Shipment Request: \w+/ }
    let(:body)        { /<h4>Shipment request \w+/ }
    it_should_behave_like 'Mailers'
  end

  describe TestRequestMailer, type: :mailer do
    let(:parameters) { create(:test_request) }
    let(:subject)   { /Test Request \d+/ }
    let(:body)      { '<b>Requested by:</b>' }
    it_should_behave_like 'Mailers'
  end

  describe TestGridError, type: :mailer do
    let(:reason)      { 'TestGrid support not executed because not all required fields were set.' }
    let(:parameters)  { [create(:conversion_database_maximal), reason] }
    let(:subject)     { 'TestGrid invocation failed for conversion database' }
    let(:body)        { '<b>Test database</b>' }
    it_should_behave_like 'Mailers'
  end

  describe ToolSpecSynchronizationError, type: :mailer do
    let(:parameters)  { [] }
    let(:subject)     { "'Tool spec synchronization error'" }
    let(:body)        { '' }
    # Missing template nothing found for this mailer under postoffice
    # it_should_behave_like 'Mailers'
  end

  describe ValidationRequest, type: :mailer do
    let(:parameters) { create(:reception) }
    let(:subject)   { 'Validation Request for' }
    let(:body)      { '<h4>Data validation request' }
    it_should_behave_like 'Mailers'
  end

end
