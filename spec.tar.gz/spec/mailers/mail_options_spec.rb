require 'rails_helper'

RSpec.shared_examples 'Mailer Filtering' do |no_extra_address|

  before do
    # Creates associated Mail Event + Options
    described_class.register_mail_event
    described_class.register_mail_options
  end

  context 'Filtering Receivers' do

    let(:test_user_1)             { create(:TESTUSER1) }
    let(:test_user_2)             { create(:TESTUSER2) }
    let(:no_filter_users)         { create_list(:user_maximal, 2) } # Expect Always Present - Have NO Filter at all

    # Default filterable names to semi random strings
    let(:test_user_1_value)       { rspec_generate_revision }
    let(:test_user_2_value)       { rspec_generate_revision }

    let(:mailer)                  { described_class }
    let(:mail)                    { mailer.build_mail(*parameters).deliver_now }
    let(:mail_event)              { MailEvent.where(name: described_class.name).first }

    # Each Mailer knows what MailEvent Options it supports - currently none have more than one, so take first
    let(:filter_option)           { mail_event.mail_event_options.first }

    let(:optional_field)          { filter_option.optional_field } # e.g optional_field = name (on ProductLine)

    let(:all_recepients)          { User.all.map(&:email) }
    let(:no_filter_recepients)    { no_filter_users.map(&:email) }

    before do
      mail_event.users << test_user_1        # Filter ON
      mail_event.users << test_user_2        # Filter ON
      mail_event.users << no_filter_users    # Always Present - Have NO Filter at all

      allow(ConfigParameter).to receive(:get).with('delivery_team_email_string') { 'Delivery-Team Mapscape <noreply@mapscape.eu>' }
      allow(ConfigParameter).to receive(:get).with('default_database_expiry_in_days', anything) { 5 }
      allow(ConfigParameter).to receive(:get).with('process_data_directory', anything) { '/tmp' }
      allow(ConfigParameter).to receive(:get).with(:local_dakota_dir) { '/tmp' }
      allow(Job).to receive(:convert_raw_to_dir) { '/tmp' }
    end

    context('No filter') do
      it 'returns the full users list when no mail options set for filtering receivers' do
        expect(mail.to).to match_array(all_recepients)
      end
    end

    context('Filter') do

      # Creates User specific Filters on specific Values

      # it should handle multiple filter values so create a non matcher too that should not impact the result

      let!(:user_mail_event_option_no_match) {
        UserMailEventOption.create(user: test_user_1,
                                   mail_event_option: filter_option,
                                   value: '** Blah Blah ^^&')

      }

      let!(:user_mail_event_option_1) {
        UserMailEventOption.create(user: test_user_1,
                                   mail_event_option: filter_option,
                                   value: test_user_1_value)
      }

      let!(:user_mail_event_option_2) {
        UserMailEventOption.create(user: test_user_2,
                                   mail_event_option: filter_option,
                                   value: test_user_2_value)
      }

      it 'filters out users with option on this event and a value that does not match' do
        set_test_user_1_match
        expect(mail.to).to match_array([test_user_1.email] + no_filter_recepients)
      end

      it 'filters out users with option on this event and a value that does not match' do
        set_test_user_2_match
        expect(mail.to).to match_array([test_user_2.email] + no_filter_recepients)
      end

      unless no_extra_address
        it 'still applies Filter to other Users when EXTRA addresses applied' do
          set_test_user_2_match
          set_user_2_as_extra         # Use test_user_2 as the extra address so matches filter
          expect(mail.to).to match_array(all_recepients - [test_user_1.email])
        end

        it 'does NOT filter EXTRA addresses even if User has applied filter' do
          set_test_user_1_match
          set_user_2_as_extra         # Use test_user_2 as the extra address so matches filter
          expect(mail.to).to match_array(all_recepients)
        end
      end

    end
  end
end

context('Mailers Supporting Filtering') do

  turn_off_extra_address_tests = true

  let(:resend) { false }

  context('Mailers with single Filter on each against ProductLine') do

    # DEFAULTS - Assign testable values to the ProductLine we will be filtering on
    let(:set_test_user_1_match) { parameters[0].product_line.update(name: test_user_1_value) }
    let(:set_test_user_2_match) { parameters[0].product_line.update(name: test_user_2_value) }

    describe ConversionFinished, type: :mailer do
      # This Mailer is passed a Conversion and Rest; Filters on ProductLine (name)
      let(:parameters)            { [create(:c_DEFAULT, :with_product_line), resend] }

      # This Mailer uses ProductLine.request_user for extra addresses
      let(:set_user_2_as_extra)   { parameters[0].update(request_user: test_user_2) }

      it_should_behave_like 'Mailer Filtering'
    end

    describe ProductionOrderlineStatusChange, type: :mailer do
      # This Mailer is passed a ProductionOrderline and optional User; Filters on ProductLine (name)
      let(:parameters)            { [create(:production_orderline, :with_product_line), nil] }

      # This Mailer uses 2nd param for extra addresses
      let(:set_user_2_as_extra)   { parameters[1] = test_user_2 }

      it_should_behave_like 'Mailer Filtering'
    end

    describe ProductionOrderStatusChange, type: :mailer do
      # This Mailer is passed a ProductionOrder and optional User; Filters on ProductLine (name)
      let(:parameters)            { [create(:production_order, :with_production_orderlines), nil] }

      let(:set_test_user_1_match) { parameters[0].product_lines[0].update(name: test_user_1_value) }
      let(:set_test_user_2_match) { parameters[0].product_lines[0].update(name: test_user_2_value) }

      # This Mailer uses 2nd param for extra addresses
      let(:set_user_2_as_extra)   { parameters[1] = test_user_2 }

      it_should_behave_like 'Mailer Filtering'
    end

    describe ProductEditDuringActiveOrder, type: :mailer do
      # This Mailer is passed a Product, ProductionOrder and Current User
      let(:parameters) do
        [create(:product), create(:production_order, :with_production_orderlines), test_user_1]
      end

      let(:set_test_user_1_match) { parameters[1].product_lines[0].update(name: test_user_1_value) }
      let(:set_test_user_2_match) { parameters[1].product_lines[0].update(name: test_user_2_value) }

      # This Mailer uses production_order.requestor for extra addresses
      let(:set_user_2_as_extra)   { parameters[1].update(requestor: test_user_2.full_name) }

      it_should_behave_like 'Mailer Filtering'
    end

    describe ShipmentRequest, type: :mailer do
      # This Mailer is passed a ProductionOrderline; Filters on ProductLine (name)
      let(:parameters) { [create(:production_orderline, :with_product_line)] }

      # Extra addresses N.A
      it_should_behave_like 'Mailer Filtering', turn_off_extra_address_tests
    end

  end

  context 'Mailers with single Filter on each against Project' do
    describe ExpiryNotification, type: :mailer, duff: true do
      # This Mailer is passed a Production order; filters on Project (name)
      let(:parameters)            { create(:po_expiration_candidate) }

      let(:set_test_user_1_match) { parameters.project.update(name: test_user_1_value) }
      let(:set_test_user_2_match) { parameters.project.update(name: test_user_2_value) }

      it_should_behave_like 'Mailer Filtering', turn_off_extra_address_tests
    end
  end

  describe ReviewUnwantedDir, type: :mailer do
    let(:job) { create(:conversion_job) }

    let(:ls_output) do
      [
        'drwxrwxrwx 7 backoffice_test conversion 4096 May 19  2017 w_20170519-100312-313563-nar_tom_2016_12_20170515b_mnr_cnt/',
        'drwxr-xr-x 2 backoffice_test conversion 4096 Dec 29 15:28 o_20171229-152411-412888-eur_tom_2016_12_20171229b_mnr_nor_dryrun/',
        'drwxr-xr-x 2 backoffice_test conversion 4096 Dec 29 15:56 o_20171229-155210-412901-eur_tom_2016_12_20171229b_mnr_ukr_dryrun/'
      ]
    end

    # This Mailer is passed a Project ID, User creates MailEventOption against the Project (name)
    # i.e is only interested in Servers associated with that Project
    let(:parameters)            { [job.project.id, FindUnwantedPaths.call(job.run_server, ls_output)] }

    let(:set_test_user_1_match) { job.project.update(name: test_user_1_value) }
    let(:set_test_user_2_match) { job.project.update(name: test_user_2_value) }

    # Extra addresses N.A
    it_should_behave_like 'Mailer Filtering', turn_off_extra_address_tests
  end

end
