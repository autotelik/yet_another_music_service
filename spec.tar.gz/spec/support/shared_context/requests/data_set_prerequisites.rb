# Set of common user/access patterns to enable request specs to be run
#
# Usage :
#   include_context "data_set_prerequisites"
#
RSpec.shared_context "data_set_prerequisites" do

  let!(:region) { create(:region) }
  let(:company_abbr) { create(:ca_HER, ms_abbr_3: 'her') }
  let(:data_release) { create(:data_release) }
  let(:data_type) { create(:data_type) }

  let!(:data_set) {
    create(:data_set, :with_coverages_region, :with_process_data_directory, region_id: reception.area_id, status: DataSet::STATUS_PRODUCTION, data_release: data_release)
  }

  let(:data_set_params) {
    attributes_for(:ds_DUMMY,
                   company_abbr_id: company_abbr.id,
                   region_id: region.id,
                   data_release_id: data_release.id,
                   data_type_id: data_type.id)
  }

  let(:product_line)  { create(:product_line) }
  let(:project)       { create(:proj_PRODUCTION) }

  let(:reception) { create(:reception, region: region, data_release: data_release) }
  let!(:region) { create(:region) }
  let!(:reg_1) { create(:region) }
  let!(:reg_2) { create(:region) }

  let(:reg_code_arr) { [reg_1.region_code, reg_2.region_code] }

  before(:each) do
    allow_any_instance_of(DataSet).to receive(:sync_elements) { true }
    allow_any_instance_of(DataSet).to receive(:allow_status_change?) { true }
  end

end
