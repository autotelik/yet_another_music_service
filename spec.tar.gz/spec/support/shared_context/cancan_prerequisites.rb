# Initializer for CanCan ability
# enables controller specs to deal with role authorization
#
# Usage : include_context 'cancan_prerequisites'
#
RSpec.shared_context "cancan_prerequisites" do

  let(:ability)           { Object.new }

  before do
    # STUB to allow all user permissions in controller/feature/requests tests
    allow_any_instance_of(CanCan::Ability).to receive(:can?)                          { true }

    ability.extend(CanCan::Ability)
    allow_any_instance_of(ApplicationController).to receive(:current_ability)         { ability }

    allow_any_instance_of(CanCan::ControllerResource).to receive(:authorize_resource) { true }
  end

end
