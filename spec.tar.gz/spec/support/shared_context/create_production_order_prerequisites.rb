# Set of common associations needed for creating a Production Order
#
# Example Usage :
#
# Whenever you want to create a production order simply add in RSpec code
#
#   include_context "create_production_order_prerequisites"
#
# The before each filter will then create all necessary underlying database records
#
RSpec.shared_context 'create_production_order_prerequisites' do

  let(:json_headers)            { { 'CONTENT_TYPE': 'application/json', 'HTTP_ACCEPT': 'application/json' } }

  let(:proj_PRODUCTION)         { create(:proj_PRODUCTION) }
  let(:proj_REGRESSION)         { create(:proj_REGRESSION) }

  let(:company_abbr)            { create(:ca_HER, ms_abbr_3: 'her') }

  let(:conversion_design)       { create(:RDF2DH, conv_script: conv_script, project: proj_PRODUCTION) }
  let(:conversion_environment)  { create(:conversion_environment) }
  let(:conversion_tool)         { create(:api_conversiontool) }

  let(:conv_design_name)  { create(:RDF2DH_design_name, project: proj_PRODUCTION, default_design: conversion_design) }
  let(:conv_script)       { create(:conv_script) }

  let(:coverage)          { create(:DS_EUROPE1) }
  let(:cvtool_bundle)     { create(:cvtool_bundle, name: 'input') }

  let(:data_release)      { create(:dr_2013Q2) }

  let(:region_eur)        { create(:r_Europe) }

  let!(:data_set) {
    create(:data_set, data_type: rdf_data_type, company_abbr: company_abbr, region: region_eur, data_release: data_release, coverage: coverage, status: 500)
  }

  let!(:data_set_group) {
    create(:data_set_group, company_abbr: company_abbr.ms_abbr_3, region_code: region_eur.region_code,
           data_release: data_release.release_code, data_type: rdf_data_type.name)
  }

  let!(:data_set_group_line) { create(:data_set_group_line, data_set: data_set, data_set_group: data_set_group) }

  let(:product_category)   { create(:product_category) }

  # Required by data_sets_controller::create_production_order
  let!(:ordertype_ds)      { create(:ordertype_ds, product_category: product_category) }

  let!(:product_set)       { create :product_set, project: proj_PRODUCTION, product_category: product_category }

  let!(:product)           { create(:product_maximal, region: region_eur, product_line_id: product_set.product_line_id, project: proj_PRODUCTION) }

  let(:rdf_data_type)     { create(:dt_RDF, name: 'RDF') }
  let(:rdb_data_type)     { create(:dt_RDB, name: 'RDB') }

  let(:server)            { create(:server, owned_by: proj_PRODUCTION) }

  let(:set_tool_handover) { create(:set_tool_handover_data_set, product_set: product_set, project: proj_PRODUCTION) }

  let(:tool_handover_p)   {
    # TODO: investigate how we can reduce factory creation, especially of ProductSets
    create(:tool_handover_product, handover: product, set_tool_handover: set_tool_handover, conv_script: conv_script, conversion_design_name: conv_design_name)
  }

  let(:tool_handover_ds) {
    create(:tool_handover_data_set, handover: data_set, conversion_design_name: conv_design_name, conv_script: conv_script, set_tool_handover: set_tool_handover)
  }

  let(:user) { create(:user) }

  before do

    # STUBS to stop Job details and Errors being displayed in Rspec STDOUT
    allow_any_instance_of(Conversion).to receive(:puts) {}
    allow_any_instance_of(Job).to receive(:puts) {}
    allow_any_instance_of(Checklog).to receive(:to_s) { '' }

    # This method checks paths and directories which are mostly stubbed anyway, so report no issues
    allow_any_instance_of(Server).to receive(:health_msg).and_return('')

    create(:dt_dHive, name: 'dHive')

    # config parameters
    [proj_PRODUCTION, proj_REGRESSION].each do |project|
      %i[
        tool_dir
        dakota_scripts_dir dakota_log_dir local_dakota_dir process_data_directory
        default_conversiontool_prefix default_bundle
        conversion_job_intermediate_dir conversion_job_result_dir
        reserve_buffer_size_bytes
      ].each { |param| create(param, project: project) }
    end

    reg_bel = create(:r_Belgium, parent_id: region_eur.id)
    reg_lux = create(:r_Luxembourg, parent_id: region_eur.id)

    create(:DS_Coverage_region_EUR_BEL, coverage: coverage, region: reg_bel)
    create(:DS_Coverage_region_EUR_LUX, coverage: coverage, region: reg_lux)

    reception = create(:r_TEST5, region: region_eur, data_release: data_release, data_type: rdf_data_type, data_set: data_set)

    pds = create(:pds_RDF, data_type: rdf_data_type, conversion_design_name: conv_design_name)
    pde = create(:pde_TEST1_RDF_ELEMENT, data_set: data_set, reception: reception, process_data_specification: pds)


    # tools need to be available for production order
    conversiontool = create(:api_conversiontool, code: 'BladeRunner_20170407_3')

    create(:cvtool_bundle_release, cvtool_bundle: cvtool_bundle, conversiontool: conversiontool)

    # TODO: Split into two, DataSet or Product based

    # DataSet
    create(:handover_rdf2rdb, tool_handover: tool_handover_ds)
    create(:handover_rdb2dh,  tool_handover: tool_handover_ds, cvtool_bundle: cvtool_bundle, conversiontool: conversiontool, conv_script: conv_script, conversion_environment: conversion_environment)

    # Product
    allow_any_instance_of(Product).to receive(:link_product_set).and_return('')
    create(:included_product, product: product, product_set: product_set)

    create(:handover_rdf2rdb, tool_handover: tool_handover_p)
    create(:handover_rdb2dh,  tool_handover: tool_handover_p, cvtool_bundle: cvtool_bundle, conversiontool: conversiontool, conv_script: conv_script, conversion_environment: conversion_environment)

    create(:data_set_info, product: product, major_data_set_yn: true, coverage: coverage, data_set: data_set)

    create(:PROD_PROD, server: server, project: proj_PRODUCTION)

    server.set_job_types(%w[ConversionJob PackingJob ShippingJob ValidationJob])

    # Executable Version

    e_rdf2rdb = create(:e_RDF2RDB)
    # input/output need datatype id's, manually handled here
    e_rdf2rdb.input = "[{\"datatype\":\"RDF\",\"mandatory\":\"false\",\"script_tag\":\"\",\"id\":#{rdf_data_type.id},\"version\":11}]"
    e_rdf2rdb.output = "[{\"identification\":\".db\",\"datatype\":\"RDB\",\"id\":#{rdb_data_type.id},\"version\":7}]"
    e_rdf2rdb.save

    allow_any_instance_of(ProcessDataElement).to receive(:get_script_lines_hash).and_return([{ file: "#{pde.directory}/data", region_code: 'EUR' }])

  end
end
