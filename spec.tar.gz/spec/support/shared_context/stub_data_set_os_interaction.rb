# Stub methods on DataSet that interact with OS or file system
#
# Usage :
#   include_context "stub_data_set_os_interaction"
#
RSpec.shared_context "stub_data_set_os_interaction" do

  before(:each) do
    allow_any_instance_of(DataSet).to receive(:sync_elements)                   { true }
    allow_any_instance_of(DataSet).to receive(:allow_status_change?)            { true }
    allow_any_instance_of(DataSet).to receive(:validate_element_file_structure) { true }
    allow_any_instance_of(DataSet).to receive(:generate_directory)              { scratch_path }
  end

end
