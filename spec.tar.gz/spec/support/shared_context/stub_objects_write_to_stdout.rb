# Set of common Stubs/Mocks
#
# STUBS to stop things like Job details, Conversions and Errors being displayed in Rspec STDOUT
#
# Usage : include_context "stub_objects_write_to_stdout"
#
RSpec.shared_context "stub_objects_write_to_stdout" do
  before do
    allow_any_instance_of(Conversion).to receive(:puts) {}
    allow_any_instance_of(Job).to receive(:puts) {}
    allow_any_instance_of(Checklog).to receive(:to_s) { "" }
    allow_any_instance_of(Checklog).to receive(:inspect) { "" }
    allow_any_instance_of(Checklog).to receive(:puts) { }
    allow_any_instance_of(ProductionOrder).to receive(:puts) {}
  end
end
