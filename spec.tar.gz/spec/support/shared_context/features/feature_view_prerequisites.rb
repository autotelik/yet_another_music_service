# Set of common view requirements, to enable FEATURE specs to run.
#
# Prerequisite containing variables is :    include_context "authorization" do
#
# Usage :
#   include_context "feature_view_prerequisites"
#
RSpec.shared_context "feature_view_prerequisites" do

  before(:each) do
    # Minimum data required for views to function as per production
    page.set_rack_session(project_id:  proj_PRODUCTION.id)

    # Mock authorization and logged in User
    page.set_rack_session(user_id: user.id)
  end

end