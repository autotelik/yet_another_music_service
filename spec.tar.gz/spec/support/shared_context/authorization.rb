# Set of common user/access patterns to enable Feature & Request & Controller
# specs that need Authorization - login - and stubbing out OS interactions
#
# N.B Since in some contexts, negative ability tests are required, we do not automatically
# include CanCan::Ability stubs.
#
# To add the ability to view any page to authorised users also add : include_context 'cancan_prerequisites'
#
#
# Usage :  Targeted way to setup request/feature test Controllers
#
#       include_context "authorization" do
#         let(:controllers) { [DataSetsController] }
#       end
#
RSpec.shared_context "authorization" do

  let!(:proj_PRODUCTION)  { create(:proj_PRODUCTION) }
  let!(:user)             { create(:user, user_profile: create(:user_profile)) }
  let(:controllers)       { [] }

  before(:each) do

    [*controllers].each do |controller|
      allow_any_instance_of(controller).to receive(:authorize)      { true }
      allow_any_instance_of(controller).to receive(:current_user)   { user }
    end

    # has to come after the derived Controllers or see strange error related to derived, e.g.
    #     method `__current_user_without_any_instance__' not defined in xyzController
    allow_any_instance_of(ApplicationController).to receive(:authorize)       { true }
    allow_any_instance_of(ApplicationController).to receive(:current_user)    { user }
    allow_any_instance_of(ApplicationController).to receive(:current_project) { proj_PRODUCTION }

    # stub out OS interaction
    allow(ShellUtil).to receive(:ssh_localhost) {}
    allow(ShellUtil).to receive(:ssh_safe) {}

    allow(FileSystemUtil).to receive(:move_directory) { true }
  end

end