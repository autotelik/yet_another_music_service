# Set of common Stubs/Mocks
#
# Whenever you want to test JOB scheduling but stub out all OS type interactions
#
#       context ("Job Scheduling") do
#
#           include_context "production_order_scheduling_stubs"
#
#           it 'runs scheduled jobs' do
#             ....
#             ProductionOrder.schedule
#
RSpec.shared_context "production_order_scheduling_stubs" do

  before do
    # necessary stubs
    allow_any_instance_of(ConversionJob).to receive(:create_dakota_scripts)

    allow_any_instance_of(ConversionJob).to receive(:execute_dakota_script).and_return(9999)
    allow_any_instance_of(ConversionJob).to receive(:get_dir_size).and_return(9999)
    allow_any_instance_of(ConversionJob).to receive(:dakota_job_finished?).and_return(true)
    allow_any_instance_of(ConversionJob).to receive(:move_scripts)
    allow_any_instance_of(ConversionJob).to receive(:o_dir_size).and_return(9999)
    allow_any_instance_of(ConversionJob).to receive(:read_dakota_done_file).and_return(0)
    allow_any_instance_of(ConversionJob).to receive(:set_permissions_outcome_directory)
    allow_any_instance_of(ConversionJob).to receive(:store_dakota_dryrun_log)
    allow_any_instance_of(ConversionJob).to receive(:tail_log).and_return('lorem')

    output_db_extensions = %w[.db .dh.sq3]
    allow_any_instance_of(ConversionJob).to receive(:o_dir_contents).and_return(output_db_extensions)

    # TODO: investigate how to stub rsyncmove, but keep the postmove(adding a wrapper around rsync)
    # workaround is to simulate outcome by manually running postmove on the job
    allow_any_instance_of(ConversionJob).to receive(:rsyncmove)

    allow(FileSystemUtil).to receive(:file_size).and_return(9999)
    allow(FileSystemUtil).to receive(:file_write_safe).and_return(true)
    allow(FileSystemUtil).to receive(:chmod_r_safe).and_return(true)

    # Create expected Mail Events
    # TODO can we stub this more efficiently
    ProductionOrderlineStatusChange.register_mail_event
    ProductionOrderStatusChange.register_mail_event

  end

end
