require_relative 'page_object'

module WebMis

  class ReceptionPage < PageObject

    def initialize; end

  end
end
