module WebMis
  class PageObject
    include FactoryBot::Syntax::Methods
    include RSpec::Matchers
    include Capybara::DSL
    extend Capybara::DSL

    def show
      save_and_open_page
    end

    def commit_form
      find('input[name="commit"]').click
    end

    def commit_form_expect_new_object(klass:)
      expect { commit_form }.to change(klass, :count).by(1)
    end

  end

end