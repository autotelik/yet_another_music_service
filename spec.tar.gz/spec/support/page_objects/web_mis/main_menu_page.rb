require_relative 'page_object'

module WebMis
  class MainMenuPage < PageObject

    def initialize; end

    def expect_reception_menu_item(text)
      expect_menu_item(key: 'reception', text: text)
    end

    # Check for a sub item in the drop down identified by the top level 'key'
    def expect_menu_item(key:, text:)
      expect(page).to have_css("##{key}+ul.dropdown-menu > li > a", text: text)
    end

    # Click sub items from Main Menu drop downs
    def click_production_item(menu_text)
      click_item(key: :production, menu_text: menu_text)
    end

    def click_reception_item(menu_text)
      click_item(key: :reception, menu_text: menu_text)
    end

    def click_item(key:, menu_text:)
      find("##{key}+ul.dropdown-menu > li > a", text: menu_text).click
    end

  end
end
