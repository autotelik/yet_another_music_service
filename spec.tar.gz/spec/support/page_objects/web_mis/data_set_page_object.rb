require_relative 'page_object'
module WebMis
  class DataSetPageObject < PageObject
    attr_reader :company_abbr, :release, :data_set_group

    def initialize; end

    # The minimum database associations required to create a DataSet
    def populate_associated

      # DataTypes
      create(:dt_RDF, name: 'RDF')
      create(:dt_RDB, name: 'RDB')

      # Regions / Coverages
      create(:region, region_code: 'RE1', name: 'Region1')
      create(:r_WORLD, :with_coverage)

      @company_abbr   = create(:company_abbr, company_name: 'HERE', ms_abbr_3: 'HER')

      # For a Release to be selectable must be linked to Company and in 'production' scope
      @release        = create(:dr_2013Q2, production: true, active: true)

      @data_set_group = create(:data_set_group, data_release: '2017Q1')

      create(:product_line, name: "VWG MIB STD2")

      # Required for RegionalParams
      create(:e_RDF2RDB)

    end

    # From Main Menu - analogous to : visit data_sets_path
    def navigate_to_index_action
      find("#reception+ul.dropdown-menu > li > a", text: "Data sets").click
    end

    alias_method :navigate_to_index_page, :navigate_to_index_action

    # N.B  When Javascript enabled the select boxes aren't visible, since dropdown populated vis JS searches etc
    # When JS is disabled, the drop down is displayed (visible) for normal non searchable selection
    def fill_page(js: false)
      # If JS enables, select boxes are NOT visible
      fill_sequence(visible: !js).each(&:call)
    end

    # N.B  When Javascript enabled the select boxes aren't visible, since dropdown populated vis JS searches etc
    # When JS is disabled, the drop down is displayed (visible) for normal non searchable selection
    #
    def fill_sequence(visible: true)

      # Manual Test Data Entered would be :
      #
      #   Release: 2017Q1
      #   Coverage: MEA – Middle East Africa
      #   Data type: RDF
      #   Description: TC2 WEBMIS TEST SCENARIO
      #   Product line whitelist: VWG MIB STD2
      #   Coverage areas: Israel, Israel Disputedv
      #   Remarks: Test scenario WebMIS TC1
      #   Select “HER 2017Q1 WLD RDF” from the Drop Down box below Remarks section.
      #   Select “Generate a group” check box.

      sequence = [
          # N.B labels such as data_set_Name do not seem to be found so use the form IDs
          proc { fill_in "data_set_name", with: "TC2_WebMIS" },
          proc { fill_in "data_set_description", with: "TC2 WEBMIS TEST SCENARIO" },   # Description
          proc { fill_in "data_set_remarks",     with: "Test scenario WebMIS TC1 " },  # Remarks

          proc { select "HER - HERE",       from: :data_set_company_abbr_id, visible: visible },  # Supplier

          # In JS mode, this is not visible and is populated via JS once Supplier chosen
          proc { select release.name,       from: :data_set_data_release_id, visible: visible },  # Release

          proc { select "RE1 - Region1",    from: :data_set_region_id, visible: visible },        # Coverage
          proc { select "RDF",              from: :data_set_data_type_id, visible: visible },     # Data type
          proc { select "VWG MIB STD2",     from: :product_line_selector, visible: visible },     # Product line whitelist
          proc { select "World ( WLD )",    from: :region_selector, visible: visible },
          proc { select "HER 2017Q1 WLD",   from: :data_set_group_id, visible: visible },         # Drop Down box below Remarks.

          proc { check "create_group" } # 'Generate a group' check box.
      ]

      sequence
    end

    def regional_param_modal_xpath
      "//div[@class='modal-dialog' and @role='document']"
    end

    def close_regional_param_modal
      find(:xpath, regional_param_modal_xpath).click_button("Close")
    end
  end
end
