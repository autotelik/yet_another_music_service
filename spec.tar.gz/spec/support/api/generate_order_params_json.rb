# Support generating a JSON BODY suitabel for Creating or Checkign Orders
#
#           include_context "generate_order_params_json"
#
RSpec.shared_context "generate_order_params_json" do

  let(:products_order_json_url) { "/api/products/#{product.id}/order_json?project_name=#{proj_PRODUCTION.name}" }

  before(:each) do
    # API disallows some actions when project == Project.default,
    # so we have to make the defautl different to the main project we are using for test
    allow(Project).to receive(:default) { proj_REGRESSION }

    # Product specifics
    create(:frontend, yaml_yn: true, status: Ordertype::STATUS_ACTIVE)

    # Complex to make this a factory or fixture as it needs Product Ids etc,
    # might be able to make more efficient using app/views/api/data_sets/order_json.jbuilder directly
    # but for now have to generate for real
    get products_order_json_url
    expect(response).to be_success

    @order_params = JSON.parse(response.body)
    @order_params_json = @order_params.to_json
  end

end
