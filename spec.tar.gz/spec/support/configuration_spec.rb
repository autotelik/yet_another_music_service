RSpec.configure do |config|
  config.render_views
  
  config.before(:each) do
    allow_any_instance_of(CanCan::ControllerResource).to receive(:authorize_resource){ true }
  end
end