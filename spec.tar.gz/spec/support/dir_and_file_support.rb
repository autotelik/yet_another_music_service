module WebMIS

  module TestHelpers

    # RSPEC RELATED PATHS

    def rspec_root
      @rspec_root ||= File.expand_path('../..', __FILE__)
    end

    def support_path
      File.join(rspec_root, 'support')
    end

    def factory_file_path
      File.join(rspec_root, 'factories', 'files')
    end

    def factory_file(name)
      File.join(factory_file_path, name)
    end

    def scratch_path
      File.join(support_path, 'scratch')
    end

    def scratch_file(name)
      File.join(scratch_path, name)
    end

    # Create a test area under the scratch directory.
    # Returns the full path to the new directory
    def create_scratch_path( dir_to_create )
      path = File.join(scratch_path, dir_to_create)
      FileUtils.mkdir_p(path) unless File.exist?(path)

      path
    end

    def scratch_path_clear( glob = nil )
      if glob
        begin FileUtils.rm_rf( File.join(scratch_path, glob) ); rescue; end
      else
        begin FileUtils.rm_rf(scratch_path); rescue; end

        FileUtils.mkdir_p(scratch_path) unless File.exist?(scratch_path)
      end
    end

    # we can't stub all file systems calls so add a dummy file to the test scratch area
    def add_dummy_files_to_scratch(path = scratch_path)
      FileUtils.touch( File.join(path, 'rspec_dummy_file.txt') )
    end

    def gen_timestamp(format = '%H%M%S%L')
      Time.zone.now.strftime(format)
    end
  end
end
