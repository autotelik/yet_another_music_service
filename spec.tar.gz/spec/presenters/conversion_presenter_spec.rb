require 'rails_helper'

describe ConversionPresenter do
  DISABLED = 'disabled'.freeze
  ENABLED = ''.freeze
  SET_PERSISTENT = 'Set persistent'.freeze
  UNSET_PERSISTENT = 'Unset persistent'.freeze
  SET_MARK_FOR_REMOVAL = 'Mark for removal'.freeze
  UNSET_MARK_FOR_REMOVAL = 'Unmark for removal'.freeze

  let(:presenter) { ConversionPresenter.new(conversion, {}, {}, {}) }

  context 'No end status' do
    let(:conversion) { instance_double('Conversion') }

    it 'returns false or disabled when conversion has not ended' do
      allow(conversion).to receive(:end_status?) { false }

      expect(presenter.allow_toggle_outcome_persistence?).to eq false

      expect(presenter.allow_toggle_mark_for_removal?).to eq false

      expect(presenter.toggle_outcome_persistence_css).to eq DISABLED

      expect(presenter.toggle_mark_for_removal_css).to eq DISABLED
    end
  end

  context 'End status, outcome_persistent_yn flag set' do
    # outcome_persistent_yn flag set means conversion does have conversion databases and all those conversion databases have file system status PERSISTENT
    let(:conversion) { instance_double('Conversion', outcome_persistent_yn: false) }

    before(:each) do
      allow(conversion).to receive(:end_status?) { true }
    end

    it 'enables unset persistent and disables mark for removal' do
      allow(conversion).to receive_message_chain(:conversion_databases, :available, :present?) { true }
      allow(conversion).to receive_message_chain(:conversion_databases, :where, :present?) { false }
      allow(conversion).to receive_message_chain(:conversion_databases, :marked_for_removal, :blank?) { true }
      expect(presenter.allow_toggle_outcome_persistence?).to eq true
      expect(presenter.set_outcome_persistence?).to eq true
      expect(presenter.toggle_outcome_persistence_label).to eq SET_PERSISTENT
      expect(presenter.toggle_outcome_persistence_css).to eq ENABLED

      expect(presenter.allow_toggle_mark_for_removal?).to eq false
      expect(presenter.mark_for_removal?).to eq true
      expect(presenter.toggle_mark_for_removal_label).to eq SET_MARK_FOR_REMOVAL
      expect(presenter.toggle_mark_for_removal_css).to eq DISABLED
    end
  end

  context 'End status, outcome_persistent_yn flag not set' do
    # assumption 1: outcome_persistent_yn flag set means that there are conversion databases with status PERSISTENT and
    # no databases with status AVAILABLE or MARK_FOR_REMOVAL
    let(:conversion) { instance_double('Conversion', outcome_persistent_yn: false) }

    before(:each) do
      allow(conversion).to receive(:end_status?) { true }
    end

    it 'has no databases' do
      allow(conversion).to receive_message_chain(:conversion_databases, :available, :present?) { false }
      allow(conversion).to receive_message_chain(:conversion_databases, :where, :present?) { false }
      allow(conversion).to receive_message_chain(:conversion_databases, :marked_for_removal, :blank?) { true }
      expect(presenter.allow_toggle_outcome_persistence?).to eq false
      expect(presenter.set_outcome_persistence?).to eq true
      expect(presenter.toggle_outcome_persistence_label).to eq SET_PERSISTENT
      expect(presenter.toggle_outcome_persistence_css).to eq DISABLED

      expect(presenter.allow_toggle_mark_for_removal?).to eq false
      expect(presenter.mark_for_removal?).to eq true
      expect(presenter.toggle_mark_for_removal_label).to eq SET_MARK_FOR_REMOVAL
      expect(presenter.toggle_mark_for_removal_css).to eq DISABLED
    end

    it 'has only databases with file system status REMOVED' do
      allow(conversion).to receive_message_chain(:conversion_databases, :available, :present?) { false }
      allow(conversion).to receive_message_chain(:conversion_databases, :where, :present?) { false }
      allow(conversion).to receive_message_chain(:conversion_databases, :marked_for_removal, :blank?) { true }
      expect(presenter.allow_toggle_outcome_persistence?).to eq false
      expect(presenter.set_outcome_persistence?).to eq true
      expect(presenter.toggle_outcome_persistence_label).to eq SET_PERSISTENT
      expect(presenter.toggle_outcome_persistence_css).to eq DISABLED

      expect(presenter.allow_toggle_mark_for_removal?).to eq false
      expect(presenter.mark_for_removal?).to eq true
      expect(presenter.toggle_mark_for_removal_label).to eq SET_MARK_FOR_REMOVAL
      expect(presenter.toggle_mark_for_removal_css).to eq DISABLED
    end

    it 'has only databases with file system status MARKED_FOR_REMOVAL' do
      allow(conversion).to receive_message_chain(:conversion_databases, :available, :present?) { false }
      allow(conversion).to receive_message_chain(:conversion_databases, :where, :present?) { true }
      allow(conversion).to receive_message_chain(:conversion_databases, :marked_for_removal, :blank?) { false }
      expect(presenter.allow_toggle_outcome_persistence?).to eq false
      expect(presenter.set_outcome_persistence?).to eq true
      expect(presenter.toggle_outcome_persistence_label).to eq SET_PERSISTENT
      expect(presenter.toggle_outcome_persistence_css).to eq DISABLED

      expect(presenter.allow_toggle_mark_for_removal?).to eq true
      expect(presenter.mark_for_removal?).to eq false
      expect(presenter.toggle_mark_for_removal_label).to eq UNSET_MARK_FOR_REMOVAL
      expect(presenter.toggle_mark_for_removal_css).to eq ENABLED
    end

    it 'has only databases with file system status AVAILABLE' do
      allow(conversion).to receive_message_chain(:conversion_databases, :available, :present?) { true }
      allow(conversion).to receive_message_chain(:conversion_databases, :where, :present?) { true }
      allow(conversion).to receive_message_chain(:conversion_databases, :marked_for_removal, :blank?) { true }
      expect(presenter.allow_toggle_outcome_persistence?).to eq true
      expect(presenter.set_outcome_persistence?).to eq true
      expect(presenter.toggle_outcome_persistence_label).to eq SET_PERSISTENT
      expect(presenter.toggle_outcome_persistence_css).to eq ENABLED

      expect(presenter.allow_toggle_mark_for_removal?).to eq true
      expect(presenter.mark_for_removal?).to eq true
      expect(presenter.toggle_mark_for_removal_label).to eq SET_MARK_FOR_REMOVAL
      expect(presenter.toggle_mark_for_removal_css).to eq ENABLED
    end

    it 'has databases with all four file system statuses' do
      allow(conversion).to receive_message_chain(:conversion_databases, :available, :present?) { true }
      allow(conversion).to receive_message_chain(:conversion_databases, :where, :present?) { true }
      allow(conversion).to receive_message_chain(:conversion_databases, :marked_for_removal, :blank?) { false }
      expect(presenter.allow_toggle_outcome_persistence?).to eq true
      expect(presenter.set_outcome_persistence?).to eq true
      expect(presenter.toggle_outcome_persistence_label).to eq SET_PERSISTENT
      expect(presenter.toggle_outcome_persistence_css).to eq ENABLED

      expect(presenter.allow_toggle_mark_for_removal?).to eq true
      expect(presenter.mark_for_removal?).to eq true
      expect(presenter.toggle_mark_for_removal_label).to eq SET_MARK_FOR_REMOVAL
      expect(presenter.toggle_mark_for_removal_css).to eq ENABLED
    end

    it 'has databases with file system statuses AVAILABLE, MARKED_FOR_REMOVAL and REMOVED' do
      allow(conversion).to receive_message_chain(:conversion_databases, :available, :present?) { true }
      allow(conversion).to receive_message_chain(:conversion_databases, :where, :present?) { true }
      allow(conversion).to receive_message_chain(:conversion_databases, :marked_for_removal, :blank?) { false }
      expect(presenter.allow_toggle_outcome_persistence?).to eq true
      expect(presenter.set_outcome_persistence?).to eq true
      expect(presenter.toggle_outcome_persistence_label).to eq SET_PERSISTENT
      expect(presenter.toggle_outcome_persistence_css).to eq ENABLED

      expect(presenter.allow_toggle_mark_for_removal?).to eq true
      expect(presenter.mark_for_removal?).to eq true
      expect(presenter.toggle_mark_for_removal_label).to eq SET_MARK_FOR_REMOVAL
      expect(presenter.toggle_mark_for_removal_css).to eq ENABLED
    end

    it 'has databases with file system statuses PERSISTENT, MARKED_FOR_REMOVAL and REMOVED' do
      allow(conversion).to receive_message_chain(:conversion_databases, :available, :present?) { true }
      allow(conversion).to receive_message_chain(:conversion_databases, :where, :present?) { true }
      allow(conversion).to receive_message_chain(:conversion_databases, :marked_for_removal, :blank?) { false }
      expect(presenter.allow_toggle_outcome_persistence?).to eq true
      expect(presenter.set_outcome_persistence?).to eq true
      expect(presenter.toggle_outcome_persistence_label).to eq SET_PERSISTENT
      expect(presenter.toggle_outcome_persistence_css).to eq ENABLED

      expect(presenter.allow_toggle_mark_for_removal?).to eq true
      expect(presenter.mark_for_removal?).to eq true
      expect(presenter.toggle_mark_for_removal_label).to eq SET_MARK_FOR_REMOVAL
      expect(presenter.toggle_mark_for_removal_css).to eq ENABLED
    end

    it 'has databases with file system statuses PERSISTENT, AVAILABLE and REMOVED' do
      allow(conversion).to receive_message_chain(:conversion_databases, :available, :present?) { true }
      allow(conversion).to receive_message_chain(:conversion_databases, :where, :present?) { true }
      allow(conversion).to receive_message_chain(:conversion_databases, :marked_for_removal, :blank?) { true }
      expect(presenter.allow_toggle_outcome_persistence?).to eq true
      expect(presenter.set_outcome_persistence?).to eq true
      expect(presenter.toggle_outcome_persistence_label).to eq SET_PERSISTENT
      expect(presenter.toggle_outcome_persistence_css).to eq ENABLED

      expect(presenter.allow_toggle_mark_for_removal?).to eq true
      expect(presenter.mark_for_removal?).to eq true
      expect(presenter.toggle_mark_for_removal_label).to eq SET_MARK_FOR_REMOVAL
      expect(presenter.toggle_mark_for_removal_css).to eq ENABLED
    end
  end
end
