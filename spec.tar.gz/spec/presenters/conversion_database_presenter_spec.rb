require 'rails_helper'

describe ConversionPresenter do

  let(:presenter) { ConversionDatabasePresenter.new(conversion_database, {}, {}, {}) }

  let(:conversion_database) { instance_double('ConversionDatabase') }

  it 'returns right label based on persistent file system status' do
    allow(conversion_database).to receive(:persistent?) { true }
    expect(presenter.toggle_persistence_label).to eq 'No longer persistent'

    allow(conversion_database).to receive(:persistent?) { false }
    expect(presenter.toggle_persistence_label).to eq 'Persistent'
  end

  it 'returns disabled when conversion database is marked for removal' do
    allow(conversion_database).to receive(:available?) { false }

    expect(presenter.toggle_mark_persistence_css).to eq 'disabled'
  end

  it 'returns false when it cannot move to mark for removal' do
    allow(conversion_database).to receive_message_chain(:conversion, :outcome_persistent_yn) { true }
    expect(presenter.allow_mark_for_removal?).to eq false

    allow(conversion_database).to receive_message_chain(:conversion, :end_status?) { false }
    expect(presenter.allow_mark_for_removal?).to eq false

    allow(conversion_database).to receive(:allow_file_system_status?) { false }
    expect(presenter.allow_mark_for_removal?).to eq false
  end

  it 'returns true when it can move to file system status available' do
    allow(conversion_database).to receive(:file_system_status) { ConversionDatabase::FILE_SYSTEM_STATUS_MARKED_FOR_REMOVAL }
    allow(conversion_database).to receive(:allow_file_system_status?) { true }

    expect(presenter.allow_unmark_for_removal?).to eq true
  end

  it 'returns true when it can move to file system status persistent' do
    allow(conversion_database).to receive(:file_system_status) { ConversionDatabase::FILE_SYSTEM_STATUS_AVAILABLE }
    allow(conversion_database).to receive(:allow_file_system_status?) { true }

    expect(presenter.allow_mark_persistent?).to eq true
  end

end
