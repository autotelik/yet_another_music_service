require 'rails_helper'

describe ConversionScriptPreparation do

  let(:rdo_path) {
    "/data/somewhere/nds/eur/o_2034-100000-eur_her_2034_q4_dvn951z0_bmw_20180118y/ROOT.NDS"
  }

  let(:item_list) {
    [
      ["parameter", "VersionName 101011713.1.00"],
      ["parameter", "VersionNumber  {{VersionName}}"]
    ]
  }

  let(:output_item_list) {
    [
      ["parameter", "VersionName 101011713.1.00"],
      ["parameter", "VersionNumber 101011713.1.00"]
    ]
  }

  it 'return the list with replaced parameters' do
    expect(ConversionScriptPreparation::replace_assigned_items(item_list, rdo_path)).to eq output_item_list
  end


  let(:item_list_unresolvable) {
    [
      ["parameter", "WhatsThis {{SomeVariable}}"]
    ]
  }

  let(:output_item_list_unresolvable) {
    [
      ["parameter", "WhatsThis {{SomeVariable}}"],
      ["#", ConversionScriptPreparation::WARNING_UNRESOLVABLE_ITEMS ]
    ]
  }

  it 'return the list with unresolvable parameters' do
    expect(ConversionScriptPreparation::replace_assigned_items(item_list_unresolvable, rdo_path)).to eq output_item_list_unresolvable
  end


  let(:item_list_arithmetic) {
    [
      ["parameter", "NrOfThings {{NrOfThings}} + 2"],
      ["parameter", "NrOfThings 1"],
      ["parameter", "NrOfThings {{NrOfThings}} + 5"],
      ["parameter", "NrOfThings {{NrOfThings}} - 8"]
    ]
  }

  let(:output_item_list_arithmetic) {
    [
      ["parameter", "NrOfThings 3"],
      ["parameter", "NrOfThings 1"],
      ["parameter", "NrOfThings 6"],
      ["parameter", "NrOfThings -7"]
    ]
  }

  it 'return the list with replaced parameters containing arithmetic' do
    expect(ConversionScriptPreparation::replace_assigned_items(item_list_arithmetic, rdo_path)).to eq output_item_list_arithmetic
  end


  let(:item_list_complex) {
    [
      ["parameter", "FinalVar {{Something}} + 5 * {{NrOfThings}}"],
      ["parameter", "Something  {{NrOfThings}} + 2 * 3"],
      ["parameter", "NrOfThings 2"]
    ]
  }

  let(:output_item_list_complex) {
    [
      ["parameter", "FinalVar 18"],
      ["parameter", "Something 8"],
      ["parameter", "NrOfThings 2"]
    ]
  }

  it 'return the list with replaced parameters complex' do
    expect(ConversionScriptPreparation::replace_assigned_items(item_list_complex, rdo_path)).to eq output_item_list_complex
  end


  let(:item_list_unresolvable2) {
    [
      ["parameter", "Something  {{NrOfThings}} + 2"],
      ["parameter", "NrOfThings {{Something}} - 3"]
    ]
  }

  let(:output_item_list_unresolvable2) {
    [
      ["parameter", "Something  {{NrOfThings}} + 2"],
      ["parameter", "NrOfThings {{Something}} - 3"],
      ["#", ConversionScriptPreparation::WARNING_UNRESOLVABLE_ITEMS ]
    ]
  }

  it 'return the list with unresolvable parameters (recursion)' do
    expect(ConversionScriptPreparation::replace_assigned_items(item_list_unresolvable2, rdo_path)).to eq output_item_list_unresolvable2
  end


  let(:item_list_text) {
    [
      ["parameter", "AnyPath  /data/somewhere"],
      ["parameter", "AnotherPath {{AnyPath}}/input"]
    ]
  }

  let(:output_item_list_text) {
    [
      ["parameter", "AnyPath  /data/somewhere"],
      ["parameter", "AnotherPath /data/somewhere/input"]
    ]
  }

  it 'return the list with replaced parameters text' do
    expect(ConversionScriptPreparation::replace_assigned_items(item_list_text, rdo_path)).to eq output_item_list_text
  end


  let(:item_list_ultimate) {
    [
      ["usepath", "/data/id/release/CVENV/ConvScripts_20180118"],
      ["use", "prod/nds/BMW_ENTRYNAVEVO_EB/BMW_NDS_MSP_EUR", ""],
      ["setenv", "NDS_NUMPROCS {{NDS_NUMPROCS}} - 1"],
      ["setenv", "NDS_NUMPROCS 2"],
      ["setenv", "NDS_NUMPROCS {{NDS_NUMPROCS}} + 7"],
      ["setenv", "TestParam {{TestParam}} + 1"],
      ["setenv", "NDS_PRE_DEMO {{BaseMap}}"],
      ["parameter", "NaviContentsDirectory", "\"/data/proces/app/wld/bmw/v3_0_eb_evo/sidedata/20170403_NaviContent_EB/\""],
      ["parameter", "SubScriptPath eur/her"],
      ["parameter", "VersionName 101011713.1.00"],
      ["parameter", "VersionNumber  {{VersionName}}"],
      ["parameter", "VersionNumber2 {{ VersionName  }}"],
      ["parameter", "BaseMap {{PredecessorMap}}"],
      ["parameter", "TheSum {{DHGC_NrOf_Clients}} + 5 - {{NDS_NUMPROCS}}"],
      ["parameter", "TheFinal   {{  TheSum}} - {{NDS_NUMPROCS}} * {{DHGC_NrOf_Clients}}"],
      ["parameter", "DHGC_NrOf_Clients 3 + {{NDS_NUMPROCS}}* 2"],
      ["parameter", "TestPath {{SubScriptPath}}/test"],
      ["parameter", "WhatsThis {{WhatsThis}} + 1"],
      ["parameter", "WhatsThat {{WheresThis}}"],
      ["parameter", "TestParam {{TestParam}} - 30"],
      ["parameter", "TestParam 100"],
      ["parameter", "TestParam {{TestParam}} + 20"],
      ["parameter", "JustAParam {{NaviContentsDirectory}}"]
    ]
  }

  let(:output_item_list_ultimate) {
    [
      ["usepath", "/data/id/release/CVENV/ConvScripts_20180118"],
      ["use", "prod/nds/BMW_ENTRYNAVEVO_EB/BMW_NDS_MSP_EUR", ""],
      ["setenv", "NDS_NUMPROCS 1"],
      ["setenv", "NDS_NUMPROCS 2"],
      ["setenv", "NDS_NUMPROCS 9"],
      ["setenv", "TestParam 121"],
      ["setenv", "NDS_PRE_DEMO /data/somewhere/nds/eur/o_2034-100000-eur_her_2034_q4_dvn951z0_bmw_20180118y/ROOT.NDS"],
      ["parameter", "NaviContentsDirectory", "\"/data/proces/app/wld/bmw/v3_0_eb_evo/sidedata/20170403_NaviContent_EB/\""],
      ["parameter", "SubScriptPath eur/her"],
      ["parameter", "VersionName 101011713.1.00"],
      ["parameter", "VersionNumber 101011713.1.00"],
      ["parameter", "VersionNumber2 101011713.1.00"],
      ["parameter", "BaseMap /data/somewhere/nds/eur/o_2034-100000-eur_her_2034_q4_dvn951z0_bmw_20180118y/ROOT.NDS"],
      ["parameter", "TheSum 17"],
      ["parameter", "TheFinal -172"],
      ["parameter", "DHGC_NrOf_Clients 21"],
      ["parameter", "TestPath eur/her/test"],
      ["parameter", "WhatsThis {{WhatsThis}} + 1"],
      ["parameter", "WhatsThat {{WheresThis}}"],
      ["parameter", "TestParam 70"],
      ["parameter", "TestParam 100"],
      ["parameter", "TestParam 120"],
      ["parameter", "JustAParam \"/data/proces/app/wld/bmw/v3_0_eb_evo/sidedata/20170403_NaviContent_EB/\""],
      ["#", ConversionScriptPreparation::WARNING_UNRESOLVABLE_ITEMS ]
    ]
  }

  it 'return the list with replaced parameters ultimate test' do
    expect(ConversionScriptPreparation::replace_assigned_items(item_list_ultimate, rdo_path)).to eq output_item_list_ultimate
  end
end
