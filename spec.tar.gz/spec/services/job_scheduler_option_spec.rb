require 'rails_helper'

describe JobSchedulerOption do
  # 2 projects to simulate servers owned by different projects
  let(:project1) { create(:proj_PRODUCTION) }
  let(:project2) { create(:proj_REGRESSION) }

  # 1 conversion, needed as condition for jobs which are allowed to run on a desktop
  let(:conversion) { create(:conversion, output_format: 'TMC') }

  # 4 servers, one empty, one which is not suitable for all kinds of reasons, one which is being used but still suitable and one which is actually a desktop machine
  let(:server) { create(:server_empty, :with_conversion_job_type, owned_by: project1) }
  let(:server_full) { create(:server_full, :with_conversion_job_type, :with_validation_job_type, :with_running_jobs, :with_failed_jobs, owned_by: project2) }
  let(:server_partly_full) { create(:server_partly_full, :with_conversion_job_type, :with_running_jobs, :with_failed_jobs, owned_by: project1) }
  let(:desktop) { create(:server_empty, :with_conversion_job_type, owned_by: project1, server_id: 'msdes_dummy') }

  # the job_sched_ops used in the test cases
  let(:job)                  { create(:cj_queued1,                                    project: project1) }
  let(:job_dummy)            { create(:cj_queued,                                     project: project1) }
  let(:job_queued_on_server) { create(:cj_queued2, run_server: server_full.server_id, project: project1) }
  let(:job_exclusive)        { create(:cj_queued3,                                    project: project1) }
  let(:job_desktop)          { create(:cj_queued, conversion: conversion,             project: project1) }
  let(:job_sched_op)                    { JobSchedulerOption.new(job_scheduler: JobScheduler.new(job),                  server: server)              }
  let(:job_sched_op_ignore)             { JobSchedulerOption.new(job_scheduler: JobScheduler.new(job),                  server: server)              }
  let(:job_sched_op_dummy)              { JobSchedulerOption.new(job_scheduler: JobScheduler.new(job_dummy),            server: server)              }
  let(:job_sched_op_full)               { JobSchedulerOption.new(job_scheduler: JobScheduler.new(job),                  server: server_full)         }
  let(:job_sched_op_partly_full)        { JobSchedulerOption.new(job_scheduler: JobScheduler.new(job),                  server: server_partly_full)  }
  let(:job_sched_op_on_server)          { JobSchedulerOption.new(job_scheduler: JobScheduler.new(job_queued_on_server), server: server_full)         }
  let(:job_sched_op_exclusive_empty)    { JobSchedulerOption.new(job_scheduler: JobScheduler.new(job_exclusive),        server: server)              }
  let(:job_sched_op_exclusive_occupied) { JobSchedulerOption.new(job_scheduler: JobScheduler.new(job_exclusive),        server: server_full)         }
  let(:job_sched_op_no_desktop)         { JobSchedulerOption.new(job_scheduler: JobScheduler.new(job),                  server: desktop)             }
  let(:job_sched_op_desktop)            { JobSchedulerOption.new(job_scheduler: JobScheduler.new(job_desktop),          server: desktop)             }
  let(:job_sched_op_desktop_on_server)  { JobSchedulerOption.new(job_scheduler: JobScheduler.new(job_desktop),          server: server)              }
  
  before do
    [job_sched_op, job_sched_op_ignore, job_sched_op_full, job_sched_op_partly_full, job_sched_op_on_server, job_sched_op_exclusive_empty, job_sched_op_exclusive_occupied,
     job_sched_op_no_desktop, job_sched_op_desktop, job_sched_op_desktop_on_server].each do |jso|
      jso.fill_jobs_on_server
      jso.fill_failed_and_finished_jobs
      # empty the scheduler_log so it is easier to test whether a testcase adds something to it
      jso.job_scheduler.scheduler_log = []
    end
    job_sched_op_ignore.ignore = true
  end

  it 'should have a valid initializer' do
    expect(job_sched_op.job_scheduler.class).to eq JobScheduler
    expect(job_sched_op.server).to eq server
    expect(job_sched_op.priority).to eq 0
    expect(job_sched_op.ignore).to be_falsey
  end

  context 'weight_server' do
    it 'should assign a priority to the job' do
      job_sched_op.weight_server
      expect(job_sched_op.priority).not_to eq 0
      expect(job_sched_op.ignore).to be_falsey
    end
  end

  context 'schedule_on_server' do
    it 'should return false and disable the server if the server check fails' do
      allow_any_instance_of(Server).to receive(:health_msg).and_return('Not healthy')
      expect(job_sched_op.schedule_on_server).to be_falsey
      expect(job_sched_op.ignore).to be_truthy
      server.reload
      expect(server.down).to be_truthy
      job.reload
      expect(job.run_server).to be_nil
    end

    it 'should return true and execute the job if the server check succeeds' do
      allow_any_instance_of(Server).to receive(:health_msg).and_return('')
      allow_any_instance_of(ConversionJob).to receive(:perform)
      expect(job_sched_op.schedule_on_server).to be_truthy
      expect(job_sched_op.ignore).to be_falsey
      server.reload
      expect(server.down).to be_falsey
      job.reload
      expect(job.run_server).not_to be_nil
    end
  end

  context 'fill_jobs_on_server' do
    it 'should work for an empty server' do
      # fill_jobs_on_server already run before each test case
      expect(job_sched_op.jobs_on_server).to be_empty
      job.update_attribute(:run_server, job_sched_op.server_id)
      job_sched_op_assigned = JobSchedulerOption.new(job_scheduler: JobScheduler.new(job), server: job_sched_op.server)
      job_sched_op_assigned.fill_jobs_on_server
      expect(job_sched_op_assigned.jobs_on_server).to be_empty
    end

    it 'should work for a non-empty server' do
      # fill_jobs_on_server already run before each test case
      expect(job_sched_op_full.jobs_on_server.count).to eq 3
      expect(job_sched_op_full.jobs_on_server.first).to be_a Job
      expect(job_sched_op_on_server.jobs_on_server.count).to eq 2
    end
  end

  context 'fill_failed_and_finished_jobs' do
    it 'should work for an empty server' do
      # fill_failed_and_finished_jobs already run before each test case
      expect(job_sched_op.failed_and_finished_jobs).to be_empty
    end

    it 'should work for a filled_server' do
      # fill_failed_and_finished_jobs already run before each test case
      expect(job_sched_op_full.failed_and_finished_jobs.count).to eq 3
      expect(job_sched_op_full.failed_and_finished_jobs.first).to be_a Job
    end
  end

  context 'check_job_load' do
    it 'should do nothing if the ignore flag is set' do
      job_sched_op_ignore.check_job_load
      expect(job_sched_op_ignore.ignore).to be_truthy
      expect(job_sched_op_ignore.job_scheduler.scheduler_log).to be_empty
    end

    it 'should properly handle the exclusive flag' do
      job_sched_op_exclusive_empty.check_job_load
      expect(job_sched_op_exclusive_empty.ignore).to be_falsey
      expect(job_sched_op_exclusive_empty.job_scheduler.scheduler_log).not_to be_empty
      expect(job_sched_op_exclusive_empty.priority).to be > 0

      job_sched_op_exclusive_occupied.check_job_load
      expect(job_sched_op_exclusive_occupied.ignore).to be_truthy
      expect(job_sched_op_exclusive_occupied.job_scheduler.scheduler_log).not_to be_empty
    end

    it 'should prioritize an empty server' do
      job_sched_op.check_job_load
      expect(job_sched_op.ignore).to be_falsey
      expect(job_sched_op.priority).to be >= 1000
      expect(job_sched_op.job_scheduler.scheduler_log).not_to be_empty
    end

    it 'should detect a fully filled server' do
      job_sched_op_full.check_job_load
      expect(job_sched_op_full.ignore).to be_truthy
      expect(job_sched_op_full.job_scheduler.scheduler_log).not_to be_empty
    end

    it 'should properly handle a partly filled server' do
      job_sched_op_partly_full.check_job_load
      expect(job_sched_op_partly_full.ignore).to be_falsey
      expect(job_sched_op_partly_full.priority).to be_between(0, 1000).exclusive
      expect(job_sched_op_partly_full.job_scheduler.scheduler_log).not_to be_empty
    end
  end

  context 'check_cores' do
    it 'should do nothing if the ignore flag is set' do
      job_sched_op_ignore.check_cores
      expect(job_sched_op_ignore.ignore).to be_truthy
      expect(job_sched_op_ignore.job_scheduler.scheduler_log).to be_empty
    end

    it 'should do nothing if the cores are not set for the job' do
      job_sched_op_dummy.check_cores
      expect(job_sched_op_dummy.ignore).to be_falsey
      expect(job_sched_op_dummy.job_scheduler.scheduler_log).to be_empty
      expect(job_sched_op_dummy.priority).to eq 0
    end

    it 'should not change the priority on an empty server' do
      job_sched_op.check_cores
      expect(job_sched_op.ignore).to be_falsey
      expect(job_sched_op.priority).to eq 0
      expect(job_sched_op.job_scheduler.scheduler_log).not_to be_empty
    end

    it 'should detect a full server' do
      job_sched_op_full.check_cores
      expect(job_sched_op_full.ignore).to be_truthy
      expect(job_sched_op_full.job_scheduler.scheduler_log).not_to be_empty
    end

    it 'should not change the priority on a partly filled server' do
      job_sched_op_partly_full.check_cores
      expect(job_sched_op_partly_full.ignore).to be_falsey
      expect(job_sched_op_partly_full.priority).to eq 0
      expect(job_sched_op_partly_full.job_scheduler.scheduler_log).not_to be_empty
    end
  end

  context 'check_memory' do
    it 'should do nothing if the ignore flag is set' do
      job_sched_op_ignore.check_memory
      expect(job_sched_op_ignore.ignore).to be_truthy
      expect(job_sched_op_ignore.job_scheduler.scheduler_log).to be_empty
    end

    it 'should do nothing if the memory is not set for the job' do
      job_sched_op_dummy.check_memory
      expect(job_sched_op_dummy.ignore).to be_falsey
      expect(job_sched_op_dummy.job_scheduler.scheduler_log).to be_empty
      expect(job_sched_op_dummy.priority).to eq 0
    end

    it 'should not change the priority on an empty server' do
      job_sched_op.check_memory
      expect(job_sched_op.ignore).to be_falsey
      expect(job_sched_op.priority).to eq 0
      expect(job_sched_op.job_scheduler.scheduler_log).not_to be_empty
    end

    it 'should detect a full server' do
      job_sched_op_full.check_memory
      expect(job_sched_op_full.ignore).to be_truthy
      expect(job_sched_op_full.job_scheduler.scheduler_log).not_to be_empty
    end

    it 'should not change the priority on a partly filled server' do
      job_sched_op_partly_full.check_memory
      expect(job_sched_op_partly_full.ignore).to be_falsey
      expect(job_sched_op_partly_full.priority).to eq 0
      expect(job_sched_op_partly_full.job_scheduler.scheduler_log).not_to be_empty
    end
  end

  context 'check_diskspace' do
    it 'should do nothing if the ignore flag is set' do
      job_sched_op_ignore.check_diskspace
      expect(job_sched_op_ignore.ignore).to be_truthy
      expect(job_sched_op_ignore.job_scheduler.scheduler_log).to be_empty
    end

    it 'should do nothing if the diskspace is not set for the job' do
      job_sched_op_dummy.check_diskspace
      expect(job_sched_op_dummy.ignore).to be_falsey
      expect(job_sched_op_dummy.job_scheduler.scheduler_log).to be_empty
      expect(job_sched_op_dummy.priority).to eq 0
    end

    it 'should not change the priority on an empty server' do
      job_sched_op.check_diskspace
      expect(job_sched_op.ignore).to be_falsey
      expect(job_sched_op.priority).to eq 0
      expect(job_sched_op.job_scheduler.scheduler_log).not_to be_empty
    end

    it 'should detect a full server' do
      job_sched_op_full.check_diskspace
      expect(job_sched_op_full.ignore).to be_truthy
      expect(job_sched_op_full.job_scheduler.scheduler_log).not_to be_empty
    end

    it 'should not change the priority on a partly filled server' do
      job_sched_op_partly_full.check_diskspace
      expect(job_sched_op_partly_full.ignore).to be_falsey
      expect(job_sched_op_partly_full.priority).to eq 0
      expect(job_sched_op_partly_full.job_scheduler.scheduler_log).not_to be_empty
    end
  end

  context 'weight_server_ownership' do
    it 'should do nothing if the ignore flag is set' do
      job_sched_op.job_scheduler.schedule_type = 'conversion_job_long'
      job_sched_op.ignore = true
      job_sched_op.weight_server_ownership
      expect(job_sched_op.ignore).to be_truthy
      expect(job_sched_op.job_scheduler.scheduler_log).to be_empty
    end

    it 'should do nothing if the server is not owned by project1' do
      job_sched_op.job_scheduler.schedule_type = 'conversion_job_long'
      job_sched_op_full.weight_server_ownership
      expect(job_sched_op_full.ignore).to be_falsey
      expect(job_sched_op_full.job_scheduler.scheduler_log).to be_empty
    end

    it 'should do nothing if the job_scheduler does not have the :conversion_job and :duration_long schedule_tags' do
      job_sched_op_full.weight_server_ownership
      expect(job_sched_op_full.ignore).to be_falsey
      expect(job_sched_op_full.job_scheduler.scheduler_log).to be_empty
    end

    it 'should increase the priority if the job_scheduler has the schedule_tags :conversion_job and :duration_long and the server is owned by project1' do
      job_sched_op.job_scheduler.schedule_type = 'conversion_job_long'
      job_sched_op.weight_server_ownership
      expect(job_sched_op.ignore).to be_falsey
      expect(job_sched_op.priority).to be > 0
      expect(job_sched_op.job_scheduler.scheduler_log).not_to be_empty
    end
  end

  context 'weight_server_flexibility' do
    it 'should do nothing if the ignore flag is set' do
      job_sched_op_ignore.weight_server_flexibility
      expect(job_sched_op_ignore.ignore).to be_truthy
      expect(job_sched_op_ignore.job_scheduler.scheduler_log).to be_empty
    end

    it 'should do nothing if the server can also handle other job types' do
      job_sched_op_full.weight_server_flexibility
      expect(job_sched_op_full.ignore).to be_falsey
      expect(job_sched_op_full.job_scheduler.scheduler_log).to be_empty
    end

    it 'should increase the priority if the server can only handle the current job type' do
      job_sched_op.weight_server_flexibility
      expect(job_sched_op.ignore).to be_falsey
      expect(job_sched_op.priority).to be > 0
      expect(job_sched_op.job_scheduler.scheduler_log).not_to be_empty
    end
  end

  context 'weight_desktop' do
    it 'should do nothing if the ignore flag is set' do
      job_sched_op_ignore.weight_desktop
      expect(job_sched_op_ignore.ignore).to be_truthy
      expect(job_sched_op_ignore.job_scheduler.scheduler_log).to be_empty
    end

    it 'should do nothing if the job_scheduler does not have the :desktop_allowed flag' do
      job_sched_op_no_desktop.weight_desktop
      expect(job_sched_op_no_desktop.ignore).to be_falsey
      expect(job_sched_op_no_desktop.priority).to eq 0
      expect(job_sched_op_no_desktop.job_scheduler.scheduler_log).to be_empty
    end

    it 'should do nothing if the server is not a desktop' do
      job_sched_op_desktop_on_server.weight_desktop
      expect(job_sched_op_desktop_on_server.ignore).to be_falsey
      expect(job_sched_op_desktop_on_server.priority).to eq 0
      expect(job_sched_op_desktop_on_server.job_scheduler.scheduler_log).to be_empty
    end

    it 'should increase the priority if the desktop_allowed scheduler_flag is set and the server is a desktop' do
      job_sched_op_desktop.weight_desktop
      expect(job_sched_op_desktop.ignore).to be_falsey
      expect(job_sched_op_desktop.priority).to be > 0
      expect(job_sched_op_desktop.job_scheduler.scheduler_log).not_to be_empty
    end
  end
end