require 'rails_helper'

describe JobScheduler do
  it 'should work in an empty environment' do
    expect { JobScheduler.schedule }.not_to raise_error

    # note that the user_create_production_order_spec feature testcase already tests the scheduler when there is something to schedule
  end
  context 'initializer' do
    let(:project) { create(:proj_PRODUCTION) }
    let(:conversion) { create(:conversion, output_format: 'TMC') }
    let(:cj_dummy)   { create(:cj_DUMMY,           project: project) }
    let(:cj_queued)  { create(:cj_queued,          project: project) }
    let(:cj_queued1) { create(:cj_queued1,         project: project, conversion: conversion) }
    let(:cj_queued2) { create(:cj_queued2,         project: project) }
    let(:cj_queued3) { create(:cj_queued3,         project: project) }
    let(:cj_queued4) { create(:cj_schedule_manual, project: project, conversion: conversion) }
    let(:vj_default) { create(:vj_DEFAULT,         project: project) }
    let(:sj_default) { create(:shipping_job) }
    let(:pj_default) { create(:packing_job) }

    let(:cs_dummy)   { JobScheduler.new(cj_dummy)   }
    let(:cs_queued)  { JobScheduler.new(cj_queued)  }
    let(:cs_queued1) { JobScheduler.new(cj_queued1) }
    let(:cs_queued2) { JobScheduler.new(cj_queued2) }
    let(:cs_queued3) { JobScheduler.new(cj_queued3) }
    let(:cs_queued4) { JobScheduler.new(cj_queued4) }
    let(:vs_default) { JobScheduler.new(vj_default) }
    let(:ss_default) { JobScheduler.new(sj_default) }
    let(:ps_default) { JobScheduler.new(pj_default) }

    it 'should initialize the schedule flags correctly' do
      expect(cs_dummy.conversion_job?).to be_truthy
      expect(cs_dummy.validation_job?).to be_falsey
      expect(cs_dummy.packing_job?).to be_falsey
      expect(cs_dummy.shipping_job?).to be_falsey
      expect(cs_dummy.duration_short?).to be_falsey
      expect(cs_dummy.duration_long?).to be_falsey
      expect(cs_dummy.duration_unknown?).to be_truthy
      expect(cs_dummy.run_exclusively?).to be_falsey
      expect(cs_dummy.reserve_server?).to be_falsey
      expect(cs_dummy.virtual_server_allowed?).to be_falsey
      expect(cs_dummy.schedule_manual?).to be_falsey
      expect(cs_dummy.desktop_allowed?).to be_falsey
      expect(cs_dummy.schedule_tags).to match_array %i[conversion_job duration_unknown]
      expect(cs_queued.schedule_tags).to match_array %i[conversion_job duration_unknown]
      expect(cs_queued1.schedule_tags).to match_array %i[conversion_job duration_long virtual_server_allowed desktop_allowed]
      expect(cs_queued2.schedule_tags).to match_array %i[conversion_job duration_short]
      expect(cs_queued3.schedule_tags).to match_array %i[conversion_job duration_unknown run_exclusively reserve_server]
      expect(cs_queued4.schedule_tags).to match_array %i[conversion_job duration_unknown schedule_manual desktop_allowed]
      expect(vs_default.schedule_tags).to match_array %i[validation_job duration_unknown]
      expect(ss_default.schedule_tags).to match_array %i[shipping_job duration_unknown]
      expect(ps_default.schedule_tags).to match_array %i[packing_job duration_unknown]
    end
  end

  context 'schedule' do
    let(:project) { create(:proj_PRODUCTION) }

    let!(:job1) { create(:cj_queued1, project: project) }
    let!(:job2) { create(:cj_queued2, project: project) }

    let!(:server1) { create(:server_empty, :with_project_server, :with_conversion_job_type, owned_by: project) }
    let!(:server2) { create(:server_partly_full, :with_project_server, :with_conversion_job_type, owned_by: project) }

    it 'should put the jobs on the servers' do
      allow_any_instance_of(Server).to receive(:health_msg).and_return('')
      allow_any_instance_of(ConversionJob).to receive(:perform)
      JobScheduler.schedule
      job1.reload
      job2.reload
      # note that job1 has the longest estimated duration so it should be scheduled first, selecting the first free server, server1,
      # job2 is then scheduled on the remaining free server, server2
      expect(job1.run_server).to eq server1.server_id
      expect(job2.run_server).to eq server2.server_id
    end
  end

  context 'auto_schedule' do
    let(:project)             { create(:proj_PRODUCTION) }
    let(:job)                 { create(:cj_queued,           project: project) }
    let(:job_planned)         { create(:cj_planned,          project: project) }
    let(:job_schedule_manual) { create(:cj_schedule_manual,  project: project) }
    let(:job_hold)            { create(:cj_hold,             project: project) }
    let!(:server) { create(:server_empty, :with_project_server, :with_conversion_job_type, owned_by: project) }

    it 'should do nothing if the job is not queued' do
      job_scheduler = JobScheduler.new(job_planned)
      job_scheduler.auto_schedule
      expect(job_planned.changed?).to be_falsey
    end

    it 'should set a job with the manual flag to status MANUAL' do
      job_scheduler = JobScheduler.new(job_schedule_manual)
      job_scheduler.auto_schedule
      job_schedule_manual.reload
      expect(job_schedule_manual.status).to eq Job::STATUS_MANUAL
    end

    it 'should set a job with no servers it could potentially run on to HOLD' do
      job.update_attribute(:schedule_cores, 10)
      job_scheduler = JobScheduler.new(job)
      job_scheduler.auto_schedule
      job.reload
      expect(job.status).to eq Job::STATUS_HOLD
    end

    it 'should schedule a job on an available server' do
      # stub the check on the server health and the actual invocation of the job on the server. As the perform method also takes care of the Job's status
      # we can't check whether the Job has status 'PROCESSING' here. Instead we just check whether the run_server has been set.
      allow_any_instance_of(Server).to receive(:health_msg).and_return('')
      allow_any_instance_of(ConversionJob).to receive(:perform)
      server.update_attribute(:down, true)
      create(:server_inactive, :with_project_server, :with_conversion_job_type, owned_by: project)
      server3 = create(:server_partly_full, :with_project_server, :with_conversion_job_type, owned_by: project)
      job_scheduler = JobScheduler.new(job)
      job_scheduler.auto_schedule
      job.reload
      expect(job.run_server).to eq server3.server_id
    end

    it 'should put a job on queued if all available servers are busy' do
      allow_any_instance_of(Server).to receive(:health_msg).and_return('Server down')
      job_scheduler = JobScheduler.new(job_hold)
      job_scheduler.auto_schedule
      job_hold.reload
      expect(job_hold.status).to eq Job::STATUS_QUEUED
    end
  end

  context 'private method scheduler_queue' do
    let(:project) { create(:proj_PRODUCTION) }
    let(:reg_project) { create(:proj_REGRESSION) }
    let!(:job1) { create(:cj_queued,      status: Job::STATUS_QUEUED,  reference_id: 100, project: project,     estimated_duration: 100) }
    let!(:job2) { create(:cj_queued,      status: Job::STATUS_QUEUED,  reference_id: 100, project: reg_project, estimated_duration: 100) }
    let!(:job3) { create(:cj_queued,      status: Job::STATUS_HOLD,    reference_id: 100, project: project,     estimated_duration: 200) }
    let!(:job4) { create(:cj_queued,      status: Job::STATUS_QUEUED,  reference_id: 100, project: reg_project, estimated_duration: 200) }
    let!(:job5) { create(:cj_queued,      status: Job::STATUS_QUEUED,  reference_id: 101, project: project,     estimated_duration: 100) }
    let!(:job6) { create(:cj_queued,      status: Job::STATUS_HOLD,    reference_id: 101, project: reg_project, estimated_duration: 200) }
    let!(:job7) { create(:validation_job, status: Job::STATUS_QUEUED,  reference_id: 100, project: project,     estimated_duration: 0)   }
    let!(:job8) { create(:validation_job, status: Job::STATUS_QUEUED,  reference_id: 100, project: project,     estimated_duration: 200) }
    let!(:job9) { create(:cj_queued,      status: Job::STATUS_PLANNED, reference_id: 100, project: project,     estimated_duration: 100) }

    it 'should create an ordered list of scheduler_options from the jobs' do
      server_list = JobScheduler.scheduler_queue
      expect(server_list.count).to eq 8
      expect(server_list.first.class).to eq JobScheduler
      expect(server_list.collect(&:job)).to match_array [job3, job1, job5, job8, job7, job4, job2, job6]
    end
  end

  context 'private method potential servers' do
    let(:project) { create(:proj_PRODUCTION) }
    let(:reg_project) { create(:proj_REGRESSION) }
    let(:conversion) { create(:conversion, output_format: 'TMC') }
    let(:job) { create(:cj_queued, project: project) }
    let(:job_sched) { JobScheduler.new(job) }
    let(:job_tmc) { create(:cj_queued, project: project, conversion: conversion) }
    let(:job_sched_desktop) { JobScheduler.new(job_tmc) }

    it 'should not find potential servers when the Server list is empty' do
      expect(job_sched.potential_servers).to be_empty
    end

    context 'with a filled server list' do
      let!(:server_dummy)         { create(:server_dummy,    :with_project_server, :with_conversion_job_type, owned_by: project) }
      let!(:server_diskcapacity)  { create(:server_dummy,    :with_project_server, :with_conversion_job_type, owned_by: project,     server_id: 'server_diskcapacity',  diskcapacity: 4) }
      let!(:server_jobs)          { create(:server_dummy,    :with_project_server, :with_conversion_job_type, owned_by: project,     server_id: 'server_jobs',          max_jobs: 2) }
      let!(:server_cores)         { create(:server_dummy,    :with_project_server, :with_conversion_job_type, owned_by: project,     server_id: 'server_cores',         cores: 4) }
      let!(:server_memory)        { create(:server_dummy,    :with_project_server, :with_conversion_job_type, owned_by: project,     server_id: 'server_memory',        memory: 4) }
      let!(:server_all)           { create(:server_empty,    :with_project_server, :with_all_job_types,       owned_by: project) }
      let!(:server_small)         { create(:server_small,    :with_project_server, :with_conversion_job_type, owned_by: project) }
      let!(:server_diff_type)     { create(:server_empty,    :with_project_server, :with_validation_job_type, owned_by: project,     server_id: 'server_diff_type') }
      let!(:server_type_disabled) { create(:server_empty,    :with_project_server, :with_conversion_job_type, owned_by: project,     server_id: 'server_type_disabled', allowed_yn: false) }
      let!(:server_virtual)       { create(:server_empty,    :with_project_server, :with_conversion_job_type, owned_by: project,     server_id: 'server_virtual',       virtual_host: 'x') }
      let!(:server_inactive)      { create(:server_inactive, :with_project_server, :with_conversion_job_type, owned_by: project) }
      let!(:server_down)          { create(:server_down,     :with_project_server, :with_conversion_job_type, owned_by: project) }
      let!(:server_diff_project)  { create(:server_empty,    :with_project_server, :with_conversion_job_type, owned_by: reg_project) }
      let!(:server_included)      { create(:server_empty,    :with_project_server, :with_conversion_job_type, owned_by: reg_project, server_id: 'server_included', other_projects: [project]) }
      let!(:desktop_dummy)        { create(:server_dummy,    :with_project_server, :with_conversion_job_type, owned_by: project,     server_id: 'msdes_dummy') }

      it 'should not restrict on disk capacity, cores, max_jobs, cores, memory or virtual_host if the job does not specify it' do
        server_list = job_sched.potential_servers.collect{ |jso| jso.server.server_id }
        expect(server_list).to match_array %w[server_dummy server_diskcapacity server_jobs server_cores server_memory server_empty server_small server_down server_included]
      end

      it 'should restrict on disk capacity if the job has a positive disk space' do
        job_sched.diskspace = 3
        server_list = job_sched.potential_servers.collect{ |jso| jso.server.server_id }
        expect(server_list).to match_array %w[server_diskcapacity server_empty server_down server_included]
      end

      it 'should restrict on cores if the job has a positive number of cores specified' do
        job_sched.cores = 3
        server_list = job_sched.potential_servers.collect{ |jso| jso.server.server_id }
        expect(server_list).to match_array %w[server_cores server_empty server_down server_included]
      end

      it 'should restrict on memory' do
        job_sched.memory = 3
        server_list = job_sched.potential_servers.collect{ |jso| jso.server.server_id }
        expect(server_list).to match_array %w[server_memory server_empty server_down server_included]
      end

      it 'should be able to restrict on virtual machines' do
        job_sched.schedule_tags << :virtual_server_allowed
        server_list = job_sched.potential_servers.collect{ |jso| jso.server.server_id }
        expect(server_list).to match_array %w[server_dummy server_diskcapacity server_jobs server_cores server_memory server_empty server_small server_down server_virtual server_included]
      end

      it 'should be able to include desktops' do
        server_list = job_sched_desktop.potential_servers.collect{ |jso| jso.server.server_id }
        expect(server_list).to match_array %w[server_dummy server_diskcapacity server_jobs server_cores server_memory server_empty server_small server_down server_included msdes_dummy]
      end

      it 'should not change the order for now' do
        server_list = job_sched.potential_servers
        expect(server_list.first.server.id).to eq Server.active.first.id
      end
    end
  end

  context 'private delegated job method' do
    let(:project) { create(:proj_PRODUCTION) }
    let(:job) { create(:conversion_job, project: project) }
    let(:job_assigned) { create(:conversion_job, project: project, run_server: 'x') }
    let(:job_sched) { JobScheduler.new(job) }
    let(:job_assigned_sched) { JobScheduler.new(job_assigned) }

    it 'update_queued_status should update the job status as if done through the job.change_status method' do
      # a successful status change
      job_sched.update_queued_status(Job::STATUS_CANCELLED)
      job.reload
      expect(job.status).to eq Job::STATUS_CANCELLED

      # a failed status change
      job_sched.update_queued_status(Job::STATUS_QUEUED)
      job.reload
      expect(job.status).to eq Job::STATUS_CANCELLED
    end

    it 'run_server? should indicate whether run_server is set' do
      expect(job_sched.run_server?).to be_falsey
      expect(job_assigned_sched.run_server?).to be_truthy
    end

    it 'should set and update the job scheduler_log' do
      job_sched.scheduler_log = %w[Line1 Line2]
      expect(job.scheduler_log).to eq('')
      job_sched.update_job_scheduler_log
      expect(job.scheduler_log).to include 'Line1'
      expect(job.scheduler_log).to include 'Line2'

      job_sched.scheduler_log = %w[Line3]
      job_sched.update_job_scheduler_log
      expect(job.scheduler_log).to include 'Line3'
      expect(job.scheduler_log).not_to include 'Line1'
    end

    it 'should save its job when saving' do
      job_sched.scheduler_log = %w[Line1]
      job_sched.job.status = Job::STATUS_SKIPPED
      expect(job_sched.save).to be_truthy
      job.reload
      expect(job.status).to eq Job::STATUS_SKIPPED
      expect(job.scheduler_log).to include 'Line1'

      job_sched.scheduler_log = %w[Line2]
      job_sched.job.status = Job::STATUS_CANCELLED
      job_sched.save!
      job.reload
      expect(job.status).to eq Job::STATUS_CANCELLED
      expect(job.scheduler_log).to include 'Line2'
    end
  end
end