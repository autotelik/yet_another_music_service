require 'rails_helper'

describe ReleaseNormalizer do

  context 'Start' do
    let!(:dr_1) { DataRelease.create(name: "5.1", release_code: "5_1",  active: true,  production: true, created_at: 3.days.ago) }
    let!(:dr_2) { DataRelease.create(name: "5.1", release_code: "5_1",  active: false,  production: true,  created_at: 2.days.ago) }
    let!(:dr_3) { DataRelease.create(name: "5.1", release_code: "5_1",  active: true,  production: true,  created_at: 1.days.ago) }


    it 'leaves a single active Release, multiple deletion candidates' do
      ReleaseNormalizer.normalise({})

      [dr_1, dr_2, dr_3].map(&:reload)

      expect(dr_1.active).to be_true
      expect(dr_1.deletion_candidate).to be_falsey

      expect(dr_2.active).to be_falsey
      expect(dr_2.deletion_candidate).to be_true

      expect(dr_3.active).to be_falsey
      expect(dr_3.deletion_candidate).to be_true
    end
  end

  context 'Middle' do
    let!(:dr_1) { DataRelease.create(name: "5.1", release_code: "5_1",  active: false, production: false, created_at: 3.days.ago) }
    let!(:dr_2) { DataRelease.create(name: "5.1", release_code: "5_1",  active: true,  production: true,  created_at: 2.days.ago) }
    let!(:dr_3) { DataRelease.create(name: "5.1", release_code: "5_1",  active: true,  production: true,  created_at: 1.days.ago) }

    it 'leaves a single active Release, multiple deletion candidates' do
      ReleaseNormalizer.normalise({})

      [dr_1, dr_2, dr_3].map(&:reload)

      expect(dr_1.active).to be_falsey
      expect(dr_1.deletion_candidate).to be_true

      expect(dr_2.active).to be_true
      expect(dr_2.deletion_candidate).to be_falsey

      expect(dr_3.active).to be_falsey
      expect(dr_3.deletion_candidate).to be_true
    end
  end


  context 'End' do
    let!(:dr_1) { DataRelease.create(name: "5.1", release_code: "5_1",  active: false, production: false,  created_at: 3.days.ago) }
    let!(:dr_2) { DataRelease.create(name: "5.1", release_code: "5_1",  active: false,  production: false,  created_at: 2.days.ago) }
    let!(:dr_3) { DataRelease.create(name: "5.1", release_code: "5_1",  active: true,  production: true,   created_at: 1.days.ago) }

    it 'leaves a single active Release, multiple deletion candidates' do
      ReleaseNormalizer.normalise({})

      [dr_1, dr_2, dr_3].map(&:reload)

      expect(dr_1.active).to be_falsey
      expect(dr_1.deletion_candidate).to be_true

      expect(dr_2.active).to be_falsey
      expect(dr_2.deletion_candidate).to be_true

      expect(dr_3.active).to be_true
      expect(dr_3.deletion_candidate).to be_falsey
    end
  end




end
