require 'rails_helper'

describe FindUnwantedPaths do

  let(:server_id) { "msdes220" }

  let(:reserved_examples) {
    [
      "drwxrwxrwx 7 backoffice_test conversion 4096 May 19  2017 w_20170519-100312-313563-nar_tom_2016_12_20170515b_mnr_cnt/",
      "drwxrwxrwx 7 backoffice_test conversion 4096 May 19  2017 w_20170519-100313-313564-nar_tom_2016_12_20170515b_mnr_cyt/",
      "drwxrwxrwx 7 backoffice_test conversion 4096 May 19  2017 w_20170519-100909-313565-nar_tom_2016_12_20170516b_mnr_cnt/",
      "drwxrwxrwx 7 backoffice_test conversion 4096 May 19  2017 w_20170519-100910-313566-nar_tom_2016_12_20170516b_mnr_cyt/",
    ]
  }
  let(:unwanted_examples) {
    [
      "drwxr-xr-x 2 backoffice_test conversion 4096 Dec 29 15:28 o_20171229-152411-412888-eur_tom_2016_12_20171229b_mnr_nor_dryrun/",
      "drwxr-xr-x 2 backoffice_test conversion 4096 Dec 29 15:56 o_20171229-155210-412901-eur_tom_2016_12_20171229b_mnr_ukr_dryrun/",
      "drwxr-xr-x 2 backoffice_test conversion 4096 Dec 29 15:58 o_20171229-155408-412873-eur_tom_2016_12_20171229b_mnr_hun_dryrun/",
      "drwxr-xr-x 2 backoffice_test conversion 4096 Dec 29 16:02 o_20171229-155809-412884-eur_tom_2016_12_20171229b_mnr_mkd_dryrun/",
      "drwxr-xr-x 2 backoffice_test conversion 4096 Dec 29 16:14 o_20171229-161009-412871-eur_tom_2016_12_20171229b_mnr_grl_dryrun/",
      "dr-xr-xr-x 2 backoffice_test conversion 4096 Dec 29 15:29 w_20171229-152411-412888-eur_tom_2016_12_20171229b_mnr_nor_dryrun/",
      "drwxrwxrwx 4 backoffice_test conversion 4096 Dec 29 15:57 w_20171229-155210-412901-eur_tom_2016_12_20171229b_mnr_ukr_dryrun/",
      "dr-xr-xr-x 2 backoffice_test conversion 4096 Dec 29 15:59 w_20171229-155408-412873-eur_tom_2016_12_20171229b_mnr_hun_dryrun/",
      "dr-xr-xr-x 2 backoffice_test conversion 4096 Dec 29 16:03 w_20171229-155809-412884-eur_tom_2016_12_20171229b_mnr_mkd_dryrun/",
      "dr-xr-xr-x 4 backoffice_test conversion 4096 Dec 29 16:15 w_20171229-161009-412871-eur_tom_2016_12_20171229b_mnr_grl_dryrun/"
    ]
  }

  let(:ls_output) { unwanted_examples + reserved_examples }

  it 'returns the details of server paths' do
    details = FindUnwantedPaths.call(server_id, ls_output)
    expect(details).to be_a FindUnwantedPaths::ServerPathDetails
  end

  it 'indicates if any unwanted details found among server paths' do
    expect(FindUnwantedPaths.call(server_id, ls_output).found?).to eq true
    expect(FindUnwantedPaths.call(server_id, reserved_examples).found?).to eq true
    expect(FindUnwantedPaths.call(server_id, unwanted_examples).found?).to eq true
  end

  it 'returns false when no unwanted details found among server paths' do
    details = FindUnwantedPaths.call(server_id, [])
    expect(details.found?).to eq false
  end

  it 'returns details of reserved dirs based on world read, filename starts "w", and no opposing "o"' do
    details = FindUnwantedPaths.call(server_id, ls_output)
    expect(details.reserved_dirs.size).to eq 4
  end

  it 'returns details of unwanted dirs based on not being reserved' do
    details = FindUnwantedPaths.call(server_id, ls_output)
    expect(details.unwanted_dirs.size).to eq ls_output.size - 4
  end

end
