require 'rails_helper'

describe 'Production Orders' do

  include_context "authorization"  do
    let(:controllers) { [ProductionOrdersController] }
  end

  let(:production_order) { create(:production_order) }

  it 'allows the Shipping Specification to be edited' do
    get edit_shipping_specification_production_order_url(production_order)

    expect(response).to render_template(:edit_shipping_specification)
  end

  it 'disallows and sets flash error on edit Shipping Specification when in End State' do
    allow_any_instance_of(ProductionOrder).to receive(:end_status?) { true }

    get edit_shipping_specification_production_order_url(production_order)

    expect(flash[:error]).to match 'ProductionOrder in End State - Cannot edit Shipping Specification.'
  end

  it 'updates the Shipping Specification' do
    expect(production_order.shipping_specification).to be_nil

    ss = create(:shipping_specification)

    params = { production_order: {'shipping_specification_id': ss.id } }

    patch update_shipping_specification_production_order_url(production_order), params

    expect(flash[:notice]).to match 'ProductionOrder Shipping Specification was successfully updated.'
    expect(production_order.reload.shipping_specification).to eq ss
  end

end