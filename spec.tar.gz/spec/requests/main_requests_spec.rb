require 'rails_helper'

describe 'Main Controller Requests' do

  context "Change Project" do

    include_context "authorization"  do
      let(:controllers) { [MainController, SetToolHandoversController] }
    end

    let(:no_index_url)        { "http://localhost:3000/webmis/set_tool_handovers/123" }
    let(:index_url)           { "http://localhost:3000/webmis/data_sets/123" }
    let(:alternative_project) { create(:proj_REGRESSION) }

    before(:each) do
      allow_any_instance_of(Project).to receive(:project_member?) { true }
    end

    it 'shows suitable flash error when no Project supplied' do
      allow_any_instance_of(ActionDispatch::Request).to receive(:referrer) { no_index_url }
      get '/webmis/main/change_project/', {}

      expect(flash[:error]).to match "No project submitted."
      expect(response).to redirect_to('http://www.example.com/webmis')
    end

    it 'redirects current Controller index page' do
      allow_any_instance_of(ActionDispatch::Request).to receive(:referrer) { index_url }
      get '/webmis/main/change_project/', { project_id: alternative_project.id }

      expect(assigns(:target_controller)).to eq "data_sets"
      expect(flash[:notice]).to match "Project successfully changed to #{alternative_project.name}."

      expect(response).to redirect_to('http://www.example.com/webmis/data_sets')
    end

    it 'redirects to home when current Controller has no index page' do
      allow_any_instance_of(ActionDispatch::Request).to receive(:referrer) { no_index_url }
      get '/webmis/main/change_project/', { project_id: alternative_project.id }

      expect(assigns(:target_controller)).to eq "set_tool_handovers"
      expect(flash[:notice]).to match "Project successfully changed to #{alternative_project.name}."

      expect(response).to redirect_to('http://www.example.com/webmis')
    end
    
  end
end
