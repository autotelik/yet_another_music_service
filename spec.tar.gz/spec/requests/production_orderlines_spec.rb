require 'rails_helper'

describe 'ProductionOrderLines' do

  include_context "authorization"  do
    let(:controllers) { [ProductionOrderlinesController] }
  end

  include_context 'cancan_prerequisites'

  # stubs out the very low level stuff, like creating dakota scripts
  include_context "production_order_scheduling_stubs"

  before do
    allow_any_instance_of(Conversion).to receive(:create_dakota_scripts) { [] }
  end

  context "Create and Update" do
    include_context "create_production_order_prerequisites"

    # The steps are driven by  conversion_design.parsed_design
    #
    # N.B THIS parameter set MIMICS - check_automatic_conversion: true
    #
    let(:parameters) do {
      "handle_conversion_action"=>"",
      "production_orderline"=>{"product_id"=>"", "volume_id"=>"", "ship_yn"=>"0", "rdo_path"=>"", "parameter_set_id"=>"", "test_yn"=>"1"},
      "data_set_id"=>"#{data_set.id}", "data_set_group_id"=>"", "ordertype"=>"#{ordertype_ds.id}", "order_name"=>"FE LTEF2DH TOM 2017.03 EUR TMC",
      "check_automatic_conversion"=>"1", "coverage_regions"=>"", "parameters"=>"",
      "conversion_design_id"=>"#{conv_design_single_step.id}",
      "conversiontool"=>{"0"=>"#{conversion_tool.id}"},
      "cvtool_bundle"=>{"0"=>"#{cvtool_bundle.id}"},
      "conv_script"=>{"0"=>"#{conv_script.id}"},
      "conversion_environment"=>{"0"=>"#{conversion_environment.id}"},
      "commit"=>"Save"
    }
    end

    let(:conv_design_single_step) { create(:conversion_design_single_step) }

    context "#update with check_automatic_conversion" do

      include_context "stub_objects_write_to_stdout"

      let!(:production_orderline) { create(:production_orderline) }

      let(:check_order_url) { "/webmis/production_orderlines/#{production_orderline.id}" }

      it 'checks the design and parameters for update of a ProductionOrder' do
        expect {
          patch check_order_url, parameters
        }.to change(ProductionOrderline, :count).by(0).and change(Conversion, :count).by(0)
        expect(assigns(:checklog).full_output).to be_present
        expect(assigns(:checklog).ok?).to be_truthy
      end
    end

    context "#create with check_automatic_conversion" do

      it 'writes a ParseError to checklog when no valid conversion object (data_set) provided' do
        parameters["data_set_id"] = nil

        expect {
          post '/webmis/production_orderlines', parameters
        }.to change(ProductionOrderline, :count).by(0)

        expect(assigns(:checklog).result).to eq "Exception"
        expect(assigns(:checklog).ok?).to_not be_truthy

        # odd in this context, Checklog::to_s produces empty string & doesn't seem to actually reach the to_s method
        expect(assigns(:checklog).full_output).to include "Unsupported conversion class NilClass"
      end

      it 'writes a ParseError to checklog when ID of association supplied but not valid' do
        missing_id = ConvScript.maximum(:id).next

        # Comes from GUI dropdown hence hash with key == dropdown position
        parameters["conv_script"] = {"0": "#{missing_id}"}

        # Post a complete OrderParameters definition, as JSON in the body
        expect {
          post '/webmis/production_orderlines', parameters
        }.to change(ProductionOrderline, :count).by(0)

        expect(assigns(:checklog).result).to eq "Exception"

        # odd in this context, Checklog::to_s produces empty string & doesn't seem to actually reach the to_s method
        expect(assigns(:checklog).full_output).to include "Failed to set conv_script on Step to value [#{missing_id}]"
      end

      it 'checks a single ProductionOrderline from full OrderParameters and rolls back' do
        expect {
          post '/webmis/production_orderlines', parameters
        }.to change(ProductionOrderline, :count).by(0)

        expect(assigns(:checklog).ok?).to be_truthy
      end

      it 'handles empty associations in OrderParameters, checks ProductionOrderline and rolls back' do

        # Deep in process creates a Conversion and assigns various defaults for the missing associations
        # just stub these here
        allow_any_instance_of(Conversion).to receive(:conversiontool)         { conversion_tool }
        allow_any_instance_of(Conversion).to receive(:cvtool_bundle)          { cvtool_bundle }
        allow_any_instance_of(Conversion).to receive(:conversion_environment) { conversion_environment }
        allow_any_instance_of(Conversion).to receive(:conv_script)            { conv_script }

        # mimic user deselecting these associations
        %w{conversion_environment cvtool_bundle conversiontool conv_script }.each {|k| parameters[k] = {"0"=>""} }

        expect {
          post '/webmis/production_orderlines', parameters
        }.to change(ProductionOrderline, :count).by(0)

        expect(assigns(:checklog).ok?).to be_truthy
      end

    end

  end

  context "Shipping" do

    it 'displays Register product link when Conversion allows it' do
      production_orderline = create(:production_orderline, :with_chosen_conversion)

      allow_any_instance_of(Conversion).to receive(:allow_product_registration?) { true }

      get "/webmis/production_orderlines/#{production_orderline.id}/show_shipment_request"

      expect(response).to render_template(:show_shipment_request)
      expect(response.body).to match("Register product")
    end

    it 'displays Ship product when Conversion does not allow Register' do
      production_orderline = create(:production_orderline)

      get "/webmis/production_orderlines/#{production_orderline.id}/show_shipment_request"
      expect(response).to render_template(:show_shipment_request)
      expect(response.body).to match("Ship product")
    end

  end

  context "Clone" do
    describe 'POST #clone when multiple linked Conversions on Order' do
      it 'clones a specific production orderline object' do

        parent = create(:production_orderline_full)

        # A group of POl linked by same parent. The test needs them to have Chosen Conversion
        #
        production_orderlines = create_list(:production_orderline_clone_able, 4, parent_linenr: parent)

        production_orderline = production_orderlines.last

        expect(production_orderline.chosen_conversion).to be_present
        expect(production_orderline.test_grid_priority).to be_truthy

        # ISSUE - The one master conversion that is cloned by webmis when cloning SAM,
        # is represented 5 times after cloning instead of 1 time
        # But Conversion counts do not change ??

        expect {
            post "/webmis/production_orderlines/#{production_orderline.id}/clone"
          }.to change(ProductionOrderline, :count).by(1)
                 .and change(Conversion, :count).by(0)
                 .and change(ConversionDatabase, :count).by(0)
                 .and change(Product, :count).by(0)

        cloned = assigns(:production_orderline)

        expect(cloned.id).to_not eq(production_orderline.id)
        expect(cloned.rdo_path).to eq(production_orderline.rdo_path)
        expect(cloned.rdo_path).to_not be_blank

        # Force box is checked, please don't check it
        expect(cloned.force_create).to eq(production_orderline.force_create)

        # Priority flag is lost, please keep it from the cloned one
        expect(cloned.test_grid_priority).to eq(production_orderline.test_grid_priority)


        # Checking all belongs_to relationships which need preserving are preserved,
        # except this list - these should be intentionally blanked by clone
        expect_nil_belongs_to = %i{ chosen_conversion }

        ProductionOrderline.reflect_on_all_associations(:belongs_to).each do |r|
          if(expect_nil_belongs_to.include?(r.name))
            expect(cloned.send(r.name)).to be_nil
            next
          end
          pp "Warning Cloned ProdOrderline had no test data for #{r.name}" if production_orderline.send(r.name).nil?
          expect(cloned.send(r.name).try(:id)).to eq(production_orderline.send(r.name).try(:id)), "expected cloned association [#{r.name}] to match but did not"
        end

        # Checking all has_many relationships which need preserving are preserved,
        # except this list - these will not be identical
        expect_empty_has_many = %i{ change_log_lines }

        ProductionOrderline.reflect_on_all_associations(:has_many).each do |r|
          if(expect_empty_has_many.include?(r.name))
            next
          end
          pp "Warning Cloned ProdOrderline had no test data for #{r.name}" if production_orderline.send(r.name).nil?
          expect(cloned.send(r.name)).to eq(production_orderline.send(r.name)), "expected cloned association [#{r.name}] to match but did not"
        end

      end
    end
  end

end
