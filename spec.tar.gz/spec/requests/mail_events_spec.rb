require 'rails_helper'

describe 'Mail Events Requests' do

  # Authorization etc
  include_context "authorization" do
    let(:controllers) { [MainController] }
  end

  let(:mail_event) { create(:mail_event) }

  it 'allows the mail_event to be edited' do
    get edit_mail_event_url(mail_event)
    expect(response).to render_template("mail_events/_form")
    expect(response.body).to include(mail_event.name)
  end

end