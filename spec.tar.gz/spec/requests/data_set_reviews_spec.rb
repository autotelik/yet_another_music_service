require 'rails_helper'

describe 'DataSet Reviews' do

  include_context "authorization"  do
    let(:controllers) { [DataSetsController, DataSetReviewsController] }
  end

  context "Non Stubbed - Errors and Validations" do

    let!(:data_set) { create(:data_set) }

    it "validates data_set contains process_data_element " do
      post "/webmis/data_sets/#{data_set.id}/request_review", format: 'js'
      expect(response.body).to eq "ERROR: No elements available!"
    end

    it "should render an error message when bad data set ID supplied" do
      no_such_id = DataSet.maximum(:id).next
      post "/webmis/data_sets/#{no_such_id}/request_review", format: 'js'
      expect(response.body).to match(/ERROR: Couldn't find DataSet with 'id'=#{no_such_id}/)
    end

  end

  context "Stubbed" do

    include_context "stub_data_set_os_interaction"

    context "Reviewing Overview" do

      let(:data_sets) { create_list(:data_set, 3, status: DataSet::STATUS_REVIEW) }
      let!(:data_set) { data_sets[0] }

      it 'lists all datasets under Review' do
        get '/webmis/data_set_reviews/index'
        expect(response).to render_template(:index)
      end

    end

    context "Request a Review" do

      let(:uri)       { "/webmis/data_sets/#{data_set.id}/request_review" }

      let(:data_sets) { create_list(:data_set, 3, status: DataSet::STATUS_IN_PROGRESS) }
      let!(:data_set) { data_sets[0] }

      it 'sets the review request User to current user' do
        expect(data_set.review_request_user_id).to be_nil

        post uri, format: 'js'

        data_set.reload
        expect(data_set.review_request_user.id).to eq user.id
        expect(data_set.review_user_id).to be_nil
      end

      it 'another request resets review_user and result' do
        data_set.update(review_user_id: user.id)
        expect(data_set.review_user_id).to eq user.id
        post uri, format: 'js'

        data_set.reload
        expect(data_set.review_user_id).to be_nil
        expect(data_set.review_result).to be_nil
      end


      it "should set flash to the review username on success" do
        post uri, format: 'js'
        expect(response.body).to match "SUCCESS"
        expect(flash[:notice]).to match "Request successfully submitted by #{user.full_name}"
      end

      it "should set the DataSet review attributes to reflect IN REVIEW" do
        post uri, format: 'js'

        data_set.reload
        expect(data_set.status).to eq DataSet::STATUS_REVIEW
        expect(data_set.review_result).to be_nil
      end

    end
  end
end
