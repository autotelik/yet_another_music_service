require 'rails_helper'

describe ConversionsController do

  include_context "authorization"  do
    let(:controllers) { [ConversionsController] }
  end

  let!(:conversion)   { create(:c_DEFAULT, project: proj_PRODUCTION) }
  let!(:no_project)   { create(:conversion) }

  context 'Search' do

    # Note - The returned type in @conversions is not the conversion but a ConversionPresenter (wrapping tConversion)

    it 'should reset all other supplied search params when reset true' do
      get '/webmis/conversions', { inactive: true, search: "blah", reset: true }

      expect(assigns(:search_opts)).to have_key(:inactive)
      expect(assigns(:search_opts)[:inactive]).to eq "1"

      expect(assigns(:conversions).size).to eq 1
    end

    it 'searches and finds a conversion object BY id' do
      get '/webmis/conversions', search: conversion.id
      expect(assigns(:conversions).first.id).to eq conversion.id
    end

    it 'searches and finds an conversion object BY FROM (input_format)' do
      get '/webmis/conversions', { 'column_search_field[exact-conversions-input_format]': conversion.input_format }
      expect(assigns(:conversions).first.id).to eq conversion.id
    end

    it 'searches and finds an conversion object BY TO (output_format)' do
      get '/webmis/conversions', { 'column_search_field[exact-conversions-output_format]': conversion.output_format }
      expect(assigns(:conversions).first.id).to eq conversion.id
    end

    it 'searches and finds an conversion object BY Coverage (region)' do
      get '/webmis/conversions', { 'column_search_field[conversions-region_id]': conversion.region.id }
      expect(assigns(:conversions).first.id).to eq conversion.id
    end

    it 'searches and finds an conversion object BY RELEASE' do
      get '/webmis/conversions',  { 'column_search_field[data_releases-name]': conversion.data_release.name }
      expect(assigns(:conversions).first.id).to eq conversion.id
    end

    it 'searches and finds an conversion object BY STATUS' do
      get '/webmis/conversions',  { 'column_search_field[exact-conversions-status]':conversion.status }
      expect(assigns(:conversions).first.id).to eq conversion.id
    end

    it 'searches and finds multiple conversion objects BY BUNDLE' do
      get '/webmis/conversions', { 'column_search_field[cvtool_bundles-name]': conversion.cvtool_bundle.name }
      expect(assigns(:conversions).first.id).to eq conversion.id
    end
  end
end

