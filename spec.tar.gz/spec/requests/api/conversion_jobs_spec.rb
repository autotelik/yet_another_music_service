require 'rails_helper'

describe 'ConversionJob API' do

  let(:project)   { create(:proj_PRODUCTION) }
  let(:user)      { create(:user) }

  let(:log_path)  { "/api/rspec/test/conv_job.log" }
  let!(:conv_job) { create(:conversion_job_maximal, log_path: log_path) }

  before do
    # Mock calls to current_user to mimic a logged in user
    allow_any_instance_of(ApplicationController).to receive(:current_project) { project }
    allow_any_instance_of(ApplicationController).to receive(:current_user)    { user }
  end

  describe 'GET /conversion_job' do
    it 'returns json representation of a ConversionJob' do
      get "/api/conversion_jobs/#{conv_job.id}/filled_json"

      json = JSON.parse(response.body)
      expect(response).to be_success
      expect(json['id']).to eq(conv_job.id)
    end

    it 'excludes large text blobs from json representation of a ConversionJob' do
      get "/api/conversion_jobs/#{conv_job.id}/filled_json"

      json = JSON.parse(response.body)
      expect(response).to be_success
      expect(json.key?('stdout_log')).to be_falsey
    end

    it 'contains the log file path in the  json representation of a ConversionJob' do
      get "/api/conversion_jobs/#{conv_job.id}/filled_json"

      json = JSON.parse(response.body)
      expect(json['log_path']).to eq(log_path)
    end

    it 'converts enum values to stringified form for to_json on a ConversionJob' do
      get "/api/conversion_jobs/#{conv_job.id}/filled_json"

      json = JSON.parse(response.body)
      expect(json['status']).to eq(conv_job.status_str)
    end

    it 'returns 404 and error message in JSON when no such ConversionJob' do
      get "/api/conversion_jobs/blah/filled_json"
      json = JSON.parse(response.body)
      expect(response.status).to eq 404
      expect(json['error']).to be_present
    end
  end

end
