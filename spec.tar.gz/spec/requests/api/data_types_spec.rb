require 'rails_helper'

describe 'Data types API' do
  it 'sends a list of active data types' do
    data_type = create(:data_type)
    get '/api/data_types'
    json = JSON.parse(response.body)
    expect(json).not_to be_empty
  end

  it 'gets a specific data type' do
    data_type = create(:data_type)
    get "/api/data_types/#{data_type.id}/filled_json"
    json = JSON.parse(response.body)
    expect(json).not_to be_empty
  end
end
