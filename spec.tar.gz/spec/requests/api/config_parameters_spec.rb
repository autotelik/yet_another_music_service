require 'rails_helper'

describe 'Config parameters sets API' do

  context("Generate JSON") do

    let(:user) { create(:user) }
    let(:proj_PRODUCTION)   { create(:proj_PRODUCTION) }
    let(:proj_REGRESSION)   { create(:proj_REGRESSION) }

    let(:json_url)          { '/api/config_parameters' }

    let(:filled_json_url)   { "#{json_url}/filled_json" }

    let(:show_json_url)     { "#{json_url}/filled_json_by_cfg_name" }
    let(:show_json_qs_url)  { "#{show_json_url}?cfg_name=" }

    def url_for_cfg(name)
      "#{show_json_qs_url}#{name}"
    end

    let(:expected_non_default)      { '/volumes2/rspec/json/api' }
    let(:proc_dir_in_default_proj)  { create(:process_data_directory, project: proj_PRODUCTION) }
    let(:proc_dir)                  { create(:process_data_directory, project: proj_REGRESSION, cfg_value: expected_non_default) }

    before do
      # Mock calls to current_user to mimic a logged in user
      allow_any_instance_of(ApplicationController).to receive(:current_project) { proj_PRODUCTION }
      allow_any_instance_of(ApplicationController).to receive(:current_user)    { user }

      proc_dir_in_default_proj
      proc_dir
    end

    it 'generates JSON for config params by cfg name' do
      get url_for_cfg(proc_dir_in_default_proj.cfg_name)
      json = JSON.parse(response.body)

      expect(response).to be_success
      expect(json.keys).to include('cfg_name')
      expect(json.values).to include(proc_dir_in_default_proj.cfg_name)
    end

    it 'generates JSON for config params by ID' do
      get "#{show_json_url}/#{proc_dir_in_default_proj.id}"
      json = JSON.parse(response.body)

      expect(response).to be_success
      expect(json.keys).to include('cfg_name')
      expect(json.values).to include(proc_dir_in_default_proj.cfg_name)
    end

    it 'generates JSON for config params by cfg_id' do
      get "#{show_json_url}?cfg_id=#{proc_dir_in_default_proj.id}"
      json = JSON.parse(response.body)

      expect(response).to be_success
      expect(json.keys).to include('cfg_name')
      expect(json.values).to include(proc_dir_in_default_proj.cfg_name)
    end

    it 'generates JSON for config params by cfg name and optional project' do
      get "#{url_for_cfg(proc_dir_in_default_proj.cfg_name)}&project_name=#{proj_REGRESSION.name}"
      json = JSON.parse(response.body)

      expect(response).to be_success
      expect(json.keys).to include('cfg_name')
      expect(json.values).to include(proc_dir.cfg_name)
    end

    context ("Errors") do
      it 'generates JSON error message when no such Project' do
        get "#{url_for_cfg(proc_dir_in_default_proj.cfg_name)}&project_name=blah"
        json = JSON.parse(response.body)

        expect(response).to have_http_status :not_found

        expect(json.keys.count).to eq(1)
        expect(json.keys).to include("error")
        expect(json["error"]).to eq "Couldn't find Project"
      end

      it 'generates error JSON when no config params' do
        get show_json_url
        json = JSON.parse(response.body)
        expect(response).to have_http_status :not_found
        expect(json.keys).to include("error")
      end
    end

    context("#filled_json") do

      before do
        create(:default_bundle, project: proj_PRODUCTION)
        create(:tool_dir, project: proj_PRODUCTION)
      end

      it 'generates empty JSON when no config params in default Project' do
        ConfigParameter.delete_all
        get filled_json_url
        json = JSON.parse(response.body)

        expect(response).to be_success
        expect(json).to be_a Array
        expect(json).to eq []
      end

      it 'generates JSON for all config params in default Project when no project givens' do
        get filled_json_url
        json = JSON.parse(response.body)

        expect(response).to be_success
        expect(json.size).to eq(3)
        expect(response.body).to_not include(expected_non_default)
        expect(json[0]["project_id"]).to eq(proj_PRODUCTION.id)
      end

      it 'generates JSON for all config params in supplied Project by Name' do
        get "#{filled_json_url}?project_name=#{proj_REGRESSION.name}"
        json = JSON.parse(response.body)

        expect(response).to be_success
        expect(json.size).to eq(1)
        expect(response.body).to include(expected_non_default)
        expect(json[0]["project_id"]).to eq(proj_REGRESSION.id)
      end

      it 'generates JSON for all config params in supplied Project by ID' do
        get "#{filled_json_url}?project_id=#{proj_REGRESSION.id}"
        json = JSON.parse(response.body)

        expect(response).to be_success
        expect(json.size).to eq(1)
        expect(response.body).to include(expected_non_default)
        expect(json[0]["project_id"]).to eq(proj_REGRESSION.id)
      end

      it 'generates JSON error message when no such Project' do
        get "#{filled_json_url}?project_name=blahblah"
        json = JSON.parse(response.body)

        expect(response).to have_http_status :not_found

        expect(json.keys.count).to eq(1)
        expect(json.keys).to include("error")
        expect(json["error"]).to eq "Couldn't find Project"
      end

    end
  end
end
