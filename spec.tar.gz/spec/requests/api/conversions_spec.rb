require 'rails_helper'

describe 'Conversions API' do
  it 'sends a list of specific conversion attribute' do
    conv = create(:conversion)
    get "/api/conversions/#{conv.id}/filled_json/"
    json = JSON.parse(response.body)
    expect(response).to be_success
    # unable to test for exact match as the JSON call adds more attributes to the returned conversion
    expect(json['id']).to eq(conv.id)
  end
end
