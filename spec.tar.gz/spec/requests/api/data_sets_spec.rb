require 'rails_helper'

describe 'Data sets API' do

  context 'Data Set' do

    include_context 'data_set_prerequisites'

    let(:create_ds_url) { '/api/data_sets/create' }

    let(:rev) { rspec_generate_revision }

    before(:each) do
      # STUB to stop DataSet error being displayed in Rspec STDOUT
      Kernel.send(:define_method, :puts) { |*_args| '' }

      allow_any_instance_of(MailEvent).to receive(:subscribed_email_addresses) { [ 'rspec@mapscape.eu'] }
    end

    context 'No update an existing data set' do
      it 'based on supplied fields finds any Duplicate DataSet - does not add new coverage areas' do
        expect {
          post create_ds_url, reception_id: reception.id, data_type: data_set.data_type.name,
                              region_code: data_set.region.region_code, coverage_areas: reg_code_arr,
                              supplier: data_set.company_abbr.name,
                              release: data_set.data_release.name,
                              revision: data_set.revision
        }.to_not change(DataSet, :count)

        expect(response.status).to be 500
      end
    end

    context 'Error situation' do

      let(:params) { { reception_id: reception.id, region_code: data_set.region.region_code, revision: rev } }

      it 'catches and handles exception when core attributes missing' do
        expect { post create_ds_url, params }.to change(DataSet, :count).by(0)
        json = JSON.parse(response.body)
        expect(json).to have_key('errors')
      end

      it 'sends handled error email when save fails' do
        post create_ds_url, params
        mail = ActionMailer::Base.deliveries.last
        expect(mail.subject).to match(/Handled Internal Server Error/)
      end

    end

    context 'creates a new data set' do

      let(:params) { { reception_id: reception.id, supplier: company_abbr.name, data_type: data_type.name, region_code: data_set.region.region_code, revision: rev } }

      it 'provides valid core attributes only' do
        expect { post create_ds_url, params }.to change(DataSet, :count).by(1)
        new_data_set = DataSet.last
        expect(new_data_set.region.id).to eq(new_data_set.coverage.coverages_regions.first.region_id)
        expect(new_data_set.revision).to eq rev
      end


      it 'provides valid core attributes and coverage areas' do
        expect { post create_ds_url, params.merge(coverage_areas: reg_code_arr) }.to change(DataSet, :count).by(1)
        new_data_set = DataSet.last
        expect(new_data_set.coverage.coverages_regions.count).to eq(2)
        expect(Region.where(region_code: reg_code_arr).collect(&:id).exclude?(new_data_set.region.id)).to eq(true)
      end

      it 'keeps default coverage if it is the only one' do
        expect { post create_ds_url, params.merge(create_coverage_area: 'False') }.to change(DataSet, :count).by(1)
        new_data_set = DataSet.last
        expect(new_data_set.coverage.coverages_regions.count).to eq(1)
        expect(new_data_set.revision).to eq rev
      end
    end
  end

  context 'Create Production Order' do

    include_context 'create_production_order_prerequisites'

    let(:data_sets_json_url) { "/api/data_sets/#{data_set.id}/order_json?project_name=#{proj_PRODUCTION.name}" }

    let(:json_primary_key)   { 'order_parameters' }

    context 'JSON Template - order_json' do

      it 'populates JSON from a toolhandover conforming to our Schema' do
        get data_sets_json_url
        expect(response).to be_success
        pending('agreement with peter regarding final json structure')
        expect(response).to match_response_schema('option_parameters')
      end

      it 'includes the conversion object and config in the JSON from a toolhandover' do
        get data_sets_json_url
        expect(response).to be_success
        expect(assigns(:presenter)).to be_a Api::OrderParametersPresenter

        json = JSON.parse(response.body)

        expect(json).to have_key(json_primary_key)

        order_params = json[json_primary_key]

        # data_set so a single orderline
        expect(order_params['orderline_parameters'][0]).to be
        orderline_params = order_params['orderline_parameters'][0]

        expect(orderline_params['conversion_object']['id']).to eq data_set.id

        expect(orderline_params['tool_handover']).to have_key('value')
        expect(orderline_params['tool_handover']['value']).to eq data_set.current_tool_handover(proj_PRODUCTION).name
      end

      it 'includes a default conversion object when NO toolhandover' do
        # basic - no toolhandover - but with process_data_elements that contain conversion_design names
        ds = create(:data_set, :with_process_data_elements)

        url = "/api/data_sets/#{ds.id}/order_json?project_name=#{proj_PRODUCTION.name}"

        get url
        expect(response).to be_success
        expect(assigns(:tool_handover)).to be nil

        json = JSON.parse(response.body)

        expect(json).to have_key(json_primary_key)

        order_params = json[json_primary_key]

        # data_set so a single orderline
        expect(order_params['orderline_parameters'][0]).to be
        orderline_params = order_params['orderline_parameters'][0]

        expect(orderline_params['conversion_object']['id']).to eq ds.id
        expect(orderline_params['tool_handover']).to have_key 'documentation'     # no toolhandover
        expect(orderline_params['conversion_design']).to have_key 'id'            # con design via process_data_elements
      end

    end

    let(:api_create_order_url) { '/api/data_sets/create_production_order' }

    let(:order_params) do
      # JSON BODY FOR data_sets_json_url
      #
      # Complex to make this a factory or fixture as it needs Product Ids etc,
      # might be able to make more efficient using app/views/api/data_sets/order_json.jbuilder directly
      # but for now have to generate for real
      get data_sets_json_url
      expect(response).to be_success
      JSON.parse(response.body) # Hash
    end

    let(:order_params_json) { order_params.to_json }
    let(:region_codes)      { coverage.regions.collect(&:region_code) }

    before(:each) do
      # API disallows some actions when project == Project.default,
      # so we have to make the defautl different to the main project we are using for test
      allow(Project).to receive(:default) { proj_REGRESSION }

      # Product specifics
      create(:frontend, yaml_yn: true, status: Ordertype::STATUS_ACTIVE)
    end

    context('Production Project') do

      it 'does not create a production order via API when no JSON configuration present' do
        expect {
          post api_create_order_url, {}, json_headers
        }.to_not change(ProductionOrder, :count)

        expect(response.status).to be 500
      end

      it 'sets up the OrderParameters for a DataSet based ProductionOrder' do
        order_parameters = OrderParameters.factory(order_params, user)

        orderline_params = order_parameters.orderline_parameter_at(0)

        expect(orderline_params.conversion_klass).to eq DataSet
        expect(orderline_params.data_set_based?).to eq true
        expect(orderline_params.product_based?).to eq false
        expect(orderline_params.steps.size).to eq 2
      end

      it 'creates a ProductionOrder via the API from DataSet based OrderParameters' do
        expect {
          post api_create_order_url, order_params_json, json_headers
        }.to change(ProductionOrder, :count).by(1).and change(Conversion, :count).by(2)
      end

      it 'creates a ProductionOrderline per Step with status STATUS_HANDLE_CONVERSION' do
        expect {
          # Post a complete OrderParameters definition, as JSON in the body
          post api_create_order_url, order_params_json, json_headers
        }.to change(ProductionOrderline, :count).by(2)

        expect(ProductionOrderline.first.status_str).to eq ProductionOrderline.status_hash[ProductionOrderline::STATUS_HANDLE_CONVERSION]
        expect(ProductionOrderline.last.status).to eq ProductionOrderline::STATUS_HANDLE_CONVERSION

        expect(ProductionOrder.last.production_orderlines.active.count).to eq 2
      end

      it 'sets fields on Conversion from OrderParameters JSON' do
        post api_create_order_url, order_params_json, json_headers

        expect(Conversion.first.force_create).to be_nil
        expect(Conversion.last.force_create).to be_nil
      end

    end

    it 'Uses the Project defined in the JSON, to create a ProductionOrder via API' do
      order_params[json_primary_key]['project']['id'] = create(:project, name: 'RSpec Test').id

      expect {
        post api_create_order_url, order_params.to_json, json_headers
      }.to change(ProductionOrder, :count).by(1)

      # all parameters filled except confirmation parameter, implicit full coverage
      expect {
        post api_create_order_url, order_params.to_json, json_headers
      }.to change(ProductionOrder, :count).by(1)

      coverages = ProductionOrder.last.conversions.all.collect(&:coverage)
      expect(coverages.last.regions.collect(&:region_code)).to match_array region_codes

    end

    it 'uses the step regions defined in the JSON, to create a ProductionOrder via API' do
      # N.B OLD API param 'coverage' is now per STEP 'region_codes'
      # This will prevent usage of region params branch : if conversion.output_format == Conversion::TAG_RDB_FORMAT
      # So set to use order_params branch
      Conversion.new # output_format is a dynamic Rails method that RSpec won't recognise unless 'brought into life'
      allow_any_instance_of(Conversion).to receive(:output_format) { 'dHive' }

      regions = [create(:r_TEST_REGION1), create(:r_TEST_REGION2)].collect(&:region_code)

      orderline_params = order_params[json_primary_key]['orderline_parameters'][0]
      orderline_params['steps'][1]['region_codes'] = regions

      expect {
        post api_create_order_url, order_params.to_json, json_headers
      }.to change(ProductionOrder, :count).by(1)

      coverages = ProductionOrder.last.conversions.all.collect(&:coverage)
      expect(coverages.last.regions.collect(&:region_code)).to match_array regions
    end

  end

  context('Query Params') do

    let(:filled_json_url) { '/api/data_sets/filled_json' }

    let(:company_abbr)      { create(:ca_RDF_SUPPLIER1) }

    let(:data_release)      { create(:dr_TEST_RELEASE) }
    let(:data_type)         { create(:dt_RDF) }

    let(:expect_region_name) { 'lorem_ipsum_dolor' }

    let!(:filling)          { create(:filling) }

    let(:region)            { create(:region, name: expect_region_name) }

    let(:data_set)          { create(:data_set, :with_process_data_directory, region: region, filling: filling, company_abbr: company_abbr, data_release: data_release, data_type: data_type) }

    it 'gets a single data set by id' do
      allow_any_instance_of(DataSet).to receive(:generate_directory) { '/rspec/test' }

      get "#{filled_json_url}?id=#{data_set.id}"

      expect(response).to be_success
      expect(response.body).to include('"default_directory":"/rspec/test"')

      json = JSON.parse(response.body)
      expect(json.keys.count).to eq(1)
      expect(json.keys).to include(data_set.id.to_s)
    end

    describe 'Maximum Parameters' do

      it 'gets a single data set with maximum passed parameters' do
        get "#{filled_json_url}?company=#{data_set.company_abbr.name}&data_release_name=#{data_release.name}&data_type_name=#{data_type.name}&filling_name=#{filling.name}"
        json = JSON.parse(response.body)

        expect(response).to be_success
        expect(json.keys.count).to eq(1)
        expect(json.keys).to include(data_set.id.to_s)
      end

      it 'gets many data sets with maximum passed parameters' do
        data_set_two = create(:data_set, :with_process_data_directory, region: region, filling: filling, company_abbr: company_abbr, data_release: data_release, data_type: data_type)
        get "#{filled_json_url}?company=#{data_set.company_abbr.name}&data_release_name=#{data_release.name}&data_type_name=#{data_type.name}"
        json = JSON.parse(response.body)

        expect(response).to be_success
        expect(json.keys.count).to eq(2)
        expect(json.keys).to include(data_set.id.to_s)
        expect(json.keys).to include(data_set_two.id.to_s)
      end
    end

    describe 'Revision' do

      let!(:data_set_one)   { create(:data_set, :with_process_data_directory, revision: data_set.revision) }

      it 'gets data sets by revision' do
        get "#{filled_json_url}?revision=#{data_set.revision}"
        json = JSON.parse(response.body)
        expect(response).to be_success
        expect(json.keys.count).to eq(2)

        expect(json[data_set.id.to_s]['revision']).to eq data_set.revision
        expect(json[data_set_one.id.to_s]['revision']).to eq data_set.revision
      end
    end

    describe 'Regions' do

      let(:not_this_region) { create(:region, region_code: 'not this one') }

      let!(:data_set_one)   { create(:data_set, :with_process_data_directory, region: region) }
      let!(:data_set_two)   { create(:data_set, :with_process_data_directory, region: region, filling: filling) }

      before do
        create_list(:data_set, 5, :with_process_data_directory, region: not_this_region)
      end

      it 'filter many data sets by region name' do
        get "#{filled_json_url}?region=#{expect_region_name}"
        json = JSON.parse(response.body)

        expect(response).to be_success
        expect(json.keys.count).to eq(2)
        expect(json.keys).to include(data_set_one.id.to_s)
        expect(json.keys).to include(data_set_two.id.to_s)

        expect(json[data_set_one.id.to_s]['region']).to eq expect_region_name
      end

      it 'filter many data sets by region_code' do
        get "#{filled_json_url}?region_code=#{region.region_code}"
        json = JSON.parse(response.body)

        expect(response).to be_success
        expect(json.keys.count).to eq(2)
        expect(json.keys).to include(data_set_one.id.to_s)
        expect(json.keys).to include(data_set_two.id.to_s)

        expect(json[data_set_one.id.to_s]['region']).to eq region.name
        expect(json[data_set_one.id.to_s]['region_code']).to eq region.region_code
      end

      it 'filter many data sets by region and region_code' do
        region_by_name = create(:region, name: 'select me')
        ds_list_1 = create_list(:data_set, 5, :with_process_data_directory, region: region_by_name).first

        get "#{filled_json_url}?region_code=#{region.region_code}&region=#{region_by_name.name}"
        json = JSON.parse(response.body)

        expect(response).to be_success

        # Conditions are combined with AND
        expect(json.keys.count).to eq(0)

        get "#{filled_json_url}?region_code=#{region_by_name.region_code}&region=#{region_by_name.name}"
        json = JSON.parse(response.body)

        expect(response).to be_success
        expect(json.keys.count).to eq(5)

        expect(json.keys).to include(ds_list_1.id.to_s)

        expect(json[ds_list_1.id.to_s]['region']).to eq region_by_name.name
        expect(json[ds_list_1.id.to_s]['region_code']).to eq region_by_name.region_code
      end
    end

    describe 'Company' do

      let(:company_abbr_alt)  { create(:company_abbr) }

      let!(:data_set_one)     { create(:data_set, :with_process_data_directory, region: region, company_abbr: company_abbr) }
      let!(:data_set_two)     { create(:data_set, :with_process_data_directory, region: region, company_abbr: company_abbr, filling: filling) }

      let!(:ds_list)          { create_list(:data_set, 5, :with_process_data_directory, company_abbr: company_abbr_alt, filling: filling) }

      it 'gets many data sets by Company' do
        get "#{filled_json_url}?company=#{company_abbr.company_name}"
        json = JSON.parse(response.body)

        expect(response).to be_success
        expect(json.keys.count).to eq(2)
        expect(json.keys).to include(data_set_one.id.to_s)
        expect(json.keys).to include(data_set_two.id.to_s)

        get "#{filled_json_url}?company=#{company_abbr_alt.company_name}"
        expect(response).to be_success
        expect(response.body).to match(":\"#{company_abbr_alt.company_name}\"")
      end

      it 'gets many data sets by Company ABBR' do
        get "#{filled_json_url}?company_abbr=#{company_abbr_alt.ms_abbr_3}"
        json = JSON.parse(response.body)

        expect(response).to be_success
        expect(json.keys.count).to eq(5)
        expect(json.keys).to_not include([data_set_one.id.to_s, data_set_two.id.to_s])
      end

    end

  end

  context('Tool Handover') do
    let(:create_tool_handover_url)          { '/api/data_sets/create_tool_handover' }
    let(:data_type)                         { create(:dt_RDF, name: 'RDF') }
    let(:data_set)                          { create(:data_set, data_type: data_type) }
    let(:project)                           { create(:proj_PRODUCTION) }

    it 'raises an error if tool handover already exists' do
      create(:tool_handover_data_set, handover: data_set)

      post create_tool_handover_url, { data_set_id: data_set.id, project_name: project.name }

      result_body = JSON.parse(response.body)
      expect(response.status).to eq(422)
      expect(result_body['error']).to eq("#{data_set.name} already has a set tool handover")
    end

    it 'raises an error if data set has no potential conversion designs' do
      post create_tool_handover_url, { data_set_id: data_set.id, project_name: project.name }

      result_body = JSON.parse(response.body)
      expect(response.status).to eq(422)
      expect(result_body['error']).to eq("#{data_set.name} does not have any valid conversion designs")
    end

    it 'creates a tool handover with minimum arguments' do
      expect(data_set.set_tool_handovers.count).to eq(0)

      create(:RDF2DH_design_name)
      # used when validating YAML design
      create(:dt_RDB, name: 'RDB')
      create(:dt_dHive, name: 'dHive')

      post create_tool_handover_url, { data_set_id: data_set.id, project_name: project.name }

      expect(data_set.set_tool_handovers.count).to eq(1)
      expect(response.body.to_i).to eq(data_set.set_tool_handovers.first.id)
    end

  end

end
