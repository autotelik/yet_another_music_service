require 'rails_helper'

describe 'Process data specifications API' do
  it 'gets a specific process data specification' do
    process_data_specification = create(:process_data_specification, name: 'api_test')
    get '/api/process_data_specifications/filled_json_by_name?name=api_test'
    json = JSON.parse(response.body)
    expect(json).not_to be_empty
  end
end
