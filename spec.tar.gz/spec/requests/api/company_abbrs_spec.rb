require 'rails_helper'

describe 'Company Abbrs API' do
  it 'sends a list of active company abbrs' do
    company_abbr = create(:company_abbr)
    get '/api/company_abbrs/filled_json/'
    json = JSON.parse(response.body)
    expect(json).not_to be_empty
  end
end
