require 'rails_helper'

describe 'ProductionOrderLines API' do

  include_context "authorization"

  include_context 'create_production_order_prerequisites'

  # stubs out the very low level stuff, like creating dakota scripts
  include_context 'production_order_scheduling_stubs'

  before do
    allow_any_instance_of(Conversion).to receive(:create_dakota_scripts) { [] }
  end

  context 'API #json' do

    include_context 'generate_order_params_json'

    let(:api_check_order_url) { '/api/production_orderlines/check_automatic_order' }

    it 'creates a single ProductionOrder from OrderParameters in JSON' do
      expect {
        post api_check_order_url, @order_params_json, json_headers
      }.to change(ProductionOrder, :count).by(0).and change(Conversion, :count).by(0)

      pending 'merge issues ?? check_automatic_order not on this controller anymore ??'
      expect(assigns(:checklog)).to be_a(Checklog)
      expect(assigns(:checklog).ok?).to be_truthy
    end
  end

end
