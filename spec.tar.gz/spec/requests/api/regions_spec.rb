require 'rails_helper'

describe 'Regions API' do
  it 'sends a list of active regions' do
    region = create(:region)
    get '/api/regions/filled_json/'
    json = JSON.parse(response.body)
    expect(json).not_to be_empty
  end
end
