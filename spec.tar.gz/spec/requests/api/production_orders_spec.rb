require 'rails_helper'

describe 'Production Orders API' do

  context('API Calls using Generated JSON') do

    include_context 'authorization' do          let(:controllers) { [ApplicationController] }  end

    include_context 'create_production_order_prerequisites'

    # Sorts out JSON headers, instantiates @order_params_json
    include_context 'generate_order_params_json'

    let(:api_create_order_url) { '/api/production_orders/create_automatic_order' }

    let(:json_primary_key) { 'order_parameters' }

    it 'creates a single ProductionOrder from OrderParameters in JSON' do
      expect {
        # Post a complete OrderParameters definition, as JSON in the body
        post api_create_order_url, @order_params_json, json_headers

      }.to change(ProductionOrder, :count).by(1).and change(Conversion, :count).by(2)
    end

    it 'creates a ProductionOrderline per Step with status STATUS_HANDLE_CONVERSION' do
      expect {
        # Post a complete OrderParameters definition, as JSON in the body
        post api_create_order_url, @order_params_json, json_headers
      }.to change(ProductionOrderline, :count).by(2)

      expect(ProductionOrderline.first.status_str).to eq ProductionOrderline.status_hash[ProductionOrderline::STATUS_HANDLE_CONVERSION]
      expect(ProductionOrderline.last.status).to eq ProductionOrderline::STATUS_HANDLE_CONVERSION

      expect(ProductionOrder.last.production_orderlines.active.count).to eq 2
    end

    it 'sets fields on Conversion from order parameters JSON' do
      post api_create_order_url, @order_params_json, json_headers

      expect(Conversion.first.force_create).to be_nil
      expect(Conversion.last.force_create).to be_nil
    end

    it 'sets the force_create object on Conversion from order parameters JSON' do
      # Configure JSON to force recreation of conversion databases
      @order_params[json_primary_key]['orderline_parameters'][0]['steps'][1]['force_create'] = true

      expect {
        post api_create_order_url, @order_params.to_json, json_headers
      }.to change(Conversion, :count).by(2)

      expect(Conversion.first.force_create).to be_nil
      expect(Conversion.last.force_create).to be_a ProductionOrder
    end

    let(:conv_design) { create(:RDF2DH_radars) }

    it 'halts production order creation when the production order fails' do
      allow_any_instance_of(ProductionOrder).to receive('change_status') { raise 'An Exception' }

      expect {
        post api_create_order_url, @order_params.to_json, json_headers
      }.to change(ProductionOrder, :count).by(0).and change(Conversion, :count).by(0)
    end

    it 'persists ignore_conversion_failures setting to DB on Production Order' do
      @order_params[json_primary_key]['ignore_conversion_failures'] = true

      post api_create_order_url, @order_params.to_json, json_headers

      expect(ProductionOrder.last.ignore_conversion_failures?).to eq true
    end

    context('Job Scheduling') do

      # Stub all OS and Dakota interactions
      include_context 'production_order_scheduling_stubs'

      it 'calls cancel on ProductionOrder when job fails but ignore_conversion_failures set' do

        # Create conversions/orderlines that become Jobs
        @order_params[json_primary_key]['ignore_conversion_failures'] = true

        expect {
          post api_create_order_url, @order_params.to_json, json_headers
        }.to change(ProductionOrderline, :count).by(2)

        po = ProductionOrder.last

        expect(po.conversion_jobs.size).to eq 0
        po.perform

        po.reload
        expect(po.conversion_jobs.size).to be > 0

        # Set Jobs to go down auto_monitor route
        po.conversion_jobs.each do |cj|
          cj.update_columns(status: Job::STATUS_PROCESSING, start_time: DateTime.now)
        end

        # Trigger a problem during auto_monitor - this is a good spot within the success branch
        allow_any_instance_of(ConversionJob).to receive(:allow_file_system_status_change?) { raise 'Mimic a Job Failing' }

        # Once we schedule the jobs the trigger should kick in
        ProductionOrder.schedule
        po.reload

        expect(po.status).to eq ProductionOrder::STATUS_CANCELLED

        po.production_orderlines.each { |p| expect(p.status).to eq ProductionOrderline::STATUS_CANCELLED }
        po.conversions.each           { |c| expect(c.status).to eq Conversion::STATUS_CANCELLED }
        po.conversion_jobs.each       { |c| expect(c.status).to eq ConversionJob::STATUS_CANCELLED }
      end
    end
  end
end
