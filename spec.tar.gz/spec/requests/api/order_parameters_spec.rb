require 'rails_helper'

describe 'Order Parameters via API' do

  context("Product") do

    context("Serialize") do

      let(:basic) { create(:product) }

      let(:products_order_json_url) { "/api/products/#{basic.id}/order_json?project_name=#{create(:proj_PRODUCTION).name}" }

      it 'can generate JSON template without a ToolHandover on Product' do
        get products_order_json_url
        expect(response).to be_success
        expect { JSON.parse(response.body) }.to_not raise_error # e.g JSON::ParserError

        order_parameters = JSON.parse(response.body)["order_parameters"]

        expect(order_parameters).to have_key("orderline_parameters")
        orderline_parameters = order_parameters["orderline_parameters"][0]

        expect(orderline_parameters).to have_key("tool_handover")
        expect(orderline_parameters["tool_handover"]).to have_key("documentation")
      end
    end

    context("DeSerialize") do

      include_context "create_production_order_prerequisites"

      let(:products_order_json_url) { "/api/products/#{product.id}/order_json?project_name=#{proj_PRODUCTION.name}" }

      before(:each) do
        # Complex to make this a factory or fixture as it needs Product Ids etc,
        # might be able to make more efficient using app/views/api/data_sets/order_json.jbuilder directly
        # but for now have to generate for real
        get products_order_json_url
        expect(response).to be_success

        @order_params = JSON.parse(response.body)
        @order_params_json = @order_params.to_json
      end

      it 'can deserialze JSON into OrderParamaters structure based upon a Product' do
        order_parameters = OrderParameters.factory(@order_params, user)

        expect(order_parameters.orderline_parameters).to be_a Array
        expect(order_parameters.orderline_parameters.size).to eq 1

        orderline_parameters = order_parameters.orderline_parameter_at(0)

        expect(orderline_parameters.conversion_klass).to eq Product
        expect(orderline_parameters.conversion_object).to be_a Product
        expect(orderline_parameters.product).to eq product
        expect(orderline_parameters.data_set).to be_nil
        expect(orderline_parameters.data_set_based?).to eq false
        expect(orderline_parameters.product_based?).to eq true
      end

    end

  end

  context("DataSets") do

    context("Serialize") do

      let(:basic) { create(:data_set) }

      let(:order_json_url) { "/api/data_sets/#{basic.id}/order_json?project_name=#{create(:proj_PRODUCTION).name}" }

      it 'can generate JSON template without a ToolHandover on DataSet' do
        get order_json_url
        expect(response).to be_success
        expect { JSON.parse(response.body) }.to_not raise_error # e.g JSON::ParserError
        order_parameters = JSON.parse(response.body)["order_parameters"]

        expect(order_parameters).to have_key("orderline_parameters")
        orderline_parameters = order_parameters["orderline_parameters"][0]

        expect(orderline_parameters).to have_key("tool_handover")
        expect(orderline_parameters["tool_handover"]).to have_key("documentation")
        expect(orderline_parameters["conversion_design"]).to have_key("documentation")
      end
    end

    context("DeSerialize") do

      include_context "create_production_order_prerequisites"

      let(:datasets_order_json_url) { "/api/data_sets/#{data_set.id}/order_json?project_name=#{proj_PRODUCTION.name}" }

      before(:each) do
        # Complex to make this a factory or fixture as it needs Product Ids etc,
        # might be able to make more efficient using app/views/api/data_sets/order_json.jbuilder directly
        # but for now have to generate for real
        get datasets_order_json_url
        expect(response).to be_success

        @order_params = JSON.parse(response.body)
        @order_params_json = @order_params.to_json
      end

      it 'can deserialize JSON into OrderParameters structure based upon a Product' do
        order_parameters = OrderParameters.factory(@order_params, user)

        expect(order_parameters.order_type).to eq "DataSet"

        expect(order_parameters.orderline_parameters).to be_a Array
        expect(order_parameters.orderline_parameters.size).to eq 1

        orderline_parameters = order_parameters.orderline_parameter_at(0)

        expect(orderline_parameters.conversion_klass).to eq DataSet
        expect(orderline_parameters.conversion_object).to be_a DataSet
        expect(orderline_parameters.product).to be_nil
        expect(orderline_parameters.data_set).to eq data_set
        expect(orderline_parameters.data_set_based?).to eq true
        expect(orderline_parameters.product_based?).to eq false
      end
    end

  end
end
