require 'rails_helper'

describe 'Receptions API' do

  let(:rev)           { rspec_generate_revision }
  let(:region)        { create(:r_TEST_REGION1, name: 'lorem_ipsum_dolor') }
  let(:data_type)     { create(:dt_RDF) }
  let(:filling)       { create(:filling) }
  let(:data_release)  { create(:dr_2013Q2) }
  let(:company_abbr)  { create(:ca_RDF_SUPPLIER1) }

  context 'API Create' do

    it 'creates an reception' do
      expect {
        post '/api/receptions/create', remarks: 'lorem', region_code: region.region_code,
                                       data_type: data_type.name, storage_location: '/ipsum',
                                       revision: rev, data_release: data_release.name,
                                       supplier: company_abbr.company_name, purpose: 'dolor',
                                       supplier_ref: ['VDAM161H0WVD000DDZ00_test']
      }.to change(Reception, :count).by(1)

      new_reception = Reception.last
      expect(new_reception.revision).to eq rev
    end

  end

  context 'API Searches' do
    let(:region_alt)        { create(:r_Netherlands) }
    let(:proj_PRODUCTION)   { create(:proj_PRODUCTION) }
    let(:user)              { create(:user) }

    before(:each) do
      allow_any_instance_of(ApplicationController).to receive(:current_project)   { proj_PRODUCTION }
      allow_any_instance_of(ApplicationController).to receive(:current_user)      { user }
    end

    before do
      create(:data_input_directory)
    end

    it 'gets a single reception by id' do
      reception = create(:r_TEST1)
      get "/api/receptions/filled_json?id=#{reception.id}"
      json = JSON.parse(response.body)

      expect(response).to be_success
      expect(json.keys.count).to eq(1)
      expect(json.keys).to include(reception.id.to_s)
    end

    # The safe_params = params.permit(:company, :data_release, :region, :region_code, :data_type, :filling)

    it 'gets a single reception with maximum passed parameters' do
      reception = create(:r_TEST1, region: region, filling: filling, data_release: data_release, data_type: data_type)
      create(:r_TEST2, region: region_alt)

      get "/api/receptions/filled_json?region=#{region.name}&data_release=#{data_release.name}&data_type=#{data_type.name}&filling=#{filling.name}"
      json = JSON.parse(response.body)

      expect(response).to be_success
      expect(json.keys.count).to eq(1)
      expect(json.keys).to include(reception.id.to_s)
    end

    describe 'Revision' do
      it 'gets data sets by revision' do
        reception = create(:reception)
        get "/api/receptions/filled_json?revision=#{reception.revision}"
        json = JSON.parse(response.body)
        expect(response).to be_success
        expect(json[reception.id.to_s]['revision']).to eq reception.revision
      end
    end

    it 'gets receptions by data_type' do
      create(:r_TEST1, data_type: create(:dt_3LM))
      create(:r_TEST2, data_type: create(:dt_3DC))
      reception = create(:r_TEST3, data_type: data_type, region: create(:region))

      get "/api/receptions/filled_json?data_type=#{data_type.name}"

      json = JSON.parse(response.body)

      expect(response).to be_success
      expect(json.keys.count).to eq(1)
      expect(json.keys).to include(reception.id.to_s)
    end

    it 'gets receptions by filling' do
      create(:r_TEST1, filling: create(:f_JVS))
      create(:r_TEST2, filling: create(:f_BIC))
      reception = create(:r_TEST3, filling: filling, region: create(:region))

      get "/api/receptions/filled_json?filling=#{filling.name}"

      json = JSON.parse(response.body)

      expect(response).to be_success
      expect(json.keys.count).to eq(1)
      expect(json.keys).to include(reception.id.to_s)
    end

    it 'gets many receptions by region (coverage name)' do
      reception_one = create(:r_TEST1, region: region)
      get "/api/receptions/filled_json?region=#{region.name}"
      json = JSON.parse(response.body)

      expect(response).to be_success
      expect(json.keys.count).to eq(1)
      expect(json.keys).to match_array [reception_one.id.to_s]
    end

    it 'gets many receptions by region.region_code' do
      reception_two = create(:r_TEST2, region: region_alt)
      get "/api/receptions/filled_json?region_code=#{region_alt.region_code}"
      json = JSON.parse(response.body)

      expect(response).to be_success
      expect(json.keys.count).to eq(1)
      expect(json.keys).to match_array [reception_two.id.to_s]
    end

    it 'gets many receptions by supplier_ref via LIKE %..%' do
      common = { region: region, data_release: data_release, data_type: data_type }

      reception_one = create(:r_TEST1, common.merge(supplier_ref: 'blah'))
      reception_two = create(:r_TEST2, common.merge(filling: filling, supplier_ref: 'blah_and_blah'))

      get "/api/receptions/filled_json?supplier_reference=#{reception_two.supplier_ref}"
      json = JSON.parse(response.body)

      expect(response).to be_success
      expect(json.keys.count).to eq(1)
      expect(json.keys).to include(reception_two.id.to_s)

      get '/api/receptions/filled_json?supplier_reference=blah'
      json = JSON.parse(response.body)

      expect(response).to be_success
      expect(json.keys.count).to eq(2)
      expect(json.keys).to match_array [reception_one.id.to_s, reception_two.id.to_s]

    end

    it 'gets many receptions by name of data_release' do
      common = { region: region, data_type: data_type }

      reception_1 = create(:r_TEST1, common.merge(data_release: data_release))
      reception_3 = create(:r_TEST3, common.merge(data_release: data_release))

      get "/api/receptions/filled_json?data_release=#{data_release.name}"
      json = JSON.parse(response.body)

      expect(response).to be_success
      expect(json.keys.count).to eq(2)
      expect(json.keys).to match_array [reception_1.id.to_s, reception_3.id.to_s]
    end

    it 'gets many receptions with maximum passed parameters' do
      common = { region: region, data_release: data_release, data_type: data_type, filling: filling }
      reception_one = create(:r_TEST1, common.merge(supplier_ref: 'blah'))
      reception_two = create(:r_TEST2, common.merge(supplier_ref: '_something_blah__'))

      get "/api/receptions/filled_json?supplier_reference=#{reception_one.supplier_ref}&region=#{region.name}" \
          "&filling=#{filling.name}&data_release=#{data_release.name}&data_type=#{data_type.name}"
      json = JSON.parse(response.body)

      expect(response).to be_success
      expect(json.keys.count).to eq(2)
      expect(json.keys).to include(reception_one.id.to_s)
      expect(json.keys).to include(reception_two.id.to_s)
    end
  end
end
