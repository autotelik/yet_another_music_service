require 'rails_helper'

describe ReceptionsController do

  include_context "authorization"  do
    let(:controllers) { [ReceptionsController] }
  end

  let!(:@reception)   { create(:r_DUMMY, status: Reception::STATUS_IN_PROGRESS) }

  describe 'GET #index' do

    it 'lists all reception requests' do
      get '/webmis/receptions/requests'
      expect(assigns(:receptions)).not_to be_empty
      expect(response).to render_template('receptions/requests')
      expect(response.body).to have_css('div#index')
    end

  end

end
