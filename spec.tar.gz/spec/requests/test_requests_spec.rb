require 'rails_helper'

describe 'TestRequests' do

  include_context "authorization"  do
    let(:controllers) { [TestRequestsController] }
  end


  context "Create" do

    let(:product)   { create(:product) }
    let(:db_list)   { create_list(:conversion_file_base, 3) }
    let(:project)   { create(:proj_PRODUCTION) }
    let(:user)      { create(:user) }

    let(:parameters) do
      {
        "test_request": {
          "requested_by_user_id": user.id,
          "assigned_to_user_id": user.id,
          "test_type_id": "1",
          "volume_id": product.volume_id,
          "start_date": Date.today.to_s,
          "finish_date": Date.today.to_s,
          "request_remarks": "hello world",
          "test_db_conversion_databases_id":    db_list[0].id,
          "ref_db_conversion_databases_id":     db_list[1].id,
          "aknavi_db_conversion_databases_id":  db_list[2].id
        },
        "return_to_controller": "", "return_to_action": "", "return_to_id": "", "commit": "Save"
      }
    end

    before(:each) do
      job = double(ConversionJob)
      allow_any_instance_of(ConversionDatabase).to receive(:conversion_job) { job }

      conversion = double(Conversion)
      production_orderline = double(ProductionOrderline)

      allow(production_orderline).to receive(:aknavi_db)          { 'ABC' }
      allow(production_orderline).to receive(:test_grid_project)  { '123' }

      allow(conversion).to receive(:conversion_tool_release)  { 'BladeRunner_2018' }
      allow(conversion).to receive(:production_orderline)     { production_orderline }

      allow_any_instance_of(TestRequest).to receive(:conversion) { conversion }
    end

    it 'creates a new TestRequest with all databases set' do
      expect { post '/webmis/test_requests', parameters }.to change(TestRequest, :count).by(1)

      test_request = TestRequest.last
      expect(test_request.test_db).to eq db_list[0]
      expect(test_request.ref_db).to eq db_list[1]
      expect(test_request.aknavi_db).to eq  db_list[2]

      expect(flash[:notice]).to match 'TestRequest was successfully created'
    end

    it 'returns JSON containing all databases set' do
      expect { post '/webmis/test_requests', parameters }.to change(TestRequest, :count).by(1)

      test_request = TestRequest.last
      get "/api/test_requests/#{test_request.id}/filled_json"
      json = JSON.parse(response.body)

      expect(json['test_database']).to eq db_list[0].path_and_file
      expect(json['ref_database']).to eq db_list[1].path_and_file

      expect(json['aknavi_database']).to_not be_blank
      expect(json['aknavi_database']).to eq  db_list[2].path_and_file
    end

  end
end
