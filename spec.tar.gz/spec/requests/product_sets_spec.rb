require 'rails_helper'

describe 'Product Sets' do

  include_context "authorization"  do
    let(:controllers) { [ProductSetsController] }
  end

  context "#pds_import NDS Gen" do

    context("Valid") do
      let(:product_category)  { create(:product_category, pds_import_file: factory_file('PDS__Export_NDS_VWG.csv')) }

      it 'creates a ProductSet from a XLS file linked to a ProductCategory' do
        expect {
          post "/webmis/product_sets/pds_import", cat_id: product_category.id
        }.to change(PdsProduct, :count).by(1)

        product = PdsProduct.last

        expect(product.volume_id).to eq "MP181-1651_SEA"
      end
    end

    context("Invalid") do
      let(:product_category)  { create(:product_category, pds_import_file: factory_file('PDS__Export_NDS_BAD.csv')) }

      it 'adds validation error to Changelog when invalid Product ID in the XLS file linked to a ProductCategory' do

        expect {
          post "/webmis/product_sets/pds_import", cat_id: product_category.id
        }.to change(PdsProduct, :count).by(0)

        checklog = assigns(:checklog)

        expect(checklog.errors_or_warnings?).to eq true
        expect(checklog.ok?).to eq false
        expect(checklog.to_s).to include "Validation failed:"
        expect(checklog.to_s).to include "contains invalid chars"
      end
    end

  end
end
