require 'rails_helper'

shared_examples_for 'change_log' do
  let(:model) { described_class } # the class that includes the concern
  let(:instance) { create(model.to_s.underscore.to_sym) }
  let(:user) { create(:user) }

  context 'preconditions' do
    it 'it should have a name method' do
      expect { instance.name }.to_not raise_exception
    end
  end

  context 'Empty change log' do
    it 'has no change log lines' do
      expect(model.new.all_change_log_lines).to be_empty
    end

    it 'has an empty formatted change_log string' do
      expect(model.new.formatted_change_log).to eq ''
    end
  end

  context 'A created instance will at least have a creation message in its change log and implicitly tests the update_change_log' do
    it 'has change log lines' do
      expect(instance.all_change_log_lines).not_to be_empty
    end

    it 'has a filled formatted change_log string' do
      expect(instance.formatted_change_log).not_to be_empty
    end

    # Note that it is not easily possible to explicitly test update_change_log because that test would require a change in one of the
    # monitored instance attributes. For now just test whether we can just call the method without an internal server error
    it 'can call update_change_log' do
      expect { instance.update_change_log }.to_not raise_exception
    end
  end

  context 'add change_log_line' do
    it 'can add change_log_lines with a specific text' do
      instance.add_change_log_line('Line1 is added.')
      instance.add_change_log_line('Line2 is added.')
      expect(instance.change_log_lines.where(description: 'Line1 is added.')).to_not be_empty
      expect(instance.formatted_change_log).to include('Line2 is added.')
    end
  end

end