require 'rails_helper'

shared_examples_for 'handle_status' do |*flags|
  let(:model) { described_class } # the class that includes the concern
  let(:instance) { create(model.to_s.underscore.to_sym) }

  context 'Validations' do
    it { is_expected.to validate_presence_of(:status) }
  end

  context 'Active scope' do
    it 'has a scope with at least one non-obsolete instance' do
      expect(instance.class.active).not_to be_empty
      expect { instance.update_attribute(:status, model::END_STATUSES.first) }.to change(instance.class.active, :count).by(-1)
    end
  end

  context 'Properly setup' do
    it 'the class has defined the hash STATUS_HASH of possible statuses and the array END_STATUSES with at least one end-status' do
      expect(model.status_hash).to be_a Hash
      expect(model.status_hash).not_to be_empty
      expect(model::END_STATUSES).to be_a Array
      expect(model::END_STATUSES).not_to be_empty
      expect(model::END_STATUSES - model.status_hash.keys).to be_empty
    end

    it 'can return the stringified version of a status' do
      expect(instance.status_str).to eq model.status_hash[instance.status]
    end
  end

  unless flags.include?(:skip_status_change)
    context 'Setting and Changing Status' do

      it 'invalidates a transition to the current state' do
        expect(instance.status_change_valid?(instance.status)).to be_falsey
      end

      it 'invalidates a transition to a non-existing state' do
        expect(instance.status_change_valid?('xdfdfarev')).to be_falsey
      end

      it 'invalidates a transition from an end status' do
        instance.status = model::END_STATUSES.first
        expect(instance.status_change_valid?((model.status_hash.keys - model::END_STATUSES).first)).to be_falsey
      end

      it 'validates a transition from a non-end status to an end-status' do
        instance.status = (model.status_hash.keys - model::END_STATUSES).first
        expect(instance.status_change_valid?(model::END_STATUSES.first)).to be_truthy
      end

      it 'implements the allow_status_change method' do
        expect(instance.allow_status_change?(instance.status)).to be_falsey
      end

      it 'validates the current status' do
        expect(instance.allow_status?(instance.status)).to be_truthy
      end

      it 'validates a status if the status change is allowed' do
        allow_any_instance_of(model).to receive(:allow_status_change?) { true }
        expect(instance.allow_status?(model::END_STATUSES.first)).to be_truthy
      end

      it 'validates a status if the status change is not allowed' do
        allow_any_instance_of(model).to receive(:allow_status_change?) { false }
        expect(instance.allow_status?(model::END_STATUSES.first)).to be_falsey
      end

      it 'does not change a status to itself' do
        new_status = instance.status
        val = instance.change_status(new_status)
        expect(val).to be_falsey
        expect(instance.status).to eq(new_status)
      end

      it 'does not change a status if the status change is not allowed' do
        allow_any_instance_of(model).to receive(:allow_status_change?) { false }
        new_status = model::END_STATUSES.first
        val = instance.change_status(new_status)
        expect(val).to be_falsey
        expect(instance.status).to_not eq(new_status)
      end

      it 'does change a status if the status change is allowed' do
        allow_any_instance_of(model).to receive(:allow_status_change?) { true }
        new_status = model::END_STATUSES.first
        val = instance.change_status(new_status)
        expect(val).to be_truthy
        expect(instance.status).to eq(new_status)
      end

      it 'allows the current state' do
        expect(instance.allow_status?(instance.status)).to be_truthy
      end

      it 'disallows a non-existing state when not already in it' do
        expect(instance.allow_status?('xdfdfarev')).to be_falsey
      end

      it 'disallows a different status when in an end status' do
        instance.status = model::END_STATUSES.first
        expect(instance.allow_status?((model.status_hash.keys - model::END_STATUSES).first)).to be_falsey
      end

      it 'checks on an end status' do
        expect(instance.end_status?).to be_falsey
        instance.status = model::END_STATUSES.first
        expect(instance.end_status?).to be_truthy
      end
    end
  end
end
