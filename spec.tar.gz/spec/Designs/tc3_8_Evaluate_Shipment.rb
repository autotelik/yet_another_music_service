# Secnario for Request Shipment
# Precondition: Production order is in Production status, Product orderline is on Handle test status with Evaluate button Enabled and Message - Manual testing in progress
# The Request shipment button is available once Evaluate button is clicked
 
context 'When I go to Production --> Production orders' do
   scenario 'Then the Production orders page is displayed' do
	# visit URL <http://backofficestaging.mapscape.nl/webmis/production_orders>
   end
end

context 'When I input a string in search field' do
  context 'And I click Search button' do
   scenario 'Then the details of the Production order matching to the string searched is displayed' do
     	# visit URL <http://backofficestaging.mapscape.nl/webmis/production_orders>
	# search: 14310
   end
 end
end


context 'When I click the dropdown button Action against the Production order searched above' do
  context 'And I click handle' do			
   scenario 'Then the Production order is opened with the Evaluate button enabled for the Product orderline, status - Handle test and message - Manual testing in progress' do
	# URL <http://backofficestaging.mapscape.nl/webmis/production_orders/14310/handle>
   end
 end
end

context 'When I click Evaluate button' do
   scenario 'Then message is displayed on the top right screen - Production orderline 28909 status changed to Evaluate., two buttons are enabled Re-request conversion and Request shipment, Status changed - Evaluate with Message - ACTION REQUIRED: Accept or reject the test results and also and email is generated' do
	# URL <http://backofficestaging.mapscape.nl/webmis/production_orders/14310/handle>
	# Email with below subject is also generated for Status change:     
	# WebMIS DEVELOPMENT TEST => Production Orderline 28909 MP173-1454 "1_BMW EE HER 17Q3 ROW ISR 1454" in status "Evaluate"
   
   end
end

context 'When I click Request shipment button' do
   scenario 'Then message is displayed on the top right screen - Production orderline 28909 status changed to Request shipment., three buttons are enabled Handle conversion, Handle shipment and Ship Automatic, Status changed - Request Shipmet with Message - ACTION REQUIRED: Request the shipment and also and email is generated' do
	# URL <http://backofficestaging.mapscape.nl/webmis/production_orders/14310/handle>
	# Email with below subject is also generated for Status change:     
	# WebMIS DEVELOPMENT TEST => Production Orderline 28909 MP173-1454 "1_BMW EE HER 17Q3 ROW ISR 1454" in status "Request shipment"
   
   end
end

context 'When I go to Shipping --> Shipment requests' do
   scenario 'Then the Shipment requests page is displayed' do
	# URL <http://backofficestaging.mapscape.nl/webmis/production_orderlines/shipment_index>
   end
end

context 'When I input a string in search field' do
  context 'And I click Search button' do
   scenario 'Then the details of the Production orderline matching to the string searched is displayed' do
	# URL <http://backofficestaging.mapscape.nl/webmis/production_orderlines/shipment_index>
	# search: 28909
   end
 end
end

context 'When I click the dropdown button Action against the Production orderline searched above' do
  context 'And I click Ship product' do			
   scenario 'Then the Edit Shipment (Outbound order) MP173-1454 page is opened' do
	# URL <http://backofficestaging.mapscape.nl/webmis/outbound_orders/26073/edit?bulk=true&return_to_action=show_shipment_request&return_to_controller=production_orderlines&return_to_id=28909>
   end
 end
end

context 'When I fill in the Edit Shipment (Outbound order) MP173-1454 form with all required fields' do
  context 'And I click the Save button' do
   scenario 'Then message is displayed on the top right screen and the Handle Shipment (Outbound order) MP173-1454 screen is displayed - Shipping successfully updated.' do
	# URL <http://backofficestaging.mapscape.nl/webmis/outbound_orders/26073/edit?bulk=true&return_to_action=show_shipment_request&return_to_controller=production_orderlines&return_to_id=28909>
  
        # Below are the filelds/selection boxes and the data which can be used in them:
        # Shipping type: Manual(S)FTP
	# Shipping specification: BMW EntryNavEVO
	# File transfer account: user04 - searched is not available
	# Sftp subdirectory: /outgoing/
	# Distribution list: BMW EntryNav EVO NDS
	# Send date: 2017-09-26
	# Send by: Manish Nimje
	# Release mail send?: check
	# Release mail send date: 2017-09-26
	# Bcc list: grayed out - Filled from distribution list
	# Remarks: Automatically created as part of the order type NDS_BMW work flow.
	# Mailing remarks: BMW Testing 
	# Content (Outbound orderlines)
	# Id: 30604 - Already filled
	# Registered product: MP173-1454 - searched is not available
	# Packing specification: Multiple items in one .tar.gz
	# Packing destination directory override: /data/product/MP173-1454ISR/R00
     
	# After Save: URL /<http://backofficestaging.mapscape.nl/webmis/outbound_orders/26073/handle>
    end
   end
end

context 'When I click on force order to complete button on page Handle Shipment (Outbound order) MP173-1454' do
   scenario 'Then message is displayed on the top right screen - Order forced to complete, and status is changed from manual to shipped ' do
	# URL /<http://backofficestaging.mapscape.nl/webmis/outbound_orders/26073/handle>

   end
end
