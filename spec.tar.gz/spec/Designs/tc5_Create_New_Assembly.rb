# Scenario to determine that new assembly can be created successfully
 
context 'When I go to Conversion --> Assemblies' do
   scenario 'Then the Assemblies headers page is displayed' do
	# visit URL <http://backofficestaging.mapscape.nl/webmis/assembly_headers>

   end
end

context 'When I click new button' do
   scenario 'Then the New assembly page is displayed' do
	# visit URL <http://backofficestaging.mapscape.nl/webmis/assembly_headers/new>

   end
end

context 'When I fill in the New assembly page form with all required fields' do
  context 'And I click the Save button' do
   scenario 'Assembly is saved with message - AssemblyHeader was successfully created.' do
	# URL <http://backofficestaging.mapscape.nl/webmis/assembly_headers/new>
  
        # Below are the filelds/selection boxes and the data which can be used in them:
        # Product: MP171-1552b-test
	# Name: VW 0716 NAR TEST
	# Output format: NDS
	# Remarks: TESTING PURPOSE

    end
   end
end

# Verify that the above assembly is created successfully.

context 'When I go to Conversion --> Assemblies' do
   scenario 'Then the Assemblies headers page is displayed' do
	# visit URL <http://backofficestaging.mapscape.nl/webmis/assembly_headers>

   end
end

context 'When I input a string in search field' do
  context 'And I click Search button' do
   scenario 'Then the details of the Assembly matching to the string searched is displayed' do
	# visit URL <http://backofficestaging.mapscape.nl/webmis/assembly_headers>
	# search: MP171-1552b-test

   end
 end
end

# Fill in the conversions, data sets, receptions.

context 'When I click the dropdown button Action against the Assembly searched above' do
  context 'And I click show' do			
   scenario 'Then the Assembly is opened' do
      	# URL <http://backofficestaging.mapscape.nl/webmis/assembly_headers/3559>

   end
 end
end

context 'When I click edit button' do
   scenario 'Then the Input for Assembly page opens' do
	# visit URL <http://backofficestaging.mapscape.nl/webmis/assembly_headers/3559/edit>

   end
end

context 'When I fill in the conversions, data sets, receptions field and click the Search ID button' do
   scenario 'Then requested conversion-id should be shown as search result' do
	# visit URL <http://backofficestaging.mapscape.nl/webmis/assembly_headers/3559/edit>
        # search: 96570
 
   end
end

context 'When I click select button besides the searched result above' do
   scenario 'Then the Pop-up with all databases from the conversion-id opens' do
	# visit URL <http://backofficestaging.mapscape.nl/webmis/assembly_headers/3559/edit?utf8=%E2%9C%93&direction=&sort=&search=96570>

   end
end

context 'When I click the check all box and click on the Add lines button' do
   scenario 'Then all lines are selected and added to the Assembly content part' do
	# visit URL <http://backofficestaging.mapscape.nl/webmis/assembly_headers/3559/edit?utf8=%E2%9C%93&direction=&sort=&search=96570>

   end
end

context 'When I click on the show button' do
   scenario 'Then the created assembly is being shown' do
	# visit URL <http://backofficestaging.mapscape.nl/webmis/assembly_headers/3559>
       
        # Below are the filelds which can be verified
        # Product: MP171-1552b-test
	# Name: VW 0716 NAR TEST
	# Input lines with conversion id: 96570
	# Remarks: TESTING PURPOSE

   end
end

