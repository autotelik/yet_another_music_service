# Secnario for Assign Test after Conversion is finished
# Precondition: Production order is in Production status and the Conversion job should be finished successfully for Product orderline and Assign Test button should be enabled with status - Request test and message - ACTION REQUIRED: Request Test

context 'When I go to Production --> Production orders' do
   scenario 'Then the Production orders page is displayed' do
	# visit URL <http://backofficestaging.mapscape.nl/webmis/production_orders>
   end
end

context 'When I input a string in search field' do
  context 'And I click Search button' do
   scenario 'Then the details of the Production order matching to the string searched is displayed' do
     	# visit URL <http://backofficestaging.mapscape.nl/webmis/production_orders>
	# search: 14310
   end
 end
end

context 'When I click the dropdown button Action against the Production order searched above' do
  context 'And I click handle' do			
   scenario 'Then the Production order is opened with the Assign Test button enabled for the Product orderline, status - Request test and message - ACTION REQUIRED: Request Test' do
      	# URL <http://backofficestaging.mapscape.nl/webmis/production_orders/14310/handle>
   end
 end
end

context 'When I click Assign Test button' do
   scenario 'Then the New Test Request page opens' do
        # URL < http://backofficestaging.mapscape.nl/webmis/test_requests/new?production_orderline_id=28909&return_to_action=handle&return_to_controller=production_orders&return_to_id=14310>
   end
end

context 'When I fill in the New Test Request form with all required fields' do
  context 'And I click the Save button' do
   scenario 'Then message is displayed on the top right screen and the related production order screen is displayed - TestRequest was successfully created and sent to Manish Nimje, 2 Emails are generated one for test request and other for status change and the Product Line Evaluate button is displayed and the status is on ?Handle test? with Message ?Manual testing in progress' do
        # URL < http://backofficestaging.mapscape.nl/webmis/test_requests/new?production_orderline_id=28909&return_to_action=handle&return_to_controller=production_orders&return_to_id=14310>
        # Below are the filelds/selection boxes and the data which can be used in them:
	# Requester: Manish Nimje - Already filled
	# Assigned to: Manish Nimje 
	# Test type: Product validation
	# Product: MP173-1454 - Already filled
	# Start date: 2017-09-22  - Already filled
	# Finish date: 2017-09-22  - Already filled
	# Test database: 106169 /data/projects/webmis_staging/output/nds_bmw_master/asi/o_20170922-132809-375946-isr_her_2017_q3_dvn171f1_bmw_entrynavevo_eb_20170821v1b_master/ROOT.NDS - Already filled
	# Reference database: 106169 /data/projects/webmis_staging/output/nds_bmw_master/asi/o_20170922-132809-375946-isr_her_2017_q3_dvn171f1_bmw_entrynavevo_eb_20170821v1b_master/ROOT.NDS - Filled if specified in earlier stages

     	# Email with below subject is also generated for Test request:
	# WebMIS DEVELOPMENT TEST => Test Request 4890 Product validation MP173-1454
     
	# Email with below subject is also generated for Status change:
	# WebMIS DEVELOPMENT TEST => Production Orderline 28909 MP173-1454 "1_BMW EE HER 17Q3 ROW ISR 1454" in status "Handle test"
   
    end
   end
end

context 'When I click on Show for the Product orderline' do
   scenario 'Then the page is displayed with Conversion and Test details associated to this particular product orderline' do
      	# URL <http://backofficestaging.mapscape.nl/webmis/production_orders/14310/handle>
   end
end

context 'When I click hyperlink under Test request' do
   scenario 'Then it displays the test request which we created in above steps' do
      	# URL <http://backofficestaging.mapscape.nl/webmis/test_requests/4890>
	# Test request: 4890
   end
end

context 'When I click handle icon' do
   scenario 'Then Cancel Test, Start Test, Finish Test and Update result test buttons get visible, Also Download Test tab is shown with Download button' do
      	# URL <http://backofficestaging.mapscape.nl/webmis/test_requests/4890/handle>
   end
end

context 'When I click on Start Test button' do
   scenario 'Then message is displayed on the top right screen - Test marked as started. and the Status is turned to RUNNING on page Testing --> Test request' do
      	# URL <http://backofficestaging.mapscape.nl/webmis/test_requests/4890/handle>
   end
end

context 'When I click on Update Result button' do
   scenario 'Then tab Remarks from test engineer tab opens' do
      	# URL <http://backofficestaging.mapscape.nl/webmis/test_requests/4890/handle>
   end
end

context 'When I fill in the Remarks from test engineer form with all required fields' do
   context 'And I click the Save button' do
    scenario 'Then message is displayed on the top right screen - TestRequest was successfully updated. The Remarks from test engineer section is added on the  Handle test request with saved details, Also a mail is generated and sent to the Assignee' do
      	# URL <http://backofficestaging.mapscape.nl/webmis/test_requests/4890/handle>
        # Below are the filelds/selection boxes and the data which can be used in them:
	# Remarks result: Test successfull
	# Actual Start date: 2017-09-26 - Already filled
	# Actual Finish date: 2017-09-26 - Already filled

        # Email with below subject is also generated for Test request:
	# WebMIS DEVELOPMENT UPDATE => Test Request 4890 Product validation MP173-1454

   end
  end
end

context 'When I click on Finish Test button' do
   scenario 'Then message is displayed on the top right screen - Result is send to requester. and the Status is turned to FINISHED on page Testing --> Test request, Also a mail is generated and sent to the Assignee' do
      	# URL <http://backofficestaging.mapscape.nl/webmis/test_requests/4890/handle>
      	# URL <http://backofficestaging.mapscape.nl/webmis/test_requests>
     	# Search Test request: 4890
        # Email with below subject is also generated for Test request:
	# WebMIS DEVELOPMENT TEST => Test Result 4890 Product validation MP173-1454

   end
end

# Precondition: The test request should not be on Finished state

context 'When I click on Cancel Test button' do
   scenario 'Then message is displayed on the top right screen - Cancellation is send to requester.  and the Status is turned to CANCELED on page Testing --> Test request, Also a mail is generated and sent to the Assignee' do
      	# URL <http://backofficestaging.mapscape.nl/webmis/test_requests/4890/handle>
      	# URL <http://backofficestaging.mapscape.nl/webmis/test_requests>
     	# Search Test request: 4890
        # Email with below subject is also generated for Test request:
	# WebMIS DEVELOPMENT TEST => Test Result 4890 Product validation MP173-1454

   end
end

