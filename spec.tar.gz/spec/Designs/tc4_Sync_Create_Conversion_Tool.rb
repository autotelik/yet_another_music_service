# Scenario to determine that a conversion tool be sync'd and created 
 
context 'When I go to Conversion --> Conversion tools' do
   scenario 'Then the Conversion tools page is displayed' do
	# visit URL <http://backofficestaging.mapscape.nl/webmis/conversiontools>
   end
end

context 'When I click sync button' do
   scenario 'Then the sync is done and New released tool will be displayed on the top and a notice is displayed - Notice:Active conversion tools synchronized with the file system.' do

   end
end

context 'When I go to Conversion --> Conversion tools' do
   scenario 'Then the Conversion tools page is displayed' do
	# visit URL <http://backofficestaging.mapscape.nl/webmis/conversiontools>
   end
end

context 'When I click new button' do
   scenario 'Then the New Conversion tool: page is displayed' do
	# visit URL <http://backofficestaging.mapscape.nl/webmis/conversiontools/new>
   end
end


context 'When I fill in the New Conversion tool: page form with all required fields' do
  context 'And I click the Save conversiontool button' do
   scenario 'Conversion Tool is saved with message - Notice: Conversiontool was successfully created. ' do
	# URL <http://backofficestaging.mapscape.nl/webmis/conversiontools/new>
  
        # Below are the filelds/selection boxes and the data which can be used in them:
        # Code(release): BladeRunner_20171011_TEST
	# Description: BladeRunner test 
	# Remarks: Testing purpose
	# Active: Check box already selected
    
    end
   end
end
