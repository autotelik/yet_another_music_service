# Scenario for Automated Conversion
# Execution Preconditions: 
#- The user is able to handle production orders
#- The New production order can be created from production --> Product Sets, Reception --> Data sets, Data set Groups
#- The New production order is created with Allow production and Allow shipment checkbox checked

context 'When I go to Production --> Product sets' do
   scenario 'Then the Product sets page is displayed' do
	# visit URL <http://backofficestaging.mapscape.nl/webmis/production_orders>
   end
end

context 'When I input a string in search field' do
  context 'And I click Search button' do
   scenario 'Then the details of the Product set code matching to the string searched is displayed' do
     	# visit URL <http://backofficestaging.mapscape.nl/webmis/production_orders>
     	# search: BMW EE HER 17Q3 ROW ISR 1454
   end
 end
end

context 'When I click the dropdown button Action against the product set searched above' do
  context 'And I click New procuction order' do			
   scenario 'Then the New Production order page is displayed - with status Order entry in blue box' do
     	# URL <http://backofficestaging.mapscape.nl/webmis/production_orders/new?productset_id=4105>
   end
 end
end

context 'When I fill in the New Production order form with all required fields' do
  context 'And I click the Save button' do
     scenario 'Then A message is being displayed on the top right corner of the screen:Production Order was successfully created. And we are already in the production order we just created in handle mode with status Order entry' do
      	# URL <http://backofficestaging.mapscape.nl/webmis/production_orders/new?productset_id=4105>
	# Below are the filelds/selection boxes and the data which can be used in them:
	# Product set: BMW EE HER 17Q3 ROW ISR 1454 - Already filled
	# Name: BMW EE HER 17Q3 ROW ISR 1454 - Already filled - Can be modified
	# Baseline commitment date - 2017-09-30
	# Modified commitment date - 2017-09-30
	# Permissions:
	#   Allow production - Check
	#   Allow shipment - Check
	#   Redelivery? - Unchecked
	# Order type - NDS_BMW
	# Distribution list - BMW EntryNav EVo NDS
	# Remarks - Testing purpose
     end
   end
end

context 'When I click the button Planning' do			
   scenario 'Then A message is being displayed on the top right corner of the screen:ProductionOrder 14310 set to Planning. And status is changed to Planning, Also the button is now changed to Production' do
      	# URL <http://backofficestaging.mapscape.nl/webmis/production_orders/14310/handle>
   end
end

context 'When I click the button Production' do			
   scenario 'Then A message is being displayed on the top right corner of the screen:ProductionOrder 14310 set to Production. And status is changed to Production, Also the button is now changed to Force Finished and turned Red and Handle conversion button is enabled for Product Line' do
      	# URL <http://backofficestaging.mapscape.nl/webmis/production_orderlines/28909/handle>
   end
end

context 'When I click Handle conversion button for Product Order line' do			
   scenario 'Then a New page opens where production orderline can be edited' do
      	# URL <http://backofficestaging.mapscape.nl/webmis/production_orders/14310/handle>
   end
end

context 'When I fill in the Edit Production orderline form with all required fields' do
  context 'And I click the Save button' do
     scenario 'Then Production order check is done, warnings are ok but no error should occur' do
      	# URL <http://backofficestaging.mapscape.nl/webmis/production_orders/14310/handle>

        # Below are the filelds/selection boxes and the data which can be used in them:
	# Ship?: Already Checked
        # Product line: BMWEEV ISR - Already filled
        # Rdo file path: 
	# Check/run automatic conversion: Already Checked
	# Force creating step(s) - NDS_BMW_MASTER_ISR: Check
        # All the below steps are for NDS_BMW_MASTER_ISR step
	# Test this: Check
	# Do manual: Uncheck
	# Conversion tool: BladeRunner_20170821_1 - Already filled
	# Conversion tool bundle: bmw_ene_eb_cw1738 - Already filled
	# Conversion script release: ConvScripts_20170821_2 - Already filled
	# CVEEngine release: CVEEngine_20170822_1 - Already filled
	# Uncheck everything else
     end
   end
end

context 'When I click Create Product Order button' do			
   scenario 'Then Processing is done and particular Production order page is opened with the requested product orderline on status Handle conversion, Wait for few minutes and with the internal processes the conversion is queued and then goes to Processing as the conversion starts on server automatically. Email is also generated' do
	# Below is the Message   
	# Below status message is displayed: 
	# Total 1, Processing 1 

	# Email with below subject is also generated:
	# WebMIS DEVELOPMENT TEST => Production order 14310 "1_BMW EE HER 17Q3 ROW ISR 1454" in status "Production"

   end
end

context 'When I go to Conversion --> Server overview' do			
   scenario 'Then the server overview page opens and the conversion can be seen running under one of the server' do
	# visit URL <http://backofficestaging.mapscape.nl/webmis/servers/overview?project_id=1>
   end
end

context 'When the conversion is finished on the Server overview' do			
   scenario 'Then the conversion job is removed from the server and is not available in the queue' do

   end
end

context 'When I go to Production --> Production orders' do
   scenario 'Then the Production orders page is displayed' do
	# visit URL <http://backofficestaging.mapscape.nl/webmis/production_orders>
   end
end

context 'When I input a string in search field' do
  context 'And I click Search button' do
   scenario 'Then the details of the Production order matching to the string searched is displayed' do
     	# visit URL <http://backofficestaging.mapscape.nl/webmis/production_orders>
	# search: 14310
   end
 end
end

context 'When I click the dropdown button Action against the Production order searched above' do
  context 'And I click handle' do			
   scenario 'Then the Production order is opened with the Assign Test button enabled for the Product orderline, status - Request test and message - ACTION REQUIRED: Request Test' do
      	# URL <http://backofficestaging.mapscape.nl/webmis/production_orders/14310/handle>
   end
 end
end

context 'When I click Assign Test button' do
   scenario 'Then the New Test Request page opens' do
        # URL < http://backofficestaging.mapscape.nl/webmis/test_requests/new?production_orderline_id=28909&return_to_action=handle&return_to_controller=production_orders&return_to_id=14310>
   end
end

context 'When I fill in the New Test Request form with all required fields' do
  context 'And I click the Save button' do
   scenario 'Then message is displayed on the top right screen and the related production order screen is displayed - TestRequest was successfully created and sent to Manish Nimje, 2 Emails are generated one for test request and other for status change and the Product Line Evaluate button is displayed and the status is on ?Handle test? with Message ?Manual testing in progress' do
        # URL < http://backofficestaging.mapscape.nl/webmis/test_requests/new?production_orderline_id=28909&return_to_action=handle&return_to_controller=production_orders&return_to_id=14310>
        
        # Below are the filelds/selection boxes and the data which can be used in them:
	# Requester: Manish Nimje - Already filled
	# Assigned to: Manish Nimje 
	# Test type: Product validation
	# Product: MP173-1454 - Already filled
	# Start date: 2017-09-22  - Already filled
	# Finish date: 2017-09-22  - Already filled
	# Test database: 106169 /data/projects/webmis_staging/output/nds_bmw_master/asi/o_20170922-132809-375946-isr_her_2017_q3_dvn171f1_bmw_entrynavevo_eb_20170821v1b_master/ROOT.NDS - Already filled
	# Reference database: 106169 /data/projects/webmis_staging/output/nds_bmw_master/asi/o_20170922-132809-375946-isr_her_2017_q3_dvn171f1_bmw_entrynavevo_eb_20170821v1b_master/ROOT.NDS - Filled if specified in earlier stages

     	# Email with below subject is also generated for Test request:
	# WebMIS DEVELOPMENT TEST => Test Request 4890 Product validation MP173-1454
     
	# Email with below subject is also generated for Status change:
	# WebMIS DEVELOPMENT TEST => Production Orderline 28909 MP173-1454 "1_BMW EE HER 17Q3 ROW ISR 1454" in status "Handle test"
   
    end
   end
end

#Note: The complete Assign Test request scenario is covered in tc3_7_Assign_Test.rb

context 'When I click Evaluate button' do
   scenario 'Then message is displayed on the top right screen - Production orderline 28909 status changed to Evaluate., two buttons are enabled Re-request conversion and Request shipment, Status changed - Evaluate with Message - ACTION REQUIRED: Accept or reject the test results and also and email is generated' do
	# Email with below subject is also generated for Status change:     
	# WebMIS DEVELOPMENT TEST => Production Orderline 28909 MP173-1454 "1_BMW EE HER 17Q3 ROW ISR 1454" in status "Evaluate"
   
   end
end

context 'When I click Request shipment button' do
   scenario 'Then message is displayed on the top right screen - Production orderline 28909 status changed to Request shipment., three buttons are enabled Handle conversion, Handle shipment and Ship Automatic, Status changed - Request Shipment with Message - ACTION REQUIRED: Request the shipment and also and email is generated' do
      	# URL <http://backofficestaging.mapscape.nl/webmis/production_orders/14310/handle>
	# Email with below subject is also generated for Status change:     
	# WebMIS DEVELOPMENT TEST => Production Orderline 28909 MP173-1454 "1_BMW EE HER 17Q3 ROW ISR 1454" in status "Request shipment"
   end
end

#Note: The complete Shipment request scenario is covered in tc3_8_Evaluate_Shipment.rb

context 'When I click Handle shipment button' do
   scenario 'Then message is displayed on the top right screen -Production orderline 28909 status changed to Handle shipment., Finished button is enabled, Status changed - Handle Shipment with Message - ACTION REQUIRED: Outbound 1, shipped 1 and also and email is generated' do
	# Email with below subject is also generated for Status change:     
	# WebMIS DEVELOPMENT TEST => Production Orderline 28909 MP173-1454 "1_BMW EE HER 17Q3 ROW ISR 1454" in status "Handle shipment"
      	# URL <http://backofficestaging.mapscape.nl/webmis/production_orders/14310/handle>
   end
end

context 'When I click Finished button' do
   scenario 'Then Everything Greyed out and Production order status changes to Finished, message is displayed on the top right screen - Production orderline 28909 status changed to Finished., Status changed - Finished with Message - Finished: Total jobs: 1, databases: 1, shipped 1 and also and email is generated' do
	# Email with below subject is also generated for Status change:     
	# WebMIS DEVELOPMENT TEST => Production Orderline 28909 MP173-1454 "1_BMW EE HER 17Q3 ROW ISR 1454" in status "Finished"
      	# URL <http://backofficestaging.mapscape.nl/webmis/production_orders/14310/handle>
   end
end

context 'When I go to Production --> Production orders' do
   scenario 'Then the Production orders page is displayed' do
	# visit URL <http://backofficestaging.mapscape.nl/webmis/production_orders>
   end
end

context 'When I input a Production order ID in search field' do
  context 'And I click Toggle button Including Finished' do
      context 'And I click Search button' do
   scenario 'Then the details of the Product set code matching to the string searched is displayed with status Finished' do
	# visit URL <http://backofficestaging.mapscape.nl/webmis/production_orders>
	# search: 14310
   end
 end
end
