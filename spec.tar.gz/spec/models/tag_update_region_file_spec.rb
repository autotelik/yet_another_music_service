require 'rails_helper'

describe TagUpdateRegionFile do
  let!(:tag_update_region_file1) { create(:tag_update_region_file) }
  let!(:tag_update_region_file2) { create(:tag_update_region_file_inactive) }
  let!(:tag_update_region_file3) { create(:tag_update_region_file_nonexisting) }

  let(:proj_PRODUCTION)   { create(:proj_PRODUCTION) }
  let(:proj_REGRESSION)   { create(:proj_REGRESSION) }

  let(:tagdir_latest) { File.join(scratch_path, "#{TagUpdateRegionFile::TAG_UPDATE_REGION_FILE_SUBDIR}", "#{TagUpdateRegionFile::TAG_UPDATE_REGION_FILE_DIR_PREFIX}_20180501") }
  let(:product_line_abbr) { 'MSEUR' }
  let(:partial_name) { 'gen_nds_eur' }

  it 'has a valid tag environment' do
    FileUtils.mkdir_p(tagdir_latest)
    FileUtils.ln_s(tagdir_latest, File.join(scratch_path, "#{TagUpdateRegionFile::TAG_UPDATE_REGION_FILE_SUBDIR}", "#{TagUpdateRegionFile::TAG_UPDATE_REGION_FILE_DIR_PREFIX}_latest"))
    FileUtils.mkdir(File.dirname(tag_update_region_file1.path))
    FileUtils.cp(factory_file(File.basename(tag_update_region_file1.path)), tag_update_region_file1.path)
    FileUtils.cp(factory_file(File.basename(tag_update_region_file2.path)), tag_update_region_file2.path)
  end

  it 'handles active_existing correctly' do
    tf = tag_update_region_file2
    expect(tf.path).to eq tag_update_region_file2.path
    expect(tf.active_yn).to eq false

    tf = tf.active_existing
    expect(tf.path).to eq tag_update_region_file1.path
    expect(tf.active_yn).to eq true
  end
 
  it 'handles calculated_md5sum correctly' do
    tf = tag_update_region_file1
    expect(TagUpdateRegionFile.calculated_md5sum(tf.path)).to eq tf.md5sum
  end

  it 'handles released_or_local_path correctly' do
    path = TagUpdateRegionFile.released_or_local_path(tag_update_region_file1.path, tag_update_region_file2.path)
    expect(path).to eq tag_update_region_file2.path

    path = TagUpdateRegionFile.released_or_local_path(tag_update_region_file2.path, tag_update_region_file1.path)
    expect(path).to eq tag_update_region_file1.path

    path = TagUpdateRegionFile.released_or_local_path(tag_update_region_file1.path, tag_update_region_file3.path)
    expect(path).to eq tag_update_region_file1.path

    path = TagUpdateRegionFile.released_or_local_path(tag_update_region_file3.path, tag_update_region_file1.path)
    expect(path).to eq tag_update_region_file1.path

    path = TagUpdateRegionFile.released_or_local_path(tag_update_region_file3.path, tag_update_region_file3.path)
    expect(path).to eq ""
  end

  it 'handles released_path correctly' do
    create(:local_tool_dir, project: proj_PRODUCTION)

    path = TagUpdateRegionFile.released_path(product_line_abbr, partial_name)
    expect(path).to eq "#{tagdir_latest}/#{product_line_abbr}/#{partial_name}.#{TagUpdateRegionFile::TAG_UPDATE_REGION_FILE_POSTFIX}"
  end

  it 'handles local_path correctly' do
    local_tool_dir = create(:ADDITIONAL_DESIGNS_DIR_LOCAL, project: proj_REGRESSION)
    path = TagUpdateRegionFile.local_path(product_line_abbr, partial_name, proj_REGRESSION)
    expect(path).to eq "#{local_tool_dir.cfg_value}/#{ConfigParameter::LOCAL_TOOL_SUBDIR}/#{TagUpdateRegionFile::TAG_UPDATE_REGION_FILE_DIR_PREFIX}/#{product_line_abbr}/#{partial_name}.#{TagUpdateRegionFile::TAG_UPDATE_REGION_FILE_POSTFIX}"
  end

  it 'handles sync_with_filesystem correctly' do
    create(:local_tool_dir, project: proj_PRODUCTION)

    tag_update_region_file1.active_yn = false
    tag_update_region_file1.save

    tag_update_region_file2.active_yn = false
    tag_update_region_file2.save

    tag_update_region_file3.active_yn = true
    tag_update_region_file3.save

    TagUpdateRegionFile.sync_with_filesystem

    tag_update_region_file1.reload
    expect(tag_update_region_file1.active_yn).to eq true

    tag_update_region_file2.reload
    expect(tag_update_region_file2.active_yn).to eq true

    tag_update_region_file3.reload
    expect(tag_update_region_file3.active_yn).to eq false

  end
end
