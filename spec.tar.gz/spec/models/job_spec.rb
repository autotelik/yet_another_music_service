# Format inspired by the following Rspec model template:
# https://gist.github.com/kyletcarlson/6234923#file-rspec_model_testing_template-rb-L4

# Gems used to make the following tests possible:
# rspec-rails: https://github.com/rspec/rspec-rails
# Shoulda-matchers: https://github.com/thoughtbot/shoulda-matchers
# shoulda-callback-matchers: https://github.com/beatrichartz/shoulda-callback-matchers
# factory_girl_rails: https://github.com/thoughtbot/factory_girl_rails

require 'rails_helper'

describe Job do
  it 'has a valid Factory' do
    expect(create(:job)).to be_valid
  end

  # Lazily loaded to ensure it's only used when it's needed
  # RSpec tip: Try to avoid @instance_variables if possible. They're slow.
  let(:job) { build_stubbed(:job) }

  describe 'ActiveRecord associations' do
    # Associations
    it { should belong_to(:fail_category_logged_by_user) }
    it { should belong_to(:original_job) }
    it { should belong_to(:project) }
    # Database columns/indexes
    # TODO: if needed, establish for which attributes these kind of tests need to exist
    it { should have_db_column(:conversion_id) }
  end

  context 'callbacks' do
    let(:job) { create(:job) }

    it { expect(job).to callback(:before_save).before(:save) }
    it do
      expect_any_instance_of(Job).to receive(:defaults)
      Job.new
    end
  end

  # a job's status, by database default, will be 10(STATUS_PLANNED) once initialized
  describe 'scopes' do
    it '.outstanding returns all jobs with status < STATUS_CANCELLED' do
      job = create(:job)
      expect(Job.outstanding.first).to eq(job)
    end

    it '.processing returns all jobs with status = STATUS_PROCESSING' do
      job = create(:job, status: Job::STATUS_PROCESSING)
      expect(Job.processing.first).to eq(job)
    end

    it '.planned returns all jobs with status = STATUS_QUEUED or status = STATUS_HOLD' do
      create(:job, status: Job::STATUS_QUEUED)
      create(:job, status: Job::STATUS_HOLD)
      expect(Job.planned.size).to eq(2)
    end

    it '.on_server returns all jobs with file_system_status >= FILE_SYSTEM_STATUS_ON_SERVER' do
      job = create(:job, file_system_status: Job::FILE_SYSTEM_STATUS_ON_SERVER)
      expect(Job.on_server.first).to eq(job)
    end

    it '.in_queue returns all jobs with status = STATUS_MANUAL or status = STATUS_HOLD' do
      create(:job, status: Job::STATUS_MANUAL)
      create(:job, status: Job::STATUS_HOLD)
      expect(Job.in_queue.size).to eq(2)
    end

    it '.queued returns all jobs with status = STATUS_QUEUED or status = STATUS_HOLD' do
      create(:job, status: Job::STATUS_QUEUED)
      create(:job, status: Job::STATUS_HOLD)
      expect(Job.queued.size).to eq(2)
    end

    it ".assigned returns all jobs with status = STATUS_QUEUED or status = STATUS_HOLD or status = STATUS_MANUAL and run_server IS NOT NULL AND run_server != ''" do
      create(:job, status: Job::STATUS_QUEUED, run_server: 'mssrv503')
      create(:job, status: Job::STATUS_HOLD, run_server: 'mssrv503')
      create(:job, status: Job::STATUS_MANUAL, run_server: 'mssrv503')
      expect(Job.assigned.size).to eq(3)
    end

    it '.active returns all jobs with status < STATUS_RESCHEDULED' do
      job = create(:job)
      expect(Job.active.first).to eq(job)
    end

    # fail_category is nil by default
    it ".failures returns all jobs with (fail_category IS NULL OR fail_category = '') AND (status = STATUS_FAILED OR status = STATUS_CANCELLED)" do
      create(:job, status: Job::STATUS_FAILED)
      create(:job, status: Job::STATUS_CANCELLED)
      expect(Job.failures.size).to eq(2)
    end

    it ".fail_reason_tagged returns all jobs with fail_category IS NOT NULL AND fail_category != ''" do
      job = create(:job, fail_category: 'SKIP')
      expect(Job.fail_reason_tagged.first).to eq(job)
    end

    it '.waiting_on_bug_tracker returns all jobs with status = STATUS_FAILED  AND file_system_status = FILE_SYSTEM_STATUS_FREE AND bug_tracker_id is not null' do
      job = create(:job, status: Job::STATUS_FAILED, file_system_status: Job::FILE_SYSTEM_STATUS_FREE, bug_tracker_id: 'TEST')
      expect(Job.waiting_on_bug_tracker.first).to eq(job)
    end

    it ".reserve_space_failed returns all jobs with status = STATUS_PROCESSING and fail_reason <> ''" do
      job = create(:job, status: Job::STATUS_PROCESSING, fail_reason: 'test')
      expect(Job.reserve_space_failed.first).to eq(job)
    end

    it ".failures_on_server returns all jobs with fail_category IS NULL OR fail_category = '') AND (status = STATUS_FAILED OR status = STATUS_CANCELLED) AND file_system_status != FILE_SYSTEM_STATUS_FREE" do
      create(:job, status: Job::STATUS_FAILED, file_system_status: Job::FILE_SYSTEM_STATUS_ON_SERVER)
      create(:job, status: Job::STATUS_CANCELLED, file_system_status: Job::FILE_SYSTEM_STATUS_RESERVED)
      expect(Job.failures_on_server.size).to eq(2)
    end
  end

  context 'Tools' do

    let!(:server)  { build_stubbed(:server, owned_by_project_id: project.id) }
    let!(:project) { create(:project) }
    let(:user)     { build_stubbed(:user) }

    let(:ls) {
      [
        'drwxrwxrwx 7 backoffice_test conversion 4096 May 19  2017 w_20170519-100312-313563-nar_tom_2016_12_20170515b_mnr_cnt/'
      ]
    }

    before do
      # Creates associated Mail Event + Options
      ReviewUnwantedDir.register_mail_event
      ReviewUnwantedDir.register_mail_options
    end

    it 'can check servers for unwanted files and sends email' do
      allow(Server).to receive(:project_server_map) { { project.id => [server] } }
      allow(FindUnwantedPaths).to receive(:list_dir).with(any_args) { ls }
      allow(Job).to receive(:find_by_working_dir).with(any_args) { job }
      allow_any_instance_of(ReviewUnwantedDir).to receive(:filter_receivers_on).with(any_args) { [user] }

      Job.check_unwanted_server_files

      mail = ActionMailer::Base.deliveries.last
      expect(mail.subject).to match(/WebMIS Review unwanted directories on servers for Project Production/)
    end
  end

  describe 'public instance methods' do
    context 'responds to its methods' do
      # TODO: if needed, establish for which functions these kind of tests need to exist
      it { expect(job).to respond_to(:status_str) }
      it { expect(job).to respond_to(:file_system_status_str) }
      it { expect(job).to respond_to(:queue) }
    end

    context 'executes methods correctly' do
      context 'self.status_hash' do
        it 'gives the correct number of statuses' do
          expect(Job.status_hash.size).to eq(11)
        end
      end
      context 'self.file_system_status_hash' do
        it 'gives the correct number of file system statuses' do
          expect(Job.file_system_status_hash.size).to eq(4)
        end
      end

      context 'estimate_duration' do
        let(:project)      { create(:project) }
        let(:conversion)   { create(:conversion) }
        let(:job_list)     { create_list(:cj_finished, 11, project: project, conversion: conversion) }
        let(:job)          { create(:cj_queued, tag_region_codes: 'REG1 REG2 REG3', project: project, conversion: conversion) }

        it 'should return the correct estimate for 10 jobs' do
          job_list.each_with_index do |j, i|
            j.update(start_time: Time.now, finish_time: Time.now + (i + 1).hours )
          end
          expect(job.estimate_duration).to eq 480
        end

        it 'should return the correct estimate if there is only 1 comparable job' do
          create(:cj_finished, project: project, conversion: conversion, start_time: Time.now, finish_time: Time.now + 1.hours)
          expect(job.estimate_duration).to eq 60
        end

        it 'should return 0 if there is no comparable job' do
          expect(job.estimate_duration).to eq 0
        end
      end

      context 'queue' do
        it 'moves the job to a queue status' do
          job = build(:job)
          job.queue
          expect(job.status).to eq(Job::STATUS_QUEUED)
        end
      end
      # context 'find_potential_server' do
      #   it 'finds a suitable server' do
      #     project = create(:proj_PRODUCTION)
      #     server = create(:server, owned_by: project)
      #     job_type = create(:job_type, name: 'Job', server: server)
      #     job = build(:job, project: project, status: Job::STATUS_QUEUED)
      #     project_server = create(:project_server, project: project, server: server)
      #     expect(job.potential_servers.size).to eq(1)
      #   end
      # end
      context 'auto_schedule' do
        it 'gets scheduled to a server' do
          pending('auto_schedule tries to perform, cannot perform as that means writing to the disk..which gets permission denied')
          raise
          # kept for template
          # jt_one = create(:jt_one, server: server)
          # jt_two = create(:jt_two, server: server)
          # jt_three = create(:jt_three, server: server)
          # jt_four = create(:jt_four, server: server)
          # jt_five = create(:jt_five, server: server)

          # conv_job = build(:cj_DEFAULT, project: project, type: jt_one.name, status: Job::STATUS_QUEUED)
          # val_job = build(:vj_DEFAULT, project: project, type: jt_two.name, status: Job::STATUS_QUEUED)
          # pac_job = build(:job, project: project, type: jt_three.name, status: Job::STATUS_QUEUED)
          # test_req_job = build(:job, project: project, type: jt_four.name, status: Job::STATUS_QUEUED)
          # ship_job = build(:job, project: project, type: jt_five.name, status: Job::STATUS_QUEUED)

          # conv_job.auto_schedule
          # val_job.auto_schedule
          # pac_job.auto_schedule
          # test_req_job.auto_schedule
          # ship_job.auto_schedule
        end
      end
    end
  end
end
