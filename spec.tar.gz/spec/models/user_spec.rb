require 'rails_helper'

describe User do

  describe 'Roles' do

    context 'No roles' do

      let(:user) {  create(:TESTUSER) }

      it 'method to check a Users roles is falsey when no such role' do
        expect(user.has_role(:blah)).to be_falsey
      end

      it 'method to check a Users roles in boolean context is false when no such symbol role' do
        expect(user.has_role?(:blah)).to eq false
      end

      it 'method to check a Users roles in boolean context is false when no such string role' do
        expect(user.has_role?('blah')).to eq false
        expect(user.has_role?('admin')).to eq false
      end

    end

    context 'Roles' do

      let!(:user)     { create(:user, :as_admin) }
      let!(:non_role) { create(:ReadOnly)  }

      before do
        allow_any_instance_of(User).to receive(:retrieve_current_project_id) { user.roles_users.first.project_id }
      end

      it 'method to check a Users roles in boolean context is true when user in a role' do
        expect(user.has_role?(:admin)).to eq true
        expect(user.has_role?('admin')).to eq true
      end

      it 'method to check a Users roles in boolean context is false when user not in role' do
        expect(user.has_role?('read only')).to eq false
      end

    end

  end
end