require 'rails_helper'

describe ConversionJob do
  # rubocop dislikes the usage of 'fail' and prefers 'raise' instead, we don't in these tests
  # rubocop:disable Style/SignalException
  it 'has a valid Factory' do
    expect(create(:conversion_job)).to be_valid
  end

  # Lazily loaded to ensure it's only used when it's needed
  # RSpec tip: Try to avoid @instance_variables if possible. They're slow.
  let(:conversion_job) { build_stubbed(:conversion_job) }

  describe 'ActiveRecord associations' do
    # Associations
    it { should belong_to(:conversion_environment) }
    it { should belong_to(:conversion) }
    it { should have_one(:production_orderline) }
    it { should have_one(:production_order) }
    it { should have_many(:conversion_databases) }
    it { should have_many(:conversion_job_process_data_elements) }
    it { should have_many(:process_data_elements) }
  end

  it 'sends an email when adding a conversion database fails' do
    conv_job = create(:conversion_job, conversion: create(:conversion))

    allow_any_instance_of(ConversionJob).to receive(:add_conversion_database) { false }

    allow_any_instance_of(ConversionJob).to receive(:o_dir_size)    { 1024 }
    allow_any_instance_of(ConversionJob).to receive(:db_result_dir) { scratch_path }
    allow_any_instance_of(ConversionJob).to receive(:output_dir) { scratch_path }

    delivery = double
    expect(delivery).to receive(:deliver_now).with(no_args)

    expect(AddConversionDatabaseFailed).to receive(:build_mail).and_return(delivery)
    conv_job.finalize_result
  end

  describe 'public instance methods' do
    context 'responds to its methods' do
      # TODO: if needed, establish for which functions these kind of tests need to exist
      it { expect(conversion_job).to respond_to(:duplicate) }
      it { expect(conversion_job).to respond_to(:regenerate) }
    end
    context 'executes methods correctly' do
      context 'cancel' do
        it 'gets cancelled' do
          conv = create(:conversion)
          conv_job = build(:conversion_job, conversion: conv)
          conv_job.cancel
          expect(conv_job.status).to eq(Job::STATUS_CANCELLED)
        end
      end
      context 'terminate' do
        it 'gets terminated' do
          conv = create(:conversion)
          conv_job = build(:conversion_job, conversion: conv)
          conv_job.terminate
          expect(conv_job.status).to eq(Job::STATUS_CANCELLED)
        end
      end
      context 'duplicate' do
        it 'creates another conversion job' do
          conv = create(:conversion)
          create(:conversion_job, conversion: conv)
          conversion_job.duplicate
          expect(ConversionJob.all.size).to eq(2)
        end
      end
      context 'regenerate' do
        it 'creates a manual conversion job' do
          conv = create(:conversion)
          conv_job = create(:conversion_job, conversion: conv, status: Job::STATUS_FAILED)
          conv_tool = create(:conversiontool)
          cvtool_bundle = create(:cvtool_bundle)
          regen_conv_job = conv_job.regenerate(conv_tool.id, cvtool_bundle.id)
          expect(conv_job.status).to eq(Job::STATUS_RESCHEDULED)
          expect(regen_conv_job.status).to eq(Job::STATUS_MANUAL)
        end
        it 'creates a queued conversion job' do
          conv = create(:c_DEFAULT)
          conv_job = create(:conversion_job, conversion: conv, status: Job::STATUS_FAILED)
          regen_conv_job = conv_job.regenerate(conv.conversiontool.id, conv.cvtool_bundle.id)
          expect(conv_job.status).to eq(Job::STATUS_RESCHEDULED)
          expect(regen_conv_job.status).to eq(Job::STATUS_QUEUED)
        end
        it 'cannot regenerate the conversion job' do # conversion status does not allow regeneration
          conv_job = create(:cj_DUMMY)
          conversiontool_id = 123
          cvtool_bundle_id = 456
          conv_job.regenerate(conversiontool_id, cvtool_bundle_id)
          expect(conv_job.status).to eq(Job::STATUS_PLANNED)
        end
      end
      context 'reschedule' do
        it 'queues a new conversion job' do
          conv = build(:conversion, server_name: 'mssrv_test')
          project = create(:proj_PRODUCTION)
          create(:server, owned_by: project)
          conv_job = build(:conversion_job, status: Job::STATUS_PROCESSING, conversion: conv)
          queued_job = conv_job.reschedule
          expect(conv_job.status).to eq(Job::STATUS_RESCHEDULED)
          expect(queued_job.status).to eq(Job::STATUS_QUEUED)
        end
      end
      context 'perform' do
        it 'moves conversion job to STATUS_PROCESSING' do
          pending('need to communicate with an actual server that can generate a pid file')
          fail
        end
      end

      context 'auto_monitor' do

        before do
          allow(ConfigParameter).to receive(:get).with(:dakota_log_dir) { '/rspec/testing' }
        end

        let!(:conv_job) { create(:conversion_job_maximal, status: Job::STATUS_PROCESSING) }

        it "monitors a conversion job's done file to update its status" do
          pending('done as part of integration test')
          fail
        end

        it 'returns full path to log in default sub directory' do
          expected = /\/rspec\/testing\/#{conv_job.current_year_quarter}\/.*\.log/

          expect(conv_job.get_log_path).to match expected
        end

        it 'returns full path to a log in specified sub directory' do
          expected = /\/rspec\/testing\/#{conv_job.neighbouring_year_quarter}\/.*\.log/

          expect(conv_job.get_log_path(sub_dir: conv_job.neighbouring_year_quarter)).to match expected
        end

        it 'returns nil when no active log present' do
          expect(conv_job.find_active_log('')).to eq nil

          expect(conv_job.find_active_log('/well/this/sure/dont/exist')).to eq nil
        end

        it 'returns nil when no wildcard present in directory glob' do
          expect(conv_job.find_active_log('/temp')).to eq nil
          expect(conv_job.find_active_log('.')).to eq nil
        end

        it 'can determine the current active log regardless of number of paths or order' do
          begin
            active = Tempfile.new('active')
            active.write("mapinfo CONVERSION_JOB_ID: \"#{conv_job.id}\"")
            active.rewind # needed for subsequent reads to succeed

            duff = Tempfile.new('duff')
            duff.write('mapinfo CONVERSION_JOB_ID: "blah"')

            # sort of mimic the conversion db path glob
            temp_glob = File.join(File.dirname(active.path), '**')

            expect(conv_job.find_active_log(temp_glob, '/temp')).to eq active.path
            expect(conv_job.find_active_log(duff.path)).to eq nil
            expect(conv_job.find_active_log('/temp/**/*.log', temp_glob)).to eq active.path
          ensure
            active.close
            active.unlink # deletes the temp file instantly
            duff.close
            duff.unlink
          end
        end

        it 'returns a file with matching ID even when contains non UTF chars' do

          log = factory_file('long_with_non_utf_chars.log')

          expect {
            File.foreach(log).grep(/mapinfo CONVERSION_JOB_ID:/)
          }.to raise_error(ArgumentError, 'invalid byte sequence in UTF-8')

=begin

# Benchmarking left for reference but not really part of rspec tests
# Large test files are stored here :
#   /data/users/rails.test/webmis/testing/fixtures

          Benchmark.bmbm do |x|
            x.report("original grep:")  { File.readlines(log, :encoding => 'ISO-8859-1').grep(/mapinfo CONVERSION_JOB_ID: RSPEC_TEST_ID/).any? }
            x.report("original grep:")  { File.readlines(log, :encoding => 'ISO-8859-1').join()[/mapinfo CONVERSION_JOB_ID: RSPEC_TEST_ID/].present? }

            x.report("file based match:")   do
              result = File.open(log, :encoding => 'ISO-8859-1') { |file|
                file.find { |line| line =~ /mapinfo CONVERSION_JOB_ID: / }
              }.present?
              expect(result).to be_truthy
            end

            x.report("file based non match:")   do
              result = File.open(factory_file('no_match_with_non_utf_chars.log'), :encoding => 'ISO-8859-1') { |file|
                file.find { |line| line =~ /mapinfo CONVERSION_JOB_ID: / }
              }.present?
              expect(result).to be_falsey
            end
          end
=end
          # 345 is hard coded inside the log fixture
          allow_any_instance_of(ConversionJob).to receive(:id) { 345 }
          expect(conv_job.find_active_log(log)).to eq log
        end

        it 'includes log file info in the json' do
          expect(conv_job.to_json).to include('"log_path":null')

          conv_job.log_path = '/rspec/test/log/blah.log'
          expect(conv_job.to_json).to include('"log_path":"/rspec/test/log/blah.log"')
        end

      end

      context 'self.create' do
        it 'creates a new conversion job' do
          pending('done as part of integration test, must read actual path/conversion databases')
          fail
        end
        # kept for template
        # it 'creates a queued conversion job' do
        #   conv = create(:c_DEFAULT)
        #   params = Hash.new
        #   params[:project_id] = conv.project_id
        #   params[:conversion_environment_id] = conv.conversion_environment_id
        #   params[:conversiontool] = conv.conversiontool.code
        #   params[:cvtool_bundle] = conv.cvtool_bundle.name
        #   params[:script_path] = "#{Rails.root}/script/start_dj_if_not_running.sh"

        #   conv_job = ConversionJob.create(params)
        #   expect(conv_job.status).to eq(Job::STATUS_QUEUED)
        # end
        # it 'creates a manual conversion job' do
        #   conv = create(:c_DEFAULT, run_server: 'mssrv_test')
        #   params = Hash.new
        #   params[:project_id] = conv.project_id
        #   params[:conversion_environment_id] = conv.conversion_environment_id
        #   params[:conversiontool] = conv.conversiontool.code
        #   params[:cvtool_bundle] = conv.cvtool_bundle.name
        #   conv_job = ConversionJob.create(params)
        #   expect(conv_job.status).to eq(Job::STATUS_MANUAL)
        # end
      end

      context 'last_comparable_jobs' do
        let(:conversion)  { create :c_tagged }
        let(:job)         { create :cj_queued, tag_region_codes: 'REG1 REG2 REG3', conversion: conversion }

        before(:all) do
          @cj_conv1_array = []
          @cj_conv2_array = []
          @cj_conv3_array = []
          @cj_conv4_array = []
          conversion1 = create(:c_tagged)
          conversion2 = create(:c_tagged, tag_md5sum_step: nil)
          conversion3 = create(:c_tagged, tag_md5sum_step: nil, tag_executables: nil)
          conversion4 = create(:c_tagged, tag_md5sum_step: nil, tag_executables: nil, input_format: 'dolor')
          11.times do
            @cj_conv1_array << create(:cj_finished, conversion: conversion1)
            @cj_conv2_array << create(:cj_finished, conversion: conversion2)
            @cj_conv3_array << create(:cj_finished, conversion: conversion3)
            @cj_conv4_array << create(:cj_finished, conversion: conversion4)
          end
        end

        after(:all) do
          DatabaseCleaner.strategy = :truncation
          DatabaseCleaner.clean
          # Project.destroy_all
          # Job.destroy_all
          # Conversion.destroy_all
          # DataRelease.destroy_all
          # CompanyAbbr.destroy_all
          # Region.destroy_all
          # Conversiontool.destroy_all
          # CvtoolBundle.destroy_all
          # ConvScript.destroy_all
          # CvtoolTemplate.destroy_all
          # ProductionOrderline.destroy_all
          # ProductionOrder.destroy_all
          # Ordertype.destroy_all
          # ProductCategory.destroy_all
          # ProductSet.destroy_all
          # ProductLine.destroy_all
        end

        it 'should return the last 10 conversion jobs with the same tag_md5sum_step' do
          result = job.last_comparable_jobs.collect(&:id)
          expected_result = @cj_conv1_array.last(10).collect(&:id)
          expect(result).to match_array expected_result
        end

        it 'should return all conversion jobs with the same tag_md5sum_step if there are less than 10' do
          10.times do |i|
            @cj_conv1_array[i].update(status: Job::STATUS_CANCELLED)
          end
          result = job.last_comparable_jobs.collect(&:id)
          expected_result = @cj_conv1_array.last(1).collect(&:id)
          expect(result).to match_array expected_result
        end

        it 'should return the last 10 conversion jobs with the same tag_executable if there are none with the same tag_md5sum_step' do
          # reload needed as the update of the previous condition is rolled back in the database but @cj_conv_array still contains the contents from before the roll back
          @cj_conv1_array.each { |cj| cj.reload.update(status: Job::STATUS_CANCELLED) }
          result = job.last_comparable_jobs.collect(&:id)
          expected_result = @cj_conv2_array.last(10).collect(&:id)
          expect(result).to match_array expected_result
        end

        it 'should return all conversion jobs with the same tag_executable if there are less than 10 and there are none with the same tag_md5sum_step' do
          @cj_conv1_array.each { |cj| cj.reload.update(status: Job::STATUS_CANCELLED) }
          10.times do |i|
            @cj_conv2_array[i].update(status: Job::STATUS_CANCELLED)
          end
          result = job.last_comparable_jobs.collect(&:id)
          expected_result = @cj_conv2_array.last(1).collect(&:id)
          expect(result).to match_array expected_result
        end

        it 'should return the last 10 conversion jobs with the same input and output if there are none with the same tag_md5sum_step or tag_executable' do
          @cj_conv1_array.each { |cj| cj.reload.update(status: Job::STATUS_CANCELLED) }
          @cj_conv2_array.each { |cj| cj.reload.update(status: Job::STATUS_CANCELLED) }
          result = job.last_comparable_jobs.collect(&:id)
          expected_result = @cj_conv3_array.last(10).collect(&:id)
          expect(result).to match_array expected_result
        end

        it 'should return all conversion jobs with the same input and output if there are less than 10 and there are none with the same tag_md5sum_step or tag_executable' do
          @cj_conv1_array.each { |cj| cj.reload.update(status: Job::STATUS_CANCELLED) }
          @cj_conv2_array.each { |cj| cj.reload.update(status: Job::STATUS_CANCELLED) }
          10.times do |i|
            @cj_conv3_array[i].update(status: Job::STATUS_CANCELLED)
          end
          result = job.last_comparable_jobs.collect(&:id)
          expected_result = @cj_conv3_array.last(1).collect(&:id)
          expect(result).to match_array expected_result
        end

        it 'should return an empty array if there are none with the same tag_md5sum_step or tag_executable or input and output' do
          @cj_conv1_array.each { |cj| cj.reload.update(status: Job::STATUS_CANCELLED) }
          @cj_conv2_array.each { |cj| cj.reload.update(status: Job::STATUS_CANCELLED) }
          @cj_conv3_array.each { |cj| cj.reload.update(status: Job::STATUS_CANCELLED) }
          result = job.last_comparable_jobs.collect(&:id)
          expect(result).to be_empty
        end
      end
    end
  end
end
