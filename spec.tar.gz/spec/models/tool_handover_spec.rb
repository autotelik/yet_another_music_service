require 'rails_helper'

describe ToolHandover do

  context 'Validations and Data' do

    let(:tool_handover) { create(:tool_handover, :with_handover_compilation_steps) }

    let(:alt_tool_handover) { create(:tool_handover, :with_handover_compilation_steps) }

    let(:empty_tool_handover) { create(:tool_handover) }

    it 'should return true when equivalent' do
      expect(tool_handover.equivalent?(tool_handover)).to eq true
    end

    it 'should return false when not equivalent due to empty steps' do
      expect(tool_handover.equivalent?(empty_tool_handover)).to eq false
    end

    it 'should return false when one step not equivalent' do
      alt_tool_handover.handover_compilation_steps[0].conv_script_id = -99
      expect(tool_handover.equivalent?(alt_tool_handover)).to eq false
    end

  end

  context 'Clone' do
    let(:tool_handover) { create(:tool_handover, :with_handover_compilation_steps) }
    let(:empty_tool_handover) { create(:tool_handover) }
    let(:set_tool_handover) { create(:set_tool_handover) }
    let(:user) { create(:user) }

    it 'should clone a tool handover to a target set tool handover' do
      expect(set_tool_handover.tool_handovers).to be_empty

      new_tool_handover = tool_handover.clone(set_tool_handover, user)
      expect(new_tool_handover.set_tool_handover_id).to eq set_tool_handover.id
      expect(tool_handover.set_tool_handover_id).not_to eq set_tool_handover.id
      expect(new_tool_handover.handover_compilation_steps.count).to eq tool_handover.handover_compilation_steps.count
    end

    it 'should be able to clone an empty tool_handover' do
      new_tool_handover = empty_tool_handover.clone(set_tool_handover, user)
      expect(new_tool_handover.set_tool_handover_id).to eq set_tool_handover.id
      expect(new_tool_handover.handover_compilation_steps).to be_empty
    end
  end

  context 'Fill' do
    let(:source_tool_handover) { create(:tool_handover_maximal, :with_handover_compilation_steps) }
    let(:target_tool_handover1) { create(:tool_handover) }
    let(:target_tool_handover2) { create(:tool_handover_data_set, :with_handover_compilation_steps) }
    let(:user) { create(:user) }

    it 'should fill a tool handover from a source tool handover' do
      name = target_tool_handover1.name
      target_tool_handover1.fill(source_tool_handover, user)
      expect(target_tool_handover1.name).to eq name
      # note that this test case will not properly take over the conversion_design_name from the source as that would require
      # a quite elaborate setup of conversion_designs, conv_scripts, conversion_design_names and projects so it would correctly
      # find the equivalent conversion_design_name within the project of the target_tool_handover1
      expect(target_tool_handover1.conv_script_id).to eq source_tool_handover.conv_script_id
      expect(target_tool_handover1.step_array.count).to eq source_tool_handover.handover_compilation_steps.count

      target_tool_handover2.fill(source_tool_handover, user)
      expect(target_tool_handover2.step_array.count).to eq source_tool_handover.handover_compilation_steps.count
    end
  end
end
