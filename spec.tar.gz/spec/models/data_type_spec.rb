require 'rails_helper'

describe DataType do

  context 'Validations and Data' do

    it 'has a valid Factory' do
      expect(create(:data_type)).to be_valid
    end

    it 'should store a test grid file extension' do
      expect(DataType.new(name: 'test', test_grid_support_yn: true)).to be_valid
    end

    it 'should validate name is unique' do
      DataType.create(name: 'test', test_grid_support_yn: true)
      expect(DataType.new(name: 'test')).to_not be_valid
    end

  end

  context 'Query' do

    let!(:nds_grid_on)     { create(:dt_NDS,   test_grid_support_yn: true) }
    let!(:support_true)    { create(:dt_RDF,   test_grid_support_yn: true) }
    let!(:support_false)   { create(:dt_dHive, test_grid_support_yn: false) }

    it 'can access list of DataTypes with associated Test grid support' do
      expect(DataType.test_grid_on).to match_array [nds_grid_on, support_true]
    end

    it 'can access list of DataType Names with associated Test grid support' do
      expect(DataType.test_grid_on_names).to match_array [nds_grid_on.name, support_true.name]
    end
  end
end
