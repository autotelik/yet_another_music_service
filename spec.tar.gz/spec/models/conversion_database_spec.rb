require 'rails_helper'

describe ConversionDatabase do

  let(:rdf_data_type_grid_off) { create(:dt_RDF, test_grid_support_yn: false) }
  let(:nds_grid_on)            { create(:dt_NDS, name: 'NDS', test_grid_support_yn: true) }

  let(:assoc_return_msg)       { 'No TestGrid support as conversion database is not associated with any production orderline/conversion.' }
  let(:gen_return_msg)         { 'TestGrid support not executed because not all required fields were set.' }

  context 'Scopes' do

    # No files should match this Extension
    let(:gen_master_grid_on) { create(:dt_dHive, name: 'GEN_MASTER', test_grid_support_yn: true) }

    before do
      # These should NOT match - NO test grid support
      create_list(:conversion_database_maximal, 3, db_type: rdf_data_type_grid_off.name)
    end

    # Only these 2 should match on db_type (DataType name) AND on test grid support
    let!(:expect1) { create(:conversion_database_maximal, filename: 'ROOT.NDS',       db_type: nds_grid_on.name) }
    let!(:expect2) { create(:conversion_database_maximal, filename: 'YES_102.04.zip', db_type: gen_master_grid_on.name) }

    it 'supplies scope to select ConversionDatabases with Testgrid support true' do
      # expect all DBS with db_type == DataType with test_grid_support = true
      expect(ConversionDatabase.testable_on_grid).to match_array [expect1, expect2]
    end

    it 'returns RDO Paths when Testgrid support true Order ID DESC' do
      expect(ConversionDatabase.rdo_path_option_list.size).to eq 2
      expect(ConversionDatabase.rdo_path_option_list.first).to match_array [expect2.label, expect2.path_and_file]
      # noinspection RubyResolve
      expect(ConversionDatabase.rdo_path_option_list.first.last).to include '.zip'

      expect(ConversionDatabase.rdo_path_option_list.last).to match_array [expect1.label, expect1.path_and_file]
      # noinspection RubyResolve
      expect(ConversionDatabase.rdo_path_option_list.last.last).to include 'ROOT.NDS'
    end

  end

  context 'Change to end_end_status' do
    let(:conv_db_ready)      { create(:conversion_database_maximal, status: ConversionDatabase::STATUS_READY_FOR_VALIDATION) }
    let(:conv_db_validating) { create(:conversion_database_maximal, status: ConversionDatabase::STATUS_VALIDATING) }
    let(:conv_db_errors)     { create(:conversion_database_maximal, status: ConversionDatabase::STATUS_HAS_ERRORS, file_system_status: ConversionDatabase::FILE_SYSTEM_STATUS_PERSISTENT) }
    let(:user)               { create(:user) }

    it 'cancels a validation' do
      expect(conv_db_ready.cancel_validation(user)).to eq true
      expect(conv_db_ready.status).to eq ConversionDatabase::STATUS_NOT_VALIDATED
      expect(conv_db_ready.validation_jobs.outstanding).to be_empty
      expect(conv_db_ready.file_system_status).to eq ConversionDatabase::FILE_SYSTEM_STATUS_AVAILABLE

      expect(conv_db_validating.cancel_validation).to eq true
      expect(conv_db_validating.status).to eq ConversionDatabase::STATUS_NOT_VALIDATED
      expect(conv_db_validating.validation_jobs.outstanding).to be_empty
      expect(conv_db_validating.file_system_status).to eq ConversionDatabase::FILE_SYSTEM_STATUS_AVAILABLE

      expect(conv_db_errors.cancel_validation(user)).to eq true
      expect(conv_db_errors.status).to eq ConversionDatabase::STATUS_NOT_VALIDATED
      expect(conv_db_errors.validation_jobs.outstanding).to be_empty
      expect(conv_db_errors.file_system_status).to eq ConversionDatabase::FILE_SYSTEM_STATUS_PERSISTENT

      # conv_db_ready has now an end-status
      expect(conv_db_ready.cancel_validation).to eq false
    end

    it 'cancels the conversion database' do
      expect(conv_db_ready.cancel).to eq true
      expect(conv_db_ready.status).to eq ConversionDatabase::STATUS_CANCELLED
      expect(conv_db_ready.validation_jobs.outstanding).to be_empty
      expect(conv_db_ready.file_system_status).to eq ConversionDatabase::FILE_SYSTEM_STATUS_MARKED_FOR_REMOVAL

      expect(conv_db_validating.cancel(user)).to eq true
      expect(conv_db_validating.status).to eq ConversionDatabase::STATUS_CANCELLED
      expect(conv_db_validating.validation_jobs.outstanding).to be_empty
      expect(conv_db_validating.file_system_status).to eq ConversionDatabase::FILE_SYSTEM_STATUS_MARKED_FOR_REMOVAL

      expect(conv_db_errors.cancel).to eq true
      expect(conv_db_errors.status).to eq ConversionDatabase::STATUS_CANCELLED
      expect(conv_db_errors.validation_jobs.outstanding).to be_empty
      expect(conv_db_errors.file_system_status).to eq ConversionDatabase::FILE_SYSTEM_STATUS_PERSISTENT

      # conv_db_ready has now an end-status
      conv_db_ready.file_system_status = ConversionDatabase::FILE_SYSTEM_STATUS_AVAILABLE
      expect(conv_db_ready.cancel).to eq false
      expect(conv_db_ready.file_system_status).to eq ConversionDatabase::FILE_SYSTEM_STATUS_AVAILABLE
    end

    it 'terminates a conversion database' do
      expect(conv_db_ready.terminate).to eq true
      expect(conv_db_ready.status).to eq ConversionDatabase::STATUS_CANCELLED
      expect(conv_db_ready.validation_jobs.outstanding).to be_empty
      expect(conv_db_ready.file_system_status).to eq ConversionDatabase::FILE_SYSTEM_STATUS_MARKED_FOR_REMOVAL

      expect(conv_db_validating.terminate).to eq true
      expect(conv_db_validating.status).to eq ConversionDatabase::STATUS_CANCELLED
      expect(conv_db_validating.validation_jobs.outstanding).to be_empty
      expect(conv_db_validating.file_system_status).to eq ConversionDatabase::FILE_SYSTEM_STATUS_MARKED_FOR_REMOVAL
      expect(conv_db_errors.terminate(user)).to eq true
      expect(conv_db_errors.status).to eq ConversionDatabase::STATUS_CANCELLED
      expect(conv_db_errors.validation_jobs.outstanding).to be_empty
      expect(conv_db_errors.file_system_status).to eq ConversionDatabase::FILE_SYSTEM_STATUS_MARKED_FOR_REMOVAL

      # conv_db_ready has now an end-status
      conv_db_ready.file_system_status = ConversionDatabase::FILE_SYSTEM_STATUS_AVAILABLE
      expect(conv_db_ready.terminate).to eq true
      expect(conv_db_ready.file_system_status).to eq ConversionDatabase::FILE_SYSTEM_STATUS_MARKED_FOR_REMOVAL
    end
  end

  context 'Test Grid Support' do

    let(:pol)         { create(:production_orderline, :with_product_line, :with_test_grid_support) }
    let(:conv_db)     { create(:conversion_database_maximal, filename: 'ROOT.NDS', db_type: nds_grid_on.name) }
    let(:conversion)  { create(:conversion, :with_product_line) }

    before(:each) do
      allow(ShellUtil).to receive(:ssh_localhost) {}
      allow(ShellUtil).to receive(:ssh_safe) { 'ssh_safe called' }

      allow(conversion).to receive(:production_orderline) { pol }
      allow(conv_db).to receive(:production_orderline) { pol }
    end

    it 'sends details to TestGrid when tg project and tg region present' do
      allow(conv_db).to receive(:path_and_file) { pol.ref_db }

      expect(conversion.production_orderline.tg_yn).to eq true
      # noinspection RubyResolve
      expect(conversion.production_orderline.test_grid_region.present?).to eq true
      expect(conv_db.handle_test_grid_support).to eq 'ssh_safe called'
    end

    it 'does not send details to TestGrid when no conversion present' do
      allow(conv_db).to receive(:conversion) { nil }

      expect(conv_db.handle_test_grid_support).to eq assoc_return_msg
    end

    it 'does not invoke TestGrid when no production orderline present' do
      allow(conv_db).to receive(:production_orderline) { nil }

      expect(conv_db.handle_test_grid_support).to eq assoc_return_msg
    end

    it 'does not invoke TestGrid when no data type present' do
      allow(conv_db).to receive(:db_type) { nil }

      expect(conv_db.handle_test_grid_support).to eq gen_return_msg
    end

    it 'does not invoke TestGrid when tg_yn flag not checked' do
      allow(pol).to receive(:tg_yn) { nil }

      expect(conv_db.handle_test_grid_support).to eq gen_return_msg
    end

    it 'does not invoke TestGrid when no test_grid_region present' do
      allow(pol).to receive(:test_grid_region) { nil }

      expect(conv_db.handle_test_grid_support).to eq gen_return_msg
    end

    it 'does not invoke TestGrid when no test_grid_nrof_servers present' do
      allow(pol).to receive(:test_grid_nrof_servers) { nil }

      expect(conv_db.handle_test_grid_support).to eq gen_return_msg
    end

    it 'does not invoke TestGrid when no path_and_file present' do
      allow(conv_db).to receive(:path_and_file) { nil }

      expect(conv_db.handle_test_grid_support).to eq gen_return_msg
    end

    it 'sends details to TestGrid when either ref or aknavi db same depth as result' do
      allow(conv_db).to receive(:path_and_file) { pol.ref_db }

      expect(conv_db.handle_test_grid_support).to eq 'ssh_safe called'
    end

    it 'does not invoke TestGrid when no test grid project determined' do
      allow(pol).to receive(:test_grid_project) { nil }
      allow(conv_db).to receive(:db_type) { nil }

      expect(conv_db.handle_test_grid_support).to eq gen_return_msg
    end

  end

end
