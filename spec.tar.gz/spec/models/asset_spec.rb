require 'rails_helper'

describe Asset do

  let(:user)  { create(:TESTUSER1) }
  let(:asset) { create(:asset).tap {|a| a.requested_by_user(user) } }

  it 'sets the requested_by field to the full name of a supplied user' do
    expect(asset.requested_by).to eq user.full_name
  end

  it 'returns true when supplied user is same as the requested_user' do
    expect(asset.requested_by_user?(user)).to be_truthy
  end

  it 'returns false when supplied user is not the requested_user' do
    expect(asset.requested_by_user?(build(:TESTUSER2))).to be_falsey
  end

end
