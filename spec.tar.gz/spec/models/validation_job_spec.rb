require 'rails_helper'

describe ValidationJob do
  it 'has a valid Factory' do
    expect(create(:validation_job)).to be_valid
  end

  # Lazily loaded to ensure it's only used when it's needed
  # RSpec tip: Try to avoid @instance_variables if possible. They're slow.
  let(:validation_job) { build_stubbed(:validation_job) }

  describe 'ActiveRecord associations' do
    it { should belong_to(:conversion_database) }
    it { should belong_to(:fail_category_logged_by_user) }
    it { should have_one(:conversion_job) }
    it { should have_one(:conversion) }
    it { should have_one(:production_orderline) }
    it { should have_one(:production_order) }
  end

  describe 'public instance methods' do
    context 'responds to its methods' do
      # TODO: if needed, establish for which functions these kind of tests need to exist
      it { expect(validation_job).to respond_to(:duplicate) }
      it { expect(validation_job).to respond_to(:regenerate) }
    end
    context 'executes methods correctly' do
      context 'cancel' do
        it 'gets cancelled' do
          project = create(:proj_PRODUCTION)
          conv_db = create(:conversion_database)
          val_job = build(:validation_job, conversion_database: conv_db)
          val_job.cancel
          expect(val_job.status).to eq(Job::STATUS_CANCELLED)
        end
      end
      context 'terminate/cancel' do
        it 'gets terminated/cancelled' do
          conv = create(:conversion)
          val_job = build(:conversion_job, conversion: conv)
          val_job.terminate
          expect(val_job.status).to eq(Job::STATUS_CANCELLED)
        end
      end
      context 'duplicate' do
        it 'creates another validation job' do
          conv_db = create(:conversion_database, conversion: create(:c_DEFAULT))
          val_job = create(:validation_job, conversion_database: conv_db)
          clone = val_job.duplicate
          expect(ValidationJob.all.size).to eq(2)
        end
      end
      context 'regenerate' do
        it 'creates a manual validation job' do
          user = build_stubbed(:user)
          conv_db = create(:conversion_database, conversion: create(:c_DEFAULT))
          val_job = build(:validation_job, conversion_database: conv_db, status: Job::STATUS_FAILED)
          conversiontool_id = 12321212121
          cvtool_bundle_id = 456121212121
          regen_val_job = val_job.regenerate(user, conversiontool_id, cvtool_bundle_id)
          expect(val_job.status).to eq(Job::STATUS_RESCHEDULED)
          expect(regen_val_job.status).to eq(Job::STATUS_MANUAL)
        end
        it 'creates a queued validation job' do
          user = build_stubbed(:user)
          conv_db = create(:conversion_database, conversion: create(:c_DEFAULT))
          val_job = build(:validation_job, conversion_database: conv_db, status: Job::STATUS_PROCESSING)
          regen_val_job = val_job.regenerate(user, conv_db.conversion.conversiontool.id, conv_db.conversion.cvtool_bundle.id)
          expect(val_job.status).to eq(Job::STATUS_RESCHEDULED)
          expect(regen_val_job.status).to eq(Job::STATUS_QUEUED)
        end
        it 'cannot regenerate the validation job' do #its status does not allow regeneration
          user = build_stubbed(:user)
          val_job = build_stubbed(:validation_job)
          conversiontool_id = 123
          cvtool_bundle_id = 456
          val_job.regenerate(user, conversiontool_id, cvtool_bundle_id)
          expect(val_job.status).to eq(Job::STATUS_PLANNED)
        end
      end
      context 'reschedule' do
        it 'allows creation of a new validation job' do
          project = create(:proj_PRODUCTION)
          conv_db = create(:conversion_database)
          val_job = build(:validation_job, conversion_database: conv_db, status: Job::STATUS_FAILED)
          val_job.reschedule
          expect(val_job.status).to eq(Job::STATUS_RESCHEDULED)
        end
        it 'cannot reschedule a new validation job' do #its status does not allow rescheduling
          val_job = build_stubbed(:validation_job)
          val_job.reschedule
          expect(val_job.status).to eq(Job::STATUS_PLANNED)
        end
      end
      context 'validate' do
        it 'moves validation job to STATUS_PROCESSING' do
          pending('need to communicate with an actual server that can generate a pid file')
          fail
          # kept for template
          # FileUtils.mkdir_p('/volumes2/backoffice/job_scripts/')
          # project = create(:proj_PRODUCTION)
          # server = create(:server, owned_by: project)
          # conv_db = create(:conversion_database, conversion: create(:c_DEFAULT))
          # val_job = create(:validation_job, conversion_database: conv_db, run_server: server.server_id)
          # val_job.validate
          # expect(val_job.status).to eq(Job::STATUS_PROCESSING)
        end
      end
      context 'auto_monitor' do
        it "monitors a validation job's done file to update its status" do
          pending('done as part of integration test')
          fail
        end
      end
    end
  end
end