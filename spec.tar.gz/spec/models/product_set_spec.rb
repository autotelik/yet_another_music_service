require 'rails_helper'

describe ProductSet do
  it 'has a valid Factory' do
    expect(create(:product_set)).to be_valid
  end

  describe 'ActiveRecord associations' do
    it { should have_many(:included_products) }
    it { should have_many(:products) }
    it { should have_many(:documents) }
    it { should have_one(:pds_product_set) }
    it { should belong_to(:product_category) }
    it { should belong_to(:product_line) }
    it { should belong_to(:predecessor) }
    it { should have_many(:set_tool_handovers) }
    it { should have_one(:shipping_specification) }
  end

  context 'Validations' do
    it { is_expected.to validate_presence_of(:code) }
  end

  context 'handle_status concern' do
    it_behaves_like 'handle_status'
  end

  context 'Changing Status' do
    let(:product_set) { create(:product_set) }

    it 'allows transition to PROPOSAL' do
      expect(product_set.allow_status_change?(ProductSet::STATUS_PROPOSAL)).to be_truthy
    end

    it 'allows transition to PROPOSAL' do
      expect(product_set.allow_status_change?(ProductSet::STATUS_PROPOSAL)).to be_truthy
    end

    it 'allows transition to APPROVED' do
      expect(product_set.allow_status_change?(ProductSet::STATUS_APPROVED)).to be_truthy
    end

    it 'allows transition to OBSOLETE' do
      expect(product_set.allow_status_change?(ProductSet::STATUS_OBSOLETE)).to be_truthy
    end
  end

  context 'Change log' do
    let(:product_set) { create(:product_set) }

    it_behaves_like 'change_log'
  end

  context 'handling included documents' do
    let(:product_set) { create(:product_set) }
    let(:user) { create(:user) }
    let(:doc) { create(:document) }

    it 'should only create a new document and add it to the product set if the document does not exist yet.' do
      expect(product_set.included_product_set_documents.count).to eq 0
      expect(Document.count).to eq 0

      new_doc = Document.new(filename: 'xxxx')
      expect(product_set.new_document(new_doc, user)).to be_nil

      expect(product_set.included_product_set_documents.count).to eq 1
      expect(Document.count).to eq 1

      new_doc = Document.new(filename: 'xxxx')
      expect(product_set.new_document(new_doc)).not_to be_nil
      expect(product_set.included_product_set_documents.count).to eq 1
      expect(Document.count).to eq 1
    end

    it 'should only add an existing document to the product set if the document has not already been added.' do
      expect(product_set.included_product_set_documents.count).to eq 0
      expect(product_set.add_document(doc, user)).to be_nil
      expect(product_set.included_product_set_documents.count).to eq 1
      expect(product_set.add_document(doc)).not_to be_nil
      expect(product_set.included_product_set_documents.count).to eq 1
    end

    it 'should only remove a document from the product set if it is part of the product set, without removed the document itself' do
      new_doc = Document.new(filename: 'xxxx')
      product_set.new_document(new_doc)
      product_set.add_document(doc)
      expect(Document.count).to eq 2
      expect(product_set.included_product_set_documents.count).to eq 2
      expect(product_set.remove_document(doc, user)).to be_nil
      expect(product_set.included_product_set_documents.count).to eq 1
      expect(Document.count).to eq 2
      expect(product_set.remove_document(doc)).not_to be_nil
      expect(product_set.included_product_set_documents.count).to eq 1
    end
  end

  context 'handling included products' do
    let(:product_set) { create(:product_set) }
    let(:user) { create(:user) }
    let(:prod) { create(:product) }
    let(:prod2) { create(:product) }

    it 'should only add an existing product to the product set if the product has not already been added.' do
      expect(product_set.included_products.count).to eq 0
      expect(product_set.add_product(prod, user)).to be_nil
      expect(product_set.included_products.count).to eq 1
      expect(product_set.add_product(prod)).not_to be_nil
      expect(product_set.included_products.count).to eq 1
    end

    it 'should only remove a product from the product set if it is part of the product set, without removing the product itself' do
      product_set.add_product(prod)
      product_set.add_product(prod2)
      expect(Product.count).to eq 2
      expect(product_set.included_products.count).to eq 2
      expect(product_set.remove_product(prod)).to be_nil
      expect(product_set.included_products.count).to eq 1
      expect(product_set.remove_product(prod, user)).not_to be_nil
      expect(product_set.included_products.count).to eq 1
      expect(product_set.remove_product(prod2, user)).to be_nil
      expect(product_set.included_products.count).to eq 0
      expect(Product.count).to eq 2
    end
  end

  context 'disable' do
    let(:product_set1) { create(:product_set) }
    let(:product_set2) { create(:product_set_maximal) }
    let(:product1) { create(:product) }
    let(:product2) { create(:product2) }
    let(:product3) { create(:product3) }
    let!(:included_product1) { create(:included_product, product_set: product_set1, product: product1) }
    let!(:included_product2a) { create(:included_product, product_set: product_set1, product: product2) }
    let!(:included_product2b) { create(:included_product, product_set: product_set2, product: product2) }
    let!(:included_product3) { create(:included_product, product_set: product_set2, product: product3) }

    it 'should disable the product set and the products only used in that product_set' do
      expect(product_set1.disable).to be_truthy
      expect(product_set1.status).to eq ProductSet::STATUS_OBSOLETE
      [product1, product2, product3].each(&:reload)
      expect(product1.status).to eq Product::STATUS_REMOVED
      expect(product2.status).to eq Product::STATUS_APPROVED
      expect(product3.status).to eq Product::STATUS_APPROVED
    end
  end

  context 'clone' do
    let(:product_set) { create(:product_set) }
    let(:product1) { create(:product) }
    let(:product2) { create(:product2) }
    let!(:included_product1) { create(:included_product, product_set: product_set, product: product1) }
    let!(:included_product2) { create(:included_product, product_set: product_set, product: product2) }
    let(:project) { create(:proj_PRODUCTION) }

    it 'should clone the product set and the products belonging to the product set' do
      clone = product_set.clone_set(project)

      expect(clone.id).not_to eq product_set.id
      expect(clone.code).not_to eq product_set.code
      expect(clone.status).to eq ProductSet::STATUS_DRAFT
      expect(clone.product_category_id).to eq product_set.product_category_id

      expect(clone.included_products.count).to eq 2
    end
  end

  context 'set tool handover' do
    # assumption, the factory of :product_set does not create a link with a :set_tool_handover instance.
    let(:product_set) { create(:product_set) }
    let(:project) { create(:proj_REGRESSION) }
    let(:user) { create(:user) }

    it 'expects current_set_tool_handover to be nil' do
      expect(product_set.current_set_tool_handover).to be_nil
    end

    it 'expects that exactly one set tool handover per project can be added to the product set' do
      # stub sync_tool_handovers, it should be tested as part of the ToolSetHandover model
      allow_any_instance_of(SetToolHandover).to receive(:sync_tool_handovers) { nil }
      expect { product_set.create_set_tool_handover(project, user) }.to change { product_set.set_tool_handovers.count }.by(1)
      expect(product_set.current_set_tool_handover(project).class).to eq SetToolHandover
      expect(product_set.current_set_tool_handover).to eq nil
    end
  end

  context 'clone set tool handover' do
    let(:product_set) { create(:product_set) }
    let(:from_project) { create(:proj_PRODUCTION) }
    let(:to_project) { create(:proj_REGRESSION) }
    let(:user) { create(:user) }
    let!(:set_tool_handover) { create(:set_tool_handover_maximal, product_set: product_set, project: from_project) }
    let!(:tool_handover) { create(:tool_handover, :with_handover_compilation_steps, set_tool_handover: set_tool_handover) }

    it 'expects that the set tool handover is copied to a new set tool handover if no set tool handover already exists for that project' do
      expect { product_set.clone_set_tool_handover(from_project: from_project, to_project: to_project, user: user) }.to change { product_set.set_tool_handovers.count }.by(1)
      expect(product_set.current_set_tool_handover(to_project).tool_handovers.count).to eq set_tool_handover.tool_handovers.count
      expect(product_set.current_set_tool_handover(to_project).tool_handovers.first.handover_compilation_steps.count).to eq tool_handover.handover_compilation_steps.count
    end

    it 'exits that the set tool handover is copied over an existing set tool handover' do
      old_set_tool_handover = create(:set_tool_handover, product_set: product_set, project: to_project)
      expect { product_set.clone_set_tool_handover(from_project: from_project, to_project: to_project, user: user) }.to change { product_set.set_tool_handovers.count }.by(0)
      expect(product_set.current_set_tool_handover(to_project).tool_handovers.count).to eq set_tool_handover.tool_handovers.count
      expect(product_set.current_set_tool_handover(to_project).tool_handovers.first.handover_compilation_steps.count).to eq tool_handover.handover_compilation_steps.count
    end



  end
end