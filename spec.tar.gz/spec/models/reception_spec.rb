require 'rails_helper'

describe Reception do
  it 'has a valid Factory' do
    expect(create(:reception)).to be_valid
  end

  context "Validations and Data" do

    let(:data_release)  { create(:data_release) }
    let(:data_type)     { create(:data_type) }
    let(:region)        { create(:region) }

    let(:reception_params) {
      attributes_for(:reception,
                     area_id: region.id,
                     data_release_id: data_release.id,
                     data_type_id: data_type.id)
    }

    it "is valid when optional revision not present" do
      reception_params[:revision] = nil
      expect(Reception.new(reception_params)).to be_valid
    end

    # 1 letter (UPPERCASE) , a number between 0 and 99, a letter (UPPERCASE), a number between 0 and 99
    %w{ A00Z00 Z99Z99 G03Z67}.each do |text|
      it { is_expected.to allow_value(text).for(:revision) }
    end

    %w{ A0Z00 a00z00 A00z00 -99Z99 g03767 0 Z ZZZZZZ 999999}.each do |text|
      it { is_expected.to_not allow_value(text).for(:revision) }
    end
  end

end
