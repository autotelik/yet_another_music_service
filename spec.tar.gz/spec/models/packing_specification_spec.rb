require 'rails_helper'

describe PackingSpecification do
  it 'has a valid Factory' do
    expect(create(:packing_specification)).to be_valid
  end

  describe 'ActiveRecord associations' do
    it { should have_many(:shipping_specifications) }
  end

  context "Validations and Data" do
    it { is_expected.to validate_presence_of(:name) }
    it { is_expected.to validate_uniqueness_of(:name) }
  end

  context "Setting and Changing Status" do
    let(:packing_specification) { create(:packing_specification, updated_by: review_user.user_name) }

    let(:review_user) { create(:TESTUSER) }
    let(:user)        { create(:user) }

    let(:user_name)   { user.user_name }

    it "has a collection of possible statuses" do
      expect(PackingSpecification.status_array).to be_a Array
      expect(PackingSpecification.status_array).not_to be_empty
    end

    it "has helpers to identify current status" do
      expect(packing_specification.respond_to?('draft?')).to be_truthy
      expect(packing_specification.respond_to?(:obsolete?)).to be_truthy

      packing_specification.status = PackingSpecification::STATUS_REVIEW
      expect(packing_specification.review?).to eq true
      expect(packing_specification.draft?).to eq false

      packing_specification.status = PackingSpecification::STATUS_DRAFT
      expect(packing_specification.review?).to eq false
      expect(packing_specification.draft?).to eq true
    end

    it "can return the stringified version of a status" do
      expect(packing_specification.status_str).to eq PackingSpecification.status_hash[PackingSpecification::STATUS_NEW]
      packing_specification.status = PackingSpecification::STATUS_REVIEW
      expect(packing_specification.status_str).to eq "Review"
    end

    it "can return the status collection as a multi-dimensional list for dropdowns" do
      list_for_dropdown = PackingSpecification.status_option_list
      expect(list_for_dropdown).to be_a Array

      expect(list_for_dropdown[0]).to be_a Array
      expect(list_for_dropdown[0][0]).to eq "New"
      expect(list_for_dropdown[0][1]).to eq PackingSpecification::STATUS_NEW
    end

    it "can exclude status from dropdown list" do
      list_for_dropdown = PackingSpecification.status_option_list(except: [PackingSpecification::STATUS_NEW,
                                                                           PackingSpecification::STATUS_OBSOLETE])
      expect(list_for_dropdown[0][0]).to eq "Draft"
      expect(list_for_dropdown[0][1]).to eq PackingSpecification::STATUS_DRAFT
    end

    it "disallows a transition to the current state" do
      expect(packing_specification.allow_status_change?(packing_specification.status, true, user_name)).to be_falsey
    end

    it "allows transition to STATUS_DRAFT if not STATUS_OBSOLETE" do
      packing_specification.status = PackingSpecification::STATUS_OBSOLETE
      expect(packing_specification.allow_status_change?(PackingSpecification::STATUS_DRAFT, true, user_name)).to be_falsey

      packing_specification.status = PackingSpecification::STATUS_NEW
      expect(packing_specification.allow_status_change?(PackingSpecification::STATUS_DRAFT, true, user_name)).to be_truthy
    end

    it "allows transition to REVIEW when STATUS_DRAFT" do
      packing_specification.status = PackingSpecification::STATUS_APPROVED
      expect(packing_specification.allow_status_change?(PackingSpecification::STATUS_REVIEW, true, review_user.user_name)).to be_falsey

      packing_specification.status = PackingSpecification::STATUS_DRAFT
      expect(packing_specification.allow_status_change?(PackingSpecification::STATUS_REVIEW, true, user_name)).to be_truthy
    end

    it "allows transition to APPROVED from REVIEW when enforce_review_procedure FALSE (ignores User)" do
      allow(ConfigParameter).to receive(:get).with(:enforce_review_procedure, anything) { false }
      packing_specification.status = PackingSpecification::STATUS_REVIEW
      expect(packing_specification.allow_status_change?(PackingSpecification::STATUS_APPROVED, true, user_name)).to be_truthy
    end

    it "allows transition to APPROVED from REVIEW when user different to review user and NOT approvable" do
      allow(ConfigParameter).to receive(:get).with(:enforce_review_procedure, anything) { true }
      packing_specification.status = PackingSpecification::STATUS_REVIEW
      expect(packing_specification.allow_status_change?(PackingSpecification::STATUS_APPROVED, false, review_user.user_name)).to be_falsey

      expect(packing_specification.allow_status_change?(PackingSpecification::STATUS_APPROVED, false, user_name)).to be_truthy
    end

    it "allows transition to STATUS_OBSOLETE when NOT NEW" do
      packing_specification.status = PackingSpecification::STATUS_NEW
      expect(packing_specification.allow_status_change?(PackingSpecification::STATUS_OBSOLETE, true, user_name)).to be_falsey

      packing_specification.status = PackingSpecification::STATUS_DRAFT
      expect(packing_specification.allow_status_change?(PackingSpecification::STATUS_OBSOLETE, true, user_name)).to be_truthy
      packing_specification.status = PackingSpecification::STATUS_REVIEW
      expect(packing_specification.allow_status_change?(PackingSpecification::STATUS_OBSOLETE, true, user_name)).to be_truthy
      packing_specification.status = PackingSpecification::STATUS_APPROVED
      expect(packing_specification.allow_status_change?(PackingSpecification::STATUS_OBSOLETE, true, user_name)).to be_truthy
    end

  end

end
