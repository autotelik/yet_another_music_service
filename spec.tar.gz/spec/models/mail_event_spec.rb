require 'rails_helper'

describe MailEvent do
  context "Validations and Data" do
    it { is_expected.to validate_presence_of(:name) }


    # Return list of email addresses for all Users subscribed to this Event
    def subscribed_email_addresses
      return self.users.collect(&:email).compact.uniq
    end

    let(:new_mail_event)  { create(:mail_event) }
    let(:mail_event)      { create(:mail_event, :with_users) }

    it "returns empty list when no subscribed Users" do
      expect(new_mail_event.subscribed_email_addresses).to be_a Array
      expect(new_mail_event.subscribed_email_addresses.size).to eq(0)
    end

    it "returns list of unique email addresses for all subscribed Users" do
      mail_event.users << mail_event.users[0]

      expect(mail_event.users.size).to eq(5)
      expect(mail_event.subscribed_email_addresses.size).to eq(4)
      expect(mail_event.subscribed_email_addresses[0]).to be_a String
      expect(mail_event.subscribed_email_addresses[0]).to include '@'
    end

  end
end
