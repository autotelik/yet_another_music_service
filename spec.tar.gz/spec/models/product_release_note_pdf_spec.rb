require 'rails_helper'

describe ProductReleaseNotePdf do

  let(:pdf)                   { ProductReleaseNotePdf.new(product_release_note) }
  let(:production_order)      { build(:production_order) }
  let(:product_set)           { build(:product_set) }
  let(:product_release_note)  { ProductReleaseNote.new }
  # needed when pulling set tool handover info
  let!(:proj_PRODUCTION)      { create(:proj_PRODUCTION) }

  RSpec.shared_examples 'Zip Package' do |name, expected, tmp_dir|

    tmp_dir ||= scratch_path

    before(:each) do
      expect_any_instance_of(ProductReleaseNotePdf).to receive(:zip_file_name) { name }

      expect_any_instance_of(ProductReleaseNote).to receive(:production_order).at_least(:once) { production_order }
      expect_any_instance_of(ProductionOrder).to receive(:product_set).at_least(:once) { product_set }

      add_dummy_files_to_scratch(FileSystemUtil.sanitize_filepath!(tmp_dir)) # we need a file in there, so zip is created
    end

    it 'can create and chmod a zip file' do
      expect_zip = File.join(tmp_dir, expected)
      expect(pdf.zip_package(tmp_dir)).to eq expect_zip
      expect(File.exist?(expect_zip)).to be_truthy
    end
  end

  context '.zip' do
    it_should_behave_like 'Zip Package', 'GR5.1IU-GEN_HER_EUR_18Q1.zip', 'GR5.1IU-GEN_HER_EUR_18Q1.zip'
  end

  context '..zip' do
    it_should_behave_like 'Zip Package', 'GR5.1IU-GEN_HER_EUR_18Q1..zip', 'GR5.1IU-GEN_HER_EUR_18Q1..zip'
  end

  context '...zip' do
    it_should_behave_like 'Zip Package', 'GR5.1IU-GEN_HER_EUR_18Q1...zip', 'GR5.1IU-GEN_HER_EUR_18Q1_.zip'
  end

  context '* ^ &' do
    it_should_behave_like 'Zip Package', 'GR*.1I^-GEN_HE&&_EUR_18Q1$@.zip', 'GR_.1I_-GEN_HE___EUR_18Q1__.zip'
  end

  context '* ^ & in path' do
    before { FileUtils.mkdir_p(File.join(scratch_path, '/_path/path_2/')) }
    it_should_behave_like 'Zip Package',
                          'GR*.1I^-GEN_HE&&_EUR_18Q1$@.zip',
                          'GR_.1I_-GEN_HE___EUR_18Q1__.zip',
                          File.join(scratch_path, '/*path/path#2/')
  end

end
