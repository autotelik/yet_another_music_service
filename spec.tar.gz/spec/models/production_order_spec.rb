require 'rails_helper'

describe ProductionOrder do
  it 'has a valid Factory' do
    expect(create(:production_order)).to be_valid
  end

  # lazily loaded to ensure it's only used when it's needed
  let(:production_order) { create(:production_order) }
  let(:user) { create(:user) }

  describe 'ActiveRecord associations' do
    # Associations
    # TODO: associations with documents, product_release_note,
    # rel_notes_request_user, rel_notes_send_user not tested as they might be removed in
    # the near feature. If not they should be added
    it { should have_many(:production_orderlines) }
    it { should have_many(:product_lines) }
    it { should have_many(:commitment_dates) }
    it { should have_many(:change_log_lines) }
    it { should have_one(:outbound_order) }
    it { should belong_to(:product_set) }
    it { should belong_to(:ordertype) }
    it { should have_one(:product_category) }
    it { should belong_to(:shipping_specification) }
    it { should belong_to(:project) }
  end

  context 'change_log concern' do
    it_behaves_like 'change_log'
  end

  context 'handle_status concern' do
    it_behaves_like 'handle_status', :skip_status_change
  end

  context 'Setting and Changing Status' do

    it 'invalidates a transition to the current state' do
      expect(production_order.status_change_valid?(production_order.status)).to be_falsey
    end

    it 'invalidates a transition to a non-existing state' do
      expect(production_order.status_change_valid?('xdfdfarev')).to be_falsey
    end

    it 'invalidates a transition from an end status' do
      production_order.status = ProductionOrder::END_STATUSES.first
      expect(production_order.status_change_valid?((ProductionOrder.status_hash.keys - ProductionOrder::END_STATUSES).first)).to be_falsey
    end

    it 'validates a transition from a non-end status to an end-status' do
      production_order.status = (ProductionOrder.status_hash.keys - ProductionOrder::END_STATUSES).first
      expect(production_order.status_change_valid?(ProductionOrder::END_STATUSES.first)).to be_truthy
    end

    it 'implements the allow_status_change method' do
      expect(production_order.allow_status_change?(production_order.status)).to be_falsey
    end

    it 'validates the current status' do
      expect(production_order.allow_status?(production_order.status)).to be_truthy
    end

    it 'validates a status if the status change is allowed' do
      allow_any_instance_of(ProductionOrder).to receive(:allow_status_change?) { true }
      expect(production_order.allow_status?(ProductionOrder::END_STATUSES.first)).to be_truthy
    end

    it 'validates a status if the status change is not allowed' do
      allow_any_instance_of(ProductionOrder).to receive(:allow_status_change?) { false }
      expect(production_order.allow_status?(ProductionOrder::END_STATUSES.first)).to be_falsey
    end

    it 'does not change a status to itself' do
      new_status = production_order.status
      val = production_order.change_status(new_status, user)
      expect(val).to be_falsey
      expect(production_order.status).to eq(new_status)
    end

    it 'does not change a status if the status change is not allowed' do
      allow_any_instance_of(ProductionOrder).to receive(:allow_status_change?) { false }
      new_status = ProductionOrder::END_STATUSES.first
      val = production_order.change_status(new_status, user)
      expect(val).to be_falsey
      expect(production_order.status).to_not eq(new_status)
    end

    it 'does change a status if the status change is allowed' do
      allow_any_instance_of(ProductionOrder).to receive(:allow_status_change?) { true }
      new_status = ProductionOrder::END_STATUSES.first
      val = production_order.change_status(new_status, user)
      expect(val).to be_truthy
      expect(production_order.status).to eq(new_status)
    end

    it 'allows the current state' do
      expect(production_order.allow_status?(production_order.status)).to be_truthy
    end

    it 'disallows a non-existing state when not already in it' do
      expect(production_order.allow_status?('xdfdfarev')).to be_falsey
    end

    it 'disallows a different status when in an end status' do
      production_order.status = ProductionOrder::END_STATUSES.first
      expect(production_order.allow_status?((ProductionOrder.status_hash.keys - ProductionOrder::END_STATUSES).first)).to be_falsey
    end

    it 'checks on an end status' do
      expect(production_order.end_status?).to be_falsey
      production_order.status = ProductionOrder::END_STATUSES.first
      expect(production_order.end_status?).to be_truthy
    end

    it 'allows a status change from ENTRY to PLANNING' do
      val = production_order.change_status(ProductionOrder::STATUS_PLANNING, user)
      expect(val).to be_truthy
      expect(production_order.status).to eq(ProductionOrder::STATUS_PLANNING)
    end

    it 'will not allow a status change from ENTRY to PRODUCTION' do
      val = production_order.change_status(ProductionOrder::STATUS_PRODUCTION, user)
      expect(val).to be_falsey
      expect(production_order.status).to eq(ProductionOrder::STATUS_ORDER_ENTRY)
    end

    it 'will not allow a status change to FINISHED without proper handling of the status of its lines' do
      po = create(:production_order, :with_production_orderlines)
      po.status = ProductionOrder::STATUS_PRODUCTION
      val = po.change_status(ProductionOrder::STATUS_FINISHED, user)
      expect(val).to be_falsey
      expect(po.status).to eq(ProductionOrder::STATUS_PRODUCTION)
      val = po.change_status(ProductionOrder::STATUS_FINISHED, user, :cancel)
      expect(val).to be_truthy
      expect(po.status).to eq(ProductionOrder::STATUS_FINISHED)
      expect(po.production_orderlines.first.status).to eq(ProductionOrderline::STATUS_CANCELLED)
    end
  end

  describe 'public instance methods' do
    context 'responds to its methods' do
      # TODO: Add the other instance methods scenarios
      it { expect(production_order).to respond_to(:clone) }
    end

    context 'executes methods correctly' do

      context 'options' do

        let(:po) { create(:production_order) }

        let(:empty_order_params)      { OrderParameters.new }
        let(:empty_orderline_params)  { Api::OrderLineParameters.new }

        let(:order_params) { empty_order_params.tap { |o| o.ignore_conversion_failures = true } }

        it 'can store an option value in DB' do
          expect {
            po.persist_order_parameters(order_params)
          }.to change(po, :ignore_conversion_failures).to true

        end

        context 'option access' do

          it 'can cast a true string value to a bool' do
            po.persist_order_parameters(order_params)
            expect(po.ignore_conversion_failures?).to be true
          end

          it 'can cast non true string option value to a bool' do
            empty_order_params.ignore_conversion_failures = 'false'
            po.persist_order_parameters(empty_order_params)
            expect(po.ignore_conversion_failures?).to be false

            empty_order_params.ignore_conversion_failures = false
            po.persist_order_parameters(empty_order_params)
            expect(po.ignore_conversion_failures?).to be false
          end

          it 'returns false when option never set' do
            po.persist_order_parameters(empty_order_params)
            expect(po.ignore_conversion_failures?).to be false
          end

          it 'returns list of Steps for which force create set' do
            [false, false, true, false, true, true, false].each do |f|
              empty_orderline_params.steps << Api::OrderLineParameters::Step.new.tap { |s| s.force_create = f }
            end
            expect(empty_orderline_params.steps.size).to eq 7
            expect(empty_orderline_params.force_create_steps).to match_array [2, 4, 5]
          end

        end

      end

      # TODO: Add the other instance methods
      context 'clone' do
        it 'gets cloned' do
          po = create(:po_clone)
          pol_line1 = create(:pol_line1, production_order: po)
          pol_line2 = create(:pol_line2, production_order: po)
          pol_fe1 = create(:pol_fe1, production_order: po)
          pol_fe2 = create(:pol_fe2, production_order: po)
          pol_be1 = create(:pol_be1, production_order: po)
          pol_be2 = create(:pol_be2, production_order: po)
          po_cloned = po.clone(User.system_user)
          expect(po_cloned.name).to eq("2nd order: #{po.name}")
          expect(po_cloned.status).to eq(ProductionOrder::STATUS_PLANNING)
          expect(po_cloned.requestor).to eq(User.system_user.full_name)
          expect(po_cloned.expired_yn).to eq(false)
          expect(po_cloned.clone_of_production_order_id).to eq(po.id)
          expect(po_cloned.baseline_commitment_date).to eq(nil)
          expect(po_cloned.modified_commitment_date).to eq(nil)
          expect(po_cloned.comments).to include('Cloned from ')

          expect(po_cloned.production_orderlines.where(remarks: pol_line1.remarks).count).to eq(1)
          expect(po_cloned.production_orderlines.where(remarks: pol_line2.remarks).count).to eq(1)
          expect(po_cloned.production_orderlines.where(remarks: pol_fe1.remarks).count).to eq(1)
          expect(po_cloned.production_orderlines.where(remarks: pol_fe2.remarks).count).to eq(1)
          expect(po_cloned.production_orderlines.where(remarks: pol_be1.remarks).count).to eq(0)
          expect(po_cloned.production_orderlines.where(remarks: pol_be2.remarks).count).to eq(1)
          expect(po_cloned.production_orderlines.count).to eq(5)

          cloned_line = po_cloned.production_orderlines.find_by_remarks(pol_line2.remarks)
          expect(cloned_line.prior_volume_id).to eq(pol_line2.volume_id)
          expect(cloned_line.chosen_conversion).to eq(nil)
          expect(cloned_line.action_required_yn).to eq(true)
          expect(cloned_line.parent_linenr).to eq(nil)
          expect(cloned_line.design_sequence).to eq(nil)
          expect(cloned_line.bp_message).to include('ACTION REQUIRED, new clone of ')
          expect(cloned_line.status).to eq(ProductionOrderline::STATUS_REQUEST_CONVERSION)
          expect(cloned_line.quantity).to eq(1)
          expect(cloned_line.owner).to eq(User.system_user.user_name)
          expect(cloned_line.product_line_id).to eq(pol_line2.product_line_id)
          expect(cloned_line.rdo_path).to eq(pol_line2.rdo_path)
          expect(cloned_line.test_yn).to eq(pol_line2.test_yn)
          expect(cloned_line.test_grid_nrof_servers).to eq(pol_line2.test_grid_nrof_servers)
          expect(cloned_line.test_grid_region_id).to eq(pol_line2.test_grid_region_id)
          expect(cloned_line.test_grid_priority).to eq(pol_line2.test_grid_priority)
          expect(cloned_line.aknavi_db).to eq(pol_line2.aknavi_db)
          expect(cloned_line.ref_db).to eq(pol_line2.ref_db)
          expect(cloned_line.ship_yn).to eq(pol_line2.ship_yn)

          cloned_line2 = po_cloned.production_orderlines.find_by_remarks(pol_be2.remarks)
          expect(cloned_line2.parent_linenr).to eq(nil)
          expect(cloned_line2.design_sequence).to eq(nil)
          expect(cloned_line2.parameter_set_id).to eq(pol_be2.parameter_set_id)
          expect(cloned_line2.product_id).to eq(pol_be2.product_id)

          po_cloned2 = po_cloned.clone(User.system_user)
          expect(po_cloned2.name).to eq("3rd order: #{po.name}")
          expect(po_cloned2.production_orderlines.count).to eq(5)
        end
      end
    end
  end
end