require 'rails_helper'

describe Conversion do
  let(:conversion)         { create(:conversion, :with_database, :with_product_line) }
  let(:conversion2)        { create(:conversion, :with_database, :with_product_line) }
  let(:conversion_skipped) { create(:conversion, :with_database, :with_product_line, status: Conversion::STATUS_SKIPPED) }
  let(:user)               { create(:user) }
  let!(:linked_job)         { create(:lj_included, conversion: conversion, job: conversion2.conversion_jobs.first) }
  let!(:linked_job_skipped) { create(:lj_included, conversion: conversion_skipped, job: conversion2.conversion_jobs.first) }

  it 'handles finish correctly' do
    # expected behavior
    # - does nothing if conversion is already in an end-status
    # - finishes the conversion
    # - only finishes all generated conversion jobs, so does not affect included ones
    # - only finishes all generated conversion databases, so do not affect included ones
    expect(conversion.status).to eq Conversion::STATUS_CONVERSION
    expect(conversion2.status).to eq Conversion::STATUS_CONVERSION
    conversion.finish
    expect(conversion.status).to eq Conversion::STATUS_FINISHED
    expect(conversion2.status).to eq Conversion::STATUS_CONVERSION
    expect(conversion.generated_conversion_jobs.first.status).to eq Job::STATUS_CANCELLED
    expect(conversion.generated_conversion_databases.first.status).to eq ConversionDatabase::STATUS_NOT_VALIDATED
    expect(conversion.generated_conversion_databases.first.file_system_status).to eq ConversionDatabase::FILE_SYSTEM_STATUS_AVAILABLE
    included_conversion_jobs = conversion.conversion_jobs - conversion.generated_conversion_jobs
    included_conversion_databases = conversion.conversion_databases - conversion.generated_conversion_databases
    expect(included_conversion_jobs.first.status).to eq Job::STATUS_PLANNED
    expect(included_conversion_databases.first.status).to eq ConversionDatabase::STATUS_HAS_ERRORS

    conversion_skipped.finish(user)
    expect(conversion_skipped.status).to eq Conversion::STATUS_SKIPPED
    expect(conversion_skipped.generated_conversion_jobs.first.status).to eq Job::STATUS_PLANNED
    expect(conversion_skipped.generated_conversion_databases.first.status).to eq ConversionDatabase::STATUS_HAS_ERRORS
  end

  it 'handles cancel correctly' do
    # expected behavior
    # - does nothing if conversion is already in an end-status
    # - cancels the conversion
    # - only cancels all generated conversion jobs, so does not affect included ones
    # - only cancels all generated conversion databases, so does not affect included ones
    conversion.cancel(user)
    expect(conversion.status).to eq Conversion::STATUS_CANCELLED
    expect(conversion2.status).to eq Conversion::STATUS_CONVERSION
    expect(conversion.generated_conversion_jobs.first.status).to eq Job::STATUS_CANCELLED
    expect(conversion.generated_conversion_databases.first.status).to eq ConversionDatabase::STATUS_NOT_VALIDATED
    expect(conversion.generated_conversion_databases.first.file_system_status).to eq ConversionDatabase::FILE_SYSTEM_STATUS_AVAILABLE
    included_conversion_jobs = conversion.conversion_jobs - conversion.generated_conversion_jobs
    included_conversion_databases = conversion.conversion_databases - conversion.generated_conversion_databases
    expect(included_conversion_jobs.first.status).to eq Job::STATUS_PLANNED
    expect(included_conversion_databases.first.status).to eq ConversionDatabase::STATUS_HAS_ERRORS

    conversion_skipped.cancel
    expect(conversion_skipped.status).to eq Conversion::STATUS_SKIPPED
    expect(conversion_skipped.generated_conversion_jobs.first.status).to eq Job::STATUS_PLANNED
    expect(conversion_skipped.generated_conversion_databases.first.status).to eq ConversionDatabase::STATUS_HAS_ERRORS
  end

  it 'handles terminate correctly' do
    # expected behavior
    # - cancels the conversion if it is not yet in an end-status
    # - only terminates all generated conversion jobs, so does not affect included ones
    # - only terminates all generated conversion databases, so does not affect included ones
    conversion.terminate
    expect(conversion.status).to eq Conversion::STATUS_CANCELLED
    expect(conversion2.status).to eq Conversion::STATUS_CONVERSION
    expect(conversion.generated_conversion_jobs.first.status).to eq Job::STATUS_CANCELLED
    expect(conversion.generated_conversion_databases.first.status).to eq ConversionDatabase::STATUS_CANCELLED
    expect(conversion.generated_conversion_databases.first.file_system_status).to eq ConversionDatabase::FILE_SYSTEM_STATUS_MARKED_FOR_REMOVAL
    included_conversion_jobs = conversion.conversion_jobs - conversion.generated_conversion_jobs
    included_conversion_databases = conversion.conversion_databases - conversion.generated_conversion_databases
    expect(included_conversion_jobs.first.status).to eq Job::STATUS_PLANNED
    expect(included_conversion_databases.first.status).to eq ConversionDatabase::STATUS_HAS_ERRORS

    conversion_skipped.terminate(user)
    expect(conversion_skipped.status).to eq Conversion::STATUS_SKIPPED
    expect(conversion_skipped.generated_conversion_jobs.first.status).to eq Job::STATUS_CANCELLED
    expect(conversion_skipped.generated_conversion_databases.first.status).to eq ConversionDatabase::STATUS_CANCELLED
  end

  it 'handles expire correctly' do
    # expected behavior
    # - cancels the conversion if it is not yet in an end-status
    # - for each conversion database (both generated and included), if all conversions this database belongs to are set to expired, mark for removal that conversion database
    # - accept an optional user parameter
    conversion.production_orderline.production_order.update_attribute(:expired_yn, true)
    conversion2.production_orderline.production_order.update_attribute(:expired_yn, false)

    conversion.expire(user)
    expect(conversion.status).to eq Conversion::STATUS_CANCELLED
    expect(conversion2.status).to eq Conversion::STATUS_CONVERSION
    expect(conversion.generated_conversion_databases.first.file_system_status).to eq ConversionDatabase::FILE_SYSTEM_STATUS_MARKED_FOR_REMOVAL
    included_conversion_databases = conversion.conversion_databases - conversion.generated_conversion_databases
    expect(included_conversion_databases.first.file_system_status).to eq ConversionDatabase::FILE_SYSTEM_STATUS_AVAILABLE

    conversion_skipped.production_orderline.production_order.update_attribute(:expired_yn, true)
    conversion2.production_orderline.production_order.update_attribute(:expired_yn, true)

    conversion_skipped.expire
    expect(conversion_skipped.status).to eq Conversion::STATUS_SKIPPED
    expect(conversion2.status).to eq Conversion::STATUS_CONVERSION
    expect(conversion_skipped.generated_conversion_databases.first.file_system_status).to eq ConversionDatabase::FILE_SYSTEM_STATUS_MARKED_FOR_REMOVAL
    included_conversion_databases = conversion_skipped.conversion_databases - conversion_skipped.generated_conversion_databases
    expect(included_conversion_databases.first.file_system_status).to eq ConversionDatabase::FILE_SYSTEM_STATUS_MARKED_FOR_REMOVAL
  end
end