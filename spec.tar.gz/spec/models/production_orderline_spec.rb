require 'rails_helper'

describe ProductionOrderline do
  context 'change_log concern' do
    it_behaves_like 'change_log'
  end

  context 'handle_status concern' do
    it_behaves_like 'handle_status', :skip_status_change
  end

  context 'Setting and Changing Status' do
    let(:production_orderline) { create(:production_orderline, :with_chosen_conversion) }
    let(:user) { create(:user) }

    it 'invalidates a transition to the current state' do
      expect(production_orderline.status_change_valid?(production_orderline.status)).to be_falsey
    end

    it 'invalidates a transition to a non-existing state' do
      expect(production_orderline.status_change_valid?('xdfdfarev')).to be_falsey
    end

    it 'invalidates a transition from an end status' do
      production_orderline.status = ProductionOrderline::END_STATUSES.first
      expect(production_orderline.status_change_valid?((ProductionOrderline.status_hash.keys - ProductionOrderline::END_STATUSES).first)).to be_falsey
    end

    it 'validates a transition from a non-end status to an end-status' do
      production_orderline.status = (ProductionOrderline.status_hash.keys - ProductionOrderline::END_STATUSES).first
      expect(production_orderline.status_change_valid?(ProductionOrderline::END_STATUSES.first)).to be_truthy
    end

    it 'implements the allow_status_change method' do
      expect(production_orderline.allow_status_change?(production_orderline.status)).to be_falsey
    end

    it 'validates the current status' do
      expect(production_orderline.allow_status?(production_orderline.status)).to be_truthy
    end

    it 'validates a status if the status change is allowed' do
      allow_any_instance_of(ProductionOrderline).to receive(:allow_status_change?) { true }
      expect(production_orderline.allow_status?(ProductionOrderline::END_STATUSES.first)).to be_truthy
    end

    it 'validates a status if the status change is not allowed' do
      allow_any_instance_of(ProductionOrderline).to receive(:allow_status_change?) { false }
      expect(production_orderline.allow_status?(ProductionOrderline::END_STATUSES.first)).to be_falsey
    end

    it 'does not change a status to itself' do
      new_status = production_orderline.status
      val = production_orderline.change_status(new_status)
      expect(val).to be_falsey
      expect(production_orderline.status).to eq(new_status)
    end

    it 'does not change a status if the status change is not allowed' do
      allow_any_instance_of(ProductionOrderline).to receive(:allow_status_change?) { false }
      new_status = ProductionOrderline::END_STATUSES.first
      val = production_orderline.change_status(new_status)
      expect(val).to be_falsey
      expect(production_orderline.status).to_not eq(new_status)
    end

    it 'does change a status if the status change is allowed' do
      allow_any_instance_of(ProductionOrderline).to receive(:allow_status_change?) { true }
      new_status = ProductionOrderline::END_STATUSES.first
      val = production_orderline.change_status(new_status)
      expect(val).to be_truthy
      expect(production_orderline.status).to eq(new_status)
    end

    it 'allows the current state' do
      expect(production_orderline.allow_status?(production_orderline.status)).to be_truthy
    end

    it 'disallows a non-existing state when not already in it' do
      expect(production_orderline.allow_status?('xdfdfarev')).to be_falsey
    end

    it 'disallows a different status when in an end status' do
      production_orderline.status = ProductionOrderline::END_STATUSES.first
      expect(production_orderline.allow_status?((ProductionOrderline.status_hash.keys - ProductionOrderline::END_STATUSES).first)).to be_falsey
    end

    it 'checks on an end status' do
      expect(production_orderline.end_status?).to be_falsey
      production_orderline.status = ProductionOrderline::END_STATUSES.first
      expect(production_orderline.end_status?).to be_truthy
    end

    it 'allows a status change from REQUEST_CONVERSION to HANDLE_CONVERSION' do
      production_orderline.production_order.status = ProductionOrder::STATUS_PRODUCTION
      val = production_orderline.change_status(ProductionOrderline::STATUS_HANDLE_CONVERSION)
      expect(val).to be_truthy
      expect(production_orderline.status).to eq(ProductionOrderline::STATUS_HANDLE_CONVERSION)
    end

    it 'will not allow a status change from REQUEST_CONVERSION to EVALUATE' do
      val = production_orderline.change_status(ProductionOrderline::STATUS_EVALUATE)
      expect(val).to be_falsey
      expect(production_orderline.status).to eq(ProductionOrderline::STATUS_REQUEST_CONVERSION)
    end

    it 'will not allow a status change to CANCELLED without proper handling of the status of its lines' do
      production_orderline.status = ProductionOrderline::STATUS_HANDLE_CONVERSION
      val = production_orderline.allow_status_change?(ProductionOrderline::STATUS_CANCELLED)
      expect(val).to be_falsey
      val = production_orderline.allow_status?(ProductionOrderline::STATUS_CANCELLED)
      expect(val).to be_falsey
      val = production_orderline.allow_status_change?(ProductionOrderline::STATUS_CANCELLED, true)
      expect(val).to be_truthy
      val = production_orderline.allow_status?(ProductionOrderline::STATUS_CANCELLED, true)
      expect(val).to be_truthy
      val = production_orderline.change_status(ProductionOrderline::STATUS_CANCELLED)
      expect(val).to be_falsey
      expect(production_orderline.status).to eq(ProductionOrderline::STATUS_HANDLE_CONVERSION)
      val = production_orderline.change_status(ProductionOrderline::STATUS_CANCELLED, true)
      expect(val).to be_truthy
      expect(production_orderline.status).to eq(ProductionOrderline::STATUS_CANCELLED)
      val = production_orderline.allow_status?(ProductionOrderline::STATUS_CANCELLED)
      expect(val).to be_truthy
    end

    it 'will not update the status to CANCELLED without proper handling of the status of its lines' do
      production_orderline.status = ProductionOrderline::STATUS_HANDLE_CONVERSION
      val = production_orderline.update_status(ProductionOrderline::STATUS_CANCELLED, user, false)
      expect(val).to be_falsey
      expect(production_orderline.status).to eq(ProductionOrderline::STATUS_HANDLE_CONVERSION)
      val = production_orderline.update_status(ProductionOrderline::STATUS_CANCELLED, user, true)
      expect(val).to be_truthy
      expect(production_orderline.status).to eq(ProductionOrderline::STATUS_CANCELLED)
    end

    it 'will give the next and previous status' do
      expect(production_orderline.go_back_status).to be_nil
      expect(production_orderline.next_status).to eq(ProductionOrderline::STATUS_HANDLE_CONVERSION)
      production_orderline.status = ProductionOrderline::STATUS_EVALUATE
      expect(production_orderline.go_back_status).to eq(ProductionOrderline::STATUS_REQUEST_CONVERSION)
      expect(production_orderline.next_status).to eq(ProductionOrderline::STATUS_FINISHED)
      production_orderline.ship_yn = true
      expect(production_orderline.next_status).to eq(ProductionOrderline::STATUS_REQUEST_SHIPMENT)
    end
  end

  describe 'Clone within production order' do
    let(:production_orderline) { create(:production_orderline, :with_chosen_conversion) }
    let(:user) { create(:user) }

    it 'will clone a production_orderline to a new production_orderline within the same production_order' do
      cloned_orderline = production_orderline.clone_orderline(user: user)
      expect(cloned_orderline.id).to_not eq(production_orderline.id)
      expect(cloned_orderline.production_order_id).to eq(production_orderline.production_order_id)
      expect(cloned_orderline.product_accepted).to eq(production_orderline.product_accepted)
      expect(cloned_orderline.prior_volume_id).to eq(production_orderline.volume_id)
      expect(cloned_orderline.chosen_conversion).to be_nil
      expect(cloned_orderline.action_required_yn).to be_truthy
      expect(cloned_orderline.parent_linenr).to be_nil
      expect(cloned_orderline.design_sequence).to be_nil
      expect(cloned_orderline.status).to eq(ProductionOrderline::STATUS_REQUEST_CONVERSION)
    end

    context 'Conversion' do
      it 'clones a conversion within the same production orderline' do
        production_orderline.update_column(:status, ProductionOrderline::STATUS_HANDLE_CONVERSION)
        production_orderline.chosen_conversion.update_column(:status, Conversion::STATUS_FINISHED)

        chosen_conversion = production_orderline.chosen_conversion
        production_orderline.clone_conversion(user)
        expect(chosen_conversion).to_not eq(production_orderline.chosen_conversion)
      end
    end
  end

  describe 'Clone into new production order' do

    let(:po)        { create(:po_clone, status: ProductionOrder::STATUS_ORDER_ENTRY) }
    let(:pol_line1) { create(:pol_line1, :with_chosen_conversion, production_order: po) }

    let(:pol_line1_cloned)  { pol_line1.clone_order(User.system_user) }
    let(:conversion_cloned) { pol_line1_cloned.chosen_conversion }

    context 'cloned ProductionOrder' do

      it 'sets the cloned status on the Order to Production when in end-status' do
        allow_any_instance_of(ProductionOrder).to receive(:end_status?) { true }
        expect(pol_line1_cloned.production_order.status).to eq(ProductionOrder::STATUS_PRODUCTION)
      end

      it 'copies the cloned status (STATUS_PLANNING) of Order when NOT in end-status' do
        allow_any_instance_of(ProductionOrder).to receive(:end_status?) { false }
        expect(pol_line1_cloned.production_order.status).to eq(ProductionOrder::STATUS_PLANNING)
      end
    end

    it 'clones the status REQUEST_CONVERSION' do
      pol_line1.update(status: ProductionOrderline::STATUS_REQUEST_CONVERSION)
      expect(pol_line1_cloned.status).to eq(ProductionOrderline::STATUS_REQUEST_CONVERSION)
    end

    it 'sets the cloned status to HANDLE_CONVERSION if status != REQUEST_CONVERSION' do
      pol_line1.update(status: ProductionOrderline::STATUS_FINISHED)
      expect(pol_line1_cloned.status).to eq(ProductionOrderline::STATUS_HANDLE_CONVERSION)
    end

    context 'Conversion Jobs' do

      let(:no_jobs)           { 3 }
      let(:pol_with_jobs)     { create(:production_orderline, :with_conversion_jobs, job_count: no_jobs) }
      let(:pol_jobs_cloned)   { pol_with_jobs.clone_order(User.system_user) }
      let(:cloned_conversion) { pol_jobs_cloned.chosen_conversion }

      it 'clones the jobs' do
        expect(pol_with_jobs.chosen_conversion.conversion_jobs.size).to eq no_jobs

        expect { pol_jobs_cloned }.to change(LinkedJob, :count).by(no_jobs).and change(ConversionJob, :count).by(no_jobs)

        expect(cloned_conversion.conversion_jobs.size).to eq pol_with_jobs.chosen_conversion.conversion_jobs.size
      end

      it 'clones the jobs pointing to the cloned conversion not the original' do
        pol_jobs_cloned

        expect(pol_jobs_cloned.chosen_conversion.id).to_not eq pol_with_jobs.chosen_conversion.id

        expect(cloned_conversion.conversion_jobs.first.conversion.id).to eq cloned_conversion.id
        expect(cloned_conversion.linked_jobs.first.conversion.id).to eq cloned_conversion.id
      end

    end
  end

  describe 'rdo_file_list' do
    let(:product_set)           { create(:product_set) }
    let(:production_orderline)  { create(:production_orderline) }

    it 'returns a list of RDO full paths' do
      allow_any_instance_of(ProductSet).to receive(:predecessor) { product_set }
      expect(production_orderline.rdo_file_list).to be_a Array
    end
  end
end
