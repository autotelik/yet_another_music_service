require 'rails_helper'

describe MailEventOption do
  context "Validations and Data" do
    it { is_expected.to define_enum_for(:category) }

    #MailEventOption.find_or_create_by!(mail_event: event, category: enum_category,
    # optional_type: type, optional_field: f)

    #UserMailEventOption.where(user: users)
    #  .joins(:mail_event_option)
    #  .where('mail_event_options.mail_event_id': self.mail_event.id,
    #         'mail_event_options.category': :filter_receivers)

  end
end
