require 'rails_helper'

describe DataSet do
  it 'has a valid Factory' do
    expect(create(:data_set)).to be_valid
  end

  describe 'ActiveRecord associations' do
    it { should have_many(:process_data_elements) }
  end

  before(:each) do
    # we dont want anything run in the shell
    allow(ShellUtil).to receive(:ssh_localhost) {}
    allow(ShellUtil).to receive(:ssh_localhost_safe) { '' }
  end

  context 'Validations and Data' do

    let(:data_set)  { create(:data_set, :with_process_data_directory) }
    let(:user)      { create(:user) }

    it { is_expected.to validate_presence_of(:data_type_id) }
    it { is_expected.to validate_presence_of(:company_abbr_id) }
    it { is_expected.to validate_presence_of(:region_id) }
    it { is_expected.to validate_presence_of(:data_release_id) }

    it 'should populate the errors collection when core attributes are not unique' do
      duplicate = data_set.dup
      duplicate.core_attributes_should_be_unique

      expect(duplicate).to be_invalid
      expect(duplicate.errors[:data_release_id].size).to eq(1)
    end

    it 'returns a composite string form of source for tagging' do
      stringified = "#{data_set.data_type.name.downcase}|#{data_set.company_abbr.ms_abbr_3.downcase}|#{data_set.data_release.name.downcase}"
      expect(data_set.source_tag).to eq stringified
    end

    it 'returns a composite string form of source for tagging when no data present' do
      stringified = '-|-|-'
      expect(DataSet.new.source_tag).to eq stringified
    end

    it 'returns a success string message when no exception thrown by validate_element_file_structure' do
      allow(data_set).to receive(:validate_element_file_structure) { true }

      expect(data_set.report_validate_element_file_structure).to include('No problems')
    end

    it 'returns exception string message when validate_element_file_structure fails' do
      allow(data_set).to receive(:validate_element_file_structure) { raise 'Oh Dear RSPEC epic fail' }

      expect(data_set.report_validate_element_file_structure).to include('Oh Dear RSPEC epic fail')
    end

    it "returns requesteer's full name for requester_name" do
      allow(data_set).to receive(:review_request_user_id) { user.id }

      expect(data_set.requester_name).to eq user.full_name
    end


    it 'returns list of used_data_release ids taking revision into account' do

      expect(data_set.used_data_release_ids).to include data_set.data_release_id

      data_set.revision ='Z99Z99'

      expect(data_set.used_data_release_ids).to_not include data_set.data_release_id
    end

    context '#create' do

      include_context 'data_set_prerequisites'

      it 'is valid when optional revision not present' do
        data_set_params[:revision] = nil
        expect(DataSet.new(data_set_params)).to be_valid
      end

      # 1 letter (UPPERCASE) , a number between 0 and 99, a letter (UPPERCASE), a number between 0 and 99
      %w[A00Z00 Z99Z99 G03Z67].each do |text|

        it { is_expected.to allow_value(text).for(:revision) }

        it 'is valid when in correct format' do
          data_set_params[:revision] = text
          expect(DataSet.new(data_set_params)).to be_valid
        end
      end

      %w[A0Z00 a00z00 A00z00 -99Z99 g03767 0 Z ZZZZZZ 999999].each do |text|
        it { is_expected.to_not allow_value(text).for(:revision) }

        it 'is valid when in correct format' do
          data_set_params[:revision] = text
          expect(DataSet.new(data_set_params)).to_not be_valid
        end
      end

      it 'should include data_release in generated directory structure' do
        expect(data_set.generate_directory).to match data_set.data_release.release_code.downcase
      end

      it 'should include revision in generated directory structure' do
        expect(data_set.generate_directory).to match "_#{data_set.revision.downcase}"
        expect(data_set.generate_directory).to match data_set.revision_name_for_dir
      end

      it 'should include filling in generated directory structure' do
        data_set = create(:data_set, :with_process_data_directory, filling: create(:filling, name: 'FILLING_ONLY'))
        data_set.revision = nil
        release = data_set.data_release.release_code.strip.parameterize.underscore.to_s
        expect(data_set.generate_directory).to match "#{release}_filling_only"
      end

      it 'should include filling and revision in generated directory structure' do
        data_set = create(:data_set, :with_process_data_directory, filling: create(:filling, name: 'CUSTOMFILLING'))
        data_set.revision = 'A01B01'
        expect(data_set.generate_directory).to match '_customfilling_a01b01'
      end

    end

  end

  context 'Setting and Changing Status' do
    let(:data_set) { create(:data_set) }

    it 'has a collection of possible statuses' do
      expect(DataSet.status_array).to be_a Array
      expect(DataSet.status_array).not_to be_empty
    end

    it 'has helpers to identify current status' do
      expect(data_set.respond_to?('draft?')).to be_truthy
      expect(data_set.respond_to?('removed?')).to be_truthy

      data_set.status = DataSet::STATUS_REVIEW
      expect(data_set.review?).to eq true
      expect(data_set.draft?).to eq false

      data_set.status = DataSet::STATUS_DRAFT
      expect(data_set.review?).to eq false
      expect(data_set.draft?).to eq true
    end

    it 'can create a new version when status changed and status is REVIEW or DRAFT' do
      # initial state is STATUS_DRAFT
      expect(data_set.create_new_version?).to be_falsey

      data_set.status = DataSet::STATUS_REVIEW
      expect(data_set.create_new_version?).to be_truthy

      data_set.save!
      data_set.status = DataSet::STATUS_DRAFT
      expect(data_set.create_new_version?).to be_truthy

      data_set.save!
      data_set.status = DataSet::STATUS_REMOVAL_CANDIDATE
      expect(data_set.create_new_version?).to be_falsey
    end

    it 'can return the stringified version of a status' do
      expect(data_set.status_str).to eq DataSet.status_hash[DataSet::STATUS_DRAFT]

      data_set.status = DataSet::STATUS_REVIEW
      expect(data_set.status_str).to eq 'Review'
    end

    it 'can return the status collection as a multi-dimensional matrix' do
      expect(DataSet.status_option_list).to be_a Array

      expect(DataSet.status_option_list[0]).to be_a Array
      expect(DataSet.status_option_list[0][0]).to eq 'Draft'
      expect(DataSet.status_option_list[0][1]).to eq DataSet::STATUS_DRAFT
    end

    it 'disallows a transition to the current state' do
      expect(data_set.allow_status_change?(data_set.status)).to be_falsey
    end

    it 'allows transition back to PRODUCTION when regions present and current status > PRODUCTION' do
      data_set.status = DataSet::STATUS_PRODUCTION + 1
      allow(data_set).to receive(:regions) { [] }
      expect(data_set.allow_status_change?(DataSet::STATUS_PRODUCTION)).to be_falsey

      allow(data_set).to receive(:regions) { ['Dummy Region'] }
      expect(data_set.allow_status_change?(DataSet::STATUS_PRODUCTION)).to be_truthy
    end

    it 'always allows transition STATUS_REMOVED' do
      expect(data_set.allow_status_change?(DataSet::STATUS_REMOVED)).to be_truthy

      data_set.status = rand(1000)
      expect(data_set.allow_status_change?(DataSet::STATUS_REMOVED)).to be_truthy
    end

    it 'allows transition to STATUS_WAITING_DELIVERY when regions present and current status DRAFT' do
      allow(data_set).to receive(:regions) { [] }
      expect(data_set.allow_status_change?(DataSet::STATUS_WAITING_DELIVERY)).to be_falsey

      allow(data_set).to receive(:regions) { ['Dummy Region'] }
      expect(data_set.allow_status_change?(DataSet::STATUS_WAITING_DELIVERY)).to be_truthy

      data_set.status = DataSet::STATUS_PRODUCTION
      expect(data_set.allow_status_change?(DataSet::STATUS_WAITING_DELIVERY)).to be_falsey
    end

    it 'allows transition to STATUS_WAITING_DELIVERY when regions present and current status IN PROGRESS' do
      data_set.status = DataSet::STATUS_IN_PROGRESS
      allow(data_set).to receive(:regions) { ['Dummy Region'] }
      expect(data_set.allow_status_change?(DataSet::STATUS_WAITING_DELIVERY)).to be_truthy
    end

    it 'allows transition to STATUS_TEST when regions present and current status WAITING_DELIVERY and File Structure ok' do
      data_set.status = DataSet::STATUS_WAITING_DELIVERY
      allow(data_set).to receive(:regions) { ['Dummy Region'] }
      allow(data_set).to receive(:validate_element_file_structure) { true }
      expect(data_set.allow_status_change?(DataSet::STATUS_TEST)).to be_truthy
    end

    it 'allows transition to STATUS_TEST when REVIEW or PRODUCTION and File Structure ok' do
      allow(data_set).to receive(:regions) { [] }
      expect(data_set.allow_status_change?(DataSet::STATUS_TEST)).to be_falsey

      allow(data_set).to receive(:validate_element_file_structure) { false }
      allow(data_set).to receive(:regions) { ['Dummy Region'] }

      expect(data_set.allow_status_change?(DataSet::STATUS_TEST)).to be_falsey

      allow(data_set).to receive(:validate_element_file_structure) { true }
      expect(data_set.allow_status_change?(DataSet::STATUS_TEST)).to be_truthy

      data_set.status = DataSet::STATUS_PRODUCTION

      allow(data_set).to receive(:allow_edit?) { false }
      expect(data_set.allow_status_change?(DataSet::STATUS_TEST)).to be_falsey

      allow(data_set).to receive(:allow_edit?) { true }
      expect(data_set.allow_status_change?(DataSet::STATUS_TEST)).to be_truthy
    end

    it 'allows transition to FAILED unless current status is REMOVED' do
      expect(data_set.allow_status_change?(DataSet::STATUS_FAILED)).to be_truthy

      data_set.status = DataSet::STATUS_REMOVED
      expect(data_set.allow_status_change?(DataSet::STATUS_FAILED)).to be_falsey
    end
  end

  context 'Dealing with Region', region: true do
    let(:data_set_empty) { create(:data_set) }

    let(:data_set) { create(:data_set, :with_coverages_region) }

    let(:data_set_no_process) { create(:data_set, :with_non_process_coverages_region) }

    context 'Processable Regions' do
      it 'has no processable_regions when no coverage' do
        allow(data_set).to receive(:coverage) { nil }

        expect(data_set.processable_regions).to be_a Array
        expect(data_set.processable_regions).to be_empty
      end

      it 'has processable coverages_regions when coverage set' do
        expect(data_set.processable_regions).to_not be_empty
        expect(data_set.processable_regions.all).to eq data_set.coverages_regions
      end

      it 'does not include coverages_regions when flag do_not_process set to true' do
        expect(data_set_no_process.processable_regions).to be_empty
      end

      it 'provides method to check the region' do
        region_id = data_set.region.id

        expect(data_set.has_region?(region_id)).to be_truthy
        expect(data_set_no_process.has_region?(region_id)).to be_falsey
      end

      it 'returns stringified false when no coverage on checking whether to process region' do
        expect(data_set_empty.coverage).to be_nil
        expect(data_set_empty.do_not_process_value_by_region_id(data_set_empty.region.id)).to eq 'false'
      end

      context 'create_or_find_coverage_region' do
        it 'returns the existing coverage when same regions requested' do
          region_ids = data_set.coverage.regions.collect(&:id)

          expect(data_set.create_or_find_coverage_region(region_ids)).to eq data_set.coverage
        end

        it 'creates a new coverage when no regions supplied' do
          expect { data_set_empty.create_or_find_coverage_region([]) }.to change(Coverage, :count)
        end

        it 'create a new coverage with attributes incl. remarks, region to data_set values' do
          expect { @coverage = data_set_empty.create_or_find_coverage_region([]) }.to change(CoveragesRegion, :count)

          expect(@coverage.regions.first).to eq data_set_empty.region

          remark = "Initiated with data set #{data_set_empty.id} #{data_set_empty.name}"
          expect(@coverage.remarks).to eq remark
        end

        it 'creates a new coverage with supplied region' do
          new_region = create(:region)

          expect do
            @coverage = data_set_empty.create_or_find_coverage_region([new_region.id])
          end.to change(Coverage, :count).and change(CoveragesRegion, :count)

          expect(@coverage.regions.first).to eq new_region
        end
      end
    end
  end

  context 'Elements - Sync', elements: true do

    before(:each) do
      scratch_path_clear
    end

    let(:data_set) { create(:data_set) }

    it 'should throw an exception when dir does not exist during sync_elements' do

      allow_any_instance_of(DataSet).to receive(:generate_directory) { '/rubbish/impossible' }

      expect { data_set.sync_elements }.to raise_error(WebMis::DirectoryNotFound)
    end

    it 'should throw an exception when dir exists but is empty of elements' do

      allow_any_instance_of(DataSet).to receive(:generate_directory) {
        create_scratch_path("an_empty_dir#{gen_timestamp})")
      }

      expect { data_set.sync_elements }.to raise_error(WebMis::DirectoryEmpty)
    end

    context 'DataSet checks directory during sync' do

      before(:each) do
        allow_any_instance_of(DataSet).to receive(:generate_directory) { scratch_path }

        scratch_path_clear
      end

      it 'should throw an exception when dir exists but no matching ProcessDataSpecification found' do
        data_set = create(:data_set, :with_process_data_directory)

        expect { data_set.sync_elements }.to raise_error(WebMis::NoMatchingModel)
      end

      context('Matching ProcessDataSpecification') do

        let(:empty_process_spec_full_path) { create_scratch_path('empty_process_spec_path') }

        # The ProcessDataSpecification does not use whole path, just the directory name
        let(:process_spec_basename) { File.basename(empty_process_spec_full_path) }

        let(:process_data_specification) {
          create(:process_data_specification, directory: File.basename(empty_process_spec_full_path), data_type_id: data_set.data_type.id)
        }

        before(:each) do
          process_data_specification
        end

        it 'should be able to find a matching ProcessDataSpecification based on the directory' do
          expect(data_set.find_specification_for_dir(process_spec_basename)).to eq process_data_specification
        end

        it 'should check the ProcessDataSpecification directory for content' do

          allow_any_instance_of(DataSet).to receive(:find_specification_for_dir) { process_data_specification }

          expect {
            data_set.sync_elements
          }.to raise_error(WebMis::DirectoryEmpty, "#{empty_process_spec_full_path} has no content!")
        end

        it 'should process file based on default when no config param and file is region' do
          Dir.mktmpdir do |dir|
            FileUtils.touch(File.join(dir, Region.active.map(&:region_code).first))
            FileUtils.touch(File.join(dir, Region.active.map(&:region_code).last))

            Dir[File.join(dir, '*')].each do |dir_sub_region|
              region, skip = data_set.check_is_region(dir_sub_region)
              expect(region).to be_a Region
              expect(skip).to be false
            end
          end
        end

        it 'should raise error during directory sync when file does NOT match region' do
          Dir.mktmpdir do |dir|
            FileUtils.touch(File.join(dir, 'some_xml_file.xml'))
            Dir[File.join(dir, '*')].each do |dir_sub_region|
              expect{
                data_set.check_is_region(dir_sub_region)
              }.to raise_error(RuntimeError, "File #{dir_sub_region} is not defined as region!")
            end
          end
        end

        it 'should set skip true and NOT raise error during  sync when file is skippable' do

          allow(ConfigParameter).to receive(:get).with(:skip_files_during_sync) {
            'multinet-.*\\.xml'
          }

          Dir.mktmpdir do |dir|
            FileUtils.touch(File.join(dir, 'multinet-hello.xml'))
            FileUtils.touch(File.join(dir, 'multinet-r-1.xml'))
            Dir[File.join(dir, '*')].each do |dir_sub_region|
              region, skip = data_set.check_is_region(dir_sub_region)
              expect(region).to be_nil
              expect(skip).to be true
            end
          end
        end

        it 'should set skip true based on ConfigParameter if set' do

          allow(ConfigParameter).to receive(:get).with(:skip_files_during_sync) {
            'multinet-.*\\.xml|this_aint_no_region.json|.*\\.bash'
          }

          Dir.mktmpdir do |dir|
            FileUtils.touch(File.join(dir, 'multinet-hello.xml'))
            FileUtils.touch(File.join(dir, 'some_script.bash'))
            FileUtils.touch(File.join(dir, 'multinet-r-1.xml'))
            FileUtils.touch(File.join(dir, 'this_aint_no_region.json'))
            Dir[File.join(dir, '*')].each do |dir_sub_region|
              region, skip = data_set.check_is_region(dir_sub_region)
              expect(region).to be_nil
              expect(skip).to be true
            end

            region_file = FileUtils.touch(File.join(dir, Region.active.map(&:region_code).first)).first

            region, skip = data_set.check_is_region(region_file)
            expect(region).to be_a Region
            expect(skip).to be false
          end
        end

      end # context
    end # context

    context 'DataSet creates ProcessDataElement' do

      before(:all) do
        scratch_path_clear
      end

      let(:process_spec_dir) { create_scratch_path('scratch_process_spec_dir') }

      # The ProcessDataSpecification does not use whole path, just the directory name
      let(:basename_process_spec_dir) { File.basename(process_spec_dir) }

      let(:process_data_specification) {
        create(:process_data_specification, directory: basename_process_spec_dir, data_type_id: data_set.data_type.id)
      }

      it 'should create a new ProcessDataElement when valid directory and ProcessDataSpecification found' do

        allow_any_instance_of(DataSet).to receive(:generate_directory)         { process_spec_dir }
        allow_any_instance_of(DataSet).to receive(:find_specification_for_dir) { process_data_specification }
        allow_any_instance_of(DataSet).to receive(:get_file_dirs)              { [process_spec_dir] }
        allow_any_instance_of(DataSet).to receive(:remove_unused_elements)     { true }
        allow_any_instance_of(ProcessDataElement).to receive(:update_script_line_json)     { '{}' }

        # We can't stub all file systems calls so add a dummy file to ProcessDataElement scratch area
        FileUtils.touch(File.join(process_spec_dir, 'rspec_dummy_file.txt'))

        expect { data_set.sync_elements }.to change(ProcessDataElement, :count).by(1)
      end

      # TODO: - The sync_elements branch "split_by_values are only regions for now" is too complex to test for now
      # this is a candidate for refactoring - break section up into smaller testable methods
    end
  end

  context 'Class level create (factory)' do

    let(:data_set) { create(:data_set, :with_coverages_region) }

    let(:reception) { create(:reception) }
    let(:data_type) { create(:data_type) }

    before(:each) do
      allow_any_instance_of(DataSet).to receive(:generate_directory)     { scratch_path }
      allow_any_instance_of(DataSet).to receive(:get_file_dirs)          { [scratch_path] }
      allow_any_instance_of(DataSet).to receive(:remove_unused_elements) { true }

      scratch_path_clear
    end

    it 'raises exception unless params contains a valid Supplier id' do
      expect {
        DataSet.factory({})
      }.to raise_error(WebMis::MissingParam, /No :supplier key found in params/)

      expect { DataSet.factory({ supplier: 'blah' }) }.to raise_error(WebMis::NoMatchingModel)
    end

    it 'raises exception unless params contains a valid Reception id' do

      params = { supplier: data_set.company_abbr.name }

      expect {
        DataSet.factory(params)
      }.to raise_error('No reception with id  found.')

      expect {
        DataSet.factory(params.merge(reception_id: 0))
      }.to raise_error('No reception with id 0 found.')
    end

    it 'raises exception unless reception is not assigned to any DataSet' do
      reception.data_set = data_set
      reception.save!

      id = reception.id

      params = { supplier: data_set.company_abbr.name, reception_id: id }

      expect {
        DataSet.factory(params)
      }.to raise_error("Reception ID: '#{id}' already part of data set ID: '#{data_set.id}'")

    end

    it 'raises exception unless params contains valid DataType id' do
      params = { supplier: data_set.company_abbr.name, reception_id:  reception.id }

      expect { DataSet.factory(params) }.to raise_error("Data Type '' not found.")

      params[:data_type] = 0
      expect { DataSet.factory(params) }.to raise_error("Data Type '0' not found.")

    end

    it 'creates a new DataSet when params valid' do
      params = {
        supplier:     data_set.company_abbr.name,
        reception_id: reception.id,
        data_type:    data_type.name,
        region_code:  data_set.region.region_code
      }

      # we can't stub all file systems calls so add a dummy file to the test scratch area
      add_dummy_files_to_scratch

      process_data_specification = create(:process_data_specification, directory: scratch_path)

      allow_any_instance_of(DataSet).to receive(:find_specification_for_dir) { process_data_specification }

      allow_any_instance_of(DataSet).to receive(:remove_unused_elements) { true }

      expect { @ds = DataSet.factory(params) }.to change(DataSet, :count)

      # trigger_change true but DataSet.create sets sync_elements to false so this should not be set
      expect(@ds.status).to_not eq DataSet::STATUS_IN_PROGRESS
    end

  end

  context 'Process Data Elements' do

    let(:data_set)                { create(:data_set, :with_process_data_elements) }

    let(:conversion_design_name)  { data_set.process_data_elements.first.process_data_specification.conversion_design_name }

    let(:project)                 { conversion_design_name.project }

    it 'returns list form name/id tuples for process_data_elements conversion_design_names' do
      results = data_set.option_list_for_conversion_designs

      expect(results.size).to eq 1

      expect(results.flatten).to include conversion_design_name.name
    end

    it 'returns list form name/id tuples for process_data_elements conversion_design_names' do
      # create in same project as existing as where clause keyed on project
      c = create(:conversion_design_name, project: project, name: 'RDFTEST2')

      results = data_set.option_list_for_conversion_designs(c.project_id, true)

      expect(results.size).to eq 2
    end
  end
end
