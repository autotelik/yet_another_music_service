require 'rails_helper'

describe ViewReceptionsAndConversiondb do

  let(:conversion)    { create(:conversion, :with_database) }
  let(:conversion_db) { conversion.conversion_databases.first }

  let(:company)       { double("CompanyAbbr") }

  it 'initialises from a ConversionDB' do
    subject = ViewReceptionsAndConversiondb.new

    allow(subject).to receive_messages(uniqid: 1)
    allow(subject).to receive_messages(source_obj: conversion_db)

    allow(company).to receive_messages(id: 1)
    allow_any_instance_of(Conversion).to receive(:company_abbr) { company }

    assembly = subject.map_to_assembly_line("blah")

    expect(assembly).to be_a AssemblyLine
    expect(assembly.company_abbr_id).to eq conversion.company_abbr.id
  end

end
