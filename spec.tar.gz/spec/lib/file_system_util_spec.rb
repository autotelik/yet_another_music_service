require 'rails_helper'

describe FileSystemUtil do
  describe 'sanitize_filepath!' do
    it 'does no changes to a valid filepath' do
      valid_filepath = '/tmp/ProductionOrder.perform'
      copy_filepath = valid_filepath.dup
      FileSystemUtil.sanitize_filepath!(valid_filepath)
      expect(valid_filepath).to eq(copy_filepath)
    end

    it 'does replaces two or more dots' do
      valid_filepath = '/tmp/ProductionOrder............perform'
      FileSystemUtil.sanitize_filepath!(valid_filepath)
      expect(valid_filepath).to eq('/tmp/ProductionOrder_.perform')
    end

    it 'replaces all characters which do not fit the criteria' do
      valid_filepath = '/tmp/ProductionOrder.perform!@#$%^&*())_;[]'
      FileSystemUtil.sanitize_filepath!(valid_filepath)
      expect(valid_filepath).to eq('/tmp/ProductionOrder.perform_______________')
    end

    it 'creates a Hash with details of a directory contents' do
     data = FileSystemUtil.directory_hash(factory_file_path)
     expect(data).to be_a Hash
     expect(data[:children]).to be_present
     expect(data[:file_type]).to eq "directory"
    end

  end
end