require 'rails_helper'

describe ReleaseNoteAttachmentsController do
  before(:each) do
    # required by view
    session[:user_id] = create(:user).id
    session[:project_id] = create(:proj_PRODUCTION).id

    # required by controller
    allow_any_instance_of(ReleaseNoteAttachmentsController).to receive(:authorize){ true }
    
    @release_note_attachment = create(:release_note_attachment)
  end

  describe 'GET #index' do
    it 'finds an release_note_attachment object' do
      get :index
      expect(assigns(:release_note_attachments)).not_to be_empty
    end
    it 'searches and finds an release_note_attachment object' do
      get :index, search: @release_note_attachment.title
      expect(assigns(:release_note_attachments)).not_to be_empty
    end
  end

  describe 'GET #show' do
    it 'gets a specific release_note_attachment object' do
      get :show, id: @release_note_attachment
      expect(assigns(:release_note_attachment)).to eq(@release_note_attachment)
    end
  end

  describe 'GET #new' do
    it 'builds a new release_note_attachment' do
      get :new
      expect(assigns(:release_note_attachment)).to be_a_new(ReleaseNoteAttachment)
    end
  end

  describe 'POST #create' do
    it 'creates an release_note_attachment' do
      expect {
        post :create, release_note_attachment: attributes_for(:release_note_attachment)
      }.to change(ReleaseNoteAttachment, :count).by(1)
    end
    it 'creates an release_note_attachment with all attributes' do
      expect {
        post :create, release_note_attachment: attributes_for(:release_note_attachment_maximal)
      }.to change(ReleaseNoteAttachment, :count).by(1)
    end
  end

  describe 'PATCH #update' do
    it 'updates a release_note_attachment' do
      @release_note_attachment.active_yn = false
      post :update, id: @release_note_attachment, release_note_attachment: @release_note_attachment.attributes
      @release_note_attachment.reload
      expect(@release_note_attachment.active_yn).to eq(false)
    end
  end
end
