require 'rails_helper'

describe DocumentsController do
  before(:each) do
    # required by view
    session[:user_id] = create(:user).id
    session[:project_id] = create(:proj_PRODUCTION).id

    # required by controller
    allow_any_instance_of(DocumentsController).to receive(:authorize){ true }
    
    @document = create(:document)
  end

  describe 'GET #index' do
    it 'finds an document object' do
      get :index
      expect(assigns(:documents)).not_to be_empty
    end
    it 'searches and finds an document object' do
      get :index, search: @document.filename
      expect(assigns(:documents)).not_to be_empty
    end
  end

  describe 'GET #show' do
    it 'gets a specific document object' do
      get :show, id: @document
      expect(assigns(:document)).to eq(@document)
    end
  end


  describe 'GET #new' do
    it 'builds a new document' do
      get :new
      expect(assigns(:document)).to be_a_new(Document)
    end
  end

  describe 'POST #create' do
    it 'creates an document' do
      # controller requires logged in user
      create(:Admin)
      user = build_stubbed(:TESTUSER)
      @controller = LoginController.new
      post "do_login", login: { username: user.user_name, password: user.pw}
      @controller = DocumentsController.new

      expect {
        post :create, document: attributes_for(:document, filename: 'Lorem_ipsum_dolor.doc')
      }.to change(Document, :count).by(1)
    end
    it 'creates an document with all attributes' do
      # controller requires logged in user
      create(:Admin)
      user = build_stubbed(:TESTUSER)
      @controller = LoginController.new
      post "do_login", login: { username: user.user_name, password: user.pw}
      @controller = DocumentsController.new

      expect {
        post :create, document: attributes_for(:document_maximal, filename: 'Lorem_ipsum_dolor.doc')
      }.to change(Document, :count).by(1)
    end
  end

  describe 'PATCH #update' do
    it 'updates a document' do
      # controller requires logged in user
      create(:Admin)
      user = build_stubbed(:TESTUSER)
      @controller = LoginController.new
      post "do_login", login: { username: user.user_name, password: user.pw}
      @controller = DocumentsController.new
      
      @document.version = 9
      post :update, id: @document, document: @document.attributes
      @document.reload
      expect(@document.version).to eq(9)
    end
  end
end
