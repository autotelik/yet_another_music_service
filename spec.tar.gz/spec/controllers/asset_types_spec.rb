require 'rails_helper'

describe AssetTypesController do
  before(:each) do
    # required by view
    session[:user_id] = create(:user).id
    session[:project_id] = create(:proj_PRODUCTION).id

    # required by controller
    allow_any_instance_of(AssetTypesController).to receive(:authorize){ true }
    
    @asset_type = create(:asset_type)
  end

  describe 'GET #index' do
    it 'finds an asset_type object' do
      get :index
      expect(assigns(:asset_types)).not_to be_empty
    end
  end

  describe 'GET #show' do
    it 'gets a specific asset_type object' do
      get :show, id: @asset_type
      expect(assigns(:asset_type)).to eq(@asset_type)
    end
  end

  describe 'GET #new' do
    it 'builds a new asset_type' do
      get :new
      expect(assigns(:asset_type)).to be_a_new(AssetType)
    end
  end
  
  describe 'POST #create' do
    it 'creates an asset_type' do
      expect {
        post :create, asset_type: attributes_for(:asset_type)
      }.to change(AssetType, :count).by(1)
    end
    it 'creates an asset_type with all attributes' do
      expect {
        post :create, asset_type: attributes_for(:asset_type_maximal)
      }.to change(AssetType, :count).by(1)
    end
  end

  describe 'PATCH #update' do
    it 'updates a asset_type' do
      @asset_type.name = 'Quotation'
      post :update, id: @asset_type, asset_type: @asset_type.attributes
      @asset_type.reload
      expect(@asset_type.name).to eq('Quotation')
    end
  end
end
