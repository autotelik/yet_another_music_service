require 'rails_helper'

describe ShippingSpecificationsController do
  include_context 'authorization'

  let!(:shipping_specification) { create(:shipping_specification) }

  describe 'GET #index' do
    it 'finds an shipping_specification object' do
      get :index

      expect(assigns(:shipping_specifications)).not_to be_empty
    end

    it 'searches and finds an shipping_specification object' do
      get :index, search: shipping_specification.id

      expect(assigns(:shipping_specifications)).not_to be_empty
    end
  end

  describe 'GET #show' do
    it 'gets a specific shipping_specification object' do
      get :show, id: shipping_specification

      expect(assigns(:shipping_specification)).to eq(shipping_specification)
    end
  end

  describe 'GET #new' do
    it 'builds a new shipping_specification' do
      get :new

      expect(assigns(:shipping_specification)).to be_a_new(ShippingSpecification)
    end
  end

  describe 'POST #create' do
    it 'creates an shipping_specification' do
      expect {
        post :create, shipping_specification: attributes_for(:shipping_specification)
      }.to change(ShippingSpecification, :count).by(1)
    end

    it 'creates an shipping_specification with all attributes' do
      expect {
        post :create, shipping_specification: attributes_for(:shipping_specification_maximal)
      }.to change(ShippingSpecification, :count).by(1)
    end
  end

  describe 'PATCH #update' do
    it 'updates a shipping_specification' do
      shipping_specification.delivery_notification_sentence = 'Lorem ipsum'

      post :update, id: shipping_specification, shipping_specification: shipping_specification.attributes

      shipping_specification.reload

      expect(shipping_specification.delivery_notification_sentence).to eq('Lorem ipsum')
    end
  end
end
