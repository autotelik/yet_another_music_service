require 'rails_helper'

describe ConversionJobsController do
  before(:each) do
    # required by view
    session[:user_id] = create(:user).id
    prod_project = create(:proj_PRODUCTION)
    session[:project_id] = prod_project.id

    # required by controller
    allow_any_instance_of(ConversionJobsController).to receive(:authorize){ true }

    @conversion = create(:conversion)
    @conversion_job = create(:conversion_job, project: prod_project, conversion: @conversion)
  end

  describe 'GET #index' do
    it 'finds an conversion_job object' do
      get :index
      expect(assigns(:conversion_jobs)).not_to be_empty
    end
    it 'searches and finds an conversion_job object' do
      get :index, search: @conversion_job.id
      expect(assigns(:conversion_jobs)).not_to be_empty
    end
  end

  describe 'GET #show' do
    it 'gets a specific conversion_job object' do
      get :show, id: @conversion_job
      expect(assigns(:conversion_job)).to eq(@conversion_job)
    end
  end

  # no new action

  # no create action

  # no update action

end
