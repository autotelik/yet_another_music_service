require 'rails_helper'

describe ExecutablesController do
  before(:each) do
    # required by view
    session[:user_id] = create(:user).id
    session[:project_id] = create(:proj_PRODUCTION).id

    # required by controller
    allow_any_instance_of(ExecutablesController).to receive(:authorize){ true }
    
    @executable = create(:executable)
  end

  describe 'GET #index' do
    it 'finds an executable object' do
      get :index
      expect(assigns(:executables)).not_to be_empty
    end
    it 'searches and finds an executable object' do
      get :index, search: @executable.id
      expect(assigns(:executables)).not_to be_empty
    end
  end

  describe 'GET #show' do
    it 'gets a specific executable object' do
      get :show, id: @executable
      expect(assigns(:executable)).to eq(@executable)
    end
  end

  # no new action

  describe 'POST #create' do
    it 'creates an executable' do
      expect {
        post :create, executable: attributes_for(:executable)
      }.to change(Executable, :count).by(1)
    end
    it 'creates an executable with all attributes' do
      expect {
        post :create, executable: attributes_for(:executable_maximal)
      }.to change(Executable, :count).by(1)
    end
  end

  describe 'PATCH #update' do
    it 'updates a executable' do
      @executable.description = 'Lorem ipsum'
      post :update, id: @executable, executable: @executable.attributes
      @executable.reload
      expect(@executable.description).to eq('Lorem ipsum')
    end
  end
end
