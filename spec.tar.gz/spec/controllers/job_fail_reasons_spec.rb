require 'rails_helper'

describe JobFailReasonsController do
  before(:each) do
    # required by view
    session[:user_id] = create(:user).id
    session[:project_id] = create(:proj_PRODUCTION).id

    # required by controller
    allow_any_instance_of(JobFailReasonsController).to receive(:authorize){ true }
    
    @job_fail_reason = create(:job_fail_reason)
  end

  describe 'GET #index' do
    it 'finds an job_fail_reason object' do
      get :index
      expect(assigns(:job_fail_reasons)).not_to be_empty
    end
    it 'searches and finds an job_fail_reason object' do
      get :index, search: @job_fail_reason.reason
      expect(assigns(:job_fail_reasons)).not_to be_empty
    end
  end

  describe 'GET #show' do
    it 'gets a specific job_fail_reason object' do
      get :show, id: @job_fail_reason
      expect(assigns(:job_fail_reason)).to eq(@job_fail_reason)
    end
  end

  describe 'GET #new' do
    it 'builds a new job_fail_reason' do
      get :new
      expect(assigns(:job_fail_reason)).to be_a_new(JobFailReason)
    end
  end

  describe 'POST #create' do
    it 'creates an job_fail_reason' do
      expect {
        post :create, job_fail_reason: attributes_for(:job_fail_reason)
      }.to change(JobFailReason, :count).by(1)
    end
    it 'creates an job_fail_reason with all attributes' do
      expect {
        post :create, job_fail_reason: attributes_for(:job_fail_reason_maximal)
      }.to change(JobFailReason, :count).by(1)
    end
  end

  describe 'PATCH #update' do
    it 'updates a job_fail_reason' do
      @job_fail_reason.description = 'Lorem ipsum'
      post :update, id: @job_fail_reason, job_fail_reason: @job_fail_reason.attributes
      @job_fail_reason.reload
      expect(@job_fail_reason.description).to eq('Lorem ipsum')
    end
  end
end
