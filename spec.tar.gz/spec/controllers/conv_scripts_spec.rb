require 'rails_helper'

describe ConvScriptsController do
  before(:each) do
    # required by view
    session[:user_id] = create(:user).id
    session[:project_id] = create(:proj_PRODUCTION).id

    # required by controller
    allow_any_instance_of(ConvScriptsController).to receive(:authorize){ true }
    
    @conv_script = create(:conv_script)
  end

  describe 'GET #index' do
    it 'finds an conv_script object' do
      get :index
      expect(assigns(:conv_scripts)).not_to be_empty
    end
    it 'searches and finds an conv_script object' do
      get :index, search: @conv_script.name
      expect(assigns(:conv_scripts)).not_to be_empty
    end
  end

  describe 'GET #show' do
    it 'gets a specific conv_script object' do
      get :show, id: @conv_script
      expect(assigns(:conv_script)).to eq(@conv_script)
    end
  end

  describe 'GET #new' do
    it 'builds a new conv_script' do
      get :new
      expect(assigns(:conv_script)).to be_a_new(ConvScript)
    end
  end

  describe 'POST #create' do
    it 'creates an conv_script' do
      expect {
        post :create, conv_script: attributes_for(:conv_script)
      }.to change(ConvScript, :count).by(1)
    end
    it 'creates an conv_script with all attributes' do
      expect {
        post :create, conv_script: attributes_for(:conv_script_maximal)
      }.to change(ConvScript, :count).by(1)
    end
  end

  describe 'PATCH #update' do
    it 'updates a conv_script' do
      @conv_script.name = 'ConvScripts_20160227_2'
      post :update, id: @conv_script, conv_script: @conv_script.attributes
      @conv_script.reload
      expect(@conv_script.name).to eq('ConvScripts_20160227_2')
    end
  end
end
