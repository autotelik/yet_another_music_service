require 'rails_helper'

describe OutboundOrderlinesController do

  include_context 'authorization'

  before(:each) do
    @outbound_orderline = create(:outbound_orderline)
  end

  describe 'GET #index' do
    it 'finds an outbound_orderline object' do
      get :index
      expect(assigns(:outbound_orderlines)).not_to be_empty
    end
    it 'searches and finds an outbound_orderline object' do
      get :index, search: @outbound_orderline.id
      expect(assigns(:outbound_orderlines)).not_to be_empty
    end
  end

  # show is outbound order show, which is already covered
  # no new action
  # no create action
  # no update action
end
