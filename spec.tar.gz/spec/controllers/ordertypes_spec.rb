require 'rails_helper'

describe OrdertypesController do
  before(:each) do
    # required by view
    session[:user_id] = create(:user).id
    session[:project_id] = create(:proj_PRODUCTION).id

    # required by controller
    allow_any_instance_of(OrdertypesController).to receive(:authorize){ true }
    
    @ordertype = create(:frontend)
  end

  describe 'GET #index' do
    it 'finds an ordertype object' do
      get :index
      expect(assigns(:ordertypes)).not_to be_empty
    end
    it 'searches and finds an ordertype object' do
      get :index, search: @ordertype.name
      expect(assigns(:ordertypes)).not_to be_empty
    end
  end

  describe 'GET #show' do
    it 'gets a specific ordertype object' do
      get :show, id: @ordertype
      expect(assigns(:ordertype)).to eq(@ordertype)
    end
  end

  describe 'GET #new' do
    it 'builds a new ordertype' do
      get :new
      expect(assigns(:ordertype)).to be_a_new(Ordertype)
    end
  end

  describe 'POST #create' do
    it 'creates an ordertype' do
      expect {
        post :create, ordertype: attributes_for(:frontend)
      }.to change(Ordertype, :count).by(1)
    end
    it 'creates an ordertype with all attributes' do
      expect {
        post :create, ordertype: attributes_for(:ordertype_maximal)
      }.to change(Ordertype, :count).by(1)
    end
  end

  describe 'PATCH #update' do
    it 'updates a ordertype' do
      @ordertype.description = 'Lorem ipsum'
      post :update, id: @ordertype, ordertype: @ordertype.attributes
      @ordertype.reload
      expect(@ordertype.description).to eq('Lorem ipsum')
    end
  end
end
