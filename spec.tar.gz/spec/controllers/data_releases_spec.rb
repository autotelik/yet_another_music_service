require 'rails_helper'

describe DataReleasesController do
  before(:each) do
    # required by view
    session[:user_id] = create(:user).id
    session[:project_id] = create(:proj_PRODUCTION).id

    # required by controller
    allow_any_instance_of(DataReleasesController).to receive(:authorize){ true }
    
    @data_release = create(:data_release)
  end

  describe 'GET #index' do
    it 'finds an data_release object' do
      get :index
      expect(assigns(:data_releases)).not_to be_empty
    end
    it 'searches and finds an data_release object' do
      get :index, search: @data_release.name
      expect(assigns(:data_releases)).not_to be_empty
    end
  end

  describe 'GET #show' do
    it 'gets a specific data_release object' do
      get :show, id: @data_release
      expect(assigns(:data_release)).to eq(@data_release)
    end
  end

  describe 'GET #new' do
    it 'builds a new data_release' do
      get :new
      expect(assigns(:data_release)).to be_a_new(DataRelease)
    end
  end

  describe 'POST #create' do
    it 'creates an data_release' do
      expect {
        post :create, data_release: attributes_for(:data_release)
      }.to change(DataRelease, :count).by(1)
    end
    it 'creates an data_release with all attributes' do
      expect {
        post :create, data_release: attributes_for(:data_release_maximal)
      }.to change(DataRelease, :count).by(1)
    end
  end

  describe 'PATCH #update' do
    it 'updates a data_release' do
      @data_release.name = 'Lorem ipsum'
      post :update, id: @data_release, data_release: @data_release.attributes
      @data_release.reload
      expect(@data_release.name).to eq('Lorem ipsum')
    end
  end
end
