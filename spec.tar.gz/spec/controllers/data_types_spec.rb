require 'rails_helper'

describe DataTypesController do
  before(:each) do
    # required by view
    session[:user_id] = create(:user).id
    session[:project_id] = create(:proj_PRODUCTION).id

    # required by controller
    allow_any_instance_of(DataTypesController).to receive(:authorize){ true }
    
    @data_type = create(:data_type)
  end

  describe 'GET #index' do
    it 'finds a data_type object' do
      get :index
      expect(assigns(:data_types)).not_to be_empty
    end
    it 'searches and finds an data_type object' do
      get :index, search: @data_type.id
      expect(assigns(:data_types)).not_to be_empty
    end
  end

  describe 'GET #show' do
    it 'gets a specific data_type object' do
      get :show, id: @data_type
      expect(assigns(:data_type)).to eq(@data_type)
    end
  end

  describe 'GET #new' do
    it 'builds a new data_type' do
      get :new
      expect(assigns(:data_type)).to be_a_new(DataType)
    end
  end

  describe 'POST #create' do
    it 'creates a data_type' do
      expect {
        post :create, data_type: attributes_for(:data_type)
      }.to change(DataType, :count).by(1)
    end
    it 'creates a data_type with all attributes' do
      expect {
        post :create, data_type: attributes_for(:data_type_maximal)
      }.to change(DataType, :count).by(1)
    end
  end

  describe 'PATCH #update' do
    it 'updates a data_type' do
      @data_type.active_yn = false
      post :update, id: @data_type, data_type: @data_type.attributes
      @data_type.reload
      expect(@data_type.active_yn).to eq(false)
    end
  end
end
