require 'rails_helper'

describe RolesController do
  before(:each) do
    # required by view
    session[:user_id] = create(:user).id
    session[:project_id] = create(:proj_PRODUCTION).id

    # required by controller
    allow_any_instance_of(RolesController).to receive(:authorize){ true }
    
    @role = create(:ConversionEngineer)
  end

  describe 'GET #index' do
    it 'finds an role object' do
      get :index
      expect(assigns(:roles)).not_to be_empty
    end
    it 'searches and finds an role object' do
      get :index, search: @role.title
      expect(assigns(:roles)).not_to be_empty
    end
  end

  describe 'GET #show' do
    it 'gets a specific role object' do
      get :show, id: @role
      expect(assigns(:role)).to eq(@role)
    end
  end

  describe 'GET #new' do
    it 'builds a new role' do
      get :new
      expect(assigns(:role)).to be_a_new(Role)
    end
  end

  describe 'POST #create' do
    it 'creates an role' do
      expect {
        post :create, role: attributes_for(:ConversionEngineer)
      }.to change(Role, :count).by(1)
    end
    it 'creates an role with all attributes' do
      expect {
        post :create, role: attributes_for(:role_maximal)
      }.to change(Role, :count).by(1)
    end
  end

  describe 'PATCH #update' do
    it 'updates a role' do
      @role.title = 'Lorem ipsum'
      post :update, id: @role, role: @role.attributes
      @role.reload
      expect(@role.title).to eq('Lorem ipsum')
    end
  end
end
