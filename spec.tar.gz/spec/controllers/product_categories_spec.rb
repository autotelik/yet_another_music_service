require 'rails_helper'

describe ProductCategoriesController do
  before(:each) do
    # required by view
    session[:user_id] = create(:user).id
    session[:project_id] = create(:proj_PRODUCTION).id

    # required by controller
    allow_any_instance_of(ProductCategoriesController).to receive(:authorize){ true }
    
    @product_category = create(:product_category)
  end

  describe 'GET #index' do
    it 'finds an product_category object' do
      get :index
      expect(assigns(:product_categories)).not_to be_empty
    end
    it 'searches and finds an product_category object' do
      get :index, search: @product_category.abbreviation
      expect(assigns(:product_categories)).not_to be_empty
    end
  end

  describe 'GET #show' do
    it 'gets a specific product_category object' do
      get :show, id: @product_category
      expect(assigns(:product_category)).to eq(@product_category)
    end
  end

  describe 'GET #new' do
    it 'builds a new product_category' do
      get :new
      expect(assigns(:product_category)).to be_a_new(ProductCategory)
    end
  end

  describe 'POST #create' do
    it 'creates an product_category' do
      expect {
        post :create, product_category: attributes_for(:product_category)
      }.to change(ProductCategory, :count).by(1)
    end
    # kept for template; product_category_maximal is alias for product_category
    # it 'creates an product_category with all attributes' do
    #   expect {
    #     post :create, product_category: attributes_for(:product_category_maximal)
    #   }.to change(ProductCategory, :count).by(1)
    # end
  end

  describe 'PATCH #update' do
    it 'updates a product_category' do
      @product_category.description = 'Lorem ipsum'
      post :update, id: @product_category, product_category: @product_category.attributes
      @product_category.reload
      expect(@product_category.description).to eq('Lorem ipsum')
    end
  end
end
