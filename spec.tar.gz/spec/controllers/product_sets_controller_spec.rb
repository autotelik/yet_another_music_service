require 'rails_helper'
require 'cancan/matchers'

describe ProductSetsController do

  include_context "authorization"  do
    let(:controllers) { [ProductSetsController] }
  end

  let(:product_line)            { create(:pli_NTG55H) }
  let(:product_category)        { create(:product_category) }
  let!(:product_set)            { create(:product_set, product_line: product_line, product_category: product_category, project: proj_PRODUCTION) }
  let!(:ps_alternative)         { create(:product_set, code: 'GMN D55H Alternative', product_category: nil, product_line: nil, project: proj_PRODUCTION) }
  let!(:ps_proposal)            { create(:product_set, code: 'GMN D55H Proposal', product_line: nil, status: ProductSet::STATUS_PROPOSAL, project: proj_PRODUCTION) }
  let!(:ps_approved)            { create(:product_set, code: 'GMN D55H Approved', product_line: create(:product_line), status: ProductSet::STATUS_APPROVED, project: proj_PRODUCTION) }
  let!(:ps_obsolete)            { create(:product_set, code: 'GMN D55H Obsolete', product_line: product_line, status: ProductSet::STATUS_OBSOLETE, project: proj_PRODUCTION) }
  let!(:doc1)                   { create(:document) }
  let!(:doc2)                   { create(:document) }
  let(:prod)                    { create(:product, project: proj_PRODUCTION) }
  let(:proj_REGRESSION)         { create(:proj_REGRESSION) }
  let(:set_tool_handover)       { create(:set_tool_handover, product_set: ps_proposal, project: proj_REGRESSION) }

  context 'Not Authorized (no ability)' do
    it { is_expected.not_to be_able_to(:edit, ProductSet) }

    it 'redirects the user if he is not authorized to access page' do
      get :edit, id: product_set

      expect(response.status).to eq 302
    end

    it 'redirects the user if attempt to edit is made under a different project' do
      session[:project_id] = proj_REGRESSION.id

      get :edit, id: product_set

      expect(response.status).to eq 302
    end

  end

  context 'Authorized (with ability)' do

    include_context 'cancan_prerequisites'

    before do
      session[:user_id]    = user.id
      session[:project_id] = proj_PRODUCTION.id
    end

    describe 'GET #index' do
      let(:normal_result_array) { [product_set, ps_alternative, ps_proposal, ps_approved].collect(&:code) }

      it 'finds collection of product set objects' do
        get :index
        expect(assigns(:product_sets).collect(&:code)).to match_array normal_result_array

        expect(subject).to render_template('product_sets/index')
      end

      it 'should default to find active product sets when no params' do
        get :index, format: 'json'
        expect(assigns(:product_sets).collect(&:code)).to match_array normal_result_array
        expect(response.content_type).to eq('application/json')
      end

      it 'should reset all other supplied search params when reset true' do
        get :index, inactive: true, search: 'Alternative', reset: true

        expect(assigns(:search_opts)).to eq ProductSetsController.default_search_options

        # same terms would normally return more entries if reset not specified
        # reset should result in same results of active product sets when no params specified
        expect(assigns(:product_sets).collect(&:code)).to match_array normal_result_array
      end

      # Have seen this test fail - rarely and unrepeatably
      # The SQL search is NOT only ID based, so maybe now and then some data accidentally matches
      #
      # My guess is abbr can match against ID as their factories use numeric sequences, and query takes form
      #
      # AND (product_sets.id = 466 OR product_categories.abbreviation LIKE '%466%' OR product_sets.code LIKE '%466%' OR product_lines.abbr LIKE '%466%')
      #
      it 'searches and finds a product set object BY id' do
        get :index, search: product_set.id
        expect(assigns(:product_sets).collect(&:code)).to match_array [product_set.code]
      end

      it 'searches and finds an data_set object BY code' do
        get :index, search: product_set.code
        expect(assigns(:product_sets).collect(&:code)).to match_array [product_set].collect(&:code)

        get :index, search: 'Alternative'
        expect(assigns(:product_sets).collect(&:code)).to match_array [ps_alternative].collect(&:code)
      end

      it 'searches and finds a product set object BY product category abbreviation' do
        get :index, search: product_set.product_category.abbreviation
        expect(assigns(:product_sets).collect(&:code)).to match_array [product_set].collect(&:code)
      end

      it 'searches and finds a product set object BY product line abbreviation' do
        get :index, search: product_set.product_line.abbr
        expect(assigns(:product_sets).collect(&:code)).to match_array [product_set].collect(&:code)
      end

      it 'can search for obsolete product set objects' do
        get :index, inactive: true
        expect(assigns(:product_sets).collect(&:code)).to match_array([product_set, ps_alternative, ps_proposal, ps_approved, ps_obsolete].collect(&:code))
      end

      it 'searches and finds inactive objects BY generic search field' do
        get :index, inactive: true, search: 'no no no'
        expect(assigns(:product_sets)).to match_array []

        get :index, search: ps_obsolete.code[10..16]
        expect(assigns(:product_sets)).to match_array []

        get :index, inactive: true, search: ps_obsolete.code[10..16]
        expect(assigns(:product_sets).collect(&:code)).to match_array [ps_obsolete].collect(&:code)
      end

      it 'can search on column status' do
        # noinspection RubyStringKeysInHashInspection
        get :index, column_search_field: { 'exact-product_sets-status' => product_set.status }
        expect(assigns(:product_sets).collect(&:code)).to match_array [ps_alternative, product_set].collect(&:code)
      end

      it 'can sort the columns based on id' do
        get :index, direction: 'asc', inactive: true, finished: true, sort: 'product_sets.id'
        expect(assigns(:product_sets).collect(&:code)).to eq [product_set, ps_alternative, ps_proposal, ps_approved, ps_obsolete].collect(&:code)

        get :index, direction: 'desc', inactive: true, finished: true, sort: 'product_sets.id'
        expect(assigns(:product_sets).collect(&:code)).to eq [product_set, ps_alternative, ps_proposal, ps_approved, ps_obsolete].collect(&:code).reverse
      end

      it 'can sort the columns based on product line abbreviation' do
        get :index, direction: 'asc', sort: 'product_lines.abbr'
        expect(assigns(:product_sets).collect(&:code)).to match_array [ps_alternative, ps_proposal, ps_approved, product_set].collect(&:code)
      end
    end

    describe 'GET #show' do
      it 'shows a  product set' do
        get :show, id: product_set
        expect(assigns(:product_set)).to eq(product_set)
        expect(subject).to render_template('product_sets/show')
      end
    end

    describe 'GET #handle' do
      it 'handles a product set' do
        get :handle, id: product_set
        expect(assigns(:product_set)).to eq(product_set)
        expect(subject).to render_template('product_sets/handle')
      end
    end

    describe 'GET #new' do
      it 'builds a new product set' do
        get :new
        expect(assigns(:product_set).id).to be_nil
        expect(subject).to render_template('product_sets/new')
      end
    end

    describe 'GET #edit' do

      it 'renders the edit form for an editable product set' do
        get :edit, id: product_set

        expect(assigns(:product_set)).to eq(product_set)
        expect(response.status).to eq 200
        expect(subject).to render_template('product_sets/edit')
      end
    end

    describe 'POST #create' do

      it 'creates a product set ready to handle' do
        allow_any_instance_of(ProductSetPresenter).to receive(:handle_allowed?) { true }

        expect do
          post :create, product_set: attributes_for(:product_set, product_line_id: product_line.id, product_category_id: product_category.id)
        end.to change(ProductSet, :count).by(1)

        expect(response.status).to eq 302
        expect(response).to redirect_to "/webmis/product_sets/#{assigns(:product_set).id}/handle"
      end

      it 'creates a product set' do
        allow_any_instance_of(ProductSetPresenter).to receive(:handle_allowed?) { false }

        expect do
          post :create, product_set: attributes_for(:product_set, product_line_id: product_line.id, product_category_id: product_category.id)
        end.to change(ProductSet, :count).by(1)

        expect(response.status).to eq 302
        expect(response).to redirect_to "/webmis/product_sets/#{assigns(:product_set).id}"
      end

      it 'renders new again when validation fails' do
        expect do
          post :create, product_set: { code: nil }
        end.to change(ProductSet, :count).by(0)

        expect(response).to render_template('product_sets/new')
      end
    end

    describe 'POST #update' do
      it 'updates a local product set' do
        product_set.code = 'xxx'
        product_set.name = 'yyy'

        allow_any_instance_of(ProductSetPresenter).to receive(:handle_allowed?) { false }
        post :update, id: product_set, product_set: product_set.attributes

        product_set.reload
        expect(product_set.code).to eq('xxx')
        expect(product_set.name).to eq('yyy')
        expect(response).to redirect_to "/webmis/product_sets/#{assigns(:product_set).id}"
      end

      it 'updates a local product set ready to handle' do
        product_set.code = 'xxx'

        allow_any_instance_of(ProductSetPresenter).to receive(:handle_allowed?) { true }
        post :update, id: product_set, product_set: product_set.attributes

        expect(response).to redirect_to "/webmis/product_sets/#{assigns(:product_set).id}/handle"
      end

      it 'renders edit again when validation fails' do
        code = product_set.code
        name = product_set.name
        product_set.code = ''
        product_set.name = 'y1y'
        post :update, id: product_set, product_set: product_set.attributes
        product_set.reload
        expect(product_set.code).to eq(code)
        expect(product_set.name).to eq(name)
        expect(response).to render_template('product_sets/edit')
      end
    end

    describe 'GET #document_options_list' do
      it 'should only respond to JSON' do
        expect do
          get :document_options_list, id: product_set, format: 'js'
        end.to raise_error(ActionController::UnknownFormat)
        expect do
          get :document_options_list, id: product_set
        end.to raise_error(ActionController::UnknownFormat)
      end

      it 'should return a zero count and empty entries array when nothing found' do
        get :document_options_list, id: product_set, search_str: 'xxxx', format: 'json'

        expect(response.body).to_not be_empty
        expect(JSON.parse(response.body)['entries']).to match_array []
        expect(JSON.parse(response.body)['total_entries']).to eq 0
        expect(JSON.parse(response.body)['per_page']).not_to eq 0
      end

      it 'should return a 2 count and 2 entries when there are 2 documents' do
        get :document_options_list, id: product_set, search_str: 'pdf', format: 'json'

        expect(Document.count).to eq 2
        expect(JSON.parse(response.body)['total_entries']).to eq 2
        expect(response.body).to include "\"id\":#{doc1.id}"
        expect(response.body).to include "\"id\":#{doc2.id}"
      end

      it 'should return a 1 count and 1 entry when there are 2 documents but one already belongs to the product set' do
        product_set.documents << doc1
        product_set.save

        get :document_options_list, id: product_set, format: 'json'

        expect(JSON.parse(response.body)['total_entries']).to eq 1
        expect(response.body).to include "\"id\":#{doc2.id}"
      end
    end

    describe 'POST #new_document' do
      it 'should create a new document and add it to the product set' do
        expect { post :new_document, id: product_set, document: { filename: 'Dolor1.pdf' } }.to change(Document, :count).by(1)
        expect { post :new_document, id: product_set, document: { filename: 'Dolor2.pdf' } }.to change(product_set.documents, :count).by(1)
      end
    end

    describe 'POST #add_document' do
      it 'should add an existing document to the product set' do
        expect { post :add_document, id: product_set, document_id: doc1.id }.to change(product_set.documents, :count).by(1)
      end
    end

    describe 'POST #remove_document' do
      it 'should remove an existing document to the product set' do
        product_set.documents << doc1
        product_set.save
        expect { post :remove_document, id: product_set, document_id: doc1.id }.to change(product_set.documents, :count).by(-1)
      end
    end

    describe 'POST #add_product' do
      it 'should add an existing product to the product set' do
        expect { post :add_product, id: product_set, product_id: prod.id }.to change(product_set.included_products, :count).by(1)
      end
    end

    describe 'POST #remove_product' do
      it 'should remove an existing product to the product set' do
        IncludedProduct.create(product_set_id: product_set.id, product_id: prod.id)
        expect { post :remove_product, id: product_set, product_id: prod.id }.to change(product_set.included_products, :count).by(-1)
      end
    end

    describe 'POST #disable' do

      before(:each) do
        product_set.products << create(:product)
      end

      it 'should handle the disable action' do
        post :disable, id: product_set
        product_set.reload
        expect(product_set.status).to eq(ProductSet::STATUS_OBSOLETE)
        expect(response).to redirect_to '/webmis'
      end

      it 'reports the products with issues when disable action fails' do
        allow_any_instance_of(Product).to receive(:update_status){ false }
        post :disable, id: product_set
        expect(flash[:error]).to match("Failed to disable product set.")
        expect(flash[:error]).to match("Product #{product_set.products.last.id}")
      end

    end

    describe 'POST #draft' do
      it 'should set the status to draft' do
        product_set.update_attribute(:status, ProductSet::STATUS_PROPOSAL)
        post :draft, id: product_set
        product_set.reload
        expect(product_set.status).to eq(ProductSet::STATUS_DRAFT)
        expect(response).to redirect_to '/webmis'
      end
    end

    describe 'POST #propose' do
      it 'should set the status to proposal' do
        post :propose, id: product_set
        product_set.reload
        expect(product_set.status).to eq(ProductSet::STATUS_PROPOSAL)
        expect(response).to redirect_to '/webmis'
      end
    end

    describe 'POST #approve' do
      it 'should set the status to approved' do
        post :approve, id: product_set
        product_set.reload
        expect(product_set.status).to eq(ProductSet::STATUS_APPROVED)
        expect(response).to redirect_to '/webmis'
      end
    end

    describe 'POST #create_set_tool_handover' do
      it 'should create a set tool _handover' do
        expect do
          post :create_set_tool_handover, id: ps_proposal
        end.to change(SetToolHandover, :count).by(1)
        expect(response).to redirect_to "/webmis/set_tool_handovers/#{assigns(:set_tool_handover).id}/edit"
      end
    end

    describe 'POST #clone_set_tool_handover' do
      it 'should clone a set_tool_handover' do
        expect do
          post :clone_set_tool_handover, id: ps_proposal, project_id: proj_PRODUCTION.id
        end.to change(SetToolHandover, :count).by(1)
        expect(response).to redirect_to "/webmis/set_tool_handovers/#{assigns(:set_tool_handover).id}/edit"
      end
    end

    describe 'GET #pds_list' do
      it 'should display the pds_list view' do
        get :pds_list
        expect(response).to render_template('product_sets/pds_list')
      end
    end

    describe 'GET #pds_import' do
      it 'should display the pds_import view' do
        # stub the actual import
        allow(PdsImporter).to receive(:import) { Checklog.new(false) }
        post :pds_import, cat_id: product_category
        expect(response).to render_template('product_sets/pds_import')
      end
    end
  end
end