require 'rails_helper'

describe ConversiontoolsController do
  before(:each) do
    # required by view
    session[:user_id] = create(:user).id
    session[:project_id] = create(:proj_PRODUCTION).id

    # required by controller
    allow_any_instance_of(ConversiontoolsController).to receive(:authorize){ true }
    
    @conversiontool = create(:conversiontool)
  end

  describe 'GET #index' do
    it 'finds an conversiontool object' do
      get :index
      expect(assigns(:conversiontools)).not_to be_empty
    end
    it 'searches and finds an conversiontool object' do
      get :index, q: @conversiontool.isactive
      expect(assigns(:conversiontools)).not_to be_empty
    end
  end

  describe 'GET #show' do
    it 'gets a specific conversiontool object' do
      get :show, id: @conversiontool
      expect(assigns(:conversiontool)).to eq(@conversiontool)
    end
  end

  describe 'GET #new' do
    it 'builds a new conversiontool' do
      get :new
      expect(assigns(:conversiontool)).to be_a_new(Conversiontool)
    end
  end

  describe 'POST #create' do
    it 'creates a conversiontool' do
      expect {
        post :create, conversiontool: attributes_for(:conversiontool, code: 'BladeRunner_20161102_3')
      }.to change(Conversiontool, :count).by(1)
    end
    it 'creates a conversiontool with all attributes' do
      expect {
        post :create, conversiontool: attributes_for(:conversiontool_maximal, code: 'BladeRunner_20161102_3')
      }.to change(Conversiontool, :count).by(1)
    end
  end

  describe 'PATCH #update' do
    it 'updates a conversiontool' do
      @conversiontool.remarks = 'Lorem ipsum'
      post :update, id: @conversiontool, conversiontool: @conversiontool.attributes
      @conversiontool.reload
      expect(@conversiontool.remarks).to eq('Lorem ipsum')
    end
  end
end
