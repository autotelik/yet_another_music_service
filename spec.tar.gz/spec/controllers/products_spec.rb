require 'rails_helper'
require 'cancan/matchers'

describe ProductsController do

  include_context "authorization"

  context 'Not Authorized (no ability)' do

    let(:product) { create(:product, project: proj_PRODUCTION) }

    describe 'GET #index' do
      it { is_expected.not_to be_able_to(:edit, Product) }

      it 'redirects the user if he is not authorized to access page' do
        get :edit, id: product

        expect(response.status).to eq 302
      end
    end
  end

  context 'Authorized (has ability)' do

    include_context 'cancan_prerequisites'

    before do
      session[:user_id]    = user.id
      session[:project_id] = proj_PRODUCTION.id
    end

    let!(:product) { create(:product, project: proj_PRODUCTION) }

    describe 'GET #index' do
      it 'finds an product object' do
        get :index

        expect(assigns(:products)).not_to be_empty

        expect(subject).to render_template('products/index')
      end

      it 'searches and finds an product object' do
        get :index, search: product.name

        expect(assigns(:products)).not_to be_empty
      end
    end

    describe 'GET #show' do
      it 'gets a specific product object' do
        get :show, id: product

        expect(assigns(:product)).to eq(product)
      end
    end

    describe 'GET #new' do
      it 'creates a new product' do
        get :new
        expect(assigns(:product)).to be_a_new(ProductPresenter)
      end
    end

    describe 'GET #edit' do

      let(:proj_REGRESSION) { create(:proj_REGRESSION) }

      it 'redirects the user if attempt to edit is made under a different project' do
        session[:project_id] = proj_REGRESSION.id

        get :edit, id: product

        expect(response.status).to eq 302
      end

      it 'renders the edit form for an editable product' do
        get :edit, id: product

        expect(assigns(:product)).to eq(product)
        expect(response.status).to eq 200
      end
    end

    describe 'POST #create' do
      it 'creates an product' do
        expect {
          post :create, product: attributes_for(:product)
        }.to change(Product, :count).by(1)
      end

      it 'creates an product with all attributes' do
        expect {
          post :create, product: attributes_for(:product_maximal)
        }.to change(Product, :count).by(1)
      end
    end

    describe 'PATCH #update' do
      # TODO: ensure all associated objects are not lost
      it 'updates a product' do
        product.remarks = 'Lorem ipsum'

        post :update, id: product, product: product.attributes

        product.reload
        expect(product.remarks).to eq('Lorem ipsum')
      end
    end
  end
end
