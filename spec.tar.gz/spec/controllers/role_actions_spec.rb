require 'rails_helper'

describe RoleActionsController do
  before(:each) do
    # required by view
    session[:user_id] = create(:user).id
    session[:project_id] = create(:proj_PRODUCTION).id

    # required by controller
    allow_any_instance_of(RoleActionsController).to receive(:authorize){ true }
    
    @role_action = create(:role_action)
  end

  describe 'GET #index' do
    it 'finds an role_action object' do
      get :index
      expect(assigns(:role_actions)).not_to be_empty
    end
    it 'searches and finds an role_action object' do
      get :index, search: @role_action.controller_name
      expect(assigns(:role_actions)).not_to be_empty
    end
  end

  describe 'GET #show' do
    it 'gets a specific role_action object' do
      get :show, id: @role_action
      expect(assigns(:role_action)).to eq(@role_action)
    end
  end

  describe 'GET #new' do
    it 'builds a new role_action' do
      get :new
      expect(assigns(:role_action)).to be_a_new(RoleAction)
    end
  end

  describe 'POST #create' do
    it 'creates an role_action' do
      expect {
        post :create, role_action: attributes_for(:role_action, role_id: @role_action.role.id)
      }.to change(RoleAction, :count).by(1)
    end
    # kept for template; role_action_maximal is an alias for role_action
    # it 'creates an role_action with all attributes' do
    #   expect {
    #     post :create, role_action: attributes_for(:role_action_maximal, role_id: @role_action.role.id)
    #   }.to change(RoleAction, :count).by(1)
    # end
  end

  describe 'PATCH #update' do
    it 'updates a role_action' do
      role = create(:Approver)
      @role_action.role = role
      post :update, id: @role_action, role_action: @role_action.attributes, 'ra-sel' => {@role_action.id.to_s => [@role_action.role.id]}
      expect(RoleAction.find_by_role_id(role.id).role).to eq(role)
    end
  end
end
