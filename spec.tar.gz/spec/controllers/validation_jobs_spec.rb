require 'rails_helper'

describe ValidationJobsController do
  before(:each) do
    # required by view
    session[:user_id] = create(:user).id
    prod_project = create(:proj_PRODUCTION)
    session[:project_id] = prod_project.id

    # required by controller
    allow_any_instance_of(ValidationJobsController).to receive(:authorize) { true }


    @validation_job = create(:vj_DEFAULT, project: prod_project)
  end

  describe 'GET #index' do
    it 'finds an validation_job object' do
      get :index
      expect(assigns(:validation_jobs)).not_to be_empty
    end
    it 'searches and finds an validation_job object' do
      get :index, search: @validation_job.id
      expect(assigns(:validation_jobs)).not_to be_empty
    end
  end

  describe 'GET #show' do
    it 'gets a specific validation_job object' do
      get :show, id: @validation_job
      expect(assigns(:validation_job)).to eq(@validation_job)
    end
  end

  describe 'POST #create' do
    it 'creates a new validation_job' do
      expect {
        post :create, validation_job: attributes_for(:validation_job)
      }.to change(ValidationJob, :count).by(1)
    end
    it 'creates a new validation_job with all attributes' do
      expect {
        post :create, validation_job: attributes_for(:validation_job_maximal)
      }.to change(ValidationJob, :count).by(1)
    end
  end

  describe 'PATCH #update' do
    it 'updates a validation_job' do
      # controller requires logged in user
      create(:proj_PRODUCTION)
      create(:Admin)
      user = build_stubbed(:TESTUSER)
      @controller = LoginController.new
      post 'do_login', { login: { username: user.user_name, password: user.pw}}
      @controller = ValidationJobsController.new
      
      @validation_job.working_dir = 'w_lorem_ipsum'
      post :update, id: @validation_job, validation_job: @validation_job.attributes, commit: 'Save'
      @validation_job.reload
      expect(@validation_job.working_dir).to eq('w_lorem_ipsum')
    end
  end
end
