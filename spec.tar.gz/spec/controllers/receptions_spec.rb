require 'rails_helper'

describe ReceptionsController do
  before(:each) do
    # required by view
    session[:user_id] = create(:user).id
    @prod_project = create(:proj_PRODUCTION)
    session[:project_id] = @prod_project.id

    # required by controller
    allow_any_instance_of(ReceptionsController).to receive(:authorize){ true }
    
    @reception = create(:r_DUMMY, status: Reception::STATUS_IN_PROGRESS)
  end

  describe 'GET #index' do

    it 'finds an reception object' do
      get :index
      expect(assigns(:receptions)).not_to be_empty
    end

    it 'searches and finds an reception object' do
      get :index, search: @reception.purpose
      expect(assigns(:receptions)).not_to be_empty
    end

    it 'searches and finds an reception object BY revision' do
      get :index, search: @reception.revision
      expect(assigns(:receptions)).to match_array [@reception]

      alternative = create(:r_DUMMY, status: Reception::STATUS_IN_PROGRESS)

      get :index, search: alternative.revision
      expect(assigns(:receptions)).to match_array [alternative]
    end

    it 'searches and finds multiple reception objects BY revision' do
      same = create(:r_DUMMY, revision: @reception.revision, status: Reception::STATUS_IN_PROGRESS)
      get :index, search: @reception.revision
      expect(assigns(:receptions)).to match_array [@reception, same]
    end

  end

  describe 'GET #show' do
    it 'gets a specific reception object' do
      create(:data_input_directory, project: @prod_project) # required by view
      get :show, id: @reception
      expect(assigns(:reception)).to eq(@reception)
    end
  end

  describe 'GET #new' do
    it 'builds a new reception' do
      get :new
      expect(assigns(:reception)).to be_a_new(Reception)
    end
  end

  describe 'POST #create' do
    it 'creates an reception' do
      # controller requires logged in user
      create(:Admin)
      user = build_stubbed(:TESTUSER)
      @controller = LoginController.new
      post "do_login", login: { username: user.user_name, password: user.pw}
      @controller = ReceptionsController.new

      expect {
        post :create, reception: attributes_for(:r_DUMMY, area_id: @reception.region.id, 
          data_release_id: @reception.data_release.id, data_type_id: @reception.data_type.id)
      }.to change(Reception, :count).by(1)
    end
    it 'creates an reception with all attributes' do
      # controller requires logged in user
      create(:Admin)
      user = build_stubbed(:TESTUSER)
      @controller = LoginController.new
      post "do_login", login: { username: user.user_name, password: user.pw}
      @controller = ReceptionsController.new

      expect {
        post :create, reception: attributes_for(:reception_maximal, area_id: @reception.region.id, 
          data_release_id: @reception.data_release.id, data_type_id: @reception.data_type.id)
      }.to change(Reception, :count).by(1)
    end
  end

  describe 'PATCH #update' do
    it 'updates a reception' do
      # controller requires logged in user
      create(:Admin)
      user = build_stubbed(:TESTUSER)
      @controller = LoginController.new
      post "do_login", login: { username: user.user_name, password: user.pw}
      @controller = ReceptionsController.new

      post :update, id: @reception, reception: @reception.attributes
      @reception.reload
      expect(@reception.status).to eq(Reception::STATUS_IN_PROGRESS)
    end
  end
end
