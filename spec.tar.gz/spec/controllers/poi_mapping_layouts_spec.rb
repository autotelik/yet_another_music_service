require 'rails_helper'

describe PoiMappingLayoutsController do
  before(:each) do
    # required by view
    session[:user_id] = create(:user).id
    session[:project_id] = create(:proj_PRODUCTION).id

    # required by controller
    allow_any_instance_of(PoiMappingLayoutsController).to receive(:authorize){ true }
    
    @poi_mapping_layout = create(:poi_mapping_layout)
  end

  describe 'GET #index' do
    it 'finds an poi_mapping_layout object' do
      get :index
      expect(assigns(:poi_mapping_layouts)).not_to be_empty
    end
    it 'searches and finds an poi_mapping_layout object' do
      get :index, search: @poi_mapping_layout.pml_filename
      expect(assigns(:poi_mapping_layouts)).not_to be_empty
    end
  end

  describe 'GET #show' do
    it 'gets a specific poi_mapping_layout object' do
      get :show, id: @poi_mapping_layout
      expect(assigns(:poi_mapping_layout)).to eq(@poi_mapping_layout)
    end
  end

  # TODO describe 'GET @new' and 'POST #create' as those require an existing PML file
end
