require 'rails_helper'

describe ConversionsController do
  let!(:project) { create(:proj_PRODUCTION) }
  let(:user) { create(:user) }
  let!(:conversion) { create(:c_DEFAULT, project: project)}

  before(:each) do
    # required by view
    session[:user_id] = user.id
    session[:project_id] = project.id

    # required by controller
    allow_any_instance_of(ConversionsController).to receive(:authorize){ true }
  end

  describe 'GET #index' do
    it 'finds an conversion object' do
      get :index

      expect(assigns(:conversions)).not_to be_empty
    end

    it 'searches and finds a conversion object' do
      get :index, search: conversion.id, inactive: 1

      expect(assigns(:conversions)).not_to be_empty
    end
  end

  # no show

  # no new

  # no create

  # no update
end
