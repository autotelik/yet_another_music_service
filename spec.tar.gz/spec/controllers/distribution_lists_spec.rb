require 'rails_helper'

describe DistributionListsController do

  include_context "authorization"

  let!(:distribution_list) { create(:distribution_list) }

  describe 'GET #index' do
    it 'finds an distribution_list object' do
      get :index

      expect(assigns(:distribution_lists)).not_to be_empty
    end

    it 'searches and finds an distribution_list object' do
      get :index, search: distribution_list.name

      expect(assigns(:distribution_lists)).not_to be_empty
    end
  end

  describe 'GET #show' do
    it 'gets a specific distribution_list object' do
      get :show, id: distribution_list

      expect(assigns(:distribution_list)).to eq(distribution_list)
    end
  end

  describe 'GET #new' do
    it 'builds a new distribution_list' do
      get :new

      expect(assigns(:distribution_list)).to be_a_new(DistributionListPresenter)
    end
  end

  describe 'POST #create' do
    it 'creates an distribution_list' do
      expect {
        post :create, distribution_list: attributes_for(:distribution_list)
      }.to change(DistributionList, :count).by(1)
    end

    it 'creates an distribution_list with all attributes' do
      expect {
        post :create, distribution_list: attributes_for(:distribution_list_maximal)
      }.to change(DistributionList, :count).by(1)
    end
  end

  describe 'PATCH #update' do
    it 'updates a distribution_list' do
      distribution_list.status = DistributionList::STATUS_INACTIVE

      post :update, id: distribution_list, distribution_list: distribution_list.attributes

      distribution_list.reload

      expect(distribution_list.inactive?).to eq(true)
    end
  end
end
