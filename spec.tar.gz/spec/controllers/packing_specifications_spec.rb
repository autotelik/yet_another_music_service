require 'rails_helper'

describe PackingSpecificationsController do

  include_context "authorization"

  before(:each) do
    # required by view
    session[:user_id]    = user.id
    session[:project_id] = proj_PRODUCTION.id
  end

  let(:review_user) { create(:TESTUSER) }

  describe 'GET #index' do

    let!(:pack_spec)          { create(:packing_specification, updated_by: review_user.user_name) }
    let!(:packing_obsolete)   { create(:PACK_OBSOLETE, updated_by: user.user_name) }

    it 'finds collection of packing_specification objects' do
      get :index
      expect(assigns(:packing_specifications)).to match_array [pack_spec]
      expect(subject).to render_template("packing_specifications/index")
    end

    it 'should include end status packing_specifications when no params' do
      get :index, format: 'json', inactive: true
      expect(assigns(:packing_specifications)).to match_array [pack_spec, packing_obsolete]
      expect(response.content_type).to eq("application/json")
    end

    context 'Search' do

      let!(:pack_spec_2)  { create(:packing_specification, updated_by: review_user.user_name) }

      it 'should reset all other supplied search params when reset true' do
        get :index, inactive: true, finished: true, search: "Well this wont be found", reset: true

        expect(assigns(:search_opts)).to eq( { inactive: '0' } )

        # same terms would normally return more entries if reset not specified
        expect(assigns(:packing_specifications)).to match_array [pack_spec, pack_spec_2]
      end

      it 'searches and finds a data_set object BY id' do
        get :index, search: pack_spec_2.id
        expect(assigns(:packing_specifications)).to match_array [pack_spec_2]
      end

      it 'searches and finds an data_set object BY name' do
        get :index, search: pack_spec.name
        expect(assigns(:packing_specifications)).to match_array [pack_spec]

        get :index, search: "No way"
        expect(assigns(:packing_specifications)).to match_array []
      end

    end

  end

  describe 'GET #show' do

    let!(:pack_spec) { create(:packing_specification, updated_by: review_user.user_name) }

    it 'gets a specific packing_specification object' do
      get :show, id: pack_spec
      expect(assigns(:packing_specification)).to eq(pack_spec)
    end
  end

  describe 'GET #new' do
    it 'builds a new packing_specification' do
      get :new
      expect(assigns(:packing_specification)).to be_a_new(PackingSpecification)
    end
  end

  describe 'POST #create' do

    it 'creates an packing_specification' do
      expect {
        post :create, packing_specification: attributes_for(:packing_specification, name: 'LoremIpsum')
      }.to change(PackingSpecification, :count).by(1)
    end

    it 'creates an packing_specification with all attributes' do
      expect {
        post :create, packing_specification: attributes_for(:packing_specification_maximal, name: 'LoremIpsum')
      }.to change(PackingSpecification, :count).by(1)
    end
  end

  describe 'PATCH #update' do

    let!(:pack_spec) { create(:PACK_APPROVED) }

    it 'updates a packing_specification' do
      post :update, id: pack_spec, packing_specification: { description: 'We Patched this Update' }
      pack_spec.reload
      expect(pack_spec.description).to eq('We Patched this Update')
      expect(pack_spec.updated_by).to eq user.user_name
    end

    it 'ALWAYS sets the status back to DRAFT after an edit/update' do
      post :update, id: pack_spec, packing_specification: { description: 'We Patched this Update' }
      pack_spec.reload
      expect(pack_spec.status).to eq PackingSpecification::STATUS_DRAFT
    end

  end

  describe 'Status Updates' do

    let(:pack_new)      { create(:PACK_MINIMAL) }
    let(:pack_obsolete) { create(:PACK_OBSOLETE) }
    let(:pack_review)   { create(:PACK_REVIEW) }

    it 'updates status NEW to DRAFT #draft' do
      expect(pack_new.status).to eq PackingSpecification::STATUS_NEW
      post :draft, id: pack_new
      pack_new.reload
      expect(pack_new.status).to eq PackingSpecification::STATUS_DRAFT
    end

    it 'updates status REVIEW to STATUS_APPROVED #approve' do
      expect(pack_review.status).to eq PackingSpecification::STATUS_REVIEW
      post :approve, id: pack_review
      pack_review.reload
      expect(pack_review.status).to eq PackingSpecification::STATUS_APPROVED
    end

    it 'cannot update status OBSOLETE to DRAFT #draft' do
      post :draft, id: pack_obsolete
      pack_obsolete.reload
      expect(pack_obsolete.status).to eq PackingSpecification::STATUS_OBSOLETE
    end

  end

end