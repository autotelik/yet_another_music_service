require 'rails_helper'

describe ShippingJobsController do
  before(:each) do
    # required by view
    session[:user_id] = create(:user).id
    session[:project_id] = create(:proj_PRODUCTION).id

    # required by controller
    allow_any_instance_of(ShippingJobsController).to receive(:authorize){ true }
    
    @shipping_job = create(:shipping_job)
  end

  describe 'GET #index' do
    it 'finds an shipping_job object' do
      get :index
      expect(assigns(:shipping_jobs)).not_to be_empty
    end
    it 'searches and finds an shipping_job object' do
      get :index, search: @shipping_job.id
      expect(assigns(:shipping_jobs)).not_to be_empty
    end
  end

  describe 'GET #show' do
    it 'gets a specific shipping_job object' do
      get :show, id: @shipping_job
      expect(assigns(:shipping_job)).to eq(@shipping_job)
    end
  end

  # no new action

  describe 'POST #create' do
    it 'creates an shipping_job' do
      expect {
        post :create, shipping_job: attributes_for(:shipping_job, reference_id: @shipping_job.outbound_orderline.id,
          fail_category_logged_by_user_id: @shipping_job.fail_category_logged_by_user.id)
      }.to change(ShippingJob, :count).by(1)
    end
    it 'creates an shipping_job with all attributes' do
      expect {
        post :create, shipping_job: attributes_for(:shipping_job_maximal, reference_id: @shipping_job.outbound_orderline.id,
          fail_category_logged_by_user_id: @shipping_job.fail_category_logged_by_user.id)
      }.to change(ShippingJob, :count).by(1)
    end
  end

  describe 'PATCH #update' do
    it 'updates a shipping_job' do
      # controller requires logged in user
      create(:Admin)
      user = build_stubbed(:TESTUSER)
      @controller = LoginController.new
      post "do_login", login: { username: user.user_name, password: user.pw}
      @controller = ShippingJobsController.new
      
      @shipping_job.working_dir = 'w_lorem_ipsum'
      post :update, id: @shipping_job, shipping_job: @shipping_job.attributes, commit: 'Save'
      @shipping_job.reload
      expect(@shipping_job.working_dir).to eq('w_lorem_ipsum')
    end
  end
end
