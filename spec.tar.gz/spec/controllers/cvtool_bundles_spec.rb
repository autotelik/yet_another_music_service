require 'rails_helper'

describe CvtoolBundlesController do
  before(:each) do
    # required by view
    session[:user_id] = create(:user).id
    session[:project_id] = create(:proj_PRODUCTION).id

    # required by controller
    allow_any_instance_of(CvtoolBundlesController).to receive(:authorize){ true }
    
    @cvtool_bundle = create(:cvtool_bundle)
  end

  describe 'GET #index' do
    it 'finds an cvtool_bundle object' do
      get :index
      expect(assigns(:cvtool_bundles)).not_to be_empty
    end
    it 'searches and finds an cvtool_bundle object' do
      get :index, search: @cvtool_bundle.name
      expect(assigns(:cvtool_bundles)).not_to be_empty
    end
  end

  describe 'GET #show' do
    it 'gets a specific cvtool_bundle object' do
      get :show, id: @cvtool_bundle
      expect(assigns(:cvtool_bundle)).to eq(@cvtool_bundle)
    end
  end

  describe 'GET #new' do
    it 'builds a new cvtool_bundle' do
      get :new
      expect(assigns(:cvtool_bundle)).to be_a_new(CvtoolBundle)
    end
  end

  describe 'POST #create' do
    it 'creates an cvtool_bundle' do
      expect {
        post :create, cvtool_bundle: attributes_for(:cvtool_bundle)
      }.to change(CvtoolBundle, :count).by(1)
    end
    it 'creates an cvtool_bundle with all attributes' do
      expect {
        post :create, cvtool_bundle: attributes_for(:cvtool_bundle_maximal)
      }.to change(CvtoolBundle, :count).by(1)
    end
  end

  describe 'PATCH #update' do
    it 'updates a cvtool_bundle' do
      @cvtool_bundle.active_yn = false
      post :update, id: @cvtool_bundle, cvtool_bundle: @cvtool_bundle.attributes
      @cvtool_bundle.reload
      expect(@cvtool_bundle.active_yn).to eq(false)
    end
  end
end
