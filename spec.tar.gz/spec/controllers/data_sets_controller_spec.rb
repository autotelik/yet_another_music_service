require 'rails_helper'

describe DataSetsController do

  let(:proj_PRODUCTION) { create(:proj_PRODUCTION) }
  let(:test_user)       { create(:TESTUSER) }
  let(:user)            { create(:user, user_profile: create(:user_profile)) }

  before(:each) do
    # required by view
    session[:user_id]    = user.id
    session[:project_id] = proj_PRODUCTION.id

    # required by controller
    allow_any_instance_of(DataSetsController).to receive(:authorize){ true }
  end

  let(:r)     { create(:region) }
  let(:pli)   { create(:product_line) }

  # Suite of DataSet's in different states and different levels of construction
  let!(:data_set)                 { create(:ds_DUMMY, :with_process_data_directory) }
  let!(:ds_alternative)           { create(:ds_DUMMY, :with_coverages_region, name: "Alternative") }
  let!(:ds_removed)               { create(:data_set, :with_coverages_region, status: DataSet::STATUS_REMOVED) }
  let!(:ds_removal_candidate)     { create(:data_set, :with_coverages_region, status: DataSet::STATUS_REMOVAL_CANDIDATE) }

  let(:ds_process_data_elements)  { create(:data_set, :with_process_data_elements) }

  let(:ds_full)                   { create(:data_set_full) }

  context "Non Stubbed" do
    describe "POST #validate_structure" do
      it 'should return text indicating error when data set has noprocess_data_elements' do
        post :validate_structure, id: data_set

        expect(assigns(:data_set)).to eq data_set
        expect(response.body).to eq 'ERROR: No elements available!'
      end

      it 'should return text indicating the data set structure is valid' do
        allow_any_instance_of(DataSet).to receive(:validate_element_file_structure) { true }

        post :validate_structure, id: data_set
        expect(response.body).to eq 'No problems in elements and file structure detected.'
      end
    end
  end

  context "Stubbed" do

    include_context "stub_data_set_os_interaction"

    describe 'GET #index' do

      it 'finds collection of data_set objects' do
        get :index
        expect(assigns(:data_sets)).to match_array [data_set, ds_alternative]

        expect(subject).to render_template("data_sets/index")
      end

      it 'should default to find datasets with \'live\' statuses when no params' do
        get :index, format: 'json'
        expect(assigns(:data_sets)).to match_array [data_set, ds_alternative]
        expect(response.content_type).to eq("application/json")
      end

      context 'Search' do
        it 'should reset all other supplied search params when reset true' do
          get :index, inactive: true, finished: true, search: "Alternative", reset: true

          expect(assigns(:search_opts)).to eq DataSetsController.default_search_options

          # same terms would normally return more entries if reset not specified
          # reset should result in same results of datasets with \'live\' statuses when no params specified
          expect(assigns(:data_sets)).to match_array [data_set, ds_alternative]
        end

        it 'searches and finds a data_set object BY id' do
          get :index, search: data_set.id
          expect(assigns(:data_sets)).to match_array [data_set]
        end

        it 'searches and finds an data_set object BY name' do
          get :index, search: data_set.name
          expect(assigns(:data_sets)).to match_array [data_set]

          get :index, search: "Alternative"
          expect(assigns(:data_sets)).to match_array [ds_alternative]
        end

        it 'searches and finds an data_set object BY receptions supplier ref' do
          get :index, search: ds_alternative.receptions.first.supplier_ref
          expect(assigns(:data_sets)).to match_array [ds_alternative]
        end

        it 'searches and finds an data_set object BY regions name' do
          get :index, search: ds_alternative.region.name
          expect(assigns(:data_sets)).to match_array [ds_alternative]
        end

        it 'can search for inactive data_set object' do
          get :index, inactive: true
          expect(assigns(:data_sets)).to match_array([data_set, ds_alternative, ds_removed])
        end

        it 'searches and finds inactive objects BY remarks' do
          get :index, inactive: true, search: "no no no"
          expect(assigns(:data_sets)).to match_array []

          get :index, search: ds_removed.remarks
          expect(assigns(:data_sets)).to match_array []

          get :index, inactive: true, search: ds_removed.remarks
          expect(assigns(:data_sets)).to match_array [ds_removed]
        end

        it 'can search for inactive and finished data_set object' do
          get :index, inactive: true, finished: true
          expect(assigns(:data_sets)).to match_array([data_set, ds_alternative, ds_removed, ds_removal_candidate])
        end

        it 'searches and finds an data_set object BY revision' do
          get :index, search: data_set.revision
          expect(assigns(:data_sets)).to match_array [data_set]

          get :index, search: ds_alternative.revision
          expect(assigns(:data_sets)).to match_array [ds_alternative]
        end

        it 'searches and finds multiple data_set objects BY revision' do
          same = create(:ds_DUMMY, revision: data_set.revision)
          get :index, search: data_set.revision
          expect(assigns(:data_sets)).to match_array [data_set, same]
        end

=begin
      it 'can search specific and multiple columns to filter the data_set list' do

        search_terms = ['exact-data_sets-id', 'data_sets-name', 'exact-company_abbrs-id',
                        'exact-data_releases-id',  'exact-regions-id','exact-data_types-id',
                        'exact-fillings-id', 'exact-data_sets-status', 'exact-set_tool_handovers-id']

        search = search_terms.collect do |st| "column_search_field[#{st}]" }

        qs = search.join("=&")

        get :index, qs
        expect(assigns(:data_sets)).to match_array([data_set, ds_alternative, ds_removed, ds_removal_candidate])
      end
=end

      end

      it 'can sort the columns based on id' do
        get :index, direction: 'asc', inactive: true, finished: true, sort: 'data_sets.id'
        expect(assigns(:data_sets).to_a).to eq [data_set, ds_alternative, ds_removed, ds_removal_candidate]#.collect(&:id)

        get :index, direction: 'desc', inactive: true, finished: true, sort: 'data_sets.id'
        expect(assigns(:data_sets).to_a).to eq [data_set, ds_alternative, ds_removed, ds_removal_candidate].reverse
      end

      it 'can sort the columns based on Supplier (Company Abbr)' do
        get :index, direction: 'asc', inactive: true, finished: true, sort: 'company_abbrs.company_name'
        expect(assigns(:data_sets)).to match_array [data_set, ds_alternative, ds_removed, ds_removal_candidate]
      end

      it 'can sort the columns based on set tool handover id' do
        get :index, direction: 'asc', sort: 'set_tool_handovers.id'
        expect(assigns(:data_sets)).to match_array [data_set, ds_alternative]
      end
    end

    describe 'POST #clone and #duplicate' do
      context 'clone - sets up data for the view' do
        it 'should assign a specific data_set object' do
          post :clone, id: ds_full
          expect(assigns(:data_set)).to eq(ds_full)
        end

        it 'has a presenter to supply list of available Releases via CompanyAbbr for the view' do
          post :clone, id: ds_full
          expect(assigns(:presenter)).to be_a(DataSetPresenter)
          expect(assigns(:presenter).available_releases).to_not be_empty
        end
      end

      context 'duplicate a VALID set of params' do
        let(:data_release) { create(:data_release) }

        let(:params) { { id: ds_full, data_set: { data_release_id: data_release.id } } }

        it 'should assign a specific data_set object' do
          post :duplicate, params
          expect(assigns(:prev_data_set)).to eq(ds_full)
        end

        it 'should duplicate a DataSet when a new data release supplied' do
          post :duplicate, params
          expect(assigns(:data_set)).to be_a DataSet
          expect(controller).to set_flash[:notice].to('Data set was successfully duplicated.')
        end

        it 'should duplicate a DataSet when a new revision supplied' do
          post :duplicate, id: ds_full, data_set: { revision: "Z00Z00" }
          expect(assigns(:data_set)).to be_a DataSet
          expect(controller).to set_flash[:notice].to('Data set was successfully duplicated.')
        end

        it 'should return errors when same release/revision supplied' do
          post :duplicate, id: ds_full, data_set: { revision: ds_full.revision }
          expect(assigns(:data_set).errors.messages).to have_key :data_release_id
          expect(controller).to set_flash[:notice].to('Data set clone failed.')
        end

        it 'should return and display error notice when validating duplicate fails' do
          # by setting to nil we force usage of existing data release which cannot be duplicated as is
          post :duplicate, id: ds_full, data_set: { data_release_id: nil }
          failed = assigns(:data_set)
          expect(failed.valid?).to be_falsey
          expect(failed.errors.messages).to have_key :data_release_id
          expect(controller).to set_flash[:notice].to('Data set clone failed.')
        end
      end
    end

    describe 'POST #change_status' do
      context 'VALID params' do
        let(:params) { { id: data_set, status: DataSet::STATUS_REMOVED } }

        it 'should assign a specific data_set object' do
          post :change_status, params
          expect(assigns(:data_set)).to eq(data_set)
        end

        it 'should set the updated_by to current user' do
          expect(data_set.updated_by).to be_nil
          post :change_status, params
          expect(data_set.reload.updated_by).to eq user.user_name
        end

        it 'should set the flash to a suitable message upon SUCCESSFUL save' do
          post :change_status, params
          expect(controller).to set_flash[:notice]
        end
      end

      it 'should set the flash to a suitable message upon UNSUCCESSFUL save' do
        post :change_status, id: data_set, status: 1
        expect(controller).to set_flash[:error]
      end
    end

    describe 'GET #show' do
      it 'gets a specific data_set object' do
        get :show, id: data_set
        expect(assigns(:data_set)).to eq(data_set)
        expect(subject).to render_template("data_sets/show")
      end

      let(:conversion) { ds_process_data_elements.conversions.first }

      it 'should provide report availability of conversion_jobs' do
        get :show_jobs_modal, id: ds_process_data_elements, conversion_id: conversion.id
        expect(assigns(:conversion_jobs)).to eq(conversion.conversion_jobs)
        expect(subject).to render_template("data_sets/_jobs_modal")
      end
    end

    describe 'GET #new' do
      it 'builds a new data_set' do
        get :new
        expect(assigns(:data_set)).to be_a_new(DataSet)
        expect(subject).to render_template("data_sets/new")
      end
    end

    describe 'POST #create' do
      let(:r)     { create(:region) }
      let(:pli)   { create(:product_line) }
      let(:ds_2)  { build_stubbed(:ds_DSRDFEUR2013Q2) }

      context 'when params are valid' do
        it 'creates an data_set' do
          expect {
            post :create, data_set: attributes_for(:ds_DUMMY, data_type_id: ds_2.data_type.id,
                                                   company_abbr_id: ds_2.company_abbr.id, region_id: ds_2.region.id,
                                                   data_release_id: ds_2.data_release.id), data_set_product_lines: [pli.id], coverage_regions: [r.id]
          }.to change(DataSet, :count).by(1)

          expect(response.status).to eq 302
          expect(response).to redirect_to "/webmis/data_sets/#{assigns(:data_set).id}"
        end

        it 'creates an data_set with all attributes' do
          expect do
            post :create, data_set: attributes_for(:data_set_maximal, data_type_id: ds_2.data_type.id,
                                                   company_abbr_id: ds_2.company_abbr.id, region_id: ds_2.region.id,
                                                   data_release_id: ds_2.data_release.id), data_set_product_lines: [pli.id], coverage_regions: [r.id]
          end.to change(DataSet, :count).by(1)

          expect(response.status).to eq 302
          expect(response).to redirect_to "/webmis/data_sets/#{assigns(:data_set).id}"
        end
      end

      context 'when params are valid' do
        it 'creates DS but renders new when product_lines missing' do
          allow_any_instance_of(DataSet).to receive(:create_or_find_product_lines) { false }

          expect do
            post :create, data_set: attributes_for(:data_set_maximal, data_type_id: ds_2.data_type.id,
                                                   company_abbr_id: ds_2.company_abbr.id, region_id: ds_2.region.id,
                                                   data_release_id: ds_2.data_release.id),
                 data_set_product_lines: [],
                 coverage_regions: [r.id]
          end.to change(DataSet, :count).by(1)

          expect(response.status).to eq 200
          expect(response).to render_template("data_sets/new")
        end

        it 'creates DS but renders new when coverage missing' do
          allow_any_instance_of(DataSet).to receive(:create_or_find_coverage_region) { false }

          expect do
            post :create, data_set: attributes_for(:data_set_maximal, data_type_id: ds_2.data_type.id,
                                                   company_abbr_id: ds_2.company_abbr.id, region_id: ds_2.region.id,
                                                   data_release_id: ds_2.data_release.id),
                 data_set_product_lines: [],
                 coverage_regions: []
          end.to change(DataSet, :count).by(1)

          expect(response.status).to eq 200
          expect(response).to render_template("data_sets/new")
        end
      end
    end

    describe 'GET #edit' do
      it 'renders the edit form for an editable data_set' do
        get :edit, id: data_set
        expect(assigns(:data_set)).to eq(data_set)
        expect(response.status).to eq 200
        expect(subject).to render_template("data_sets/edit")
      end

      context("edit is disallowed") do
        before(:each) do
          allow_any_instance_of(DataSet).to receive('allow_edit?') { false }
        end

        it 'redirects to in_use_orders when NON editable data_set and status NOT REVIEW' do
          data_set.update(status: DataSet::STATUS_IN_PROGRESS)

          get :edit, id: data_set
          expect(response.status).to eq 302
          expect(response).to redirect_to "/webmis/data_sets/#{data_set.id}/in_use_orders"
        end

        it 'redirects to back when NON editable data_set and status REVIEW' do
          data_set.update(status: DataSet::STATUS_REVIEW)

          request.env["HTTP_REFERER"] = "http://example.com/back"

          get :edit, id: data_set
          expect(response.status).to eq 302
          expect(response).to redirect_to "http://example.com/back"
        end
      end
    end

    describe 'PATCH #update' do
      it 'updates a data_set' do
        data_set.description = 'Lorem ipsum'
        post :update, id: data_set, data_set: data_set.attributes, data_set_product_lines: [pli.id], coverage_regions: [r.id]
        data_set.reload
        expect(data_set.description).to eq('Lorem ipsum')
      end
    end

    describe 'DELETE #destroy' do
      it "deletes the data_set" do
        expect { delete :destroy, id: data_set }.to change(DataSet, :count).by(-1)
      end

      it "redirects to data_set#index" do
        delete :destroy, id: data_set
        expect(response).to redirect_to data_sets_url
      end
    end

    describe 'GET #in_use_orders' do
      let!(:data_set) { create(:ds_DUMMY, :with_process_data_elements) }

      it "renders the in_use_orders template" do
        get :in_use_orders, id: data_set

        expect(assigns(:data_set)).to eq(data_set)
        expect(assigns(:production_orders)).to_not be_empty

        expect(response.status).to eq 200
        expect(subject).to render_template("data_sets/in_use_orders")
      end
    end

    describe 'GET #handle' do
      it "renders the handle template" do
        session[:project_id] = Project.default.id

        get :handle, id: data_set

        expect(assigns(:data_set)).to eq(data_set)
        expect(assigns(:current_user)).to eq(user)

        expect(response.status).to eq 200
        expect(subject).to render_template("data_sets/handle")
      end

      it "resets the session project when session project not default" do
        session[:project_id] = Project.default.id + 1

        get :handle, id: data_set

        expect(assigns(:data_set)).to eq(data_set)
        expect(session[:project_id]).to eq Project.default.id
        expect(controller).to set_flash[:notice] # .to(/Your project is switched to #{Project.default.name}./)

        expect(response.status).to eq 302
        expect(response).to redirect_to handle_data_set_path(data_set)
      end

      context "JS requests for group" do
        let(:data_set_group) { create :data_set_group }

        before(:each) do
          request.env['HTTP_X_REQUESTED_WITH'] = "XMLHttpRequest"
        end

        it "can create a group" do
          expect do
            get :create_group, id: data_set, format: 'js'
          end.to change(DataSetGroup, :count).by(1)

          expect(assigns(:msg)).to include "Created and added to new data set group "
          expect(response.status).to eq 200
          expect(subject).to render_template("data_sets/create_group")
        end

        it "create does not add existing group and sets suitable message" do
          data_set.data_set_groups << data_set_group

          expect do
            get :create_group, id: data_set, data_set_group_id: data_set_group
          end.to_not change(DataSetGroup, :count)

          message = "Already related to data set definition group(s) #{data_set_group.name}"

          expect(assigns(:msg)).to eq message
          expect(response.status).to eq 200
          expect(subject).to render_template("data_sets/create_group")
        end

        it "can add a data set to a group" do
          data_set.data_set_groups << data_set_group

          new_group = create(:data_set_group)

          get :add_to_group, id: data_set, data_set_group_id: new_group

          data_set.reload

          expect(data_set.data_set_groups.size).to eq(2)

          expect(response.status).to eq 200
          expect(subject).to render_template("data_sets/add_to_group")
        end

        it "can remove data set from a group" do
          data_set.data_set_groups << data_set_group

          expect(data_set.data_set_groups.size).to eq(1)

          get :remove_from_group, id: data_set, data_set_group_id: data_set_group

          data_set.reload

          expect(data_set.data_set_groups.size).to eq(0)
          expect(response.status).to eq 200
          expect(subject).to render_template("data_sets/remove_from_group")
        end
      end
    end

    describe 'GET #create_set_tool_handover' do
      it "renders the edit set_tool_handover template when set_tool_handover created" do
        get :create_set_tool_handover, id: data_set

        expect(assigns(:data_set)).to eq(data_set)
        expect(assigns(:set_tool_handover)).to be_a SetToolHandover

        expect(response.status).to eq 302
        expect(response).to redirect_to edit_set_tool_handover_path(assigns(:set_tool_handover))
      end

      it "renders the show template when no set_tool_handoever" do
        allow_any_instance_of(DataSet).to receive(:create_set_tool_handover) { nil }

        get :create_set_tool_handover, id: data_set

        expect(assigns(:data_set)).to eq(data_set)
        expect(assigns(:set_tool_handover)).to be_nil
        expect(response.status).to eq 302
        expect(response).to redirect_to "/webmis/data_sets/#{assigns(:data_set).id}"
      end

    end

    context("EDIT DATA SET FILES - AJAX Calls from partial : edit_process_data_elements.erb") do
      before(:each) do
        request.env['HTTP_X_REQUESTED_WITH'] = "XMLHttpRequest"
      end

      describe "POST #filling_for_data_type" do
        it 'should assign empty array if no data type ids present' do
          post :filling_for_data_type, id: data_set

          expect(assigns(:data_set)).to eq data_set
          expect(assigns(:datatype_fillings)).to match_array []
        end

        it 'should assign list of datatype filling names and ids for supplied data types' do
          type = create(:data_type, :with_fillings)

          post :filling_for_data_type, id: data_set, data_type_val: type

          expected = type.fillings.order(:name).collect { |f| [f.name, f.id] }

          expect(assigns(:data_set)).to eq data_set
          expect(assigns(:datatype_fillings).size).to eq 2
          expect(assigns(:datatype_fillings)).to match_array expected
        end
      end

      describe "POST #receptions_for_select" do
        it 'should only respond to JSON' do
          expect do
            post :receptions_for_select, product_lines: [], format: 'js'
          end.to raise_error(ActionController::UnknownFormat)
        end

        it 'should return an empty JSON body when nothing found' do
          post :receptions_for_select, q: '', format: 'json'

          expect(assigns(:receptions_for_select2)).to match_array []
          expect(response.body).to eq "[]"
        end

        context "Valid Params" do
          # Must be 'available' to be included
          let(:reception) { create(:reception, :available, :with_company) }

          it 'should return a JSON body containing available reception data' do
            post :receptions_for_select, q: reception.id.to_s, format: 'json'

            expect(assigns(:receptions_for_select2)).to_not be_empty
            expect(response.body).to_not be_empty

            json = JSON.parse(response.body)
            expect(json[0]['id']).to eq reception.id
            expect(json[0]['company_abbr']).to have_key('id')
          end
        end
      end

      describe "POST #update_product_lines_list_view" do
        it 'should assign empty array if no product_lines ids present' do
          post :update_product_lines_list_view, product_lines: []

          expect(assigns(:product_lines)).to match_array []
        end

        it 'should assign list of found product_lines for ids supplied from list' do
          list_view = create_list(:product_line, 3)
          list_view_items = list_view.collect(&:id)

          post :update_product_lines_list_view, product_lines: list_view_items

          expect(assigns(:product_lines).size).to eq 3
          expect(assigns(:product_lines)).to match_array(list_view)
        end
      end

      describe "POST #update_coverage_regions_list_view" do
        it 'should assign empty array if no coverage_regions ids present' do
          post :update_coverage_regions_list_view, id: data_set

          expect(assigns(:data_set)).to eq data_set

          expect(assigns(:coverage_regions)).to match_array []
        end

        it 'should assign list of found coverage_regions for supplied ids' do
          list_view = create_list(:region, 2)
          list_view_items = list_view.collect(&:id)

          post :update_coverage_regions_list_view, coverage_regions: list_view_items

          expect(assigns(:coverage_regions).size).to eq 2
          expect(assigns(:coverage_regions)).to match_array(list_view)
        end
      end

      describe "POST #review_result" do
        context "Valid Params" do

          let(:data_set_valid) do
            create(:data_set, :with_review_users, :with_process_data_elements, :with_coverages_region)
          end

          let(:remark) { "i like this review very much" }
          let(:params) { { id: data_set_valid, review_result: remark } }

          before(:each) do
            allow_any_instance_of(DataSet).to receive(:validate_element_file_structure) { true }
          end

          it "should return review successful text on success" do
            post :review_result, params, format: 'js'
            expect(response.body).to eq 'success:Review successfully submitted.'
          end

          it "should set DataSet review attributes to reflect IN_PROGRESS when NOT approved" do
            post :review_result, params, format: 'js'

            data_set_valid.reload

            expect(data_set_valid.status).to eq DataSet::STATUS_IN_PROGRESS
            expect(data_set_valid.review_request_user_id).to be_nil
            expect(data_set_valid.review_user_id).to eq user.id
            expect(data_set_valid.review_result).to eq remark
          end

          it "should set DataSet review attributes to PRODUCTION when approved" do
            post :review_result, params.merge!(result: 'approve'), format: 'js'

            data_set_valid.reload

            expect(data_set_valid.status).to eq DataSet::STATUS_PRODUCTION
            expect(data_set_valid.review_request_user_id).to be_nil
            expect(data_set_valid.review_user_id).to eq user.id
            expect(data_set_valid.review_result).to eq remark
          end
        end
      end

      describe "POST #save_process_data_element" do
        # Driven via Action menu - data set files  - views/data_sets/edit_process_data_elements.erb

        let(:process_data_specification)  { create(:process_data_specification) }
        let(:process_data_element)        { create(:process_data_element, :with_specification) }

        context "JS requests WITHOUT a ProcessDataElement" do
          let(:params) { { id: data_set, process_data_specification_id: process_data_specification } }

          it "creates new process_data_element when none provided" do
            expect do
              post :save_process_data_element, params, format: 'js'
            end.to change(ProcessDataElement, :count).by(1)
          end

          it "creates new process_data_element data set attributes to reflect update and status in progress" do
            expect(data_set.status).to_not eq DataSet::STATUS_IN_PROGRESS

            post :save_process_data_element, params, format: 'js'

            data_set.reload

            expect(assigns(:data_set)).to eq(data_set)
            expect(data_set.updated_by).to eq user.user_name
            expect(data_set.status).to eq DataSet::STATUS_IN_PROGRESS
          end

          it "renders partial process_data_element" do
            post :save_process_data_element, params, format: 'js'

            expect(response.status).to eq 200
            expect(subject).to render_template(partial: '_process_data_element')
          end
        end

        context "JS requests WITH a ProcessDataElement" do
          # The supplied process_data_element_id must belong to a DataSet
          let(:data_set) { create(:data_set, :with_process_data_elements, :with_process_data_directory) }

          let(:params) do
            {
              id: data_set,
              process_data_element_id: data_set.process_data_elements.first,
              process_data_specification_id: process_data_specification
            }
          end

          it "render error text when no process_data_specification_id supplied" do
            post :save_process_data_element, params.except(:process_data_specification_id), format: 'js'

            expect(response.body).to eq "ERROR: Process data specification is mandatory."
          end

          it "render error text when process_data element supplied does not belong to a DataSet" do
            params[:process_data_element_id] = process_data_element

            post :save_process_data_element, params, format: 'js'

            expect(response.body).to eq "ERROR: Element does not belong to a data set."
          end

          it 'assigns new process_data_specification and updates process_data_element' do
            post :save_process_data_element, params, format: 'js'

            data_set.reload
            updated_pds = data_set.process_data_elements.first.process_data_specification

            expect(updated_pds.id).to eq process_data_specification.id
            expect(data_set.status).to eq DataSet::STATUS_IN_PROGRESS
          end

          it 'should render partial process_data_element' do
            post :save_process_data_element, params, format: 'js'

            expect(response.status).to eq 200
            expect(subject).to render_template(partial: '_process_data_element')
          end
        end
      end

      describe "POST #sync_with_directory_structure" do
        let(:data_set) { create(:data_set, :with_process_data_elements) }

        before(:each) do
          allow_any_instance_of(DataSet).to receive(:sync_elements) { true }
        end

        it 'should render the process_data_element' do
          post :sync_with_directory_structure, id: data_set, format: 'js'

          expect(response.status).to eq 200
          expect(subject).to render_template(partial: '_process_data_element')
        end

        it 'should set the updated_by field' do
          post :sync_with_directory_structure, id: data_set, format: 'js'
          data_set.reload
          expect(data_set.updated_by).to eq user.user_name
          expect(data_set.status).to eq DataSet::STATUS_DRAFT
        end

        it 'should set the status when still active process data element' do
          allow_any_instance_of(DataSet).to receive(:sync_elements) { raise WebMis::DirectoryEmpty, "has no content!" }

          data_set.status = DataSet::STATUS_IN_PROGRESS
          data_set.process_data_elements << create(:process_data_element)

          post :sync_with_directory_structure, id: data_set, format: 'js'

          expect(response.body).to eq "ERROR: has no content!"
          expect(data_set.status).to eq DataSet::STATUS_IN_PROGRESS
        end
      end

      describe "POST #remove_process_data_element" do
        context "WITH a ProcessDataElement" do
          let(:data_set) { create(:data_set, :with_process_data_elements) }
          let(:pde)      { data_set.process_data_elements.first }

          let(:params) do
            {
              id: data_set,
              process_data_element_id: [pde]
            }
          end

          before(:each) do
            allow_any_instance_of(ProcessDataElement).to receive(:remove_and_sync) { true }
          end

          it 'should set the removed_yn flag to true' do
            expect(pde.removed_yn).to be_falsey

            post :remove_process_data_element, params, format: 'js'

            expect(response.status).to eq 200

            pde.reload
            expect(pde.removed_yn).to be_truthy
          end

          it 'should log the removal to DataSetStatusLog' do
            expect do
              post :remove_process_data_element, params, format: 'js'
            end.to change(DataSetStatusLog, :count).by(1)
          end

          it 'should update the data set status to DRAFT when no active PDEs' do
            post :remove_process_data_element, params, format: 'js'

            data_set.reload
            expect(data_set.updated_by).to eq user.user_name
            expect(data_set.status).to eq DataSet::STATUS_DRAFT
          end
        end
      end
    end
  end
end

