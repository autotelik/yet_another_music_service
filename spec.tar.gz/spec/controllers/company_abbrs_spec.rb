require 'rails_helper'

describe CompanyAbbrsController do
  before(:each) do
    # required by view
    session[:user_id] = create(:user).id
    session[:project_id] = create(:proj_PRODUCTION).id

    # required by controller
    allow_any_instance_of(CompanyAbbrsController).to receive(:authorize){ true }
    
    @company_abbr = create(:company_abbr)
  end

  describe 'GET #index' do
    it 'finds an company_abbr object' do
      get :index
      expect(assigns(:company_abbrs)).not_to be_empty
    end
    it 'searches and finds an company_abbr object' do
      get :index, search: @company_abbr.company_name
      expect(assigns(:company_abbrs)).not_to be_empty
    end
  end

  describe 'GET #show' do
    it 'gets a specific company_abbr object' do
      get :show, id: @company_abbr
      expect(assigns(:company_abbr)).to eq(@company_abbr)
    end
  end

  describe 'GET #new' do
    it 'builds a new company_abbr' do
      get :new
      expect(assigns(:company_abbr)).to be_a_new(CompanyAbbr)
    end
  end

  describe 'POST #create' do
    it 'creates an company_abbr' do
      expect {
        post :create, company_abbr: attributes_for(:company_abbr, ms_abbr_3: 'NOK')
      }.to change(CompanyAbbr, :count).by(1)
    end
    it 'creates an company_abbr with all attributes' do
      expect {
        post :create, company_abbr: attributes_for(:company_abbr_maximal, ms_abbr_3: 'NOK')
      }.to change(CompanyAbbr, :count).by(1)
    end
  end

  describe 'PATCH #update' do
    it 'updates a company_abbr' do
      @company_abbr.ms_abbr_3 = 'NOK'
      post :update, id: @company_abbr, company_abbr: @company_abbr.attributes
      @company_abbr.reload
      expect(@company_abbr.ms_abbr_3).to eq('NOK')
    end
  end
end
