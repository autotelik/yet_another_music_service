require 'rails_helper'

describe TestRequestsController do
  before(:each) do
    # required by view
    prod_project = create(:proj_PRODUCTION)
    session[:user_id] = create(:user).id
    session[:project_id] = prod_project.id

    allow_any_instance_of(TestRequestsController).to receive(:authorize){ true }

    # validation false as otherwise the factory will create multiple instances of the same region
    @test_request = create(:test_request, project: prod_project)
  end

  describe 'GET #index' do
    it 'finds an test_request object' do
      get :index
      expect(assigns(:test_requests)).not_to be_empty
    end
    it 'searches and finds an test_request object' do
      get :index, search: @test_request.test_type.name
      expect(assigns(:test_requests)).not_to be_empty
    end
  end

  describe 'GET #show' do
    it 'gets a specific test_request object' do
      get :show, id: @test_request
      expect(assigns(:test_request)).to eq(@test_request)
    end
  end

  describe 'GET #new' do
    it 'builds a new test_request' do
      get :new
      expect(assigns(:test_request)).to be_a_new(TestRequest)
    end
  end

  describe 'POST #create' do
    it 'creates an test_request' do
      expect {
        post :create, test_request: attributes_for(:test_request, test_type_id: @test_request.test_type.id, 
          assigned_to_user_id: @test_request.assigned_user.id, test_db_conversion_databases_id: @test_request.test_db.id)
      }.to change(TestRequest, :count).by(1)
    end
    it 'creates an test_request with all attributes' do
      expect {
        post :create, test_request: attributes_for(:test_request_maximal, test_type_id: @test_request.test_type.id, 
          assigned_to_user_id: @test_request.assigned_user.id, test_db_conversion_databases_id: @test_request.test_db.id)
      }.to change(TestRequest, :count).by(1)
    end
  end

  describe 'PATCH #update' do
    it 'updates a test_request' do
      @test_request.result_remarks = 'Lorem ipsum'
      post :update, id: @test_request, test_request: @test_request.attributes
      @test_request.reload
      expect(@test_request.result_remarks).to eq('Lorem ipsum')
    end
  end
end
