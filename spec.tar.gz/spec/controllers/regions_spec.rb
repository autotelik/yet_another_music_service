require 'rails_helper'

describe RegionsController do
  before(:each) do
    # required by view
    session[:user_id] = create(:user).id
    session[:project_id] = create(:proj_PRODUCTION).id

    # required by controller
    allow_any_instance_of(RegionsController).to receive(:authorize){ true }
    
    @region = create(:r_WORLD)
  end

  describe 'GET #index' do
    it 'finds an region object' do
      get :index
      expect(assigns(:regions)).not_to be_empty
    end
    it 'searches and finds an region object' do
      get :index, q: @region.region_code
      expect(assigns(:regions)).not_to be_empty
    end
  end

  describe 'GET #show' do
    it 'gets a specific region object' do
      get :show, id: @region
      expect(assigns(:region)).to eq(@region)
    end
  end

  describe 'GET #new' do
    it 'builds a new region' do
      get :new
      expect(assigns(:region)).to be_a_new(Region)
    end
  end

  describe 'POST #create' do
    it 'creates a real region' do
      expect {
        post :create, region: attributes_for(:r_TEST_REGION1)
      }.to change(Region, :count).by(1)
    end
    it 'creates a region alias' do
      expect {
        post :create, region: {active_yn: true, name: 'Earth', region_type: Region::REGION_ALIAS, parent_id: @region.id}
      }.to change(Region, :count).by(1)
    end
  end

  describe 'PATCH #update' do
    it 'updates a region' do
      @region.name = 'Lorem'
      post :update, id: @region, region: @region.attributes
      @region.reload
      expect(@region.name).to eq('Lorem')
    end
  end
end
