require 'rails_helper'

describe ConversionDesignNamesController do
  before(:each) do
    # required by view
    session[:user_id] = create(:user).id
    prod_project = create(:proj_PRODUCTION)
    session[:project_id] = prod_project.id
    conversion_design = create(:conversion_design, project: prod_project)

    # required by controller
    allow_any_instance_of(ConversionDesignNamesController).to receive(:authorize){ true }
    
    @conversion_design_name = create(:conversion_design_name, project: prod_project, default_design: conversion_design)
  end

  describe 'GET #index' do
    it 'finds an conversion_design_name object' do
      get :index
      expect(assigns(:conversion_design_names)).not_to be_empty
    end
    it 'searches and finds an conversion_design object' do
      get :index, search: @conversion_design_name.name
      expect(assigns(:conversion_design_names)).not_to be_empty
    end
  end

  describe 'GET #show' do
    it 'gets a specific conversion_design object' do
      get :show, id: @conversion_design_name
      expect(assigns(:conversion_design_name)).to eq(@conversion_design_name)
    end
  end

  # no new action
  # no create action
  # no update action
end
