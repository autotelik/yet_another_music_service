require 'rails_helper'

describe CommitmentChangeReasonsController do
  before(:each) do
    # required by view
    session[:user_id] = create(:user).id
    session[:project_id] = create(:proj_PRODUCTION).id

    # required by controller
    allow_any_instance_of(CommitmentChangeReasonsController).to receive(:authorize){ true }
    
    @commitment_change_reason = create(:commitment_change_reason)
  end

  describe 'GET #index' do
    it 'finds an commitment_change_reason object' do
      get :index
      expect(assigns(:commitment_change_reasons)).not_to be_empty
    end
    it 'searches and finds an commitment_change_reason object' do
      get :index, search: @commitment_change_reason.reason
      expect(assigns(:commitment_change_reasons)).not_to be_empty
    end
  end

  describe 'GET #show' do
    it 'gets a specific commitment_change_reason object' do
      get :show, id: @commitment_change_reason
      expect(assigns(:commitment_change_reason)).to eq(@commitment_change_reason)
    end
  end

  describe 'GET #new' do
    it 'builds a new commitment_change_reason' do
      get :new
      expect(assigns(:commitment_change_reason)).to be_a_new(CommitmentChangeReason)
    end
  end

  describe 'POST #create' do
    it 'creates an commitment_change_reason' do
      expect {
        post :create, commitment_change_reason: attributes_for(:commitment_change_reason)
      }.to change(CommitmentChangeReason, :count).by(1)
    end
    it 'creates an commitment_change_reason with all attributes' do
      expect {
        post :create, commitment_change_reason: attributes_for(:commitment_change_reason_maximal)
      }.to change(CommitmentChangeReason, :count).by(1)
    end
  end

  describe 'PATCH #update' do
    it 'updates a commitment_change_reason' do
      @commitment_change_reason.description = 'Lorem ipsum'
      post :update, id: @commitment_change_reason, commitment_change_reason: @commitment_change_reason.attributes
      @commitment_change_reason.reload
      expect(@commitment_change_reason.description).to eq('Lorem ipsum')
    end
  end
end
