require 'rails_helper'

describe ConversionDatabasesController do

  let(:company_abbr)  { create(:company_abbr) }
  let(:conv)          { create(:conversion, project: prod_project, company_abbr: company_abbr) }
  let(:conv_job)      { create(:conversion_job, conversion: conv) }
  let(:prod_project)  { create(:proj_PRODUCTION) }
  let(:data_release)  { create(:data_release) }

  before(:each) do

    # required by view
    session[:user_id]    = create(:user).id
    session[:project_id] = prod_project.id

    @conversion_database = create(:conversion_database_maximal,            conversion_job: conv_job)
    @cd_removed          = create(:conversion_database_removed,            conversion_job: conv_job)
    @cd_marked           = create(:conversion_database_marked_for_removal, conversion_job: conv_job)

    # Stubs

    # required by controller
    allow_any_instance_of(ConversionDatabasesController).to receive(:authorize){ true }

    allow_any_instance_of(Conversion).to receive(:project_id)         { session[:project_id] }
    allow_any_instance_of(ConversionDatabase).to receive(:project_id) { session[:project_id] }
  end

  describe 'GET #index' do

    it 'finds an conversion_database object' do
      get :index
      expect(assigns(:conversion_databases)).to match_array([@conversion_database, @cd_marked])
    end

    it 'searches and finds an conversion_database object' do
      get :index, search: @conversion_database.db_type
      expect(assigns(:conversion_databases)).to match_array([@conversion_database, @cd_marked])
    end

    it 'can search for conversion_database objects by volume id' do
      get :index, search: @cd_marked.volume_id
      expect(assigns(:conversion_databases)).to match_array([@cd_marked])
    end
  end

  describe 'POST #remove_databases' do

    context 'do not render view db_remove_script' do

      render_views false

      before(:each) do
        allow(ConfigParameter).to receive(:get).with('conversion_job_result_dir', anything) { "/tmp/rspec" }
      end

      context 'param set is remove_selected' do

        it 'finds and removes a selected conversion_database' do
          post :remove_databases, remove_selected: 1, selected: [@cd_marked.id]

          expect(assigns(:conversion_databases)).to eq([@cd_marked])
          expect(response.status).to eq(200)
        end

        it 'sets the ConversionDatabase status to removed upon removal' do

          allow_any_instance_of(ConversionDatabase).to receive(:allow_file_system_status_change?) { true }

          expect(@cd_marked.file_system_status).to_not eq ConversionDatabase::FILE_SYSTEM_STATUS_REMOVED

          post :remove_databases, remove_selected: 1, selected: [@cd_marked.id]

          @cd_marked.reload
          expect(@cd_marked.remarks).to include ": Removed as (manual) batch."
          expect(@cd_marked.file_system_status).to eq ConversionDatabase::FILE_SYSTEM_STATUS_REMOVED

        end

        it 'sets the flash notice when no databases found for removal' do
          post :remove_databases, remove_selected: true, selected: []

          expect(assigns(:conversion_databases)).to eq([])
          expect(controller).to set_flash[:notice].to(/No databases to remove./)

          post :remove_databases, remove_selected: true, selected: [0, ConversionDatabase.maximum(:id).next]
          expect(assigns(:conversion_databases)).to eq([])
          expect(controller).to set_flash[:notice].to(/No databases to remove./)
        end

      end

      context 'param set is delete_selected - automatic removal' do

        it 'finds and automatically deletes requested conversion_database' do
          allow_any_instance_of(ConversionDatabase).to receive(:change_file_system_status) { true }

          post :remove_databases, delete_selected: 1, selected: [@cd_marked.id]

          # delete_selected does not assign to member conversion_databases, just goes ahead and removes
          expect(assigns(:conversion_databases)).to eq([])

          expect(controller).to set_flash[:notice].to(/All selected databases were successfully removed/)
        end

        it 'fails if the requested conversion_database does not have valid path' do
          allow_any_instance_of(ConversionDatabase).to receive(:change_file_system_status) { true }

          post :remove_databases, delete_selected: 1, selected: [@cd_marked.id]

          # delete_selected does not assign to member conversion_databases, just goes ahead and removes
          expect(assigns(:conversion_databases)).to eq([])

          expect(response.status).to eq(302)
        end

        it 'fails if the requested conversion_database cannot change file_system_status' do
          allow_any_instance_of(ConversionDatabase).to receive(:change_file_system_status).with(
              ConversionDatabase::FILE_SYSTEM_STATUS_REMOVED
          ) { false }

          post :remove_databases, delete_selected: 1, selected: [@cd_marked.id]

          expect(response.status).to eq(302)

          @cd_marked.reload

          expect_msg = "file_system change from Marked for removal to Removed is not allowed - not removed."

          expect(@cd_marked.removal_remark).to include(expect_msg)
        end

      end

      it 'selects and removes conversion_database already marked for removal' do
        post :remove_databases, remove_all: 1, selected: [@conversion_database.id, @cd_removed.id]

        # Should select only Conversions ALREADY marked for removal and ignore param 'selected'
        expect(assigns(:conversion_databases)).to eq([@cd_marked])
      end


    end

  end


  describe 'GET #show' do
    it 'gets a specific conversion_database object' do
      get :show, id: @conversion_database.id
      expect(assigns(:conversion_database)).to eq(@conversion_database)
    end
  end

  describe 'GET #new' do
    it 'builds a new conversion_database' do
      get :new
      expect(assigns(:conversion_database)).to be_a_new(ConversionDatabase)
    end
  end

  describe 'POST #create' do
    it 'creates an conversion_database' do
      expect {
        post :create, conversion_database: attributes_for(:conversion_database, remarks: 'lorem')
      }.to change(ConversionDatabase, :count).by(1)
    end
    it 'creates an conversion_database with all attributes' do
      expect {
        post :create, conversion_database: attributes_for(:conversion_database_maximal)
      }.to change(ConversionDatabase, :count).by(1)
    end
  end

  describe 'PATCH #update' do
    it 'updates a conversion_database' do
      @conversion_database.db_type = 'NDS'
      post :update, id: @conversion_database, conversion_database: @conversion_database.attributes
      @conversion_database.reload
      expect(@conversion_database.db_type).to eq('NDS')
    end
  end
end
