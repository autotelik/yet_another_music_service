require 'rails_helper'

describe DefaultContentReleaseNotesController do
  before(:each) do
    # required by view
    session[:user_id] = create(:user).id
    session[:project_id] = create(:proj_PRODUCTION).id

    # required by controller
    allow_any_instance_of(DefaultContentReleaseNotesController).to receive(:authorize){ true }
    
    @default_content_release_note = create(:default_content_release_note)
  end

  describe 'GET #index' do
    it 'finds an default_content_release_note object' do
      get :index
      expect(assigns(:default_content_release_notes)).not_to be_empty
    end
    it 'searches and finds an default_content_release_note object' do
      get :index, search: @default_content_release_note.title
      expect(assigns(:default_content_release_notes)).not_to be_empty
    end
  end

  describe 'GET #show' do
    it 'gets a specific default_content_release_note object' do
      get :show, id: @default_content_release_note
      expect(assigns(:default_content_release_note)).to eq(@default_content_release_note)
    end
  end

  describe 'GET #new' do
    it 'builds a new default_content_release_note' do
      get :new
      expect(assigns(:default_content_release_note)).to be_a_new(DefaultContentReleaseNote)
    end
  end

  describe 'POST #create' do
    it 'creates an default_content_release_note' do
      # controller requires logged in user
      create(:Admin)
      user = build_stubbed(:TESTUSER)
      @controller = LoginController.new
      post "do_login", login: { username: user.user_name, password: user.pw}
      @controller = DefaultContentReleaseNotesController.new

      expect {
        post :create, default_content_release_note: attributes_for(:default_content_release_note, 
          product_category_id: @default_content_release_note.product_category.id)
      }.to change(DefaultContentReleaseNote, :count).by(1)
    end
    it 'creates an default_content_release_note with all attributes' do
      # controller requires logged in user
      create(:Admin)
      user = build_stubbed(:TESTUSER)
      @controller = LoginController.new
      post "do_login", login: { username: user.user_name, password: user.pw}
      @controller = DefaultContentReleaseNotesController.new

      expect {
        post :create, default_content_release_note: attributes_for(:default_content_release_note_maximal, 
          product_category_id: @default_content_release_note.product_category.id)
      }.to change(DefaultContentReleaseNote, :count).by(1)
    end
  end

  describe 'PATCH #update' do
    it 'updates a default_content_release_note' do
      @default_content_release_note.title = 'Product Information'
      post :update, id: @default_content_release_note, default_content_release_note: @default_content_release_note.attributes
      @default_content_release_note.reload
      expect(@default_content_release_note.title).to eq('Product Information')
    end
  end
end
