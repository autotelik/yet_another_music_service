require 'rails_helper'

describe CompaniesController do
  before(:each) do
    # required by view
    session[:user_id] = create(:user).id
    session[:project_id] = create(:proj_PRODUCTION).id

    # required by controller
    allow_any_instance_of(CompaniesController).to receive(:authorize){ true }
    
    @company = create(:company)
  end

  describe 'GET #index' do
    it 'finds an company object' do
      get :index
      expect(assigns(:companies)).not_to be_empty
    end
    it 'searches and finds an company object' do
      get :index, search: @company.name
      expect(assigns(:companies)).not_to be_empty
    end
  end

  describe 'GET #show' do
    it 'gets a specific company object' do
      get :show, id: @company
      expect(assigns(:company)).to eq(@company)
    end
  end

  describe 'GET #new' do
    it 'builds a new company' do
      get :new
      expect(assigns(:company)).to be_a_new(Company)
    end
  end

  describe 'POST #create' do
    it 'creates an company' do
      expect {
        post :create, company: attributes_for(:company, name: 'Lorem ipsum')
      }.to change(Company, :count).by(1)
    end
    it 'creates an company with all attributes' do
      expect {
        post :create, company: attributes_for(:company_maximal, name: 'Lorem ipsum')
      }.to change(Company, :count).by(1)
    end
  end

  describe 'PATCH #update' do
    it 'updates a company' do
      @company.name = 'Lorem ipsum'
      post :update, id: @company, company: @company.attributes
      @company.reload
      expect(@company.name).to eq('Lorem ipsum')
    end
  end
end
