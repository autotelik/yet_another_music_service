require 'rails_helper'

describe ConfigParametersController do
  before(:each) do
    # required by view
    session[:user_id] = create(:user).id
    prod_project = create(:proj_PRODUCTION)
    session[:project_id] = prod_project.id

    # required by controller
    allow_any_instance_of(ConfigParametersController).to receive(:authorize){ true }

    @config_parameter = create(:process_data_directory, project: prod_project)
  end

  describe 'GET #index' do
    it 'finds an config_parameter object' do
      get :index
      expect(assigns(:config_parameters)).not_to be_empty
    end
    it 'searches and finds an config_parameter object' do
      get :index, search: @config_parameter.cfg_name
      expect(assigns(:config_parameters)).not_to be_empty
    end
  end

  describe 'GET #show' do
    it 'gets a specific config_parameter object' do
      get :show, id: @config_parameter
      expect(assigns(:config_parameter)).to eq(@config_parameter)
    end
  end

  describe 'GET #new' do
    it 'builds a new config_parameter' do
      get :new
      expect(assigns(:config_parameter)).to be_a_new(ConfigParameter)
    end
  end

  describe 'POST #create' do
    it 'creates an config_parameter' do
      expect {
        post :create, config_parameter: attributes_for(:process_data_directory, cfg_name: 'tool_release_directory')
      }.to change(ConfigParameter, :count).by(1)
    end
    it 'creates an config_parameter with all attributes' do
      expect {
        post :create, config_parameter: attributes_for(:process_data_directory_maximal, cfg_name: 'tool_release_directory')
      }.to change(ConfigParameter, :count).by(1)
    end
  end

  describe 'PATCH #update' do
    it 'updates a config_parameter' do
      @config_parameter.cfg_name = 'tool_release_directory'
      post :update, id: @config_parameter, config_parameter: @config_parameter.attributes
      @config_parameter.reload
      expect(@config_parameter.cfg_name).to eq('tool_release_directory')
    end
  end
end
