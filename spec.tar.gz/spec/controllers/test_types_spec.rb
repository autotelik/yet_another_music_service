require 'rails_helper'

describe TestTypesController do
  before(:each) do
    # required by view
    session[:user_id] = create(:user).id
    session[:project_id] = create(:proj_PRODUCTION).id

    # required by controller
    allow_any_instance_of(TestTypesController).to receive(:authorize){ true }
    
    @test_type = create(:test_type)
  end

  describe 'GET #index' do
    it 'finds an test_type object' do
      get :index
      expect(assigns(:test_types)).not_to be_empty
    end
    it 'searches and finds an test_type object' do
      get :index, search: @test_type.name
      expect(assigns(:test_types)).not_to be_empty
    end
  end

  describe 'GET #show' do
    it 'gets a specific test_type object' do
      get :show, id: @test_type
      expect(assigns(:test_type)).to eq(@test_type)
    end
  end

  describe 'GET #new' do
    it 'builds a new test_type' do
      get :new
      expect(assigns(:test_type)).to be_a_new(TestType)
    end
  end

  describe 'POST #create' do
    it 'creates an test_type' do
      expect {
        post :create, test_type: attributes_for(:test_type)
      }.to change(TestType, :count).by(1)
    end
    it 'creates an test_type with all attributes' do
      expect {
        post :create, test_type: attributes_for(:test_type_maximal)
      }.to change(TestType, :count).by(1)
    end
  end

  describe 'PATCH #update' do
    it 'updates a test_type' do
      @test_type.description = 'Lorem ipsum'
      post :update, id: @test_type, test_type: @test_type.attributes
      @test_type.reload
      expect(@test_type.description).to eq('Lorem ipsum')
    end
  end
end
