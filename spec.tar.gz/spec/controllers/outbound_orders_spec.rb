require 'rails_helper'

describe OutboundOrdersController do

  include_context 'authorization'

  let!(:outbound_order) { create(:outbound_order) }

  describe 'GET #index' do
    it 'finds an outbound_order object' do
      get :index

      expect(assigns(:outbound_orders)).not_to be_empty
    end
    it 'searches and finds an outbound_order object' do
      get :index, search: outbound_order.id

      expect(assigns(:outbound_orders)).not_to be_empty
    end
  end

  describe 'GET #show' do
    it 'gets a specific outbound_order object' do
      get :show, id: outbound_order

      expect(assigns(:outbound_order)).to eq(outbound_order)
    end
  end

  describe 'GET #new' do
    it 'builds a new outbound_order' do
      # create(:company_abbr) # required by view
      get :new

      expect(assigns(:outbound_order)).to be_a_new(OutboundOrder)
    end
  end

  describe 'POST #create' do
    it 'creates an outbound_order' do
      expect {
        post :create, outbound_order: attributes_for(:outbound_order)
      }.to change(OutboundOrder, :count).by(1)
    end

    it 'creates an outbound_order with all attributes' do
      expect {
        post :create, outbound_order: attributes_for(:outbound_order_maximal)
      }.to change(OutboundOrder, :count).by(1)
    end
  end

  describe 'PATCH #update' do
    it 'updates a outbound_order' do
      outbound_order.remarks = 'Lorem ipsum'

      post :update, id: outbound_order, outbound_order: outbound_order.attributes

      outbound_order.reload

      expect(outbound_order.remarks).to eq('Lorem ipsum')
    end
  end
end
