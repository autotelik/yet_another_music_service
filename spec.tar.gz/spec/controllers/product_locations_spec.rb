require 'rails_helper'

describe ProductLocationsController do
  let(:conversion)                        { create(:c_DEFAULT, volume_id: 'lorem') }
  let!(:product_location)                 { create(:product_location) }
  let(:user)                              { create(:user) }
  let(:project)                           { create(:proj_PRODUCTION) }

  before(:each) do
    # required by view
    session[:user_id] = user.id
    session[:project_id] = project.id

    # required by controller
    allow_any_instance_of(ProductLocationsController).to receive(:authorize){ true }
  end

  describe 'GET #index' do
    it 'finds an product_location object' do
      get :index

      expect(assigns(:product_locations)).not_to be_empty
    end
    it 'searches and finds an product_location object' do
      get :index, search: product_location.volume_id

      expect(assigns(:product_locations)).not_to be_empty
    end
  end

  describe 'GET #show' do
    it 'gets a specific product_location object' do
      get :show, id: product_location

      expect(assigns(:product_location)).to eq(product_location)
    end
  end

  describe 'GET #new' do
    it 'builds a new product_location' do
      get :new

      expect(assigns(:product_location)).to be_a_new(ProductLocation)
    end
  end

  describe 'POST #create' do
    it 'creates an product_location' do
      expect {
        post :create, product_location: attributes_for(:product_location), conversion_id: conversion.id
      }.to change(ProductLocation, :count).by(1)
    end
    it 'creates an product_location with all attributes' do
      expect {
        post :create, product_location: attributes_for(:product_location_maximal), conversion_id: conversion.id
      }.to change(ProductLocation, :count).by(1)
    end
  end

  describe 'PATCH #update' do
    it 'updates a product_location' do
      product_location.update(remarks: 'Lorem ipsum')

      post :update, id: product_location, product_location: product_location.attributes
      product_location.reload

      expect(product_location.remarks).to eq('Lorem ipsum')
    end
  end
end
