require 'rails_helper'

describe ExternalContactsController do
  before(:each) do
    # required by view
    session[:user_id] = create(:user).id
    session[:project_id] = create(:proj_PRODUCTION).id

    # required by controller
    allow_any_instance_of(ExternalContactsController).to receive(:authorize){ true }
  end

  let!(:external_contact)     { create(:external_contact) }
  let(:company)              { create(:company) }

  describe 'GET #index' do
    it 'finds an external_contact object' do
      get :index
      expect(assigns(:external_contacts)).not_to be_empty
    end
    it 'searches and finds an external_contact object' do
      get :index, search: external_contact.first_name
      expect(assigns(:external_contacts)).not_to be_empty
    end
  end

  describe 'GET #show' do
    it 'gets a specific external_contact object' do
      get :show, id: external_contact
      expect(assigns(:external_contact)).to eq(external_contact)
    end
  end

  describe 'GET #new' do
    it 'builds a new external_contact' do
      get :new
      expect(assigns(:external_contact)).to be_a_new(ExternalContact)
    end
  end

  describe 'POST #create' do
    it 'creates an external_contact' do
      expect {
        post :create, external_contact: attributes_for(:external_contact, company_id: company.id)
      }.to change(ExternalContact, :count).by(1)
    end
    it 'creates an external_contact with all attributes' do
      expect {
        post :create, external_contact: attributes_for(:external_contact_maximal, company_id: company.id)
      }.to change(ExternalContact, :count).by(1)
    end
  end

  describe 'PATCH #update' do
    it 'updates a external_contact' do
      external_contact.first_name = 'Lorem ipsum'
      post :update, id: external_contact, external_contact: external_contact.attributes
      external_contact.reload
      expect(external_contact.first_name).to eq('Lorem ipsum')
    end
  end
end
