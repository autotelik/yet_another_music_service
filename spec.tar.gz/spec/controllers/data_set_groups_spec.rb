require 'rails_helper'

describe DataSetGroupsController do
  before(:each) do
    # required by view
    session[:user_id] = create(:user).id
    session[:project_id] = create(:proj_PRODUCTION).id

    # required by controller
    allow_any_instance_of(DataSetGroupsController).to receive(:authorize){ true }
    
    @data_set_group = create(:data_set_group)
  end

  describe 'GET #index' do
    it 'finds an data_set_group object' do
      get :index
      expect(assigns(:data_set_groups)).not_to be_empty
    end
    it 'searches and finds an data_set_group object' do
      get :index, search: @data_set_group.company_abbr
      expect(assigns(:data_set_groups)).not_to be_empty
    end
  end

  describe 'GET #show' do
    it 'gets a specific data_set_group object' do
      get :show, id: @data_set_group
      expect(assigns(:data_set_group)).to eq(@data_set_group)
    end
  end

  describe 'GET #new' do
    it 'builds a new data_set_group' do
      get :new
      expect(assigns(:data_set_group)).to be_a_new(DataSetGroupPresenter)
    end
  end

  describe 'POST #create' do
    it 'creates an data_set_group' do
      expect {
        post :create, data_set_group: attributes_for(:data_set_group, company_abbr: 'TOM')
      }.to change(DataSetGroup, :count).by(1)
    end
    it 'creates an data_set_group with all attributes' do
      expect {
        post :create, data_set_group: attributes_for(:data_set_group_maximal, company_abbr: 'TOM')
      }.to change(DataSetGroup, :count).by(1)
    end
  end

  describe 'PATCH #update' do
    it 'updates a data_set_group' do
      @data_set_group.region_code = 'NAR'
      post :update, id: @data_set_group, data_set_group: @data_set_group.attributes
      @data_set_group.reload
      expect(@data_set_group.region_code).to eq('NAR')
    end
  end
end
