require 'rails_helper'

describe ConversionEnvironmentsController do
  before(:each) do
    # required by view
    session[:user_id] = create(:user).id
    session[:project_id] = create(:proj_PRODUCTION).id

    # required by controller
    allow_any_instance_of(ConversionEnvironmentsController).to receive(:authorize){ true }
    
    @conversion_environment = create(:conversion_environment)
  end

  describe 'GET #index' do
    it 'finds an conversion_environment object' do
      get :index
      expect(assigns(:conversion_environments)).not_to be_empty
    end
    it 'searches and finds an conversion_environment object' do
      get :index, search: @conversion_environment.name
      expect(assigns(:conversion_environments)).not_to be_empty
    end
  end

  describe 'GET #show' do
    it 'gets a specific conversion_environment object' do
      get :show, id: @conversion_environment
      expect(assigns(:conversion_environment)).to eq(@conversion_environment)
    end
  end

  describe 'GET #new' do
    it 'builds a new conversion_environment' do
      get :new
      expect(assigns(:conversion_environment)).to be_a_new(ConversionEnvironment)
    end
  end

  describe 'POST #create' do
    it 'creates an conversion_environment' do
      expect {
        post :create, conversion_environment: attributes_for(:conversion_environment)
      }.to change(ConversionEnvironment, :count).by(1)
    end
    it 'creates an conversion_environment with all attributes' do
      expect {
        post :create, conversion_environment: attributes_for(:conversion_environment_maximal)
      }.to change(ConversionEnvironment, :count).by(1)
    end
  end

  describe 'PATCH #update' do
    it 'updates a conversion_environment' do
      @conversion_environment.active_yn = false
      post :update, id: @conversion_environment, conversion_environment: @conversion_environment.attributes
      @conversion_environment.reload
      expect(@conversion_environment.active_yn).to eq(false)
    end
  end
end
