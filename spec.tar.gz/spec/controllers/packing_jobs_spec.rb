require 'rails_helper'

describe PackingJobsController do
  before(:each) do
    # required by view
    session[:user_id] = create(:user).id
    prod_project = create(:proj_PRODUCTION)
    session[:project_id] = prod_project.id

    # required by controller
    allow_any_instance_of(PackingJobsController).to receive(:authorize){ true }
    
    @packing_job = create(:packing_job)
  end

  describe 'GET #index' do
    it 'finds an packing_job object' do
      get :index
      expect(assigns(:packing_jobs)).not_to be_empty
    end
    it 'searches and finds an packing_job object' do
      get :index, search: @packing_job.id
      expect(assigns(:packing_jobs)).not_to be_empty
    end
  end

  describe 'GET #show' do
    it 'gets a specific packing_job object' do
      get :show, id: @packing_job
      expect(assigns(:packing_job)).to eq(@packing_job)
    end
  end

  # no new action

  describe 'POST #create' do
    it 'creates an packing_job' do
      expect {
        post :create, packing_job: attributes_for(:packing_job, reference_id: @packing_job.outbound_orderline.id,
          fail_category_logged_by_user_id: @packing_job.fail_category_logged_by_user.id)
      }.to change(PackingJob, :count).by(1)
    end
    it 'creates an packing_job with all attributes' do
      expect {
        post :create, packing_job: attributes_for(:packing_job_maximal, reference_id: @packing_job.outbound_orderline.id,
          fail_category_logged_by_user_id: @packing_job.fail_category_logged_by_user.id)
      }.to change(PackingJob, :count).by(1)
    end
  end

  describe 'PATCH #update' do
    it 'updates a packing_job' do
      # controller requires logged in user
      create(:Admin)
      user = build_stubbed(:TESTUSER)
      @controller = LoginController.new
      post "do_login", login: { username: user.user_name, password: user.pw}
      @controller = PackingJobsController.new

      @packing_job.working_dir = 'w_lorem_ipsum'
      post :update, id: @packing_job, packing_job: @packing_job.attributes, commit: 'Save'
      @packing_job.reload
      expect(@packing_job.working_dir).to eq('w_lorem_ipsum')
    end
  end
end
