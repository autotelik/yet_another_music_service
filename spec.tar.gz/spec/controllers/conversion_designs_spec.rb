require 'rails_helper'

describe ConversionDesignsController do
  before(:each) do
    # required by view
    session[:user_id] = create(:user).id
    prod_project = create(:proj_PRODUCTION)
    session[:project_id] = prod_project.id

    # required by controller
    allow_any_instance_of(ConversionDesignsController).to receive(:authorize){ true }
    
    @conversion_design = create(:conversion_design, project: prod_project)
    # all data types present in the yaml desgn must also exist within the database
    create(:dt_RDF, name: 'RDF')
    create(:dt_RDB, name: 'RDB')
    create(:dt_dHive, name: 'dHive')
  end

  describe 'GET #show' do
    it 'gets a specific conversion_design object' do
      get :show, id: @conversion_design
      expect(assigns(:conversion_design)).to eq(@conversion_design)
    end
  end

  # no index action
  # no new action
  # no create action
  # no update action
end
