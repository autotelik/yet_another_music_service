require 'rails_helper'

describe AssemblyHeadersController do
  before(:each) do
    # required by view
    session[:user_id] = create(:user).id
    session[:project_id] = create(:proj_PRODUCTION).id

    # required by controller
    allow_any_instance_of(AssemblyHeadersController).to receive(:authorize){ true }
    
    @assembly_header = create(:assembly_header)
  end

  describe 'GET #index' do
    it 'finds an assembly_header object' do
      get :index
      expect(assigns(:assembly_headers)).not_to be_empty
    end
    it 'searches and finds an assembly_header object' do
      get :index, search: @assembly_header.name
      expect(assigns(:assembly_headers)).not_to be_empty
    end
  end

  describe 'GET #show' do
    it 'gets a specific assembly_header object' do
      get :show, id: @assembly_header
      expect(assigns(:assembly_header)).to eq(@assembly_header)
    end
  end
  
  describe 'GET #new' do
    it 'builds a new assembly_header' do
      get :new
      expect(assigns(:assembly_header)).to be_a_new(AssemblyHeader)
    end
  end

  describe 'POST #create' do
    it 'creates an assembly_header' do
      diff_product = build_stubbed(:product)
      expect {
        post :create, assembly_header: attributes_for(:assembly_header, name: 'Second Assembly Header', volume_id: diff_product.volume_id)
      }.to change(AssemblyHeader, :count).by(1)
    end
    it 'creates an assembly_header with all attributes' do
      diff_product = build_stubbed(:product)
      expect {
        post :create, assembly_header: attributes_for(:assembly_header_maximal, name: 'Second Assembly Header', volume_id: diff_product.volume_id)
      }.to change(AssemblyHeader, :count).by(1)
    end
  end

  describe 'PATCH #update' do
    it 'updates a assembly_header' do
      @assembly_header.name = 'Lorem ipsum'
      post :update, id: @assembly_header, assembly_header: @assembly_header.attributes
      @assembly_header.reload
      expect(@assembly_header.name).to eq('Lorem ipsum')
    end
  end
end
