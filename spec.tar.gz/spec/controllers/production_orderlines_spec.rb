require 'rails_helper'

describe ProductionOrderlinesController do

  include_context "authorization"

  let(:ordertype) { create(:ordertype_maximal) }

  describe 'POST #create_automatic_order' do

    let(:conv_design) { create(:RDF2DH, conv_script: conv_script, project: proj_PRODUCTION) }
    # needed when checking if a production orderline is shippable
    let!(:rdb) { create(:data_type, name: 'RDB') }

    let(:conv_environment)  { create(:conversion_environment) }
    let(:conv_script)       { create(:conv_script) }
    let(:cvtool_bundle)     { create(:cvtool_bundle) }
    let(:conversiontool)    { create(:conversiontool) }
    let(:data_set)          { create(:data_set) }
    let(:product)           { create(:product) }
    let(:region)            { create(:r_Europe) }
    let(:ref_db)            { '/data/output/backoffice/prod/nds/mea/o_20170103-153347-248455-mea_tom_gmn_2016_09_20170103b_v5_0/ROOT.NDS' }

    let(:json_parameters) do
      {
        params_json: parameters.to_json
      }
    end

    let(:parameters) do
      {
        'handle_conversion_action': '',
        'production_orderline':
          {
            'product_id': product.id, volume_id: '', ship_yn: '0', 'parameter_set_id': '190', 'test_yn': '1'
          },
        data_set_id: '', data_set_group_id: '', ordertype: ordertype.id, 'order_name': 'NDS GMN NTG5E MEA TOM 2018/2019 (V6.0) AFRICA/MIDDLE EAST',
        'rdo_path': ref_db,
        'product_line_id': '40', 'check_automatic_conversion': '1', conversion_design_id: conv_design.id,
        'test_step': %w[0 1 2 3 4],
        'conversiontool': { '0': conversiontool.id, '1': conversiontool.id, '2': conversiontool.id, '3': conversiontool.id, '4': conversiontool.id },
        'cvtool_bundle': { '0': cvtool_bundle.id, '1': cvtool_bundle.id, '2': cvtool_bundle.id, '3': cvtool_bundle.id, '4': cvtool_bundle.id },
        'conv_script': { '0': '-1', '1': '-1', '2': '-1', '3': '-1', '4': conv_script.id },
        'conversion_environment': { '0': conv_environment.id, '1': conv_environment.id, '2': conv_environment.id, '3': conv_environment.id,
                                    '4': conv_environment.id },
        'tg_yn': %w[0 1 2 3 4],
        'tg_region': { '0': region.id, '1': region.id, '2': region.id, '3': region.id, '4': region.id },
        'tg_nrof_servers': { '0': '', '1': '', '2': '', '3': '', '4': '' },
        'tg_ref_db': { '0': :ref_db, '1': :ref_db,  '2': :ref_db, '3': :ref_db, '4': :ref_db },
        'tg_aknavi_db': { '0': :ref_db, '1': :ref_db, '2': :ref_db, '3': :ref_db, '4': :ref_db },
        'commit': 'Save'
      }
    end

    before(:each) do
      allow_any_instance_of(Conversion).to receive(:region) { region }
      allow_any_instance_of(Conversion).to receive(:create_dakota_scripts) { [] }
      allow_any_instance_of(Conversion).to receive(:dakota_input_lines) { 'Run script # AUTO-GENERATED DAKOTA SCRIPT' }
      allow_any_instance_of(Conversion).to receive(:similar_databases) { [] }

      allow_any_instance_of(ParsedDesign).to receive(:validate_design) { true }
      allow_any_instance_of(ParsedDesign).to receive(:check_data_types).with(any_args) { nil }

      allow(DataSet).to receive(:find_by_design_tag).with(any_args) { data_set }
      allow(ConfigParameter).to receive(:get).with(any_args) { '' }
    end

    it 'checks the creation of production orderline parsing option parameters correctly' do
      expect {
        post :create, parameters
      }.to change(ProductionOrderline, :count).by(0)

      expect(subject).to render_template('production_orderlines/check_automatic_order')

      checklog = assigns(:checklog)
      expect(checklog).to be_a Checklog
      expect(checklog.errors_or_warnings?).to eq(false)
    end

    it 'creates production orderline, parsing option parameters correctly' do
      delivery = double
      expect(delivery).to receive(:deliver_now).with(no_args)
      expect(ProductionOrderStatusChange).to receive(:build_mail).and_return(delivery)

      expect {
        post :create_automatic_order, json_parameters
      }.to change(ProductionOrder, :count).by(1).and change(ProductionOrderline, :count).by(2)

      pol = ProductionOrderline.last

      expect(response.status).to eq 302
      expect(response.location).to match(/\/production_orders\/\d+\/handle/)
      expect(pol.rdo_path).to eq ref_db
    end

  end

  describe 'POST #create' do

    it 'creates a new production order, orderline and conversion' do
      conversion = build(:conversion, status: Conversion::STATUS_ENTRY, data_files: '')
      post :create, { production_orderline: attributes_for(:production_orderline), conversion: conversion.attributes,
                      ordertype: ordertype.id }
      expect(ProductionOrder.count).to eq(1)
      expect(ProductionOrderline.count).to eq(1)
      expect(Conversion.count).to eq(1)
    end
  end
end
