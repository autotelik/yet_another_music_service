require 'rails_helper'

describe ProductLinesController do
  before(:each) do
    # required by view
    session[:user_id] = create(:user).id
    session[:project_id] = create(:proj_PRODUCTION).id

    # required by controller
    allow_any_instance_of(ProductLinesController).to receive(:authorize){ true }
    
    @product_line = create(:product_line)
  end

  describe 'GET #index' do
    it 'finds an product_line object' do
      get :index
      expect(assigns(:product_lines)).not_to be_empty
    end
    it 'searches and finds an product_line object' do
      get :index, search: @product_line.name
      expect(assigns(:product_lines)).not_to be_empty
    end
  end

  describe 'GET #show' do
    it 'gets a specific product_line object' do
      get :show, id: @product_line
      expect(assigns(:product_line)).to eq(@product_line)
    end
  end

  describe 'GET #new' do
    it 'builds a new product_line' do
      get :new
      expect(assigns(:product_line)).to be_a_new(ProductLine)
    end
  end

  describe 'POST #create' do
    it 'creates an product_line' do
      expect {
        post :create, product_line: attributes_for(:product_line, abbr: 'Ipsum')
      }.to change(ProductLine, :count).by(1)
    end
    it 'creates an product_line with all attributes' do
      expect {
        post :create, product_line: attributes_for(:product_line_maximal, abbr: 'Ipsum')
      }.to change(ProductLine, :count).by(1)
    end
  end

  describe 'PATCH #update' do
    it 'updates a product_line' do
      @product_line.name = 'Lorem'
      post :update, id: @product_line, product_line: @product_line.attributes
      @product_line.reload
      expect(@product_line.name).to eq('Lorem')
    end
  end
end
