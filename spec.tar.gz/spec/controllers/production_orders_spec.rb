require 'rails_helper'

describe ProductionOrdersController do

  let(:prod_project)      { create(:proj_PRODUCTION) }
  let(:production_order)  { create(:production_order, project: prod_project) }

  let!(:product_set) { create(:product_set) }

  before(:each) do
    # required by view
    session[:user_id] = create(:user).id
    session[:project_id] = prod_project.id

    # required by controller
    allow_any_instance_of(ProductionOrdersController).to receive(:authorize) { true }
  end

  describe 'GET #index' do
    it 'finds an production_order object' do
      production_order
      get :index
      expect(assigns(:production_orders)).not_to be_empty
    end
    it 'searches and finds an production_order object' do
      get :index, search: production_order.name
      expect(assigns(:production_orders)).not_to be_empty
    end
  end

  describe 'GET #show' do
    it 'gets a specific production_order object' do
      get :show, id: production_order
      expect(assigns(:production_order)).to eq(production_order)
    end
  end

  describe 'GET #new' do
    it 'builds a new production_order' do
      get :new, product_set_id: product_set.id
      expect(assigns(:production_order).model).to be_a_new(ProductionOrder)
    end
  end

  describe 'POST #create' do
    it 'creates a new production_order' do
      expect {
        post :create, production_order: attributes_for(:production_order).merge(
          product_set_id: product_set.id,
          ordertype_id: create(:ordertype).id
        )
      }.to change(ProductionOrder, :count).by(1)
    end
  end

  describe 'POST #clone' do
    it 'clones a specific production order object' do
      post :clone, id: production_order
      expect(assigns(:production_order).id).not_to eq(production_order.id)
      expect(assigns(:production_order).name).to eq("2nd order: #{production_order.name}")
    end
  end
end
