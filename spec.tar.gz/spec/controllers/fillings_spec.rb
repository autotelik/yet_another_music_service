require 'rails_helper'

describe FillingsController do
  before(:each) do
    # required by view
    session[:user_id] = create(:user).id
    session[:project_id] = create(:proj_PRODUCTION).id

    # required by controller
    allow_any_instance_of(FillingsController).to receive(:authorize){ true }
    
    @filling = create(:filling)
  end

  describe 'GET #index' do
    it 'finds an filling object' do
      get :index
      expect(assigns(:fillings)).not_to be_empty
    end
    it 'searches and finds an filling object' do
      get :index, search: @filling.name
      expect(assigns(:fillings)).not_to be_empty
    end
  end

  describe 'GET #show' do
    it 'gets a specific filling object' do
      get :show, id: @filling
      expect(assigns(:filling)).to eq(@filling)
    end
  end

  describe 'GET #new' do
    it 'builds a new filling' do
      get :new
      expect(assigns(:filling)).to be_a_new(Filling)
    end
  end

  describe 'POST #create' do
    it 'creates an filling' do
      expect {
        post :create, filling: attributes_for(:filling, name: 'Lorem')
      }.to change(Filling, :count).by(1)
    end
    it 'creates an filling with all attributes' do
      expect {
        post :create, filling: attributes_for(:filling_maximal, name: 'Lorem')
      }.to change(Filling, :count).by(1)
    end
  end

  describe 'PATCH #update' do
    it 'updates a filling' do
      @filling.active_yn = false
      post :update, id: @filling, filling: @filling.attributes
      @filling.reload
      expect(@filling.active_yn).to eq(false)
    end
  end
end
