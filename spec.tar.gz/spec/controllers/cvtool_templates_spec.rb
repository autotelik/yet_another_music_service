require 'rails_helper'

describe CvtoolTemplatesController do
  before(:each) do
    # required by view
    session[:user_id] = create(:user).id
    session[:project_id] = create(:proj_PRODUCTION).id

    # required by controller
    allow_any_instance_of(CvtoolTemplatesController).to receive(:authorize){ true }
    
    @cvtool_template = create(:cvtool_template)
  end

  describe 'GET #index' do
    it 'finds an cvtool_template object' do
      get :index
      expect(assigns(:cvtool_templates)).not_to be_empty
    end
    it 'searches and finds an cvtool_template object' do
      get :index, search: @cvtool_template.name
      expect(assigns(:cvtool_templates)).not_to be_empty
    end
  end

  describe 'GET #show' do
    it 'gets a specific cvtool_template object' do
      get :show, id: @cvtool_template
      expect(assigns(:cvtool_template)).to eq(@cvtool_template)
    end
  end

  describe 'GET #new' do
    it 'builds a new cvtool_template' do
      get :new
      expect(assigns(:cvtool_template)).to be_a_new(CvtoolTemplate)
    end
  end

  describe 'POST #create' do
    it 'creates an cvtool_template' do
      expect {
        post :create, cvtool_template: attributes_for(:cvtool_template, name: 'Lorem ipsum')
      }.to change(CvtoolTemplate, :count).by(1)
    end
    it 'creates an cvtool_template with all attributes' do
      expect {
        post :create, cvtool_template: attributes_for(:cvtool_template_maximal, name: 'Lorem ipsum')
      }.to change(CvtoolTemplate, :count).by(1)
    end
  end

  describe 'PATCH #update' do
    it 'updates a cvtool_template' do
      @cvtool_template.active_yn = false
      post :update, id: @cvtool_template, cvtool_template: @cvtool_template.attributes
      @cvtool_template.reload
      expect(@cvtool_template.active_yn).to eq(false)
    end
  end
end
