require 'rails_helper'

describe ParameterSetsController do
  before(:each) do
    # required by view
    session[:user_id] = create(:user).id
    prod_project = create(:proj_PRODUCTION)
    session[:project_id] = prod_project.id

    # required by controller
    allow_any_instance_of(ParameterSetsController).to receive(:authorize){ true }
    
    @parameter_set = create(:parameter_set, project: prod_project)
  end

  describe 'GET #index' do
    it 'finds an parameter_set object' do
      get :index
      expect(assigns(:parameter_sets)).not_to be_empty
    end
    it 'searches and finds an parameter_set object' do
      get :index, search: @parameter_set.name
      expect(assigns(:parameter_sets)).not_to be_empty
    end
  end

  describe 'GET #show' do
    it 'gets a specific parameter_set object' do
      get :show, id: @parameter_set
      expect(assigns(:parameter_set)).to eq(@parameter_set)
    end
  end

  describe 'GET #new' do
    it 'builds a new parameter_set' do
      get :new
      expect(assigns(:parameter_set)).to be_a_new(ParameterSet)
    end
  end

  describe 'POST #create' do
    it 'creates an parameter_set' do
      # controller requires logged in user
      create(:Admin)
      user = build_stubbed(:TESTUSER)
      @controller = LoginController.new
      post "do_login", login: { username: user.user_name, password: user.pw}
      @controller = ParameterSetsController.new

      expect {
        post :create, parameter_set: attributes_for(:parameter_set, name: 'Lorem')
      }.to change(ParameterSet, :count).by(1)
    end
    it 'creates an parameter_set with all attributes' do
      # controller requires logged in user
      create(:Admin)
      user = build_stubbed(:TESTUSER)
      @controller = LoginController.new
      post "do_login", login: { username: user.user_name, password: user.pw}
      @controller = ParameterSetsController.new

      expect {
        post :create, parameter_set: attributes_for(:parameter_set_maximal, name: 'Lorem')
      }.to change(ParameterSet, :count).by(1)
    end
  end

  describe 'PATCH #update' do
    it 'updates a parameter_set' do
      # controller requires logged in user
      create(:Admin)
      user = build_stubbed(:TESTUSER)
      @controller = LoginController.new
      post "do_login", login: { username: user.user_name, password: user.pw}
      @controller = ParameterSetsController.new

      @parameter_set.description = 'Lorem ipsum'
      post :update, id: @parameter_set, parameter_set: @parameter_set.attributes
      @parameter_set.reload
      expect(@parameter_set.description).to eq('Lorem ipsum')
    end
  end
end
