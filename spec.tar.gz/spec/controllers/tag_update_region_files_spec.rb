require 'rails_helper'

describe TagUpdateRegionFilesController do
  before(:each) do
    # required by view
    session[:user_id] = create(:user).id
    session[:project_id] = create(:proj_PRODUCTION).id

    # required by controller
    allow_any_instance_of(TagUpdateRegionFilesController).to receive(:authorize){ true }
    
    @tag_update_region_file = create(:tag_update_region_file)
  end

  describe 'GET #index' do
    it 'finds an tag_update_region_file object' do
      get :index
      expect(assigns(:tag_update_region_files)).not_to be_empty
    end
    it 'searches and finds a tag_update_region_file object' do
      get :index, search: @tag_update_region_file.path
      expect(assigns(:tag_update_region_files)).not_to be_empty
    end
  end

  describe 'GET #show' do
    it 'gets a specific tag_update_region_file object' do
      get :show, id: @tag_update_region_file
      expect(assigns(:tag_update_region_file)).to eq(@tag_update_region_file)
    end
  end
end
