require 'rails_helper'

describe UsersController do
  before(:each) do
    # required by view
    session[:user_id] = create(:user).id
    session[:project_id] = create(:proj_PRODUCTION).id

    # required by controller
    allow_any_instance_of(UsersController).to receive(:authorize){ true }
    
    @user = create(:TESTUSER)
  end

  describe 'GET #index' do
    it 'finds an user object' do
      get :index
      expect(assigns(:users)).not_to be_empty
    end
    it 'searches and finds an user object' do
      get :index, search: @user.email
      expect(assigns(:users)).not_to be_empty
    end
  end

  describe 'GET #show' do
    it 'gets a specific user object' do
      get :show, id: @user
      expect(assigns(:user)).to eq(@user)
    end
  end

  # no new action

  describe 'POST #create' do
    it 'creates an user' do
      expect {
        post :create, user: attributes_for(:user)
      }.to change(User, :count).by(1)
    end
    it 'creates an user with all attributes' do
      expect {
        post :create, user: attributes_for(:user_maximal)
      }.to change(User, :count).by(1)
    end
  end

  describe 'PATCH #update' do
    it 'updates a user' do
      @user.first_name = 'Lorem'
      post :update, id: @user, user: @user.attributes
      @user.reload
      expect(@user.first_name).to eq('Lorem')
    end
  end
end
