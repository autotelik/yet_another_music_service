require 'rails_helper'

describe SetToolHandoversController do

  let(:project_1)             { create(:proj_PRODUCTION) }
  let(:project_2)             { create(:proj_REGRESSION) }
  let(:user)                  { create(:user) }
  let(:product)               { create(:product, project: project_1) }
  let!(:set_tool_handover_1)  { create(:set_tool_handover, project: project_1) }
  let(:set_tool_handover_2)   { create(:set_tool_handover, project: project_2) }

  before(:each) do
    # required by view
    session[:user_id] = user.id
    session[:project_id] = project_1.id

    # required by controller
    allow_any_instance_of(SetToolHandoversController).to receive(:authorize) { true }
  end

  describe 'GET #show' do
    it 'gets a specific tool handover object' do
      get :show, id: set_tool_handover_1

      expect(assigns(:set_tool_handover)).to eq(set_tool_handover_1)
    end
  end

  describe 'GET #edit' do
    it 'pre fills parameter set if tool handover in default Project has one' do
      allow_any_instance_of(ApplicationController).to receive(:current_project) { project_2 }

      # stub sync_tool_handovers for now
      allow_any_instance_of(SetToolHandover).to receive(:sync_tool_handovers) { false }

      th_max = create(:tool_handover_maximal, set_tool_handover: set_tool_handover_1, handover: product)
      create(:tool_handover, set_tool_handover: set_tool_handover_2, handover: product)

      get :edit, id: set_tool_handover_2

      expect(assigns(:set_tool_handover).tool_handovers.first.parameter_set).to eq(th_max.parameter_set)
    end
  end

  describe 'PATCH #update' do
    it 'updates a tool handover' do
      pending('needs an actual conversion design which maps to the handover_compilation_steps, so awaiting the integration test')
      fail
    end
  end

  describe 'GET #tool_handover_options_list' do
    let!(:tool_handover_1) { create :tool_handover_data_set }
    let!(:tool_handover_2) { create :tool_handover_maximal }
    it 'should only respond to JSON' do
      expect do
        get :tool_handover_options_list, id: set_tool_handover_1, search_str: '', format: 'js'
      end.to raise_error(ActionController::UnknownFormat)
      expect do
        get :tool_handover_options_list, id: set_tool_handover_1, search_str: ''
      end.to raise_error(ActionController::UnknownFormat)
    end

    it 'should return a zero count and empty entries array when nothing found' do
      get :tool_handover_options_list, id: set_tool_handover_1, search_str: 'xxxx', format: 'json'

      expect(response.body).to_not be_empty
      expect(JSON.parse(response.body)['entries']).to match_array []
      expect(JSON.parse(response.body)['total_entries']).to eq 0
      expect(JSON.parse(response.body)['per_page']).to eq 100
    end

    it 'should return a 2 count and 2 entries when there are 2 tool handovers' do
      get :tool_handover_options_list, id: set_tool_handover_1, search_str: '', format: 'json'

      expect(ToolHandover.where.not(conversion_design_name_id: nil).count).to eq 2
      expect(JSON.parse(response.body)['total_entries']).to eq 2
      # noinspection RubyResolve
      expect(response.body).to include "\"id\":#{tool_handover_1.id}"
      # noinspection RubyResolve
      expect(response.body).to include "\"id\":#{tool_handover_2.id}"
    end

    it 'should return a 1 count and 1 entry where 1 tool handover already belongs to the set tool handover' do
      get :tool_handover_options_list, id: set_tool_handover_1, tool_handover_id: tool_handover_1.id, search_str: '', format: 'json'

      expect(JSON.parse(response.body)['total_entries']).to eq 1
      # noinspection RubyResolve
      expect(response.body).to include "\"id\":#{tool_handover_2.id}"
    end

    it 'should restricts the results based on the search_str' do
      get :tool_handover_options_list, id: set_tool_handover_1, tool_handover_id: 0, search_str: 'set data', format: 'json'

      expect(JSON.parse(response.body)['total_entries']).to eq 1
      # noinspection RubyResolve
      expect(response.body).to include "\"id\":#{tool_handover_1.id}"
    end
  end
end
