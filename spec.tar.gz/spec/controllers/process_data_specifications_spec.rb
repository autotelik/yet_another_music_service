require 'rails_helper'

describe ProcessDataSpecificationsController do
  before(:each) do
    # required by view
    session[:user_id] = create(:user).id
    session[:project_id] = create(:proj_PRODUCTION).id

    # required by controller
    allow_any_instance_of(ProcessDataSpecificationsController).to receive(:authorize){ true }
    
    @process_data_specification = create(:process_data_specification) 
  end

  describe 'GET #index' do
    it 'finds an process_data_specification object' do
      get :index
      expect(assigns(:process_data_specifications)).not_to be_empty
    end
    it 'searches and finds an process_data_specification object' do
      get :index, search: @process_data_specification.name
      expect(assigns(:process_data_specifications)).not_to be_empty
    end
  end

  describe 'GET #show' do
    it 'gets a specific process_data_specification object' do
      get :show, id: @process_data_specification
      expect(assigns(:process_data_specification)).to eq(@process_data_specification)
    end
  end

  describe 'GET #new' do
    it 'builds a new process_data_specification' do
      get :new
      expect(assigns(:process_data_specification)).to be_a_new(ProcessDataSpecification)
    end
  end

  describe 'POST #create' do
    it 'creates an process_data_specification' do
      expect {
        post :create, process_data_specification: attributes_for(:process_data_specification, name: 'Lorem')
      }.to change(ProcessDataSpecification, :count).by(1)
    end
    it 'creates an process_data_specification with all attributes' do
      expect {
        post :create, process_data_specification: attributes_for(:process_data_specification_maximal, name: 'Lorem')
      }.to change(ProcessDataSpecification, :count).by(1)
    end
  end

  describe 'PATCH #update' do
    it 'updates a process_data_specification' do
      @process_data_specification.description = 'Lorem ipsum'
      post :update, id: @process_data_specification, process_data_specification: @process_data_specification.attributes
      @process_data_specification.reload
      expect(@process_data_specification.description).to eq('Lorem ipsum')
    end
  end
end
