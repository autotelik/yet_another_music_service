require 'rails_helper'

describe AssetsController do
  before(:each) do
    # required by view
    session[:user_id] = create(:user).id
    session[:project_id] = create(:proj_PRODUCTION).id

    allow_any_instance_of(AssetsController).to receive(:authorize){ true }

    @asset = create(:asset)
  end

  describe 'GET #index' do
    it 'finds an asset object' do
      get :index
      expect(assigns(:assets)).not_to be_empty
    end
    it 'searches and finds an asset object' do
      get :index, search: @asset.ref_id
      expect(assigns(:assets)).not_to be_empty
    end
  end

  describe 'GET #show' do
    it 'gets a specific asset object' do
      get :show, id: @asset
      expect(assigns(:asset)).to eq(@asset)
    end
  end

  # no new action
  # no create action

  describe 'PATCH #update' do
    it 'updates a asset' do
      @asset.requested_by = 'Lorem ipsum dolor'
      post :update, id: @asset, asset: @asset.attributes
      @asset.reload
      expect(@asset.requested_by).to eq('Lorem ipsum dolor')
    end
  end
end
