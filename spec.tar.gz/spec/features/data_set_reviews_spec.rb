require 'rails_helper'


feature 'DataSet Reviews' do

  include_context "authorization" do
    let(:controllers) { [DataSetsController, DataSetReviewsController, MainController] }
  end

  include_context 'cancan_prerequisites'

  include_context 'feature_view_prerequisites'

  include_context "stub_data_set_os_interaction"

  let(:main_menu) {  WebMis::MainMenuPage.new }

  context 'When I Go to Menu --> Reception ' do

    before(:each) do
      visit root_path
    end

    scenario 'Then a menu item to Review DataSets displayed' do
      main_menu.expect_reception_menu_item(/Data set Review\z/)
    end

    context 'And I click Data set Review' do
      scenario 'Then the reviews index page is displayed' do
        main_menu.click_reception_item(/Data set Review\z/)

        expect(page).to have_css("div#index_data_set_reviews")
      end
    end
  end

  context 'When I visit the DataSet Reviews page ' do
    let(:data_sets) { create_list(:data_set, 3, status: DataSet::STATUS_REVIEW) }
    let!(:data_set) { data_sets[0] }

    before(:each) do
      visit data_set_reviews_path
    end

    scenario 'Then a link to the handle method of each DataSet is available' do
      expect(page).to have_css("div#index div.row.index_model_row div.col-md-1.index_model_item a")

      expect(page).to have_selector(:css, "a[href=\"/webmis/data_sets/#{data_set.id}/handle\"]")
    end

    context 'And click a link to handle a DataSet' do

      before do
        find(:css, "a[href=\"/webmis/data_sets/#{data_set.id}/handle\"]").click
      end

      scenario 'Then I should be on the handle DataSet page with next button enabled' do
        expect(page).to have_text('Handle data set')

        expect(page).to have_css("a.btn.btn-default i.icon-step-forward.glyphicon.glyphicon-step-forward")
        expect(page).to have_selector(:css, "a[href=\"/webmis/data_sets/#{data_sets[1].id}/handle\"]")
      end

      context 'And I click next ' do
        scenario 'Then prev and next buttons should be enabled' do
          find(:css, "a[href=\"/webmis/data_sets/#{data_sets[1].id}/handle\"]").click

          expect(page).to have_selector(:css, "a[href=\"/webmis/data_sets/#{data_sets[0].id}/handle\"]")
          expect(page).to have_selector(:css, "a[href=\"/webmis/data_sets/#{data_sets[2].id}/handle\"]")
          expect(page).to have_css("a.btn.btn-default i.icon-step-backward.glyphicon.glyphicon-step-backward")
          expect(page).to have_css("a.btn.btn-default i.icon-step-forward.glyphicon.glyphicon-step-forward")
        end
      end

      context 'And I should be able to click the Review button', js: true do

        before do
          find(:css, "button#requestReviewBtn.btn.btn-default").click
        end

        scenario 'Then request modal should pop up' do
          expect(page).to have_content("Request review")
        end

        scenario 'And Then I should be able to click the Send Review button', js: true do
          find(:css, "#btnSendReviewRequest").click
          expect(page).to have_css('.bg-warning span#reviewerName', visible: false)
        end

      end
    end

  end
end