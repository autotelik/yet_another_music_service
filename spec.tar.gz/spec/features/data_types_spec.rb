require 'rails_helper'

feature 'User creates a data type' do

  # General stubs for controllers e.g authorization and setting associated  page sessions
  include_context "authorization" do
    let(:controllers) { [DataTypesController] }
  end

  include_context 'feature_view_prerequisites'

  scenario 'user creates data type through normal flow' do
    visit new_data_type_path

    fill_in 'data_type_name', with: 'Test Data Type'
    click_button 'Save'

    expect(page).to have_content('Test Data Type')
  end
end
