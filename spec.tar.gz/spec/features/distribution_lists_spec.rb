require 'rails_helper'

feature 'Distribution Lists' do

  include_context "authorization" do
    let(:controllers) { [DistributionListsController] }
  end

  describe("ACTIVE Lists") do
    context 'When I Go to Handle on an Active List ' do

      let!(:dlist) { create(:distribution_list, status: DistributionList::STATUS_ACTIVE) }

      before(:each) do
        visit handle_distribution_list_path(dlist)
      end

      scenario 'Then the Disable button should be enabled' do
        expect(page).to have_content('Disable')
      end

      scenario 'And the Create bulk shipment button should navigate to Outbound Orders' do
        click_on("Create bulk shipment")
        expect(page).to have_css('form#new_outbound_order.new_outbound_order')
      end

      scenario 'And the Create e-mail buttons should be enabled' do
        expect(page).to have_link('Create e-mail body', class: 'btn btn-default')
      end

    end
  end

  describe("INACTIVE Lists") do
    context 'When I Go to Handle on an Inactive List ' do

      let!(:distribution_list) { create(:distribution_list, status: DistributionList::STATUS_INACTIVE) }

      before(:each) do
        visit handle_distribution_list_path(distribution_list)
      end

      scenario 'Then the Activate button should be enabled' do
        expect(page).to have_content('Enable')
      end

      scenario 'And the Create bulk shipment and Create e-mail buttons should be disabled' do
        expect(page).to have_link('Create bulk shipment', class: 'disabled')
        expect(page).to have_link('Create e-mail body', class: 'disabled')
      end
    end

  end

end