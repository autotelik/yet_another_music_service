require 'rails_helper'

shared_examples_for 'production_order' do |object_type|
  it "runs through the production order flow for #{object_type}" do
    visit "/webmis/#{object_type.pluralize}"

    if object_type == 'product_set'
      click_link 'New production order'

      check 'production_order_allow_production'
      check 'production_order_allow_shipment'

      click_button 'Save'

      click_link 'Handle conversion'
    else
      click_link 'New automatic conversion'
    end

    # inside the production orderline form
    check 'check_automatic_conversion'

    click_button 'Save'

    # middle step - checking production order; for debugging purpose, uncomment next command:
    # save_and_open_page
    if object_type == 'product_set'
      expect {
        click_button 'Create Production order'
      }.to change(Conversion, :count).by(2)
    else
      expect {
        click_button 'Create Production order'
      }.to change(ProductionOrder, :count).by(1).and change(Conversion, :count).by(2)
    end

    # general checks
    po = ProductionOrder.first
    expect(po.status).to eq(ProductionOrder::STATUS_PRODUCTION)
    expect(ProductionOrderline.all.size).to eq(2)

    # RDF to RDB
    first_pol = ProductionOrderline.first
    expect(first_pol.status).to eq(ProductionOrderline::STATUS_HANDLE_CONVERSION)
    expect(first_pol.conversions.size).to eq(1)
    first_conv = first_pol.chosen_conversion
    expect(first_conv.status).to eq(Conversion::STATUS_CONVERSION)
    expect(first_conv.conversion_jobs.size).to eq(0)
    expect(first_conv.conversion_databases.size).to eq(0)
    expect(first_conv.wait_for_intermediate?).to eq(nil)
    # RDB to dHive
    second_pol = ProductionOrderline.last
    expect(second_pol.status).to eq(ProductionOrderline::STATUS_HANDLE_CONVERSION)
    expect(second_pol.conversions.size).to eq(1)
    second_conv = second_pol.chosen_conversion
    expect(second_conv.status).to eq(Conversion::STATUS_CONVERSION)
    expect(second_conv.conversion_jobs.size).to eq(0)
    expect(second_conv.conversion_databases.size).to eq(0)
    expect(second_conv.wait_for_intermediate?).to eq(true)

    po.perform
    [first_pol, second_pol, first_conv, second_conv].each(&:reload)

    expect(first_pol.checklog.errors_or_warnings?).to eq(false)
    expect(first_pol.status).to eq(ProductionOrderline::STATUS_HANDLE_CONVERSION)
    expect(second_pol.checklog.errors_or_warnings?).to eq(false)
    expect(second_pol.status).to eq(ProductionOrderline::STATUS_HANDLE_CONVERSION)
    expect(first_conv.status).to eq(Conversion::STATUS_CONVERSION)
    expect(first_conv.conversion_databases.size).to eq(0)
    expect(first_conv.conversion_jobs.size).to eq(1)
    expect(second_conv.status).to eq(Conversion::STATUS_CONVERSION)
    first_cj = first_conv.conversion_jobs.first
    expect(first_cj.status).to eq(Job::STATUS_QUEUED)
    expect(first_cj.file_system_status).to eq(Job::FILE_SYSTEM_STATUS_FREE)
    # sanity check; cannot start conversion jobs with no servers available
    server.active = false
    server.save

    ProductionOrder.schedule
    first_cj.reload
    expect(first_cj.status).to eq(Job::STATUS_HOLD)
    server.active = true
    server.save

    # necessary stubs
    allow_any_instance_of(ConversionJob).to receive(:create_dakota_scripts)
    allow_any_instance_of(ConversionJob).to receive(:execute_dakota_script).and_return(9999)
    allow_any_instance_of(ConversionJob).to receive(:get_dir_size).and_return(9999)
    allow_any_instance_of(ConversionJob).to receive(:store_dakota_dryrun_log)
    allow_any_instance_of(ConversionJob).to receive(:read_dakota_done_file).and_return(0)
    allow_any_instance_of(ConversionJob).to receive(:tail_log).and_return('lorem')
    allow_any_instance_of(ConversionJob).to receive(:move_scripts)
    allow_any_instance_of(ConversionJob).to receive(:set_permissions_outcome_directory)
    allow_any_instance_of(ConversionJob).to receive(:o_dir_size).and_return(9999)
    output_db_extensions = %w[.db .dh.sq3]
    allow_any_instance_of(ConversionJob).to receive(:o_dir_contents).and_return(output_db_extensions)
    # TODO: investigate how to stub rsyncmove, but keep the postmove(adding a wrapper around rsync)
    # workaround is to simulate outcome by manually running postmove on the job
    allow_any_instance_of(ConversionJob).to receive(:rsyncmove)

    allow(FileSystemUtil).to receive(:file_size).and_return(9999)
    allow(FileSystemUtil).to receive(:file_write_safe).and_return(true)
    allow(FileSystemUtil).to receive(:chmod_r_safe).and_return(true)

    allow_any_instance_of(ValidationJob).to receive(:move_scripts)
    allow_any_instance_of(ValidationJob).to receive(:dakota_job_finished?).and_return(true)
    allow_any_instance_of(ValidationJob).to receive(:read_dakota_done_file).and_return(0)
    allow_any_instance_of(ValidationJob).to receive(:tail_log).and_return('lorem')
    allow_any_instance_of(ValidationJob).to receive(:which_path).and_return('lorem/ipsum')
    allow_any_instance_of(ValidationJob).to receive(:log_lines).and_return(['lorem'])
    allow_any_instance_of(ValidationJob).to receive(:move_scripts)
    allow_any_instance_of(ValidationJob).to receive(:clear_working_dir)

    # general workflow, for one conversion job
    allow_any_instance_of(ConversionJob).to receive(:dakota_job_finished?).and_return(false)
    ProductionOrder.schedule
    [first_pol, first_conv, first_cj].each(&:reload)
    expect(first_pol.checklog.errors_or_warnings?).to eq(false)
    expect(first_conv.status).to eq(Conversion::STATUS_CONVERSION)
    expect(first_cj.status).to eq(Job::STATUS_PROCESSING)
    expect(first_cj.file_system_status).to eq(Job::FILE_SYSTEM_STATUS_ON_SERVER)

    first_pol.perform
    first_pol.reload
    expect(first_pol.bp_message).to eq('Total 1, Processing 1')

    # conclusions of first production orderline
    allow_any_instance_of(ConversionJob).to receive(:dakota_job_finished?).and_return(true)
    ProductionOrder.schedule
    first_cj.post_move
    [first_pol, first_conv, first_cj].each(&:reload)
    expect(first_pol.status).to eq(ProductionOrderline::STATUS_FINISHED)
    expect(first_pol.checklog.errors_or_warnings?).to eq(false)
    expect(first_conv.status).to eq(Conversion::STATUS_FINISHED)
    expect(first_cj.status).to eq(Job::STATUS_FINISHED)
    expect(first_cj.conversion_databases.size).to eq(1)
    first_cd = first_cj.conversion_databases.first
    expect(first_cd.status).to eq(ConversionDatabase::STATUS_NOT_VALIDATED)
    expect(first_cd.file_system_status).to eq(ConversionDatabase::FILE_SYSTEM_STATUS_AVAILABLE)
    expect(second_conv.status).to eq(Conversion::STATUS_CONVERSION)
    expect(second_conv.conversion_jobs.size).to eq(0)

    second_pol.perform
    second_conv.reload
    expect(second_conv.conversion_jobs.size).to eq(2)
    first_cj = second_conv.conversion_jobs.first
    second_cj = second_conv.conversion_jobs.last
    expect(second_conv.status).to eq(Conversion::STATUS_CONVERSION)
    expect(first_cj.status).to eq(Job::STATUS_QUEUED)
    expect(first_cj.file_system_status).to eq(Job::FILE_SYSTEM_STATUS_FREE)
    expect(second_cj.status).to eq(Job::STATUS_QUEUED)
    expect(second_cj.file_system_status).to eq(Job::FILE_SYSTEM_STATUS_FREE)

    # general workflow, for two conversion jobs
    allow_any_instance_of(ConversionJob).to receive(:dakota_job_finished?).and_return(false)
    ProductionOrder.schedule
    [second_pol, second_conv, first_cj, second_cj].each(&:reload)
    expect(second_pol.checklog.errors_or_warnings?).to eq(false)
    expect(second_conv.status).to eq(Conversion::STATUS_CONVERSION)
    expect(first_cj.status).to eq(Job::STATUS_PROCESSING)
    expect(first_cj.file_system_status).to eq(Job::FILE_SYSTEM_STATUS_ON_SERVER)
    expect(second_cj.status).to eq(Job::STATUS_PROCESSING)
    expect(second_cj.file_system_status).to eq(Job::FILE_SYSTEM_STATUS_ON_SERVER)

    second_pol.perform
    second_pol.reload
    expect(second_pol.bp_message).to eq('Total 2, Processing 2')

    # exception to the general workflow, created conversion databases are part of automatic validation
    # validation jobs are also created
    allow_any_instance_of(ConversionJob).to receive(:dakota_job_finished?).and_return(true)
    ProductionOrder.schedule
    first_cj.post_move
    second_cj.post_move
    [second_pol, second_conv, first_cj, second_cj].each(&:reload)
    expect(second_conv.status).to eq(Conversion::STATUS_CONVERSION)
    expect(first_cj.status).to eq(Job::STATUS_FINISHED)
    expect(first_cj.conversion_databases.size).to eq(1)
    first_cd = first_cj.conversion_databases.first
    expect(second_cj.status).to eq(Job::STATUS_FINISHED)
    expect(second_cj.conversion_databases.size).to eq(1)
    second_cd = second_cj.conversion_databases.first
    expect(first_cd.status).to eq(ConversionDatabase::STATUS_VALIDATING)
    expect(first_cd.file_system_status).to eq(ConversionDatabase::FILE_SYSTEM_STATUS_AVAILABLE)
    expect(first_cd.validation_jobs.size).to eq(1)
    expect(second_cd.status).to eq(ConversionDatabase::STATUS_VALIDATING)
    expect(second_cd.file_system_status).to eq(ConversionDatabase::FILE_SYSTEM_STATUS_AVAILABLE)
    expect(second_cd.validation_jobs.size).to eq(1)
    first_vj = first_cd.validation_jobs.first
    expect(first_vj.status).to eq(Job::STATUS_QUEUED)
    second_vj = second_cd.validation_jobs.first
    expect(second_vj.status).to eq(Job::STATUS_QUEUED)

    second_pol.perform
    second_pol.reload
    expect(second_pol.bp_message).to eq('Total 2, Finished 2, Validating 2 (Queued 2)')

    allow_any_instance_of(ValidationJob).to receive(:dakota_job_finished?).and_return(false)
    ProductionOrder.schedule
    [second_pol, first_vj, second_vj].each(&:reload)
    expect(second_pol.checklog.errors_or_warnings?).to eq(false)
    expect(first_vj.status).to eq(Job::STATUS_PROCESSING)
    expect(first_vj.file_system_status).to eq(Job::FILE_SYSTEM_STATUS_ON_SERVER)
    expect(second_vj.status).to eq(Job::STATUS_PROCESSING)
    expect(second_vj.file_system_status).to eq(Job::FILE_SYSTEM_STATUS_ON_SERVER)

    # conclusions of second production orderline
    allow_any_instance_of(ValidationJob).to receive(:dakota_job_finished?).and_return(true)
    ProductionOrder.schedule
    [po, second_pol, second_conv, first_vj, second_vj].each(&:reload)
    expect(po.status).to eq(ProductionOrder::STATUS_FINISHED)
    expect(second_pol.checklog.errors_or_warnings?).to eq(false)
    expect(second_pol.status).to eq(ProductionOrderline::STATUS_FINISHED)
    expect(second_conv.status).to eq(Conversion::STATUS_FINISHED)
    expect(first_vj.status).to eq(Job::STATUS_FINISHED)
    expect(second_vj.status).to eq(Job::STATUS_FINISHED)
    first_cd = first_vj.conversion_database
    expect(first_cd.status).to eq(ConversionDatabase::STATUS_ACCEPTED)
    expect(first_cd.file_system_status).to eq(ConversionDatabase::FILE_SYSTEM_STATUS_AVAILABLE)
    second_cd = second_vj.conversion_database
    expect(second_cd.status).to eq(ConversionDatabase::STATUS_ACCEPTED)
    expect(second_cd.file_system_status).to eq(ConversionDatabase::FILE_SYSTEM_STATUS_AVAILABLE)
  end
end