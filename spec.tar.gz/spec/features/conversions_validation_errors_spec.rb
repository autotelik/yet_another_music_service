require 'rails_helper'

feature 'User interaction with databases that have unhandled validation errors' do

  # General stubs for controllers e.g authorization and setting associated  page sessions
  include_context "authorization" do
    let(:controllers) { [ConversionsController] }
  end
  include_context 'feature_view_prerequisites'

  let(:c)         { create(:conversion, project: proj_PRODUCTION) }
  let!(:cd)       { create(:conversion_database, :with_validation_error, conversion: c, status: ConversionDatabase::STATUS_HAS_ERRORS) }

  before(:each) do
    visit show_validation_errors_conversions_path
  end

  scenario 'user investigates validation outcome', js: true do
    ticket_nr = 'PROC-7527'

    # Click on the question mark icon
    find("#investigateBtn_#{c.id}_1").click

    fill_in 'handle_ticket_nr', with: ticket_nr

    click_button('Register')

    ve = cd.validation_errors.first
    expect(ve.ticket_nr).to eq(ticket_nr)
    expect(page).to have_content(ve.name)
  end
end
