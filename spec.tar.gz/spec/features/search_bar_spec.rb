require 'rails_helper'

feature 'The Layout contains Navigation Menu and optional Search Bar' do

  # General stubs for controllers e.g authorization and setting associated  page sessions
  include_context "authorization" do
    let(:controllers) { [MainController, ProductionOrdersController] }
  end

  include_context 'feature_view_prerequisites'

  before do
    visit root_path
  end

  context 'When I Go to the WebMIS Home Page' do
    context 'Then I should see the Top Level menus' do
      scenario 'But no search bar should be displayed' do
        expect(page).to have_css("#production+ul.dropdown-menu")
        expect(page).to have_css("#reception+ul.dropdown-menu > li > a", text: "Data sets")
        expect(page).to have_css("#conversion+ul.dropdown-menu")

        expect(page).to_not have_link("New", :href => "/webmis/data_sets/new")
      end
    end
  end

  context 'When I Click the Production dropdown' do
    scenario 'Then I should see sub menu' do
      expect(page).to have_css("#production+ul.dropdown-menu > li > a", text: "Product sets")
      expect(page).to have_css("#production+ul.dropdown-menu > li > a", text: "Products")
      expect(page).to have_css("#production+ul.dropdown-menu > li > a", text: "New product set")
      expect(page).to have_css("#production+ul.dropdown-menu > li > a", text: "Tagged Failed jobs report")
    end

    context 'And when I click Production Orders ' do
      scenario 'Then the search bar and number of active Production Orders should be displayed' do
        find("#production+ul.dropdown-menu > li > a", text: "Production orders").click

        expect(page).to have_css("a", :text => /\d+ Production orders/)

        expect(page).to have_css("form.navbar-form.navbar-left div.input-group input#search")
      end
    end
  end

  context 'When I Click the Reception dropdown' do
    scenario 'Then I should see sub menu' do
      expect(page).to have_css("ul.dropdown-menu > li > a", text: "Data types")
      expect(page).to have_css("ul.dropdown-menu > li > a", text: "Fillings")
    end
  end

end
