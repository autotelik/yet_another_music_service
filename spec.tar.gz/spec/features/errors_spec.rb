require 'rails_helper'

feature 'Errors are displayed correctly' do

  # General stubs for controllers e.g authorization and setting associated  page sessions
  include_context "authorization" do
    let(:controllers) { [DataSetsController, MainController] }
  end

  include_context 'feature_view_prerequisites'

  let(:data_set_page) { WebMis::DataSetPageObject.new }

  let(:exception)     { RuntimeError.new("A Terrible Error Occured") }

  before do

    # Cannot find way to stub env directly or add headers to env
    # This does not seem to work :
    #   page.set_rack_session('REQUEST_URI' => "http://example.com")
    #
    allow_any_instance_of(ActionDispatch::ExceptionWrapper).to receive_message_chain(:env, '[]') { "Blah" }

    allow_any_instance_of(ActionDispatch::ExceptionWrapper).to receive_message_chain(:env, '[]')
                                                                 .with('action_dispatch.exception') { exception }

    allow_any_instance_of(ActionDispatch::ExceptionWrapper).to receive_message_chain(:env, '[]')
                                                                 .with('action_dispatch.request.request_parameters') { {a: 'b'} }

    allow_any_instance_of(ActionDispatch::ExceptionWrapper).to receive_message_chain(:env, '[]')
                                                                 .with('REQUEST_URI') { "http://example.com" }
  end

  context 'When I Go to a WebMIS Page' do
    context 'And I click a Link that causes an Internal Server Error' do
      scenario 'Then our WebMIS 404 Error page is displayed.' do

        visit root_path

        # Setup the DataSets index link to always fail
        allow_any_instance_of(DataSetsController).to receive(:index) { raise exception }

        # Click the link to the DataSets index action
        data_set_page.navigate_to_index_action

        # should route to errors#internal_server_error
        within(:xpath, '//h4[@style="color:red"]') do
          expect(page).to have_content("Internal server error")
        end
      end
    end

    context 'And I try to run an internal method that raises a WebMis Exception' do
      scenario 'Then our WebMIS 404 Error page is displayed.' do

        visit root_path

        # Setup the DataSets index action to fail
        allow_any_instance_of(DataSetsController).to receive(:column_search_query) do
          raise WebMis::DirectoryEmpty, "RSpec feature test raising a WebMis specific exception"
        end

        # Click the link to the DataSets index action which internally calls column_search_query
        data_set_page.navigate_to_index_action

        # should route to errors#internal_server_error
        within(:xpath, '//h4[@style="color:red"]') do
          expect(page).to have_content("Internal server error")
        end
      end
    end

    context 'And try to visit a non existing page' do
      scenario 'Then our WebMIS 404 Error page is displayed.' do

        visit root_path

        visit '/foo'

        within(:xpath, '//h4[@style="color:red"]') do
          expect(page).to have_content("The page you were looking for does not exist")
        end
      end
    end

  end

end
