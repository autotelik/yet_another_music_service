require 'rails_helper'

# NOTES
#
# These specs were derived from WebMIS_Test_Scenario_20170912.ods - TC2
#
#   1. How to debug display options from a select dropdown
#
#       find('data_set_group_id').text
#
#   2. Debugging element content
#
#       puts find("//div#region_module/div.span").text
#       puts find("//div#region_module/div.span").value
#
#       puts find("//div#region_module/div.span")['innerHTML'].inspect
#
#       puts find("//div#region_module/div.span").native.inspect
#       puts find("//div#region_module/div.span").native.children.inspect
#
feature 'User creates a New Data Set definition' do

  include_context "authorization" do
    let(:controllers) { [DataSetsController, MainController] }
  end

  include_context 'cancan_prerequisites'

  include_context "feature_view_prerequisites"

  before(:each) do
    # Testing DataSet creation - just show the New button regardless of params
    allow_any_instance_of(SearchBarPresenter).to receive(:show_new_button?) { true }
  end

  context 'When I Go to Menu → Reception → Data sets' do
    scenario 'Then the Data sets page should be displayed' do
      visit root_path

      # Drop down nav bar - so look for li by content which causes
      # Capybara to automatically wait for it to appear
      find("#reception+ul.dropdown-menu > li > a", text: "Data sets").click

      expect(page).to have_link("New", :href => "/webmis/data_sets/new")
    end
  end

  context 'When I Click on button New (besides the search bar)' do
    scenario "Then the New Data set page should be displayed" do
      visit data_sets_path

      # Alternative using CSS :
      #   find("span.input-group-btn > a", text: "New").click
      click_link("New", :href => "/webmis/data_sets/new")

      expect(page).to have_content "Draft"
      expect(page).to have_css("form#new_data_set.new_data_set")
    end


    context 'Add New Data set' do
      let(:data_set_page) { WebMis::DataSetPageObject.new }

      before do
        # Populate database with all the data required to book a new DataSet
        data_set_page.populate_associated

        # Release dropdown is either populated from params or populated dynamically when Company selected
        # over ride to setup population from params
        allow_any_instance_of(DataSetPresenter).to receive(:render_release_select?) { true }

        release = data_set_page.release

        # In options_for_select format e.g : [["69693", "2013_Q2"]]   ..... [["Dollar", "$"], ["Kroner", "DKK"]]
        # ummm this is weird, id and name seem to get reversed somewhere, hack it for now
        allow_any_instance_of(DataSetPresenter).to receive(:company_abbr_data_releases) { [[release.name, release.id]] }

        allow_any_instance_of(DataSet).to receive(:generate_directory) { scratch_path }
      end

      context 'When I Fill in the new DataSet form with all required fields' do
        context 'And I click the Save data set button' do
          scenario 'Then No errors are displayed - The DataSet is created' do
            visit new_data_set_path

            data_set_page.fill_page

            data_set_page.commit_form_expect_new_object(klass: DataSet)

            expect(page).to have_content('Show data set')
          end
        end
      end

      context 'When I click on Coverage Area screwdriver icon' do
        scenario 'Then a Pop-up Regional parameter settings should be displayed', js: true do
          visit new_data_set_path

          sleep 1   # this test fails at random, due to data not being selected

          data_set_page.fill_page(js: true)

          # Click on the screwdriver icon
          within(:xpath, "//div[@id='region_module']") do
            find('button.glyphicon-wrench', text: nil).click
          end

          # Popup - Regional Parameter
          # 	Add parameter and click the arrow pointing below
          within(:xpath, data_set_page.regional_param_modal_xpath) do
            expect(page).to have_content("Regional parameter settings")

            # Just choose first Regional Param option from the dropdown
            all("select#parameters", visible: false).first.select_option

            data_set_page.close_regional_param_modal
          end

          # Try to esnure, JS had time to get all data cos otherwise this test can fail
          # to save DataSet at random, due to missing data (validation failures)
          select data_set_page.release.name, from: :data_set_data_release_id, visible: false

          data_set_page.commit_form_expect_new_object(klass: DataSet)
        end
      end


      context 'When I Click the handle Button' do
        context 'And then I Click the Set to Production button' do
          before do
            visit new_data_set_path

            data_set_page.fill_page

            data_set_page.commit_form_expect_new_object(klass: DataSet)
          end

          scenario "Then Button dataset definition is greyed out and the Create reception button is available." do
            data_set = DataSet.last

            # No link text to find, check HREF associated with the Handle icon exists and click it
            expect(page).to have_selector(:css, "a[href=\"/webmis/data_sets/#{data_set.id}/handle\"]")

            find(:css, "a[href=\"/webmis/data_sets/#{data_set.id}/handle\"]").click

            expect(page).to have_content('Handle data set')

            # Set to Production
            expect(page).to have_selector(:css, "a[href=\"/webmis/data_sets/#{data_set.id}/change_status?status=#{DataSet::STATUS_PRODUCTION}\"]")

            find("#status_production").click

            data_set.reload

            pending "See Manish - are we missing a step ? since we cannot go from Status DRAFT to PRODUCTION"
            expect(data_set.status).to eq DataSet::STATUS_PRODUCTION
          end

          context "And then I Click the Create reception button" do
            scenario "A new page is opened and no error is being displayed and data is already filled in" do
              pending "Waiting on previous scenario - how to go from Status DRAFT to PRODUCTION"

              expect(page).to have_content('Reception date')
              #
              #       Reception date: <Current date>
              #       Usability: Production Data
              #       Medium: FTP
              #       Supplier HERE Data release: 2011Q3
              #       Coverage: Middle East Africa
              #       Data type: RDF Relational Data File
              #
              #   10	Fill in the following:
              #     Remarks: Test scenario WebMIS TC1
              #     Storage location: /data/input/prod/rdf/wld/wld/her_2011_Q3/20141208/data/
              #     And click the Save and send Mail button
              #     The user will be redirected to the Receptions index page.
              #     Verify that the created reception is in the list
              #     and that an email with subject 'WebMIS DEVELOPMENT TEST => Reception notification RDF HER PROD 2011Q3 MEA <current date> <receptionID>' is sent
              #
              #   11	Go to Menu - Reception - Data sets			Page Data sets is being displayed
              #   12	Click the action button of the, in step 1.3 created data set and click on data set files.			The page Edit data set files is being displayed
              #   13	Click button "New element".			A pop-up "Add new element to data set" appears.
              #   14	Fill in the following from left to right:
              #     Related Reception Id: reception id of the,
              #     in step 1.9 created reception P
              #     rocess data specification: RDF Leave split by value empty and click the submit button
              #     The pop-up disappears and an element on the page Edit data set files is added with the following content:
              #     Related Reception Id: reception id of the, in step 1.9 created reception
              #     Process data specification: RDF Directory /data/proces/backofficestaging/rdf/mea/her/11_q3/rdf/
              #     The directory itself is created on the filesystem with permissions drwxrwxr-x.
            end
          end
        end
      end
    end
  end
end
