require 'rails_helper'

# Scenario to create New Reception
feature 'Reception pages' do

  include_context "authorization" do
    let(:controllers) { [ReceptionsController, MainController] }
  end

  include_context 'cancan_prerequisites'

  include_context "feature_view_prerequisites"

  let(:main_menu_nav) {  WebMis::MainMenuPage.new }

  context 'When I Go to Menu --> Reception --> New reception' do
    scenario 'Then the New Reception page is displayed' do
      visit root_path

      main_menu_nav.click_reception_item(/New reception\z/)

      expect(page).to have_css("form#new_reception.new_reception")
    end
  end

  context 'When I fill in the new Reception form with all required fields' do

    let(:reception_page)  { WebMis::ReceptionPage.new }

    context 'And I click the Save button' do
      scenario 'Reception is successfully created And Reception page is displayed with the Reception in Status - INPROGRESS', js: true do

        company_abbr = create(:company_abbr, company_name: 'HERE', ms_abbr_3: 'HER')
        release      = create(:dr_2013Q2, production: true, active: true)
        reception    = create(:dt_RDF, name: 'RDF')
        region       = create(:region, region_code: 'RE1', name: 'Region1')

        visit new_reception_path

        select "HERE",         from: :reception_company_abbr_id, visible: false
        select release.name,   from: :reception_data_release_id, visible: false
        select reception.name, from: :reception_data_type_id,    visible: false
        select region.name,    from: :reception_area_id,         visible: false

        fill_in "reception_supplier_ref", with: "VMAM14404WVM000QAADY",   visible: false
        fill_in "reception_remarks", with: "MEA RDF version 2014Q4 RevA", visible: false

        reception_page.commit_form_expect_new_object(klass: Reception)

        # Expect A message is being displayed on the top right corner of the screen:
        expect(page).to have_content('Reception was successfully created.')

      end
    end
  end
end
