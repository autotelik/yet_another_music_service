require 'rails_helper'

feature 'Data Set Index Page is Filterable and Searchable' do

  # Manages login etc and setting associated  page sessions
  include_context "authorization" do
    let(:controllers) { [DataSetsController] }
  end

  include_context 'feature_view_prerequisites'

  let(:data_set_page) { WebMis::DataSetPageObject.new }

  # Suite of DataSet's in different states and different levels of construction
  let!(:data_set)                 { create(:ds_DUMMY) }

  context 'When I visit the DataSets Index page' do
    before do
      # Populate database with enough data to populate the search boxes
      data_set_page.populate_associated

      visit data_sets_path
    end

    context 'And I enter RDF in the Type search field' do
      scenario "Then the display is filtered on the Type and only DataSets with type RDF are shown", js: true do

        #data_set_page.show

        pending 'javascript errors occur -  Capybara::Poltergeist::JavascriptError:'
        # column_search_field[exact-data_types-id]
        # select "RDF",    from: 'column_select_field[exact-data_types-id]'#, visible: false
        select "RDF",    from: 'column_select_field_exact-data_types-id', visible: false
        raise "TODO: finish this test case, there are no more javascript errors"
      end
    end
  end

end
