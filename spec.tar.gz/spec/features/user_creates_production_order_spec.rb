require 'rails_helper'

feature 'User creates a production order' do

  # Stubs authorization
  include_context "authorization" do
    let(:controllers) {
      [ConversionsController, DataSetsController, DataSetGroupsController,
       ProductionOrdersController, ProductionOrderlinesController, ProductsController, ProductSetsController,
       MainController]
    }
  end

  include_context 'cancan_prerequisites'

  include_context "feature_view_prerequisites"

  # objects and factories to create all underlying data needed for ProductOrder creation
  include_context 'create_production_order_prerequisites'

  # cleanup of generated files/folders by dakota
  after(:all) do
    # before(:all) is ran outside of transactions, so data created here will bleed into other specs
    # manually destroy variables
    Project.destroy_all
  end

  context 'user creates production order through a data set' do
    it_behaves_like 'production_order', 'data_set'
  end

  context 'user creates production order through a data set group' do
    it_behaves_like 'production_order', 'data_set_group'
  end

  context 'user creates production order through a product' do
    it_behaves_like 'production_order', 'product'
  end

  context 'user creates production order through a product set' do
    it_behaves_like 'production_order', 'product_set'
  end
end
