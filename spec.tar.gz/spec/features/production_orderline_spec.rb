require 'rails_helper'

feature 'User edits a Production Orderline' do

  include_context "authorization"   do
    let(:controllers) { [ProductionOrderlinesController] }
  end

  include_context 'feature_view_prerequisites'

  let(:conversion)        { create(:conversion) }
  let(:conversion_design) { create(:conversion_design_single_step) }
  let(:tool_handover)     { create(:tool_handover_data_set) }

  let(:production_orderline)  { create(:production_orderline_full) }

  let(:test_grid_fields) {
    {
      # visibility driven by whether its an automatic order or not
      production_orderline_test_grid_priority: false,
      production_orderline_test_grid_nrof_servers: false,
      rdo_path_ref_db: false,
      rdo_path_aknavi_db: false
    }
  }

  let(:test_grid_selects) {
    %w[
      production_orderline_test_grid_region_id
    ]
  }

  context 'Auto Conversion panel' do

    before(:each) do
      # For the Auto panel to appear we need
      #
      # The order can't have any conversions
      # A tool handover with a conversion design
      #
      allow_any_instance_of(ParsedDesign).to          receive(:validate_design)                                     { true }
      allow_any_instance_of(ParsedDesignBase).to      receive(:shippable?)                                          { true }
      allow_any_instance_of(ParsedDesignStep_V1).to receive_message_chain(:output_data_type, :test_grid_support_yn) { false }
      allow_any_instance_of(ProductionOrderline).to            receive(:conversions)                                { [] }
      allow_any_instance_of(ProductionOrderline).to            receive(:current_tool_handover)                      { tool_handover }
      allow_any_instance_of(ProductionOrderlinesController).to receive(:fill_params_from_set_tool_handover)         { true }

      production_orderline.update(tg_yn: false)
    end

    scenario 'User cannot edit Test Grid info when tg_yn flag is false', js: true do
      visit edit_production_orderline_path(production_orderline, {conversion_id: conversion.id})

      find('#check_automatic_conversion').set(false)

      test_grid_fields.each { |field, visability| expect(page).to have_field(field, disabled: true, visible: visability) }

      test_grid_selects.each { |field| expect(page).to have_select(field, disabled: true, visible: false) }
    end


    scenario 'User clicks Test checkbox against a Step and appropriate panel with StepDetails appears', js: true do
      # ensure the details panels actually appear
      allow_any_instance_of(ParsedDesignStep_V1).to receive_message_chain(:output_data_type, :test_grid_support_yn) { true }

      visit edit_production_orderline_path(production_orderline, {conversion_id: conversion.id})

      expect(page).to have_selector('#step_test_grid_row_1', visible: false)

      find('#test_grid_step_check_box_1').set(true)

      expect(page).to have_selector('#step_test_grid_row_1', visible: true)
    end

    scenario 'User can deselect AutomaticConversion and then Conversion and Test Grid panels appears', js: true do
      visit edit_production_orderline_path(production_orderline, {conversion_id: conversion.id})

      # N.B Use have_selector since it waits for JS (to completely populate page) but have_field does not
      expect(page).to have_selector('#test_grid', visible: false)

      find('#check_automatic_conversion').set(false)

      expect(page).to have_selector('#test_grid', visible: false)
    end

  end

  context 'Manual Conversion panel' do

    before(:each) do
      production_orderline.update(tg_yn: true)

      visit edit_production_orderline_path(production_orderline)
    end

    scenario 'User can edit (disabled false) Test Grid elements when tg_yn flag is true', js: true do
      test_grid_fields.each { |field, visability| expect(page).to have_field(field, disabled: false, visible: visability) }

      test_grid_selects.each { |field| expect(page).to have_select(field, disabled: false, visible: false) }
    end
  end

end
