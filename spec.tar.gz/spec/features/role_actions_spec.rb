require 'rails_helper'

feature 'User navigates to Configuration->Role-Action matrix' do

  include_context "authorization" do
    let(:controllers) { [RoleActionsController] }
  end

  let!(:role_action) { create(:role_action) }

  scenario 'Then the Index Matrix page should be displayed' do
    visit role_actions_path
    expect(page).to have_css("input#column_search_field_role_actions-action_name")
  end

  context "And User selects a Role to edit" do
    scenario 'Then the Matrix page should be displayed' do
      visit edit_role_action_path(role_action)
      expect(page).to have_css("form.edit_role_action")
    end
  end
end
