require "rails_helper"

RSpec.describe VolumeIdValidator do

  module MadeUpProduct
    extend ActiveSupport::Concern
    include ActiveModel::Model
    include ActiveModel::Validations
    attr_accessor :volume_id
  end

  class ValidationPlainProduct
    include MadeUpProduct
    validates :volume_id, "volume_id": { allow_blank: true }
  end

  context "the volume_id is valid without glob or whitespace chars" do
    ['MP181-1651_SEA', 'MP181-1651_SEA.CLONE', 'MP173-1613-SIDE-MASTERING-AUTOMATIC'].each do |vid|
      subject { ValidationPlainProduct.new(volume_id: vid) }
      it { is_expected.to be_valid }
    end
  end

  context "the volume_id is invalid with any glob related chars such as *([ newline or whitespace" do
    [
      "MP1-1651_SEA\n",
     "MP2-1651_SEA\n ",
     "MP3-1651_SEA ",
     "[[\"MP092-0001\"]]",
     "MP172-1453a Fa (Test 2017Q2)",
     "Regtest: BMW_EEV_EUR (VEN) 2018Q1",
     "Regtest: BMW_EEV_EUR (VEN) 2018Q1\n"
    ].each do |vid|
      context("subject") do
        subject { ValidationPlainProduct.new(volume_id: vid) }
        it { is_expected.to be_invalid }
      end
    end
  end

  context "when the strip option applied volume_id is valid with whitespace and/or newline" do

    class ValidationStripProduct
      include MadeUpProduct
      validates :volume_id, "volume_id": { strip_first: true, allow_blank: true }
    end

    ["MP1-1651_SEA\n","MP2-1651_SEA\n ", "MP3-1651_SEA "].each do |vid|
      context("subject") do
        subject { ValidationStripProduct.new(volume_id:  vid) }
        it "strips volume id before validating and leaves it trimmed" do
          expect(subject).to be_valid
          expect(subject.volume_id).to eq vid.strip
        end
      end
    end
  end

end
