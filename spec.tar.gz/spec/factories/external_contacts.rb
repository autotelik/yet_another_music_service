FactoryBot.define do
  factory :external_contact do
    salutation                  'Mr.'
    first_name                  'Test'
    last_name                   'Contact'
    primary_address_street      'Luchthavenweg 34'
    primary_address_postalcode  '5657 EB'
    primary_address_city        'Eindhoven'
    primary_address_country     'Nederland'
    status                      100
    association :company,       factory: :MAPSCAPE
  end

  factory :external_contact_maximal, parent: :external_contact do
    title                       'lorem'
    primary_address_state       'lorem'
    phone_work                  'lorem'
    phone_mobile                'lorem'
    email                       'lorem'
    external_id                 9
  end
  
  factory :EC_EWOUT, parent: :external_contact do
    first_name                  'Robert'
    last_name                   'de Ruyter'
    primary_address_street      'Henri Wijnmalenweg 5b'
    primary_address_postalcode  '5657 EP'
    email                       'robert.deruyter@mapscape.eu'
    external_id                 'f22e9f62-bb3d-74cf-b7b4-4f67653d0582'
  end

  factory :EC_ROBERT, parent: :external_contact do
    first_name                  'Ewout'
    last_name                   'Voogt'
    primary_address_street      'Henri Wijnmalenweg 5b'
    primary_address_postalcode  '5657 EP'
    email                       'ewout.voogt@mapscape.eu'
    external_id                 '929b056e-e206-2f98-52b9-4f676507a46b'
  end

  factory :EC_JOS, parent: :external_contact do
    first_name                  'Jos'
    last_name                   'de Callafon'
    email                       'jos.decallafon@mapscape.eu'
  end

  factory :EC_MAURICE, parent: :external_contact do
    first_name                  'Maurice'
    last_name                   'Schekkerman'
    email                       'maurice.schekkerman@mapscape.eu'
  end
end
