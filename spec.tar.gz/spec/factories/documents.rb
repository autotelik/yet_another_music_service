FactoryBot.define do
  factory :document do
    filename        'Lorem_Ipsum.pdf'
  end

  factory :document_maximal, parent: :document do
    content_type            'lorem'
    description             'ipsum'
    binary_data             99
    version                 0
    category               'dolor'
    sync_filepath          'lorem'
    last_modified_timestamp Time.now
    checksum                'dolor'
    user_id                 0
    document_object_id      99
    production_order_id     99
    package_directory       'lorem'
    mandatory_yn            true
    production_orderline_id 99
  end
end
