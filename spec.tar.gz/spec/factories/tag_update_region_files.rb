FactoryBot.define do
  factory :tag_update_region_file do
    path                  {
      scratch_file(File.join("#{TagUpdateRegionFile::TAG_UPDATE_REGION_FILE_SUBDIR}", "#{TagUpdateRegionFile::TAG_UPDATE_REGION_FILE_DIR_PREFIX}_20180501", 'gen_nds_eur', 'TAG_UPDATE_REGION_FILE__eur_2018_q2.txt'))
    }
    md5sum                '196375c535cc8093df75300ba0814ad3'
    active_yn             true
  end

  factory :tag_update_region_file_inactive, parent: :tag_update_region_file do
    path                  {
      scratch_file(File.join("#{TagUpdateRegionFile::TAG_UPDATE_REGION_FILE_SUBDIR}", "#{TagUpdateRegionFile::TAG_UPDATE_REGION_FILE_DIR_PREFIX}_20180501", 'gen_nds_eur', 'TAG_UPDATE_REGION_FILE__eur_2016_q1.txt'))
    }
    active_yn             false
  end

  factory :tag_update_region_file_nonexisting, parent: :tag_update_region_file do
    path                  {
      scratch_file(File.join("#{TagUpdateRegionFile::TAG_UPDATE_REGION_FILE_SUBDIR}", "#{TagUpdateRegionFile::TAG_UPDATE_REGION_FILE_DIR_PREFIX}_20180501", 'gen_nds_eur', 'TAG_UPDATE_REGION_FILE__eur_1999_q1.txt'))
    }
    md5sum                '12341234123412341234123412341234'
    active_yn             false
  end
end
