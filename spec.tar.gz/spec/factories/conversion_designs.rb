FactoryBot.define do
  factory :conversion_design do
    name                  'RDF2DH'
    active_yn             true
    remarks               'Test'
    association :project, factory: :proj_PRODUCTION
    yaml_str                "product_line : generic\noutput_format: dHive\nschema_version: 1\nsteps:\n  - step: RDF2RDB (HER)  SubScript\n    step_file: /data/id/release/CVENV/ConvScripts_20170411/designs/steps/generic/RDF2RDB.yaml\n    parameters:\n      - SubScriptPath fe/her\n    input_data:\n      - &RDF\n        data_type : RDF\n    output_data:\n      - &RDB\n        data_type : RDB\n        filling   : RDF\n    subscript     : RDF\n  - step: RDB2DH (RDF)  SubScript\n    step_file: /data/id/release/CVENV/ConvScripts_20170411/designs/steps/generic/RDB2DH.yaml\n    parameters:\n      - SubScriptPath fe/her\n    input_data:\n      - *RDB\n    output_data:\n      - &DH_core\n        data_type : dHive\n        filling   : RDB\n    subscript     : RDB\n"
  end

  factory :conversion_design_single_step, parent: :conversion_design do
    sequence(:name)       { |n| "RDF#{n}" }
    yaml_str              "# WebMIS Development test
                          map_region   : 'tst1'
                          product_line : generic
                          output_format: dHive
                          steps:
                            - step: RDF2RDB (HER)  SubScript
                              step_file: /data/id/release/CVENV/ConvScripts_20170118_1/designs/steps/generic/RDF2RDB.yaml
                              parameters:
                                - SubScriptPath fe/her
                              input_data:
                                - &RDF
                                  id        : RDF
                                  data_type : RDF
                              output_data:
                                - &RDB
                                  id        : RDB
                                  data_type : RDB
                                  filling   : RDF
                              subscript     : RDF
                          "
  end

  factory :RDF2DH, parent: :conversion_design do
    sync_path             '/volumes2/_projects/conversion_designs/DESIGN_RDF2DH.yaml'
    association :conv_script, factory: :conv_script
  end

  factory :RDF2DH_ADDITIONAL, parent: :conversion_design do
    sync_path               '/volumes2/_projects/conversion_designs/regression/DESIGN_RDF2DH.yaml'
    association :project,   factory: :proj_REGRESSION
  end

  factory :RDF2DH_radars, parent: :conversion_design do
    name                  'FE RDF2DH'
    active_yn             true
    remarks               'Radars production order request test API' #FakerLorem
    association :project, factory: :proj_PRODUCTION
    sync_path             '/data/id/release/CVENV/ConvScripts_20170118_1/designs/DESIGN_FE_RDF2DH.yaml'
    yaml_str              "# WebMIS Development test
                          map_region   : 'tst1'
                          product_line : generic
                          output_format: dHive
                          steps:
                            - step: RDF2RDB (HER)  SubScript
                              step_file: /data/id/release/CVENV/ConvScripts_20170118_1/designs/steps/generic/RDF2RDB.yaml
                              parameters:
                                - SubScriptPath fe/her
                              input_data:
                                - &RDF
                                  id        : RDF
                                  data_type : RDF
                              output_data:
                                - &RDB
                                  id        : RDB
                                  data_type : RDB
                                  filling   : RDF
                              subscript     : RDF
                            - step: RDB2DH (RDF)  SubScript
                              step_file: /data/id/release/CVENV/ConvScripts_20170118_1/designs/steps/generic/RDB2DH.yaml
                              parameters:
                                - SubScriptPath fe/her
                              input_data:
                                - *RDB
                              output_data:
                                - &DH_core
                                  id        : DH_core
                                  data_type : dHive
                                  filling   : RDB
                              subscript     : RDB
                          "
  end
end
