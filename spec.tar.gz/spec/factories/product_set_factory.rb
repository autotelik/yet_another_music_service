FactoryBot.define do
  factory :product_set, aliases: [:ps_GMN] do
    sequence(:code)             { |n| "GMN_D55H_HRQ2_EUR_#{n}" }
    name                        'Navis-AMS Daimler NTG5.5H - 2013 Q2 (E42) NL - HERE - NDS'
    status                      ProductSet::STATUS_DRAFT
    association :product_category, factory: :product_category
    association :product_line, factory: :product_line
    association :project, factory: :proj_PRODUCTION
  end

  factory :product_set_maximal, parent: :product_set do
    name                      'Navis-AMS Daimler NTG5.5H - 2013 Q2 (E42) NL - HERE - NDS'
    status                    ProductSet::STATUS_PROPOSAL
    remarks                   'ipsum'
  end
end
