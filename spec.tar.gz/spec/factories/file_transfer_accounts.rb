FactoryBot.define do
  factory :file_transfer_account do
    transfer_type                 'SFTP'
    address                       'localhost'
    active                        true
    association :company_abbr
    remarks                       'WebMIS test account'
  end

  factory :FTP_TEST, parent: :file_transfer_account do
    user_name                     'regtest'
  end

  factory :FTP_DUMMY, parent: :file_transfer_account do
    user_name                     'user1'
  end
end
