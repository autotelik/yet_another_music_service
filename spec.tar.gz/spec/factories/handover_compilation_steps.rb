FactoryBot.define do
  factory :handover_compilation_step do
    association :tool_handover, factory: :tool_handover
    seq 0
  end

  factory :handover_compilation_step_1, parent: :handover_compilation_step do
    association :tool_handover, factory: :tool_handover_maximal
    name   'Ipsum'
    seq    1
  end

  factory :handover_compilation_step_2, parent: :handover_compilation_step do
    association :tool_handover, factory: :tool_handover_maximal
    name   'Lorem'
    seq    2
  end

  factory :handover_rdf2rdb, parent: :handover_compilation_step do
    association :tool_handover, factory: :tool_handover_data_set
    name 'RDF2RDB'
    seq 1
  end

  factory :handover_rdb2dh, parent: :handover_compilation_step do
    association :tool_handover, factory: :tool_handover_data_set
    name 'RDB2DH'
    seq 2
    association :cvtool_bundle, factory: :cvtool_bundle
    association :conversiontool, factory: :api_conversiontool
    association :conv_script, factory: :conv_script
    association :conversion_environment, factory: :conversion_environment
  end
end
