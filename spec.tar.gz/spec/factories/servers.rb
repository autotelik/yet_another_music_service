FactoryBot.define do
  factory :server, aliases: [:LOCALHOST] do
    server_id               'localhost'
    server_remark           'RSPEC Server Remark'
    active                  true
    diskcapacity            '999999999999999'
    processor               'Proc1'
    down                    false
    max_jobs                8
    scheduling_allowed_yn   true
    cores                   8
    memory                  8096
    association :owned_by,  factory: :proj_REGRESSION

    trait :with_project_server do
      transient do
        other_projects []
      end

      after(:create) do |s, evaluator|
        s.projects << s.owned_by
        evaluator.other_projects.each do |p|
          s.projects << p
        end
        s.save!
      end
    end

    trait :with_conversion_job_type do
      transient do
        allowed_yn true
      end
      after(:create) do |s, evaluator|
        s.job_types << create(:jt_conversion, server: s, allowed_yn: evaluator.allowed_yn)
      end
    end

    trait :with_validation_job_type do
      after(:create) do |s|
        s.job_types << create(:jt_validation, server: s)
      end
    end

    trait :with_all_job_types do
      after(:create) do |s|
        s.job_types << create(:jt_conversion, server: s)
        s.job_types << create(:jt_validation, server: s)
        s.job_types << create(:jt_packing, server: s)
        s.job_types << create(:jt_shipping, server: s)
        s.job_types << create(:jt_test_request, server: s)
      end
    end

    trait :with_running_jobs do
      after(:create) do |s|
        create(:cj_running2, run_server: s.server_id, project: s.owned_by)
        create(:cj_running3, run_server: s.server_id, status: Job::STATUS_MANUAL, project: create(:proj_TEST))
      end
    end

    trait :with_failed_jobs do
      after(:create) do |s|
        create(:cj_failed1, run_server: s.server_id, project: s.owned_by)
        create(:cj_failed2, run_server: s.server_id, project: s.owned_by)
        create(:cj_failed3, run_server: s.server_id, project: create(:proj_TEST))
      end
    end
  end

  factory :server_dummy, parent: :server do
    server_id               'server_dummy'
    active                  true
    diskcapacity            0
    max_jobs                0
    cores                   0
    memory                  0
  end

  factory :server_small, parent: :server do
    server_id               'server_small'
    active                  true
    diskcapacity            1
    max_jobs                1
    cores                   1
    memory                  1
  end

  factory :server_empty, parent: :server do
    server_id               'server_empty'
    active                  true
    diskcapacity            11
    max_jobs                2
    cores                   5
    memory                  5
  end

  factory :server_inactive, parent: :server_empty do
    server_id               'server_inactive'
    active                  false
  end

  factory :server_down, parent: :server_empty do
    server_id               'server_down'
    down                    true
  end

  factory :server_full, parent: :server_empty do
    server_id               'server_full'
  end

  factory :server_partly_full, parent: :server_empty do
    server_id               'server_partly_full'
    diskcapacity            12
    max_jobs                3
    cores                   6
    memory                  6
  end
end
