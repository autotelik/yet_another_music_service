FactoryBot.define do
  factory :distribution_list, aliases: [:dl_WEBMIS_TEST] do
    name                                  'WebMIS_TEST'
    association :product_category,        factory: :pc_NDS_DML
    association :shipping_specification,  factory: :shipping_specification
    status                                DistributionList::STATUS_ACTIVE
  end

  factory :distribution_list_maximal, parent: :distribution_list do
    remarks                               'Distribution list used by the Rails automatic test cases.'
  end
end
