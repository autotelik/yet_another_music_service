FactoryBot.define do
  factory :job
end
