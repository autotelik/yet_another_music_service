FactoryBot.define do
  factory :product do
    name                                          'Garmin NTG55H EUR'
    sequence(:volume_id)                          { |n| "MP000-000#{n}" }
    remarks                                       'Test conversion'
    association :region,                          factory: :region
    association :project,                         factory: :proj_PRODUCTION
    status                                        Product::STATUS_APPROVED
  end

  factory :product_maximal, parent: :product do
    detailed_coverage                             'ipsum'
  end

  factory :product2, parent: :product do
    name                                         'Garmin NTG55H EUR2'
  end

  factory :product3, parent: :product do
    name                                         'Garmin NTG55H EUR3'
  end

  factory :product4, parent: :product do
    name                                         'Garmin NTG55H EUR4'
  end

  factory :product5, parent: :product do
    name                                         'Garmin NTG55H EUR5'
  end

end
