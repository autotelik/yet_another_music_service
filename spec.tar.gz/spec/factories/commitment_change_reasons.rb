FactoryBot.define do
  factory :commitment_change_reason do
    reason            'C00 Initial Value'
    commitment_type   ProductionOrder::COMMITMENT_BASELINE
  end

  factory :DEFAULT_BASELINE, aliases: [:commitment_change_reason_maximal], parent: :commitment_change_reason do
    description       'This one should only be used for the initial Baseline Commitment.'
  end
  
  factory :DEFAULT_MODIFIED, parent: :commitment_change_reason do
    description       'This one should only be used for the initial Modified Commitment.'
    commitment_type    ProductionOrder::COMMITMENT_MODIFIED
  end
end
