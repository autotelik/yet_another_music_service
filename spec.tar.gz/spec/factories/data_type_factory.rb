FactoryBot.define do
  factory :data_type do
    sequence(:name)                 {|n| "default#{n}"}
    active_yn                       true
    intermediate_yn                 false
    automatic_validation_yn         false
    status                          'approved'
    schedule_manual                 true
    schedule_cores                  1
    schedule_memory_base            0
    schedule_memory_times_input     0
    schedule_diskspace_base         0
    schedule_diskspace_times_input  1
    schedule_allow_virtual          true
    schedule_exclusive              false

    trait :with_fillings do
      after(:create) do |dt|
        dt.data_type_fillings << [build(:dtf_TEST_FILLING), build(:dtf_POI_NOKF)]
      end
    end

    trait :with_process_data_specification do
      after(:create) do |dt|
        dt.process_data_specifications << create(:process_data_specification)
      end
    end
  end

  factory :data_type_maximal, parent: :data_type do
    description                     'lorem'
    updated_by                      'ipsum'
    version                         9
    comment                         'dolor'
    validation_executable           'lorem'
    identification                  'ipsum$'
    automatic_shipment_yn       true
    test_grid_support_yn            true
    test_yn                         true
  end

  factory :dt_RDF, parent: :data_type do
    sequence(:name)                 {|n| "RDF#{n}"}
    description                     'Relational Data File'
  end

  factory :dt_3DC, parent: :data_type do
    sequence(:name)                 {|n| "3DC#{n}"}
    description                     '3D content'
    status                          'draft'
  end

  factory :dt_3LM, parent: :data_type do
    sequence(:name)                 {|n| "3LM#{n}"}
    description                     '3D Landmarks'
    comment                         'approve action'
  end

  factory :dt_TMC, parent: :data_type do
    sequence(:name)                 {|n| "TMC#{n}"}
    description                     'Traffic Table'
    version                         1
  end

  factory :dt_POI, parent: :data_type do
    sequence(:name)                 {|n| "POI#{n}"}
    description                     'Data with POI'
    comment                         "''approve'' action"
  end

  factory :dt_JVS, parent: :data_type do
    sequence(:name)                 {|n| "JVS#{n}"}
    description                     'Junction Views'
    comment                         "''approve'' action"
  end

  factory :dt_VAR, parent: :data_type do
    sequence(:name)                 {|n| "VAR#{n}"}
    description                     'Various'
    status                          'draft'
  end

  factory :dt_NDS, parent: :data_type do
    sequence(:name)                 {|n| "NDS#{n}"}
    description                     'Navigation Data Standard'
    identification                  'ROOT.NDS$'
  end

  factory :dt_RDB, parent: :data_type do
    sequence(:name)                 {|n| "RDB#{n}"}
    description                     'Loaded RDF Database'
    intermediate_yn                 true
    comment                         "''approve'' action"
    identification                  '.db$'
  end

  factory :dt_RDO, parent: :data_type do
    sequence(:name)                 {|n| "rdo#{n}"}
    description                     'ReDo Database'
    version                         1
    schedule_manual                 false
    identification                  '.RDO.sq3$'
  end

  factory :dt_SHP, parent: :data_type do
    sequence(:name)                 {|n| "SHP#{n}"}
    description                     'Shape'
    version                         1
    status                          'draft'
  end

  factory :dt_dHive, parent: :data_type do
    sequence(:name)                 {|n| "dHive#{n}"}
    description                     'Data Hive'
    intermediate_yn                 true
    automatic_validation_yn         true
    version                         1
    schedule_manual                 false
    validation_executable           'ValidateDH'
    identification                  '.dh.sq3$'
  end

  factory :dt_DOC, parent: :data_type do
    sequence(:name)                 {|n| "DOC#{n}"}
    description                     'Documentation'
    intermediate_yn                 true
    automatic_validation_yn         true
    version                         1
    schedule_manual                 false
    validation_executable           'Default'
  end
end
