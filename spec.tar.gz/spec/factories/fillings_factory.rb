FactoryBot.define do
  factory :filling, aliases: [:filling_maximal] do
    name          'Default'
    active_yn     true
    removed_yn    false
  end

  factory :f_TEST_FILLING, parent: :filling do
    name          'filling_front_end_rdf2dh_her'
  end

  factory :f_LANDMARKS, parent: :filling do
    name          '3D Landmarks'
  end

  factory :f_JVS, parent: :filling do
    name          'Junction views'
  end

  factory :f_NOKF, parent: :filling do
    name          'NOKFuel'
  end

  factory :f_BIC, parent: :filling do
    name          'Brand Icons'
  end

  factory :f_EJVS, parent: :filling do
    name          'Enhanced Junction Views'
  end

  factory :f_ACM, parent: :filling do
    name          'Advanced City Models'
  end
end
