FactoryBot.define do
  factory :cvtool_bundle_release, aliases: [:DEV_DEV_TOOL] do
    active_yn                     true
    association :cvtool_bundle,   factory: :cb_DEV
    association :conversiontool,  factory: :DEV_TOOL
  end
end
