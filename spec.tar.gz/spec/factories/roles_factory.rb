FactoryBot.define do
  factory :role, aliases: [:Minimal]

  factory :ConversionEngineer, aliases: [:role_maximal], parent: :role do
    title   'conversion engineer'
  end

  factory :ReadOnly, parent: :role do
    title   'read only'
  end

  factory :Admin, parent: :role do
    title   'admin'
  end

  factory :Approver, parent: :role do
    title   'approver'
  end
end
