FactoryBot.define do
  factory :product_category, aliases: [:pc_NDS_DML, :product_category_maximal] do
    sequence(:abbreviation)           { |n| "NDS_DML_#{n}" }
    description                       'NDS Daimler'
    active                            true
    pds_import_file                   '/tmp'
    attach_pds_in_rn_yn               true
  end
end
