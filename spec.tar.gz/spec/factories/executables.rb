# TODO: validate executables' input/output/parameters as e_RDF2RDB
# TODO: find a way to export/import executables
# TODO: executable_versions

FactoryBot.define do
  factory :executable do
    schedule_manual                   false
    schedule_allow_virtual            true
    schedule_exclusive                false
    customer_visibility               true
    is_improvement_process            true
    input                             '[]'
    output                            '[]'
    version                           1
  end

  factory :executable_maximal, parent: :executable do
    name                              'lorem'
    description                       'lorem'
    parameters                        'lorem'
    rules                             'lorem'
    source_data_def_type              'lorem'
    updated_by                        'lorem'
    metalogic                         'lorem'
    subprocs                          'lorem'
    bug_tracker_id                    'lorem'
    comment                           'lorem'
    status                            0
    schedule_cores                    0
    schedule_memory_base              0
    schedule_memory_times_input       0
    schedule_diskspace_base           0
    schedule_diskspace_times_input    0
  end

  factory :e_RDF2RDB, parent: :executable do
    name                              'RDF2RDB'
    description                       'Loads RDF into sqlite. The result is an RDB database. Note that some
      postprocesses are already applied to the RDB database. An example is the generation
      of new government codes.'
    input                             "[{\"datatype\":\"RDF\",\"mandatory\":\"false\",\"script_tag\":\"\",\"id\":null,\"version\":11}]"
    output                            "[{\"identification\":\".db\",\"datatype\":\"RDB\",\"id\":null,\"version\":7}]"
    parameters                        "{\"parameters\":[{\"name\":\"ContinueWithoutVoiceMap\",\"description\":\"Purpose: to enable loading of RDF data without voice map data present.\\u003cbr\\u003e\\u003c/br\\u003e\\nHere RDF data can be delivered with or without voice map data.\\u003cbr\\u003e\\u003c/br\\u003e\\nPer default the compiler will force a crash if no voice map data is present and report the absence.\\u003cbr\\u003e\\u003c/br\\u003e\\nWith this parameter set to 1, the conversion will continue. The absence of voice map data will be reported in the 'Stat file'.\\u003cbr\\u003e\\u003c/br\\u003e\\n\\u003cbr\\u003e\\u003c/br\\u003e\\nNote:\\u003cbr\\u003e\\u003c/br\\u003e\\nThere are two different situations of absent voice maps:\\u003cbr\\u003e\\u003c/br\\u003e\\n- The voice map files are really absent.\\u003cbr\\u003e\\u003c/br\\u003e\\n- The voice map files are present, but empty.\\u003cbr\\u003e\\u003c/br\\u003e\\nThis difference will be marked in the report.\",\"datatype\":\"numeric\",\"default_value\":\"0\",\"mandatory\":false,\"allocate\":false,\"allocate_tags\":\"\",\"source_allocate_tags\":\"\",\"visibility\":null},{\"name\":\"RDBCompressionMethod\",\"description\":\"Defines the compression method for the RDB database\",\"datatype\":\"string\",\"default_value\":\"-\",\"mandatory\":false,\"allocate\":false,\"allocate_tags\":\"\",\"source_allocate_tags\":\"\",\"visibility\":null},{\"name\":\"RdfAdditionalRegions\",\"description\":\"Parameter to define additional regions file.\\u003cbr\\u003e\\u003c/br\\u003e\\n\\u003cbr\\u003e\\u003c/br\\u003e\\nContent additional region file:\\u003cbr\\u003e\\u003c/br\\u003e\\nOne Region per line. Each line consists of\\u003cbr\\u003e\\u003c/br\\u003e\\nRegionTag\\u003cbr\\u003e\\u003c/br\\u003e\\nDescription\\u003cbr\\u003e\\u003c/br\\u003e\\nAdmin_Place_Id from RDF\\u003cbr\\u003e\\u003c/br\\u003e\\nFeature Type: 1111 (Country), 1112 (Order 1), 1113 (Order 2) or 1119 (order 8)\\u003cbr\\u003e\\u003c/br\\u003e\\n\\u003cbr\\u003e\\u003c/br\\u003e\\nExample content\\u003cbr\\u003e\\u003c/br\\u003e\\n\\u003cbr\\u003e\\u003c/br\\u003e\\nROOI,sint-oedenrode,23055658,1119\\u003cbr\\u003e\\u003c/br\\u003e\\nLAAR,laarbeek,23055916,1119\\u003cbr\\u003e\\u003c/br\\u003e\\nSCHIJNDEL,schijndel,23055923,1119\\u003cbr\\u003e\\u003c/br\\u003e\",\"datatype\":\"string\",\"default_value\":\"\",\"mandatory\":false,\"allocate\":false,\"allocate_tags\":\"\",\"source_allocate_tags\":\"\",\"visibility\":null},{\"name\":\"RegionTemplate\",\"description\":\"Create a custom region code list (Used in china)\",\"datatype\":\"string\",\"default_value\":\"-\",\"mandatory\":false,\"allocate\":false,\"allocate_tags\":\"\",\"source_allocate_tags\":\"\",\"visibility\":null},{\"name\":\"ApplyPatchNavinfoRDB\",\"description\":\"Purpose: force RDF2DH to apply or skip patching Navinfo data.\\u003cbr\\u003e\\u003c/br\\u003e\\n\\u003cbr\\u003e\\u003c/br\\u003e\\nPatches are specific to Navinfo data. Navinfo data is automatically detected, but in unforeseen cases it may be necessary to override this detection and force patching on/off.\",\"datatype\":\"numeric\",\"default_value\":\"-1\",\"mandatory\":false,\"allocate\":false,\"allocate_tags\":\"\",\"source_allocate_tags\":\"\",\"visibility\":false},{\"name\":\"LinkattributeSideFilePath\",\"description\":\"Defines the location of the link attributes patch file\",\"datatype\":\"string\",\"default_value\":\"\",\"mandatory\":false,\"allocate\":false,\"allocate_tags\":\"\",\"source_allocate_tags\":\"\",\"visibility\":null},{\"name\":\"ADAS\",\"description\":\"Defines the location of the ADAS patch file\",\"datatype\":\"string\",\"default_value\":\"\",\"mandatory\":false,\"allocate\":false,\"allocate_tags\":\"\",\"source_allocate_tags\":\"\",\"visibility\":null},{\"name\":\"LaneInfo\",\"description\":\"Defines the location of the LaneInfo patch file\",\"datatype\":\"string\",\"default_value\":\"\",\"mandatory\":false,\"allocate\":false,\"allocate_tags\":\"\",\"source_allocate_tags\":\"\",\"visibility\":null},{\"name\":\"JvSideFilePath\",\"description\":\"\",\"datatype\":\"string\",\"default_value\":\"\",\"mandatory\":false,\"allocate\":false,\"allocate_tags\":\"\",\"source_allocate_tags\":\"\",\"visibility\":null},{\"name\":\"TrafficInfoSideFilePath\",\"description\":\"\",\"datatype\":\"string\",\"default_value\":\"\",\"mandatory\":false,\"allocate\":false,\"allocate_tags\":\"\",\"source_allocate_tags\":\"\",\"visibility\":null},{\"name\":\"RoadNameSideFilePath\",\"description\":\"\",\"datatype\":\"string\",\"default_value\":\"\",\"mandatory\":false,\"allocate\":false,\"allocate_tags\":\"\",\"source_allocate_tags\":\"\",\"visibility\":null},{\"name\":\"PoiNameSideFilePath\",\"description\":\"\",\"datatype\":\"string\",\"default_value\":\"\",\"mandatory\":false,\"allocate\":false,\"allocate_tags\":\"\",\"source_allocate_tags\":\"\",\"visibility\":null},{\"name\":\"Restriction\",\"description\":\"Defines the location of the Restriction patch file\",\"datatype\":\"string\",\"default_value\":\"\",\"mandatory\":false,\"allocate\":false,\"allocate_tags\":\"\",\"source_allocate_tags\":\"\",\"visibility\":null}]}"
    source_data_def_type              'DIRECTORY'
    comment                           'updated by toolspec importer (dev_20141015/dev)'
    status                            'approved'
    is_improvement_process            false
  end

  factory :e_CLEANUP, parent: :executable do
    name                              'Cleanup'
    description                       'Cleanup and finalize conversion output'
    source_data_def_type              'FILE'
    comment                           "'approve' action"
    status                            'approved'
    schedule_cores                    1
    schedule_diskspace_times_input    0
    is_improvement_process            false
  end

  factory :e_RDF2DH, parent: :executable do
    name                              'RDF2DH'
    description                       'Converts rdf to dHive'
    input                             '[{"datatype":"RDB","mandatory":"false","script_tag":""},{"datatype":"RDF","mandatory":"false","script_tag":""}]'
    output                            '[{"identification":".dh.sq3","datatype":"dHive"}]'
    parameters                        '{"parameters":[{"name":"AnnotationFilePath","description":"Defines
      annotation side file","datatype":"string","default_value":"","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"AspectRatio","description":"Purpose:
      specifies the aspect ratio for the used junction views","datatype":"string","default_value":"","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ChinaRDF_annotIconDaylight_isSupported","description":"Parameter
      to indicate if annotIconDayligh is supported","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"DisputedAreas","description":"Generates
      a global DHive with all disputed area/Boundary information. This database is \n                     is
      used by DHMerge to generate the desired view for customers.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"include_all_carto","description":"In
      RDF, every cartographic element is supposed to have a relation to an admin element.\nIn
      RDF terms: rdf_carto has a reference to rdf_carto_link, which has a reference
      to rdf_link. rdf_link has a reference (actually 2) to rdf_admin_place.<br></br>\n<br></br>\nHere
      RDF deliveries fulfill this requirement.<br></br>\n<br></br>\nThe MXF created
      by DH2Mxf also attempts to fulfill this requirement. For this, it depends on the
      availability of dh_lur, which contains relation from dh_lue to (amongst others)
      dh_cit, dh_vil, dh_reg an dh_cou. In case dh_lur is not populated with references
      to administrative elements, the MXF will contain all cartographic features, but
      no administrative links. This is reported by ValidateMXF.<br></br>\n<br></br>\nThe
      carto admin relation is used in the preselection part of the Rdf2DH processing.
      If the link is not available in RDF, the cartographic elements will not be imported.
      To bypass the preselection for cartographic elements, a parameter was introduced
      in Rfd2DH: include_all_carto<br></br>\n<br></br>\nPurpose: When performing Rdf2DH
      conversion (after a DH2Mxf); the rdf_carto should be translated to dh_lue, inspite
      of a mismatch between admin_place_id and carto_id.<br></br>\n<br></br>\nWARNING:
      sub selection not applied for carto when include_all_carto is enabled.","datatype":"string","default_value":"","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"Landmark3DPath","description":"Location
      of the 3D landmarks","datatype":"string","default_value":"","mandatory":false,"allocate":true,"allocate_tags":"3DC","visibility":null},{"name":"NavLinksForEta","description":"Purpose:
      The RDF compiler by default creates navigable links for the boundaries of an enclosed
      traffic area (ETA), which are cartographic features with feature code H_RDF_CARTO_FEAT_TYPE_UNDEF_TRAFFIC_AREA
      (900159), H_RDF_CARTO_FEAT_TYPE_PARKING_LOT (1700215), or H_RDF_CARTO_FEAT_TYPE_PARKING_GARAGE
      (1700216). With parameter NavLinksForEta the creation of these navigable links
      can be overruled.<br></br>\n<br></br>\nRationale: The navigable links for ETA
      boundaries are created by RDF2DH for 1st generation Carin systems to avoid guidance
      on parking places. For legacy reasons they are generated by default. Suppressing
      the creation of navigable links in round-trip conversions avoids map differences
      because of added navigable links, and hence better reflects the actual contents
      of the (intermediate) RDF. For products that do no rely on ETAs being enclosed
      by navigable links the generation of these links can also be suppressed. NavLinksForEta
      enables one to choose the desired behaviour.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"PoiIconFilePath","description":"Defines
      the location of the PoiIconFile","datatype":"string","default_value":"","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"PostProcessEntryPointPOI","description":"In
      the past we created EntryPoint POIs as part of Rdf2DH. As part of the DDF project\n                     an
      improvement process was created DHEntryPointFromPOI to do this. Rdf2DH code will
      be removed \n                     in the near future.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"JvImagePath","description":"Purpose:
      Specifies the path to all the multimedia files related to junction views. Note:
      for RDF2DH, multiple paths can be specified by space-separating them (or by using
      the param+ mechanism)","datatype":"string","default_value":"","available_in_version":"=
      ..","allocate":true,"allocate_tags":"JVS","mandatory":false,"visibility":false},{"name":"JvImagePathNight","description":"Purpose:
      Specifies the path to all the multimedia files related to junction views. Note:
      for RDF2DH, multiple paths can be specified by space-separating them (or by using
      the param+ mechanism)","datatype":"string","default_value":"","available_in_version":11,"removed_after_version":false,"allocate":false,"allocate_tags":"","source_allocate_tags":""},{"name":"JvImagePathEnglishDay","description":"Purpose:
      Specifies the path to all the multimedia files related to junction views. Note:
      for RDF2DH, multiple paths can be specified by space-separating them (or by using
      the param+ mechanism)","datatype":"string","default_value":"","available_in_version":11,"removed_after_version":false,"allocate":false,"allocate_tags":"","source_allocate_tags":""},{"name":"JvImagePathEnglishNight","description":"Purpose:
      Specifies the path to all the multimedia files related to junction views. Note:
      for RDF2DH, multiple paths can be specified by space-separating them (or by using
      the param+ mechanism)","datatype":"string","default_value":"","available_in_version":11,"removed_after_version":false,"allocate":false,"allocate_tags":"","source_allocate_tags":""}]}'
    source_data_def_type              'FILE'
    metalogic 'metalogic' #TODO: add it somehow - Maybe dump from db into a file, then open file and read it here
    comment                           "'approve' action"
    status                            'approved'
    schedule_cores                    1
    schedule_diskspace_times_input    2
    is_improvement_process            false
  end

  factory :e_STOREDH, parent: :executable do
      name                              'StoreDH'
      description "<p xmlns=\"http://www.w3.org/1999/xhtml\" class=\"inline\">Performs
        some standard improvements upon all dHives registered in the current input list
        and\nstores a copy of each to the conversion's output directory.\nThe following
        steps are performed in the order shown.</p>\n      <p xmlns=\"http://www.w3.org/1999/xhtml\"
        class=\"inline\">StoreDH can be called in DAKOTAPROCS with a set of arguments,
        where each argument can be</p>\n      <ul xmlns=\"http://www.w3.org/1999/xhtml\"
        class=\"inline\">\n        <li>The name of an improvement process.</li>\n        <li>\"-NoSpatial\"
        - to say that the dHives should have spatialization removed and not be Spatialized.</li>\n
        \     </ul>\n      <p xmlns=\"http://www.w3.org/1999/xhtml\" class=\"inline\">e.g.
        <tt xmlns=\"http://www.w3.org/1999/xhtml\" class=\"inline\">setenv DAKOTAPROCS
        \"StoreDH(A B C --- -NoSpatial)\"</tt></p>\n      <ol xmlns=\"http://www.w3.org/1999/xhtml\"
        class=\"inline\">\n        <li>If parameter OnlyStoreDHiveDB is not true, perform
        the following dHive improvement processes on\n        the dHives in the Work
        directory.\n        <ul xmlns=\"http://www.w3.org/1999/xhtml\" class=\"inline\"><li>DHCyclicChains</li><li>DHFillGeometry</li><li>DHGenerateCrossRestr</li><li>DHRemoveConsecutiveSpaces</li></ul></li>\n
        \       <li>Add the standard indexes to each dHive in the work directory.</li>\n
        \       <li>If the parameter SupplierAreaCode has been supplied add/replace
        the SUPPLIER_AREA_CODE metadata item with the supplied value.</li>\n        <li>Make
        a copy of each dHive for placing in the conversions output directory. All steps
        after this work on the copies.</li>\n        <li>Perform each improvement process
        listed in the arguments from the DAKOTAPROCS on each of the dHive copies.</li>\n
        \       <li>Spatialize or remove spatialization in each dHive depending on whether
        -NoSpatial was present in the arguments.</li>\n        <li>Add the dakota.convert
        and stat file text as metavalues to each dHive copy.</li>\n        <li>Clean
        and compress each dHive copy.</li>\n      </ol>"
      input                             '[{"datatype":"dHive","id":2,"version":1,"mandatory":false,"script_tag":""}]'
      output                            '[{"datatype":"dHive","id":2,"version":1,"identification":".dh.sq3"}]'
      parameters                        '{"parameters":[{"name":"OnlyStoreDHiveDB","description":"Specifies
        if the standard list of improvement processes should be applied to the\n                     dHives
        in the work directory before storing the dHives.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"SupplierAreaCode","description":"Add
        a dhive_metadata value for the attribute \"SUPPLIER_AREA_CODE\"","datatype":"string","default_value":"do
        not add or replace any SupplierAreaCode","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null}]}'
      source_data_def_type              'DIRECTORY'
      comment                           'updated by toolspec importer (dev_rel1/dev)'
      status                            'approved'
      schedule_cores                    1
      schedule_diskspace_times_input    2
    end

  factory :e_NOKFUEL2DH, parent: :executable do
      name                              'NOKFuel2DH'
      description "Generates a dHive based on the POI's in a Nokia Fuel Types product.
        No parameters required."
      input                             '[{"datatype":"POI","id":null,"version":null,"mandatory":"false","script_tag":""}]'
      output                            '[{"datatype":"dHive","id":2,"version":1,"mandatory":null,"script_tag":null,"identification":".dh.sq3"}]'
      source_data_def_type              'DIRECTORY'
      comment                           'updated by toolspec importer (dev_20141015/dev)'
      status                            'approved'
      schedule_cores                    1
      schedule_diskspace_times_input    2
      is_improvement_process            false
    end

  factory :e_LTEF2DH, parent: :executable do
      name                              'LTEF2DH'
      description                       'Generates a dHive based on Location Table Exchange Format (LTEF) TMC data.'
      input                             '[{"datatype":"TMC","id":null,"version":null,"mandatory":"false","script_tag":""},{"datatype":"CSV","id":31,"version":1,"mandatory":false,"script_tag":""}]'
      output                            '[{"datatype":"dHive","id":2,"version":1,"mandatory":null,"script_tag":null,"identification":".dh.sq3"}]'
      source_data_def_type              'FILE'
      comment                           'testuser'
      status                            'approved'
      schedule_cores                    1
      schedule_diskspace_times_input    2
      is_improvement_process            false
    end

  factory :e_DHCreateAntiLabelingHints, parent: :executable do
    name                              'DHCreateAntiLabelingHints'
    description                       'This process creates the anti-labeling hint records by using the DH_LLH
      table. Those hints are to avoid road name labels on sharp turns.'
    input                             '[{"datatype":"dHive","id":2,"version":1,"mandatory":false,"script_tag":""}]'
    output                            '[{"datatype":"dHive","id":2,"version":1,"mandatory":null,"script_tag":null,"identification":".dh.sq3"}]'
    parameters                        '{"parameters":[{"name":"AntiLabelingHintAngleThreshold","description":"This
      is the angle threshhold of whether to create an anti-labeling hint record. It
      is in the metrics of degree.\n                    The smaller the threshhold value,
      the easier that an anti-labeling record be created.","datatype":"numeric","default_value":"45","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null}]}'
    source_data_def_type              'DIRECTORY'
    comment                           'updated by toolspec importer (dev_20141015/dev)'
    status                            'draft'
    schedule_cores                    1
    schedule_memory_base              0
    schedule_memory_times_input       0
    schedule_diskspace_base           0
    schedule_diskspace_times_input    2
  end

  factory :e_DHCreateLabelingHints, parent: :executable do
    name                              'DHCreateLabelingHints'
    description {
      <<-DESCRIPTION
        The CreateLabelingHints improvement process generates curved labeling
      hints. Curved labeling hints give

      information about where a text string can be positioned along the road or bmd
      feature. The hint is described

      in the form of a spline, defined by its anchoring points. Curved labeling hints
      are generated for all BMD

      features on all levels and RTG RoadGeoLines and BaseLinks on BaseLevel. Curved
      labeling hints are stored

      in the flexible attribute LABELING_HINT. A road/bmd feature within a tile can
      have multiple curved labeling

      hints. If a curved labeling hint is present in several tiles for the same road
      or bmd feature, the labeling

      hint data will be combined. This is done by the following rule: if a road crosses
      a tile border, then an

      anchoring point of the spline will be defined on the tile border that is the same
      for both tiles. This rule

      specifies which curved labeling hints belong together.
      DESCRIPTION
    }
    input                             '[{"datatype":"dHive","id":2,"version":1,"mandatory":false,"script_tag":""}]'
    output                            '[{"datatype":"dHive","id":2,"version":1,"mandatory":null,"script_tag":null,"identification":".dh.sq3"}]'
    parameters                        '{"parameters":[{"name":"CurvedLabelingHintMinimumLength","description":"The
      CurvedLabelingHintMinimumLength is used to ignore subgeometries that are too small
      to contain a label. The length\nis specified in centimeters. Any subgeometry that
      is smaller than the threshold will be not be eligible as a labeling\nhint candidate.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CurvedLabelingHintAngleThreshold","description":"The
      CurvedLabelingHintAngleThreshold is used to split the geometry (that is being
      processed) into several subgeometries\nthat are candidates for labeling hints.
      The geometry is scanned and split up at each corner that exceeds the\nCurvedLabelingHintAngleThreshold.
      This will prevent labels from being placed around corners that are too sharp.
      The\nangle threshold is specified in degrees.","datatype":"numeric","default_value":"60","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CurvedLabelingHintAngleLengthThreshold","description":"The
      CurvedLabelingHintAngleLengthThreshold is used to skip simple subgeometries. These
      simple subgeometries span the predefined\nCurvedLabelingHintAngleLengthThreshold
      in centimeters without changing too much in angle and thus don''t require special
      labeling hints.","datatype":"numeric","default_value":"1000","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null}]}'
    comment                           'updated by toolspec importer (dev_20141015/dev)'
    status                            'approved'
  end

  factory :e_DHEntryPointFromPOI, parent: :executable do
    name                              'DHEntryPointFromPOI'
    description {
      <<-DESCRIPTION
      Input-conversion to dHive might publish entrypoints for POI's as
      if they are POI's. However entry-points in dHive are not modeled as POI's. DHEntryPointFromPOI
      detects and deletes (related information of-) POI's that are:\n                <ul><li>Child
      in the relation through dh_rel</li><li>and having same source category as its
      parent</li><li>and having same name as its parent</li></ul>\n                    The
      process makes sure all related dh_pvn, dh_pho, dh_pcv, dh_pva, dh_rel, dh_pco
      and dh_gcs-data is updated to maintain a valid dHive in the new situation for
      both child and parent POI's. Also the dh_poi.firstRelId field is recalculated.\n\n
      \                   The deduplication of POI's used to be a integral part of RDF2DH
      but then later become separated as a improvement process. RDF2DH however still
      contains its old behavior but that one is aught to be switched off by specification
      of \"parameter PostProcessEntryPointPOI 1\".
      DESCRIPTION
    }
    input                             '[{"datatype":"dHive","id":2,"version":1,"mandatory":false,"script_tag":""}]'
    output                            '[{"datatype":"dHive","id":2,"version":1,"mandatory":null,"script_tag":null,"identification":".dh.sq3"}]'
    parameters                        '{"parameters":[]}'
    comment                           'updated by toolspec importer (dev_20141015/dev)'
    status                            'approved'
  end

  factory :e_DHFill3D, parent: :executable do
    name                              'DHFill3D'
    description "Imports 3D content (OBJ and Collada files) into a dHive database.\n\n
      \       Assumes that the DH_LUR and DH_MME tables are already filled in.\n\n        Fills
      in the appropriate 3D-tables with correct content using Wavefront functionalities
      (for OBJ files) and the Collada importer."
    input                             '[{"datatype":"dHive","id":2,"version":1,"mandatory":"false","script_tag":""}]'
    output                            '[{"datatype":"dHive","id":2,"version":1,"mandatory":null,"script_tag":null,"identification":".dh.sq3"}]'
    parameters                        '{"parameters":[{"name":"DeleteInvalidLandmarks","description":"Purpose:
      Controls deletion of unreferenced 3D records, set to 0 to prevent deletion.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"Landmark3DCoordinateSystem","description":"Purpose:
      set the coordinate system of the 3D landmark vertices in the Wavefront OBJ files.\n\n        This
      is the meaning of a vertex coordinate (x,y,z) in the input wavefront OBJ files.","datatype":"string","default_value":"ENU","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"AllowFaceWithoutTextures","description":"Purpose:
      do not reject Wavefront (OBJ) 3D Models that contain faces with vertexes that
      have no texture reference.\n\n        For full 3D Landmark operation, all face
      vertices are required to have a texture reference. This is not a requirement of
      Wavefront, so when passing 3D objects via Fill3D/Export3D, objects that have faces
      without textures should be accepted and maintained.\n\n        For this, the parameter
      AllowFaceWithoutTextures should be set to 1.\n\n        NOTE: the default value
      of this parameter is changed in tasks 30761 and 30762 from 0 to 1, since all tooling
      is long capable of handling faces without textures.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"Default3DObjectLevel","description":"Purpose:
      set fallback quality level in case the 3D object filename does not provide quality
      level information.\n\n        Fill3D tries to deduce the (quality) level of a
      3D object from the filename using the Navteq naming standards. Not all suppliers
      use that. This parameter allows to set a default level that is used in case it
      cannot be deduced from the file name. It does not override the level that is available
      from a 3D object filename.","datatype":"numeric","default_value":"H_DH_3DG_LEVEL_UNKNOWN","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"Fill3D_AddFoundations","description":"Purpose:
      Add foundations to 3D landmarks.\n\n        This will prevent the floating of
      3D landmarks on top the DTM.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"GenFoundations_Export3DObjects","description":"Purpose:
      Export the modified 3D objects (with foundations) to a file in the working folder.\n\n        The
      file will be created in added to the folder \"models_with_foundations\" and\n        its
      name will start with \"Generated_\".","datatype":"numeric","default_value":"1","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CityModel3DSupplier","description":"Purpose:
      Set the supplier of the city model 3D data.\n\n        This is needed because
      different suppliers can deliver 3D data (*.DAE) with some differences.","datatype":"string","default_value":"NAVTEQ","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CityModel3DFilter","description":"Purpose:
      Remove 3D landmarks that have an overlap with a part of a 3D collada city model.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":true},{"name":"Fill3D_ObjModelsHaveAbsoluteCoordinates","description":"Purpose:
      We can process only the 3D models which have vertexes containing relative coordinates
      (stored in meters). If the models we are trying to process contain vertexes with
      absolute coordinates (stored in degrees), then this parameter must be used. This
      will enable the conversion of the coordinates.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"MotorwayJunctions3DPath","datatype":"path","default_value":"","mandatory":false,"allocate":true,"visibility":false,"allocate_tags":"jvs","description":""},{"name":"CityModel3DPath","datatype":"path","default_value":"","mandatory":false,"allocate":true,"visibility":false,"allocate_tags":"3dc","description":""}]}'
    source_data_def_type              'DIRECTORY'
    comment                           'updated by toolspec importer (dev_20141015/dev)'
    status                            'approved'
    schedule_cores                    1
    schedule_memory_base              0
    schedule_memory_times_input       0
    schedule_diskspace_base           0
    schedule_diskspace_times_input    2
  end

  factory :e_DHGateways, parent: :executable do
    name                              'DHGateways'
    description "This improvement process will fill the DH_GWY table in the supplied
      dhives. Optionally a gateway rdo file can be supplied,\n            in which case
      the tool tries to reuse the gateway id's (based upon coordinate or permanent node
      id).\n            If a gateway is new, a new id is defined for it.\n            The
      gateway information for the gateways actually present in the input dhives is written
      to the output gateway rdo file,\n            which can then be used for the gateway
      processing of the next data release."
    input                             '[{"datatype":"dHive","id":2,"version":1,"mandatory":false,"script_tag":""},{"datatype":"NOTVALID","id":null,"version":null,"mandatory":false,"script_tag":""}]'
    output                            '[{"datatype":"dHive","id":2,"version":1,"mandatory":null,"script_tag":null,"identification":".dh.sq3"},{"datatype":"NOTVALID","id":null,"version":null,"mandatory":null,"script_tag":null}]'
    parameters                        '{"parameters":[{"name":"old_GatewayUseNodPermanentId","description":"This
      parameter specifies whether nodes are matched between datasets by coordinate or
      by permanent id.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"GenerateBorderNodes","description":"Purpose:
      The border node flags in DH_NOD are sometimes incorrect, resulting in incorrect
      gateways.\n                    Hence DHGateways offers a conversion parameter
      that controls whether border nodes should be (re-)generated from the input databases
      of DHGateways.\n                    If GenerateBorderNodes is enabled DHGateways
      finds nodes that occur in multiple databases and marks them as border nodes.\n                    All
      other nodes are marked as non-border nodes.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"GatewayDistanceTolerance","description":"Purpose:
      a.k.a \"Fuzzy Gateway Matching\".\n                    Indicates the distance
      to look around for matching gateways to the dataset''s bordernodes.\n                    When
      GatewayUseNodPermanentId is disabled,  a default of 100cm is used.\n                    When
      GatewayUseNodPermanentId is enabled, the default of 0cm is used, which practically\n                    disables
      fuzzy gateway matching.","datatype":"numeric","default_value":"100","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"GatewayVirtualMode","description":"Enable
      or disable VirtualGateway mode. This mode enables the generation of stub- dhive
      databases to be serverd as input for the regular gateway process so that the all
      gateways from the input rdo file will be matched against the real input update-regions.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null}]}'
    comment                           'updated by toolspec importer (dev_20141015/dev)'
    status                            'approved'
  end

  factory :e_DHGenerateTrafficPhonemes, parent: :executable do
    name                              'DHGenerateTrafficPhonemes'
    description                       'This process creates new DH_PHO records for DH_RVN records. The contents
      of the new DH_PHO records should come FROM the existing DH_PHO records.'
    input                             '[{"datatype":"dHive","id":2,"version":1,"mandatory":false,"script_tag":""}]'
    output                            '[{"datatype":"dHive","id":2,"version":1,"mandatory":null,"script_tag":null,"identification":".dh.sq3"}]'
    source_data_def_type              'DIRECTORY'
    comment                           'updated by toolspec importer (dev_20141015/dev)'
    status                            'draft'
    schedule_cores                    1
    schedule_memory_base              0
    schedule_memory_times_input       0
    schedule_diskspace_base           0
    schedule_diskspace_times_input    2
  end

  factory :e_DHImportBrandIcons, parent: :executable do
    name                              'DHImportBrandIcons'
    description                       'This process is used to import brand icons data into DHive. The brand
      icons can be supplied as a side database. New records should be created for the
      brand icons unless the brand icon is already present in the database.'
    input                             '[{"datatype":"dHive","id":2,"version":1,"mandatory":"false","script_tag":""}]'
    output                            '[{"datatype":"dHive","id":2,"version":1,"mandatory":null,"script_tag":null,"identification":".dh.sq3"}]'
    parameters                        '{"parameters":[{"name":"BrandIconsPath","description":"This parameters
      specifies the path to the side database containing the brand icons.","datatype":"path","default_value":"","mandatory":false,"allocate":false,"allocate_tags":"BIC","visibility":false}]}'
    source_data_def_type              'DIRECTORY'
    comment                           'updated by toolspec importer (dev_20141015/dev)'
    status                            'draft'
    schedule_cores                    1
    schedule_memory_base              0
    schedule_memory_times_input       0
    schedule_diskspace_base           0
    schedule_diskspace_times_input    2
  end

  factory :e_DHImportNtqFuelXML, parent: :executable do
    name                              'DHImportNtqFuelXML'
    description                       'This improvement process imports fuel station (specifically Electric
      Charging Stations and LPG stations)

      POI''s into the core dHive from Nokia side databases specified by the parameter
      FuelXMLDatabase. This process is essential

      because such information is provided as standalone side files (database or xml
      files) and not included in the source data.

      Therefore this tool needs to be run to import data from the side data.'
    input                             '[{"datatype":"dHive","id":2,"version":1,"mandatory":"false","script_tag":""}]'
    output                            '[{"datatype":"dHive","id":2,"version":1,"mandatory":null,"script_tag":null,"identification":".dh.sq3"}]'
    parameters                        '{"parameters":[{"name":"FuelXMLDatabase","description":"This parameter
      points to the Navteq fuel xml database that has to be imported in the dHive.","datatype":"string","default_value":"","mandatory":false,"allocate":true,"allocate_tags":"NOKFUEL","visibility":null}]}'
    source_data_def_type              'DIRECTORY'
    comment                           'updated by toolspec importer (dev_20141015/dev)'
    status                            'approved'
    schedule_allow_virtual            false
  end

  factory :e_DHImproveZLevelTransitionRendering, parent: :executable do
    name                              'DHImproveZLevelTransitionRendering'
    description "<p xmlns=\"http://www.w3.org/1999/xhtml\" class=\"inline\">\n            When
      drawing road situations with multiple z-level transitions in application software,
      it's possible that roads appear to\n            go through one another even though
      they are at different height levels in real life. This is because the application
      software\n            needs to assign a certain width to the road to be able to
      draw it, and this combined with interpolating height values between\n            shape
      points results in drawing errors with road lines going through one another. Two
      approaches have been implemented in\n            DHImproveZLevelTransitionRendering
      to decrease the likelihood of this occurring.\n            </p>\n      <p xmlns=\"http://www.w3.org/1999/xhtml\"
      class=\"inline\">\n            The z-levels in DHive are relative, which means
      that if there are no z-level transitions, the level is 0. If a road\n            crosses
      and runs above another road, it will have z-level 1, the one above that level
      2 and so on. This implies that even\n            if a road is continually at the
      same height in real-life, it might have multiple z-level transitions because of
      the roads\n            below it. Since the application software uses the z-level
      for determining drawing order, this needlessly increases the risk\n            of
      drawing issues. We therefore try to reduce the amount of transitions by increasing
      the z-level where possible so a chain's\n            z-levels are as uniform as
      possible.\n            </p>\n      <p xmlns=\"http://www.w3.org/1999/xhtml\" class=\"inline\">\n
      \           Another factor is the distance between two points that have a z-level
      transition. If the slope between them isn't very sharp,\n            there's a
      higher chance get tangled up with other lines. Therefore if there's a z-level
      transition, we insert a new point in\n            between the two points and calculate
      a height for it. The has the effect of making the transition shorter and sharper.
      To prevent\n            the new points from being filtered out, they are marked
      with a special flag and the actual height is set by the NDS compiler.\n            </p>"
    input                             '[{"datatype":"dHive","id":2,"version":1,"mandatory":false,"script_tag":""}]'
    output                            '[{"datatype":"dHive","id":2,"version":1,"mandatory":null,"script_tag":null,"identification":".dh.sq3"}]'
    parameters                        '{"parameters":[{"name":"EnableZLevelTransitionReduction","description":"Whether
      or not we try to reduce the z-level transitions by increasing the z-level where
      possible so a chain''s\n                    z-levels are as uniform as possible.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"MaxZLevelTransitionReductionIterations","description":"Z-level
      transition reduction is a heuristic which is implemented as an iterative algorithm
      where\n                    each iteration improves the quality of the result.
      The algorithm can converge on its own (if no\n                    further points
      can be updated), but there are diminishing returns for subsequent iterations.
      This\n                    parameter specifies an upper bound for this to tune
      the resulting time / quality trade-off.","datatype":"numeric","default_value":"5","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ZLevelTransitionReductionDistanceThreshold","description":"Z-level
      transition reduction only tries to update the z-level of a point if it lies within\n                    the
      distance threshold specified by this parameter. There isn''t much gain in making
      a point''s z-level\n                    the same as one which is very far away,
      since the drawing issues mainly occur in small areas with\n                    many
      transitions. The distance threshold is expressed in meters.","datatype":"numeric","default_value":"50","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"RemoveUnnecessaryZLevelSplits","description":"Whether
      or not we remove the unnecessary z-level splits by decreasing the z-level by one.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null}]}'
    source_data_def_type              'DIRECTORY'
    comment                           'updated by toolspec importer (dev_20141015/dev)'
    status                            'draft'
    schedule_cores                    1
    schedule_memory_base              0
    schedule_memory_times_input       0
    schedule_diskspace_base           0
    schedule_diskspace_times_input    2
  end

  factory :e_DHMerge, parent: :executable do
    name                              'DHMerge'
    description                       'Merge Dhive merges groups of dHive (Mapscape Data Hive) databases
      into 1 or more databases. The grouping is based on dHive tags

      and thus requires all input databases to be tagged. The conversion script specifies
      which input databases should be merged into which output

      databases. A typical use case for merge dHive is to merge all databases of europe
      into databases per country, e.g. for TA data d51..d70 are

      merged into a single database. If a dHive is tagged with RDO, then it will excluded
      from the merge. If a dHive is tagged with MME, then the

      multimedia blobs from this database will replace any mme record that is not in
      a blob in all input databases.'
    input                             '[{"datatype":"dHive","id":2,"version":1,"mandatory":"false","script_tag":""}]'
    output                            '[{"datatype":"dHive","id":2,"version":1,"mandatory":null,"script_tag":null,"identification":".dh.sq3"}]'
    parameters                        '{"parameters":[{"name":"LogGlueingNodeChain","description":"Purpose:
      Enable logging of border nodes and border chains in different databases that are
      identified is being equal and\nhence merged into a single border node / chain.
      It is mainly for debugging purposes and should not be used for normal production.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"DHMerge_MergeChainsWithPermId","description":"Indication
      whether chains with the same permanent id should be considered the same.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"DHMerge_MergeNodesWithPermId","description":"Controls
      merging of nodes with a permanent id. This is required for Multinet-R data as
      a consequence of the coordinate rounding (7 to 5 digits).","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CountrySpecificView","description":"This
      parameter allows for the creation of a (merged) dHive  with contents according
      to the view of the indicated country.\nRequires as input the (normal) dHive(s)
      of one country and the ''disputed areas'' dHive of the same continent. DHives
      of other countries\nmay also be supplied, but they will not undergo ''specific
      treatment''. The value of this parameter defines which country view is used.\nOnly
      one country code is allowed.","datatype":"string","default_value":"","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null}]}'
    source_data_def_type              'DIRECTORY'
    metalogic 'metalogic'#TODO: add it somehow..
    comment                           'updated by toolspec importer (dev_20141015/dev)'
    status                            'draft'
    schedule_cores                    1
    schedule_diskspace_times_input    2
  end

  factory :e_DHMergeCountryInAnotherCountry, parent: :executable do
    name                              'DHMergeCountryInAnotherCountry'
    description "The DHMergeCountryInAnotherCountry improvement process is used to
      merge one country in another country. The Use case was adding the possibility
      to merge Kosovo under Serbia. You can merge each country under another country,
      but there are some rules: <br></br>\n                Only real countries can be
      merged, states and continents can't be merged.<br></br>\n                You cannot
      merge countries in another country if this country is merged under another country."
    input                             '[{"datatype":"dHive","id":2,"version":1,"mandatory":false,"script_tag":""}]'
    output                            '[{"datatype":"dHive","id":2,"version":1,"mandatory":null,"script_tag":null,"identification":".dh.sq3"}]'
    parameters                        '{"parameters":[{"name":"MergeCountryInAnotherCountry","description":"The
      MergeCountryInAnotherCountry parameter specifies pairs of countries that will
      be merged. The values consists of a list of pairs, where the first country is
      merged in the second country.<br></br>\n                        The format is
      as follows: ISOCC#ISOCC ISOCC#ISOCC ..., where each ISOCC is an ISO country code
      consisting of three uppercase letters. For example to merge Kosovo under Serbia
      use: \"KOS#SRB\".","datatype":"string","default_value":"","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":false},{"name":"ConvertMergedCountryBorderToDisputed","description":"When
      the ConvertMergedCountryBorderToDisputed parameter is enabled, the borders of
      the country that is merged inside another country will be marked as a disputed
      border.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":false},{"name":"KeepOldCountryAsRegion","description":"Standard
      behavior removes the country to be merged; its regions are put directly under
      the second country.\n                    With this parameter set to 1, the to
      be merged country is made a (top level) region under the second country.\n                    Regions
      of the old country will then become children of that (new) top level region.\n                    The
      already existing top level regions of the second country will remain unchanged.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null}]}'
    source_data_def_type              'DIRECTORY'
    comment                           'updated by toolspec importer (dev_20141015/dev)'
    status                            'draft'
    schedule_cores                    1
    schedule_memory_base              0
    schedule_memory_times_input       0
    schedule_diskspace_base           0
    schedule_diskspace_times_input    2
  end

  factory :e_DHNameCustomize, parent: :executable do
    name                              'DHNameCustomize'
    description "The DHNameCustomize improvement process is used to convert names
      in the DHive. The conversion is based on a set of rules that is\nsupplied via
      the configuration file. The rules allow replacement, adding before or after and
      deletion of words, full names or certain patterns.\n Each rule only applies to
      a single language, DHive table and DHive column. DHNameCustomize is mostly used
      to normalize street names and replace\nabbreviation street names by full street
      names."
    input                             '[{"datatype":"dHive","id":2,"version":1,"mandatory":false,"script_tag":""}]'
    output                            '[{"datatype":"dHive","id":2,"version":1,"mandatory":null,"script_tag":null,"identification":".dh.sq3"}]'
    parameters                        '{"parameters":[{"name":"NameCustomizeConfiguration","description":"Configuration
      file location for the name customization improvement process. This file contains
      a list of rules that\nare used for the name customization. Each rule should contain
      the following items:\n           - DHTableColumn   : The field in dHive which
      will be matched against (for example ''DH_CHN.Name'')\n           - LanguageCode    :
      The MARC language code of the desired language (for example ''ENG'')\n           -
      Pattern         : The pattern to search for\n           - PatternMatchMode: WORD      (the
      given pattern should match a whole word)\n                               FULL_NAME
      (the given pattern should match the complete name)\n                               REGEX     (the
      given pattern is a regular expression)\n           - ReplacePattern  : The replacement
      string if a pattern is found (can be empty in ReplaceMode is DELETE)\n           -
      ReplaceMode     : REPLACE    (The found pattern should be replaced with the ReplacePattern)\n                               ADD        (The
      found pattern should be replaced with the ReplacePattern, but as an additional
      name)\n                               ADD_BEFORE (The found pattern should be
      replaced with the ReplacePattern, but as an additional name before the found.\n                                           This
      is to be able to make the replaced name more important than the matched one)\n                               DELETE     (A
      record that matches the given pattern should be deleted)\n                               TRANS      (the
      given pattern is the ENG transliteration column name from the same entry)\nThe
      process will crash if no valid file is supplied.","datatype":"string","default_value":"__DEFAULT__","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null}]}'
    comment                           'updated by toolspec importer (dev_20141015/dev)'
    status                            'approved'
  end

  factory :e_DHPOIDeduplicate, parent: :executable do
    name                              'DHPOIDeduplicate'
    description                       'This improvement process will remove duplicate POI''s.

      First the tool will find all POI''s with similar PermanentId and OutputCategoryList
      values in the main dHive POI table.

      These POI''s will be marked as candidates for removal. The candidate with the
      lowest id will be selected as reference

      and is removed from the candidates list. Next, the reference is compaired to all
      candidates in all POI related tables

      (DH_PVA, DH_PVN, DH_REL, DH_CPO, DH_PCV). If a candidate is equal to the reference
      in all POI related tables,

      then it will be removed from the candidate list. Finally all candidates that are
      left will be removed.'
    input                             '[{"datatype":"dHive","id":2,"version":1,"mandatory":false,"script_tag":""}]'
    output                            '[{"datatype":"dHive","id":2,"version":1,"mandatory":null,"script_tag":null,"identification":".dh.sq3"}]'
    parameters                        '{"parameters":[{"name":"DeDuplicateBasedOnPos","description":"Flag
      to specify if additional deduplication of POI''s based on position, name and phonenumber
      \nneeds to be done","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ModifyPoiidInPVAPCVForDuplicatePOI","description":"Flag
      to Modify Poiid In PVA and PCV For Duplicate POI","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null}]}'
    comment                           'updated by toolspec importer (dev_20141015/dev)'
    status                            'approved'
  end

  factory :e_DHPOIMap, parent: :executable do
    name                              'DHPOIMap'
    description                       'POI Mapper. Maps POI categories based on a configuration file'
    input                             '[{"datatype":"dHive","id":2,"version":1,"mandatory":"false","script_tag":""}]'
    output                            '[{"datatype":"dHive","id":2,"version":1,"mandatory":null,"script_tag":null,"identification":".dh.sq3"}]'
    parameters                        '{"parameters":[{"name":"POI_mapping_AllowUnmappedCategories","description":"Determines
      if the POI Mapper should terminate if there are unmapped POIs. This means there
      are no mapping rules for these POIs","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":false},{"name":"POI_mapping_duplication","description":"Determines
      if the POI Mapper should duplicate POIs with more than one output category (comma
      separated output categories in the OutputCategoryList).","datatype":"numeric","default_value":"1","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":false},{"name":"POI_mapping_output_categorization","description":"Indicates
      the required output categorization.","datatype":"string","default_value":null,"mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"POI_mapping_data_supplier","description":"Indicates
      the supplier of the source data. Optional when specified in DH_METADATA","datatype":"string","default_value":null,"mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"POI_mapping_input_categorization","description":"Indicates
      the source data POI categorization. Optional when specified in DH_METADATA","datatype":"string","default_value":null,"mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"POI_mapping_area","description":"Indicates
      the source data coverage. Optional when specified in DH_METADATA","datatype":"string","default_value":null,"mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"POI_mapping_version","description":"A
      unique string representing the version of the POI Map layout file","datatype":"string","default_value":null,"mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"POI_mapping_layout_file","description":"Fully
      qualified filename of the mapping layout file in CSV format (''|'' as separator)","datatype":"string","default_value":null,"mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":false},{"name":"POI_mapping_layout","datatype":"string","default_value":"","mandatory":false,"allocate":true,"visibility":false,"allocate_tags":"PML","description":"","available_in_version":"=
      .."}]}'
    source_data_def_type              'FILE'
    comment                           'updated by toolspec importer (dev_20141015/dev)'
    status                            'draft'
    schedule_allow_virtual            false
  end

  factory :e_DHRemoveCountries, parent: :executable do
    name                              'DHRemoveCountries'
    description                       'RemoveCountries is intended to remove all data from a given dHive
      database, except for the landuse elements.

      This improvement process can be used to retain display elements for countries
      that will not be included in a product

      conversion. A whitelist of ISO country codes is given to indicate which countries
      must be included. Countries not in

      this list are to be removed. For risk minimization, the current prerequisite is
      that the given dHive database shall

      only contain countries that are all to be removed, or all to be kept. Otherwise
      stated: the tool does not accept that

      it has to remove part of the data. This check is performed upfront, and if it
      does not succeed, a crash is enforced.'
    input                             '[{"datatype":"dHive","id":2,"version":1,"mandatory":false,"script_tag":""}]'
    output                            '[{"datatype":"dHive","id":2,"version":1,"mandatory":null,"script_tag":null,"identification":".dh.sq3"}]'
    parameters                        '{"parameters":[{"name":"RemoveCountriesNotInList","description":"This
      parameter specifies a list of ISO (International Organization for Standardization)
      country codes\n(space separated) that are NOT removed from the dHive (Mapscape
      Data Hive) database(s). This means it actually serves as\na whitelist. When a
      country is not in the list, then ONLY the landuse elements will be kept.","datatype":"string","default_value":"","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null}]}'
    comment                           'updated by toolspec importer (dev_20141015/dev)'
    status                            'approved'
  end

  factory :e_DHRemoveDuplicateBorders, parent: :executable do
    name                              'DHRemoveDuplicateBorders'
    description "The DHRemoveDuplicateBorders improvement process is used to remove
      border lines (country- and order1 borders) across different dHives. Rationale
      behind the process is that every country dHive contains a country border, which
      is de-duplicated during DHMerge. However, when eventually creating an NDS map,
      the duplication for country borders on an update region border still remains,
      since each update region is a separate dHive (after DHMerge).\n            To
      avoid this, this process looks across all dHives and duplicated border lines are
      removed from the dHives except for one udpate region, so that effectively the
      borderline will only be present once in the resulting NDS map."
    input                             '[{"datatype":"dHive","id":2,"version":1,"mandatory":"false","script_tag":""}]'
    output                            '[{"datatype":"dHive","id":2,"version":1,"mandatory":null,"script_tag":null,"identification":".dh.sq3"}]'
    parameters                        '{"parameters":[{"name":"RemoveBordersByGeometry","description":"Determines
      how duplicate borders should be detected.\n                    Value 1 means:
      use the borderline geometry\n                    Value 0 means: use PermanentId
      values","datatype":"numeric","default_value":"1","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null}]}'
    source_data_def_type              'FILE'
    comment                           'updated by toolspec importer (dev_20141015/dev)'
    status                            'approved'
    schedule_allow_virtual            false
  end

  factory :e_DH2NDH, parent: :executable do
    name                              'DH2NDH'
    description "The tool DH2NDH prepares a dHive database for conversion to NDS.\n
      \           As intermediate database NDH is introduced which in the basis is a
      copy of dHive,\n            but only includes changes that are required for NDS
      processing. This makes NDH a\n            more stable and compatible database
      than dHive, especially in development.\n            Next to the table data migration
      also some preparation steps are done,\n            such as conversion to the NDS
      coordinate system."
    input                             '[{"datatype":"dHive","id":2,"version":1,"mandatory":"false","script_tag":""}]'
    output                            '[{"datatype":"NDH","id":53,"version":1,"mandatory":null,"script_tag":null}]'
    parameters                        '{"parameters":[{"name":"RoadConditionFilter","description":"Filters
      roads with a certain road condition out of the map. Comma separated values are
      accepted, the value is directly inserted into a sql query within a ''NOT IN ()'',
      so DH defines like ''H_DH_CHA_RCO_BACKROAD()'' are also accepted.","datatype":"string","default_value":"","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null}]}'
    source_data_def_type              'FILE'
    comment                           'updated by toolspec importer (dev_20141015/dev)'
    status                            'approved'
    schedule_allow_virtual            false
  end

  factory :e_NDH2NDS, parent: :executable do
    name                              'NDH2NDS'
    description                       'The NDS compiler is a compiler that generates NDS maps.'
    input                             '[{"datatype":"NDH","id":53,"version":1,"mandatory":"false","script_tag":""}]'
    output                            '[{"datatype":"NDS","id":54,"version":1,"mandatory":null,"script_tag":null,"identification":"ROOT.NDS"}]'
    parameters                        '{"parameters":[{"name":"SdsStoreStateNames","description":"Toggle
      the inclusion of state names in SDS.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"WorldBoundaryMapLocation","description":"The
      WorldBoundaryMapLocation parameter is used to pass the location of a WBM product
      to a NDS conversion, so that the WBM product is automatically included at the
      very end of the compilation.","datatype":"path","default_value":"","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"DTMMapLocation","description":"The
      DTMMapLocation parameter is used to pass the location of a DTM product to a NDS
      conversion, so that the DTM product is automatically included at the very end
      of the compilation. The DTM data should be \u201cclipped\u201d given the BMD tiles
      of the navigation data: only the tiles which are present in BMD should be included
      in the DTM product.","datatype":"path","default_value":"","mandatory":false,"allocate":true,"allocate_tags":"NDS","source_allocate_tags":"3DC","visibility":true},{"name":"PermanentNDSIdPath","description":"Purpose:
      Set the directory in which the permanent id databases for all update regions are
      stored that must be used to as input to generate permanent id''s See also UsePermanentNDSIds.
      When the parameter is set to an empty string, no previous permanent id databases
      will be used.","datatype":"path","default_value":"","mandatory":false,"allocate":true,"allocate_tags":"","source_allocate_tags":"","visibility":false},{"name":"BDAMMapLocation","description":"This
      parameter points to an NDS map containing only BDAM data. When provided, this
      BDAM map will be included in the result of the conversion result.","datatype":"string","default_value":"","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"APN_Extended","description":"When
      the APN_Extended parameter is enabled, all Alpine specific features will be included
      in the NDS database.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"EnableBuildingHeight","description":"When
      this option is absent or enabled, the building height is (by default) added to
      2d footprint of a building . Use this option to disable the building height flexible
      attrribute for EB_EVO.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"IncludeSpaceInNvcTree","description":"This
      parameter can be used to control the inclusion of spaces in the NVC tree.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"FLI_NVC_Separator","description":"This
      parameter controls the separation character for first letter input in NVC trees.
      First letter input it typically used for ideogram languages like Chinese. The
      NVC tree then contains both the Chinese ideogram and the first letter equivalent
      for that ideogram in the NVC node''s prefix. Both are separated by the given character.
      Theoretically, any character can be used, but it is ofcourse advised to make sure
      that the character never occurs as part of a string (in NVC).","datatype":"string","default_value":"#","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"AddHyphenInAdpNvcTree","description":"When
      the AddHyphenInAdpNvcTree parameter is enabled hyphens will be kept for first
      letter input in NVC trees. This will enable the first letter input for Chinese
      to be able contains complete house numbers, because the hyphens are included.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UsePlainNameInSdsLanguages","description":"Defines
      the languages for which the plain names are to be used as SDS names. The value
      consists of a list of comma seperated language codes.","datatype":"string","default_value":"","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UseTransPlainNameInSds","description":"Defines
      whether trans plain names should be used in the Sds. Trans names can be used in
      cases where no speech is available (for instance for China, Macau and Hongkong).
      If this parameter is enabled, the NDS compiler will generate PinYin trans names
      for all languages, except the ones specified by the UsePlainNameInSdsLanguages
      parameter.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"LandMark3DScaletexcoords","description":"The
      LandMark3DScaletexcoords parameter is used to enable texture scaling. Texture
      scaling is not allowed according to the NDS specification, but the scaling is
      required for Alpine and Mapview.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"Create_RNFeatCodeAdminRoadClass","description":"By
      default shield icons are only displayed for highways. With this parameter countries
      can be defined that will also display shield icons for Express Highways, Urban
      Expressways, National Roads (Provincial Road), Regional (Local) Roads. The value
      consists of a list of comma seperated iso country codes.","datatype":"string","default_value":"","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"AdditionalMetadataRegions","description":"The
      AdditionalMetadataRegions is used to create additional regions. For example, by
      default the USA only contains regions for the seperate states. When this parameter
      is enabled an additional region will be created for USA itself. This region can
      then be used to get some region data just after country selection (without having
      to select a state). The value of this parameter consists of a list of ISO country
      codes seperated by spaces.","datatype":"string","default_value":"","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"NDSApiVersion","description":"Use
      this permanent set in datascriptVersionName in dataModelVersionTable in ROOT.NDS.","datatype":"string","default_value":"\"\"","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CreateContourMap","description":"Defines
      whether a Contour map should be created or not.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CreateOverViewMap","description":"Defines
      whether an Overview map should be created or not.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ProductOverViewMapFlag","description":"","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ProductId","description":"Defines
      productId.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CreateGlobalAMDMap","description":"","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"FillGapsForGlobeWldOverviewMap","description":"This
      parameter enables the behavior of adding extra points to polygons bordered by
      tile boders in the World Overview Map. The purpose of adding extra points is to
      avoid gaps being created between polygons when the world overview map is rendered
      into a 3D Globe View Map by some 3D renderer on the targeted navigation device.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"BmdScaleSubLevelFile","description":"This
      is the configuration of BMD feature for scale sub levels. Each line contains the
      following elements: ISOConCode, EnumName, BmdFeatureClass, FeatureCode, populationLevel,
      OOName, Level, ScaleValue, Exclude. This means the specific scale sub level value
      of BmdFeatureClass in the NDS in the specific country(ISOConCode) and specific
      level.","datatype":"path","default_value":"BmdScaleSubLevelCfg_Default.csv","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UseFixedRoutingCoordShift","description":"With
      the current version of NDS the application can jump from one level to the other
      by using up and down references between links. But this concept is not suitable
      for Incremental Update, because a motorway geometry update causes the update of
      almost all up and down link references in the complete database. To solve this
      problem MapScape proposes the concept of \"Implicit Up and Down Links\" using
      intersections to jump between different levels. With the UseFixedRoutingCoordShift
      parameter this new behaviour can be enabled or disabled","datatype":"numeric","default_value":"0L","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ZIPCodesAsVillage","description":"This
      parameters controls how postalcode villages should be handled in the NDS compiler.
      By default, they are handled as required by the Elektrobit specification. This
      means that postal code villages are not included in the creation of road named
      objects, and that they are not included in the SC_PLACE selection criterion. If
      this switch is enabled, postal code villages are selectable as PLACE in the NVC
      tree and road named objects are split on postal code boundaries.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"IncludeIndiaLocalitiesInCityTree","description":"When
      this parameter is enabled, localities (city division) from the MapMyIndia data
      are added to the NVC tree for city search.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"AddDrawingOrderToLink","description":"When
      the AddDrawingOrderToLink parameter is enabled, a drawing order will be supplied
      for baselinks and geolinks.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UseDrivingSide","description":"","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"FillRangeIdList","description":"This
      parameter is to decide whether RangeIdList should be filled or not.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"EnableJV4APN","description":"With
      this parameter enabled, all fromlink-, tolink- and intermediatelinklists for Junction
      Views are stored using base/route links.","datatype":"numeric","default_value":"0L","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"EnableHarmanTweaks","description":"Enables
      some small tweaks for Harman.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"TileContentIndexLevel","description":"The
      TileContentIndexLevel parameter defines the levels on which the tile content indices
      should be enabled. The value is a comma seperated list of levels.","datatype":"string","default_value":"8","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"IncludeSpeechInfo","description":"This
      parameter controls the inclusion of Speech data in the NDS database.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"EnableCharacterMapping","description":"This
      setting controls if charactermapping must be carried out on name strings, especially
      for the name strings that are included in NVC trees. This charactermapping includes
      a lower-to-upper conversion and a replacement of all other special characters
      to spaces. When disabled, this work is not done. Consequently, alternate spellings
      are not generated either (umlaut variants, removed accents, etc...)","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UseRoadFTS","description":"This
      determines if the nameFtsTable is filled with road FTS information or not.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ProductName","description":"This
      parameter is to set the product name which will be present in the NDS database,
      e.g. ''productName'' in ROOT.NDS.","datatype":"string","default_value":"","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CopyrightName","description":"Sets
      the name of the copyright owner in GDF and SVF deliveries. In GDF deliveries from
      Mapscape to 3rd parties, the copyright owner can be set to a custom value using
      this parameter. Note that this parameter takes as default the value of SupplierName,
      but has no limit on string length. This parameter is relevant for all GDF output
      compilers, IDB2GDF and DH2GDF. The common use of this is: ''&lt;data supplier&gt;
      powered by Mapscape \u00a9''. For the NDS compiler, the placeholder <u>YEAR</u>
      will be recognised and replaced by the year at the moment of map compilation.","datatype":"string","default_value":"","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"BaselineMapId","description":"This
      parameter sets the baselineMapId of an NDS database. This value is present in
      the productDbTable of the NDS database.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"DefaultLaneWidth","description":"This
      parameter is used to add lane width values to the NDS database even if there is
      none in the source data. Unless you use the value of 0 decimeters, the width value
      will be added to all chains having lane information (such as number of lanes).
      If there is lane width source data for a given lane, then that will be used. Note
      that the value is given in decimeters (0-255).","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"NdsDbVersionId","description":"This
      parameter sets the versionId of an NDS database. This is a value which can be
      found throughout an NDS map, and is important in the context of map updates. Typically
      the version number is increased for every product successor.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"EnableExtendIncludeLinkReference","description":"The
      parameter EnableExtendIncludeLinkReference is used to indicate whether the EXT_INCLUDE_LINK_REFERENCE
      is filled. If this parameter is enabled, then the EXT_INCLUDE_LINK_REFERENCE is
      filled. Otherwise, the include-link-references will be stored in RoutingTile.RouteUpLinkList.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CreateIndexOnExtendPoiTableForKOR","description":"When
      this parameter is enabled indices will be created on the extended POI table. These
      indices will prevent duplicate search results for hotels in Korea.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"AddExtRoutingToTileBeforePU0313","description":"When
      this parameter is enabled table extendroutingtiletableafterpu0313 will be kept
      empty. Instead all information will be stored in the extendroutingtiletable table.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UseALPFillContinuedTurnRestriction","description":"When
      this parameter is enabled, all links that belong to a CONTINUED_TURN_RESTRICTION
      will have an attribute that contains the references to all links that belong to
      that CONTINUED_TURN_RESTRICTION.","datatype":"numeric","default_value":"0L","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UseALPFillTollEntry","description":"If
      toll booths are missing in the TCO table, this means that the driver needs to
      pay money driving through the area, but the price is unkown. When this parameter
      is enabled, these toll booth are still stored with TOLL_ENTRY. TOLL_ENTRY is stored
      guidanceAttributeMapList in routingAuxTileTable and TOLL_ENTRY is related to the
      link in the same way that TOOL_GATE_ID''s are related to links. TOLL_ENTRY is
      stored for every Entrance/Exit TG.","datatype":"numeric","default_value":"0L","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"FillHasVics","description":"Purpose:
      fill flexible attribute HAS_VICS indicating that link has traffic information.
      It is an Alpine specific requirement to have this information at links.","datatype":"numeric","default_value":"0L","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"EnableVics","description":"Enable
      processing of VICS data. This parameter can be used to enable/disable this feature.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"AddBMWStreetTypeAttribute","description":"When
      this parameter is enabled, a flexible attribute for the BMW street type will be
      added to the NDS database.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UseALPFillTransitionTurnRestriction","description":"Currently
      restrictions are grouped when they have similar time condition information. When
      the UseALPFillTransitionTurnRestriction parameter is enabled each restriction
      will be stored separately.","datatype":"numeric","default_value":"0L","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UseALPAddProhibitedPassage","description":"Currently
      a prohibited passage in two directions can be stored in the a single attribute
      describing both directions. When this parameter is enabled, this data will be
      duplicated to store the prohibited passage seperatly for each direction.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UseCHNRequirementToFillExtendTollAttributes","description":"","datatype":"numeric","default_value":"0L","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"MandatoryDTMOrthoLevelMetadata","description":"When
      the MandatoryDTMOrthoLevelMetadata parameter is enabled levelMetadata for orthoimages
      in the DTM will be added to the NDS map. With this data in place, the other building
      blocks can be compiled without DTM.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ForceLevel14Metadata","description":"Purpose:
      Force the addition of level 14 metadata to the level definitions, even though
      there is no actual BMD data present. This parameter only needs to be set for Alpine
      Taiwan NDS compilations. Since the Alpine applications always expects to have
      level 14 metadata available (with scale info), the application won''t function
      properly if this is not present (e.g. POIs are not properly displayed). However,
      in Taiwan NDS databases there is no actual level 14 BMD data available. So by
      default this level is not present in the level definitions. With the parameter,
      you force the NDS compiler to add this level anyway, regardless of the missing
      data.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"MergeNVCPrefixes","description":"This
      parameter controls the creation of NVC prefixes of more than one character. Merging
      prefixes reduces the space consumed by the NVC tree. Suppose for example that
      we have the words \u201cBelgium\u201d and \u201cBelgie\u201d. The NVC would look
      like this with the prefixes NOT merged:<br></br>\n=B --&gt; E --&gt; L --&gt;
      G --&gt; I --&gt; U --&gt; M<br></br>\n=                                      --&gt;
      E<br></br>\nWhen using merged prefies, it would look like this:<br></br>\n=BELGI
      --&gt; UM<br></br>\n=      --&gt; E<br></br>","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CreateDiffLeafNodeForDiffLanguage","description":"If
      the CreateDiffLeafNodeForDiffLanguage parameter is enabled seperate leaf nodes
      will be created in the NVC tree for each different language.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"AddSpecialNVCEntryForCompleteCitySearch","description":"When
      this parameter is enabled a special NVC entry will be created to support city-wide
      street search.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"EnableLaneConnectivity","description":"When
      this parameter is enabled, lane information provided by Teleatlas(TomTom) can
      be processed. This functionality is needed for Garmin products because for a lot
      of countries Teleatlas is selected as raw data supplier.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UseAdvisorySpeedLimit","description":"The
      UseAdvisorySpeedLimit parameter can be used to include advisory speed limits next
      to legal speed limits.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"APNDuplexLaneRemoval","description":"This
      parameter controls the execution of Alpine specific duplex lane removal. The duplex
      lane removal will remove lane information in the following cases. For complex
      intersection with INTERSECTION_CATEGORY Manuevor and Indescrible, all lane information
      is be deleted. For complex intersection with INTERSECTION_CATEGORY Intersection
      Internal, all lane information is deleted if all lanes are going straight on.
      For complex intersection with INTERSECTION_CATEGORY Intersection Internal, all
      lane information is kept if at least there is one lane is not going straight on.
      For none complex intersection, all lane information is kept, nothing need to be
      changed.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"EnableLaneBusOnly","description":"This
      parameter controls the inclusion of bus lanes in the NDS.","datatype":"numeric","default_value":"0L","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"TextureMapSupportTransparent","description":"When
      the TextureMapSupportTransparent parameter is enabled, the NDS map will support
      transparency for texture maps. Otherwise the transparency of the input images
      is lost during conversion.","datatype":"numeric","default_value":"0L","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"MileStoneName","description":"Purpose:
      Specifies the name of the milestone to be used as versionName in PRODUCT.NDS/versionTable.
      If omitted, versionName is set to current date (format YYYY-MM-DD).","datatype":"string","default_value":"","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"SingleContainedInHierarchy","description":"This
      parameter creates a single CONTAINED_IN path of relationships to the top of the
      admin hierarchy if it is set. The choice for one out of many is made random. Purpose
      is to fulfill an Elektrobit requirement. Note: If this setting is enabled, one
      should also enable the street merge mechanism. Otherwise, it makes no sense to
      have a single CONTAINED_IN hierarchy, because you will lose information. The other
      way around is possible: you can have streetmerge, but this setting disabled.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"GenerateEBSpeechXml","description":"Purpose:
      Elektrobit wants to have a XML side file containing the administrative structure.
      This XML file will be used by Elektrobit''s voice recognition software.","datatype":"numeric","default_value":"0L","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UseNodeForEcoRouting","description":"By
      default eco routing is created from traffic sign information. When this parameter
      is enabled the eco routing of korea is computed with the node information.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ModifyChineseCityNames","description":"This
      parameter enables several modifications to Chinese city names. Modification 1:
      Strip off the \"shi\" ending character for city names. For example: \"BeiJingShi\"
      should become \"BeiJing\". Modification 2: Strip off the \"special administrative
      region\" description from the names of Hongkong and Macau.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"PseudoTolerancePercentageScale","description":"","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"StoreCentroidInAttributeMap","description":"This
      parameter influences 3D displays. When driving on the road, the navigation shows
      3D models of buildings on both sides of the road. When the StoreCentroidInAttributeMap
      parameter is enabled 3D models of buildings are not displayed when a vehicle runs
      through the centroid point of the building. These centroid points of buildings
      are stored in AttributeMap NAMED_OBJECT_POSITION.","datatype":"numeric","default_value":"0L","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"disableFillLabelingHintBMD13and14Lvl","description":"Disables
      the labeling hints on level 13 and 14 when enabled.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"NotMergeBuildingArea","description":"In
      China data ,there are no names for buiding area, build areas will be merged in
      the MergeLanduse process. This can be avoided by using the NotMergeBuildingArea
      parameter to filter out the build areas in this process The feature class of building
      areas are: AREA_COMMERCIAL_BUILDING, AREA_INDUSTRIAL_BUILDING, AREA_PUBLIC_BUILDING,
      AREA_RELIGIOUS_BUILDING","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"MergeOceanPolygons","description":"Enables
      merging ocean landuse polygons.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"RouteNumbersOnly","description":"This
      parameter controls the inclusion of chain names in the NDS map. By default, all
      names are added to the NDS map. However, when this parameter is set, all streetnames
      from the given level onwards are discarded from the map. For example, when the
      value is \u201c8\u201d, BMD levels 0 through 8 will have either a routenumber
      as name, or no name at all.","datatype":"numeric","default_value":"8","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"BmdShowScenicRoutes","description":"Daimler
      requires Scenic roads to be displayed in specific styles. It''s not efficient
      to look up these attributes in routing tiles for map display purpose therefore
      the BmdShowScenicRoutes parameter can be enabled to provide Scenic as line attributes
      in the BMD.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"BmdShowAttrLevel","description":"Daimler
      requires IPD roads to be displayed in specific styles. It''s not efficient to
      look up these attributes in routing tiles for map display purpose therefore the
      BmdShowAttrLevel parameter can be enabled to provide IPD as line attributes in
      the BMD.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"IncludeRoadNumbers","description":"This
      parameter is used to control the inclusion of road numbers. By default road numbers
      are included, but they can be turned off for specific products like China.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"TranslateBmdPointToHamlet","description":"Landmark
      in NDH is BMD_POINT. In APN requirement the Landmark and symbols should be POINT_HAMLET.
      In EB and normal projects, the landmark and symbols should be filter out now.
      So for ALP project: use the \u201cBmdPointFeatureClassToHamlet = 1\u201d to convert
      the landmark and symbols as POINT_HAMLET. For EB and other projects: use the \u201cBmdPointFeatureClassToHamlet
      = 0\u201d to filter the landmark (In EB and other projects the symbols are not
      filter by this parameter, but by the parameter: BmdLanduseFilterFile)","datatype":"numeric","default_value":"0L","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CreateBmd3DIconPois","description":"By
      default 3D icons for POIs are created by the NDS compiler. When the CreateBmd3DIconPois
      parameter is disabled the 3D icon points that come from POIs will be removed from
      the BMD layer.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UseCityPopulationForUrbanAreaLandUsePopulation","description":"Urban
      area land-use elements are not only filtered by their size, but also by their
      population. When the UseCityPopulationForUrbanAreaLandUsePopulation parameter
      is set to 1, then the population data of the urban area land-use element is filled
      with the population data of the city the land-use element belongs to. This makes
      the appearance/disappearance of city faces consistent at the different levels
      of detail. See also the DHUnifyScaleMask process of the DHToolkit, which has a
      similar effect on the scalemask.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"SuppressBridgeInformation","description":"When
      the SuppressBridgeInformation parameter is enabled, the bridge flexible attribute
      will not be used by the NDS map.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"AddMoreSteetNameForTaiwan","description":"The
      AddMoreSteetNameForTaiwan parameter is used to add additional street names to
      layer 13 of the Basic Map Display.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"AddPopulationForBMDPoint","description":"Application
      should use different population to distinguish the province capital and prefecture
      capitals.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"MappingProvinceCapitalToCityCentreForVW","description":"Application
      need the province capital with population POPULATION_1M and prefecture capitals
      POPULATION_100K as POINT_CITY_CENTRE.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"AddCountryCapitalPopulationForVW","description":"Application
      need the true population value of country capital from POI.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UpdateScaleForGolfCourse","description":"By
      default golf courses are lost on the 500 m scale level. When the UpdateScaleForGolfCourse
      parameter is enabled, the scale mask of golf courses is set to 63, meaning that
      they will be visible up until the 5 km scale.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"DisableMergeLanduseLines","description":"By
      default all the landuse lines are merged. This greatly improves the visual result
      in higher levels, because data suppliers tend to deliver lines in chopped up parts.
      This could otherwise result in very suboptimal line simplification in higher levels.
      However, the MergeLanduseLines functionality may conflict with the ApplyCBS function.
      When the BMDLayer depends on the CBSLayer, this parameter should be enabled to
      avoid conflicts.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CreateBmdPois","description":"By
      default BMD annotations for POIs are created by the NDS compiler. When the CreateBmdPois
      parameter is disabled the annotations for POIs will be removed from the BMD layer.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CreateBmdCityCenterPois","description":"By
      default city_center/city_district_center for POIs are created by the NDS compiler.
      When the CreateBmdCityCenterPois parameter is disabled the city_center/city_district_center
      for POIs will be removed from the BMD layer.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UpdateFeatureCodeForKoreaCapital","description":"The
      UpdateFeatureCodeForKoreaCapital is used to change the featurecode and set AdditionalBmdFeatureClass
      for Seoul. This parameter is only used for Korea products.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"RemoveBMDNamesFromFeatcodes","description":"The
      RemoveBMDNamesFromFeatcodes parameter is used to removes BMD names for a set of
      feature codes. The value consists of a space or comma separated list of 4-digit
      dHive feature codes that will have their names removed in the BMD layer.","datatype":"string","default_value":"","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ExcludeDongDisplay","description":"If
      the ExcludeDongDisplay parameter is enabled, \u201cDong\u201d names will be removed
      from NDS Level 8 and Level 10 subscale 0.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"IncludeLiDisplay","description":"When
      enabled Area Name \u201cLi\u201d and Legal \u201cDong\u201d names in this Map
      should be displayed in Level 13.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"LevelXCapitalsAsNeighbourhood","description":"This
      parameter can be used to map city centers of a given admin area to POINT_NEIGHBORHOOD,
      instead of to the regular POINT_CITY_CENTRE featureclass. This behaviour was introduced
      for Garmin NTG5E China because of the strict display requirements. If the parameter
      is not set (or to its default value of 9999), the regular mapping to POINT_CITY_CENTRE
      happens. If it is set to a different value, all capital from the given admin level
      (and levels above) are mapped to POINT_NEIGHBORHOOD. For example, if the value
      is set to 8, all city centre POI''s for AA0 to AA8 are converted to POINT_NEIGHBORHOOD.
      The AA9 capitals are still mapped to POINT_CITY_CENTRE (or similar, like POINT_CITY_DISTRICT_CENTRE).","datatype":"numeric","default_value":"9999","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CityDistrictCentreAsBmdPoint","description":"Translates
      city district centres BMD points to featureclass BMD_POINT (where they would otherwise
      be coded as POINT_CITY_DISTRICT_CENTRE). This parameter has been introduced to
      give city district centres a special class for Garmin China maps.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"StorePoiHamletAsBmdHamlet","description":"As
      VW requirement Hamlets in CHN must be stored as BMD_HAMLET","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"HighwayExitAndIntersectPoiDisplayInBmd","description":"As
      VW requirement Highway Exit POI must be stored as POINT_ROAD_EXIT, Highway Intersect
      POI must be stored as POINT_ROAD_INTERCHANGE.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"HavingHighwayExitAndIntersectPoiInNDH","description":"Create
      Highway exit and intersect poi in PDH process.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ReserveSelfIntersectPolygon","description":"This
      parameter is used to keep self intersecting polygons.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CyclicBorderMinLength","description":"During
      compilation of NDS, this parameter controls the minimal length of any type of
      border line. The current BMD feature classes are considered: LINE_BORDER, LINE_BORDER_ORDER_0,
      LINE_BORDER_ORDER_1, LINE_BORDER_ORDER_2, LINE_BORDER_ORDER_3, LINE_BORDER_ORDER_4,
      LINE_BORDER_ORDER_5, LINE_BORDER_ORDER_6, LINE_BORDER_ORDER_7, LINE_BORDER_ORDER_8,
      LINE_BORDER_ORDER_9, LINE_BORDER_NON_ADMIN, LINE_BORDER_PHONE, LINE_BORDER_POSTAL,
      LINE_BORDER_POLICE, LINE_BORDER_SCHOOL, LINE_BORDER_DISPUTED, LINE_BORDER_DISPUTED_ORDER_0,
      LINE_BORDER_DISPUTED_ORDER_1, LINE_BORDER_TREATY_ * LINE, LINE_BORDER_TREATY_
      * LINE_ORDER_0, LINE_BORDER_TREATY_ * LINE_ORDER_1, LINE_SEA_BORDER_ORDER_0, LINE_SEA_BORDER_ORDER_1.
      When the length of a cyclic border line is below the given value, it is removed
      from all BMD levels. The default value is 0, which means that any cyclic border
      line is included, regardless of its length.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UseFeatCode4ScaleSubLevel","description":"","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"SetSAPASubScaleLevelForChina","description":"The
      subscalelevel for China annotation is not configured by BmdScaleSubLevelCfg_APN.csv,
      it comes from scalemask in NDH_LUE and is calculated by  CalculateSublev(), because
      level 10 has three subscale levels, but we can only store tow values in scalemask.
      As Alpine''s requirement, the SA/PA annotation shoud be displayed in subscale
      2 on Lv10, so we update the subscalelevel of SA/PA by configuration file.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"RemovePopulationFromDistrict","description":"","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"DistrictFeatureCodeToCity","description":"For
      Korea, District names will be converted to POINT_CITY_CENTRE.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"APN_CountryNameDisplayInKorea","description":"In
      APN Korea product, annotation of country name should be set as POINT_CITY_CENTER
      instead of POINT_HAMLET. Furthermore, it should only be displayed at Level 4 and
      6 with ScaleSubLevel 0.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"APN_DisplayMoreRoadsOnLevelTen","description":"Update
      scale sub level information in bmd_layer table for Road_Lines in Level 10 according
      to BMW''s requirement.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"Dual2SingleLineFromLevel","description":"Dual2SingleLineFromLevel
      defines the level from which the RDS negative directed chains will be removed
      in the BMD layer.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ProcessLinkTypeBySpeedCatagory","description":"The
      ProcessLinkTypeBySpeedCatagory parameter is used to set LinkType = 8 when SpeedCategory
      &gt; 7. This is mainly used in the NDS map for Taiwai.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"IntermediateFilterSTFResolution","description":"This
      is the filter resolution of all chains belonging to junction type other than JU_NO_JUNCTION
      (0). (e.g. junction types square, stf, parking place/building, roundabout and
      undefined area). The unit of the parameter is cm.","datatype":"numeric","default_value":"175","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"APN_AdminRoadClassDrawOrder","description":"This
      parameter is used to alter the road drawing order as requested by Alpine''s. When
      enabled the BMD road line should be stored as AdminRoadClass level in NDS data.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"SortLinkTypeAfterAdminClass","description":"The
      SortLinkTypeAfterAdminClass is used to control the ordering of sorting link types
      and admin road classes. When enabled the sorting will first be done on link types.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"RemoveFeatCodesInOcean","description":"This
      parameter controls which type of landuse elements should be removed if they are
      located inside an ocean polygon. The default is ofcourse to remove nothing. This
      parameter was introduced for the creation of a Turkey standalone NDS product,
      where the Turkish government has specific regulations with regards to islands
      display in the Mediterranian Sea. Removing the islands altogether is a way to
      comply to those rules. The value consists of a space or comma separated list of
      4-digit dHive feature codes.","datatype":"string","default_value":"","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"OrthoImagesMapLocation","description":"Specifies
      the location of a NDS ortho image map, to be merged with the current NDS map.
      The path must point to the ROOT.NDS of the ortho image map.","datatype":"path","default_value":"","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"OrthoImageSize","description":"This
      parameter determines to which size ortho images are scaled per tile. OrthoImageSize
      specifies the length in pixels of both the width and height of the resulting image.
      If the value is 0, no scaling is done.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"OrthoImageSupportTransparent","description":"Enables
      or disables transparent images in the ortho image map.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"OrthoImageAlignToTileBorder","description":"With
      this parameter enabled ortho images are required to be aligned to the tile borders
      precisely without transparent background. That is, tiles that are not fully filled
      with a valid image will be discarded in NDS database.","datatype":"numeric","default_value":"0L","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"RemoveCountryCodeFromNVCPhonenumber","description":"When
      the RemoveCountryCodeFromNVCPhonenumber is enabled, country calling codes are
      removed from telephone numbers in the NVC tree.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"OnlyOneNameStringInEveryRoadNamedObject","description":"Each
      road can consist of several links. These links may have a different number of
      names: except for the same offical name A, for example, some links have alternative
      names B, some links have no alternative names.  This can cause for a single road
      to have several namedObjects with same offical name A and different alternative
      names. When the application searches for a road name, it will list a long list
      of names including the redundant official names. To counter this behaviour, one
      can enable the OnlyOneNameStringInEveryRoadNamedObject parameter to enforce every
      road to only have one namedObject.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"HousenumberSearchBaseOnChainName","description":"By
      default house number search is based on chain id. When the name. When the HousenumberSearchBaseOnChainName
      parameter is enabled, house number search will be based on chain name.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"IncludePortugueseInEnglishPoiNvc","description":"There
      are three POI NVC trees: poinames, poienglishnames and poichinesnames. By default,
      Portugese POI''s are included in poinames. With this parameter enabled, the Portugese
      POI''s will be included in poienglishnames.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"RemoveEvcsFromNvcAndSetFlagForEvcs","description":"","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"PromoteSpecialCitiesInNVC","description":"When
      the PromoteSpecialCitiesInNVC parameter is enabled, the NDS compiler will collects
      so-called \u201cspecial cities\u201d. These cities in Asia will be promoted to
      the provincial level. Best known examples are BeiJing, ShangHai and TaiPei.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UseAA1ForNVCStateSelection","description":"For
      NVC selection, different selection criteria can be given. One of those is SC_STATE,
      which per default select states/provinces from USA/CAN for the NVC trees. These
      states are coded in dHive in the DH_COU table. Alternatively, one could select
      the AA1 entries from the DH_REG table to fill the SC_STATE NVC tree. When this
      parameter is enabled, this behaviour is triggered.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"AddIndirectRoadInCityNVC","description":"For
      city to road NVC trees, usually all roads belonging to a city are added to the
      tree, regardless of the fact that they are part of a suburb of that city. For
      some regions, this is not desired so with this parameter it can be controlled
      that only roads that are only belonging to the city are part of the city\u2192road
      NVC tree. The ones that also belong to a suburb are only provided in the NVC tree
      for the suburb.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"EnforceNVCDistrictSelectionForSpecialCities","description":"This
      parameter works together with the NVC configuration file, and was introduced for
      Garmin Taiwan maps. The requirement was that for a city object, the district needs
      to be selected first if this city is a \u201cspecial city\u201d (not part of a
      province, like Taipei). If it is a regular city under control of a county/province,
      district selection is not required. When set to 1, this parameter exactly creates
      this behaviour: one can have the path SC_CITY \u2013&gt; SC_ROAD in the NVC configuration,
      but when the parameter is set to 1, there will not be an NVC tree to select streetnames
      directly for a special city. One will be enforced to first specify the district.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"RoadToHousenumberInKorea","description":"","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"DividePoiNvcToEnglishAndChinese","description":"When
      enabled, the NDS compiler will generate two seperate NVC trees. One for English
      and the other for Chinese POI''s.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"FirstLetterOfPoiNamesInCountry","description":"","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UseAntiLabelingHints","description":"When
      enabled labeling hints for road names are avoided on sharp turns.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ReuseNDSIds","description":"Purpose:
      Reuse nds id''s of features that are not present in the new map. By default NDS
      id''s are never reused when using permanent NDS id''s (see UsePermanentNDSIds).
      Advantage: feature id''s are truly unique. A new feature will never have the same
      id as an another feature present in an older map. If the parameter is set to 1,
      then if a feature is not present in the map from the next (quarterly) release,
      its id can be reused for another feature. Advantage: NDS id''s are kept small,
      reducing the mapsize.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"StabilizeNDSIds","description":"Enable
      stabilization of id''s. This reduces the size of incremental updates. This ensures
      that for example if a POI or named object is present in both a Q1 and Q2 map then
      they are assigned the same POI id or namedobject id. As a result when computing
      the difference between the two NDS maps (using the ndsiff tool), there will be
      less differences and the resulting patch map will be smaller.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CreateCityListPriorityIndex","description":"Fill
      the SLI priorityIndex for cities from the list in the configuration file.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CreateCityPopulationPriorityIndex","description":"Fill
      the SLI priorityIndex for cities based on their population.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UseCrossRoadFTS","description":"","datatype":"numeric","default_value":"0L","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ZIPCodesAsIs","description":"This
      parameter controls if the villages with NameType ZIP_NAME must be converted to
      villages with NameType ZIP during the NDH2NDS conversion. If the switch is on
      5626 Eindhoven and 5626 Acht are merged into the entry 5626. Only entries inside
      a city are merged. This switch is needed to fullfill an Elektrobit requirement.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"PinyinCapitals","description":"Purpose:
      enforce First Letter Pinyin (FLP) generation in capitals, i.e. upper case","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"IncludeHousenumberNamedObjects","description":"This
      indicator controls the inclusion of house number (include address point and house
      number range) for NDS maps. This is typically only desired for China maps.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"IncludeADPNamedObjects","description":"When
      the IncludeADPNamedObjects parameter is enabled, ADP data will be used for named
      object creation.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"SetNoRelationToEveryRecord","description":"When
      the SetNoRelationToEveryRecord parameter is enabled, every Name record will have
      its relation type set to NO_RELATION.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"NotSplitForBothSideReferences","description":"Controls
      the splitting of links where one chain has Both-Side-References. When enabled,
      these links are split to R and L references. When disabled, these links will not
      be split.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"IncludeAddressCodeNameStrings","description":"When
      enabled AddressCodes will be added to NameStrings in NamedObjects.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"IncludeGovernmentCodeInNameStrings","description":"When
      enabled Government Code will be added to NameStrings in NamedObjects.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"SortAnnotationByPosition","description":"When
      enabled named objects are sorted by position for BMD annotation.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"Use3LevelAdminStructure","description":"This
      parameter is used to convert the order 9 featureclass to order 5. This parameter
      is mainly used for TaiWan data, where order 5 is missing.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CreateRoadNamedObjectBaseOnCity","description":"The
      CreateRoadNamedObjectBaseOnCity parameter is used to control creation of road
      named objects. When the parameter is enabled, road named object creation is based
      on the city. By default road named object creation is based on village.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"IncludeNamesOfGeneratedVillages","description":"Controls
      the inclusion of names of generated villages in the name layer.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"NamedObjectIncludePreferredAlternateName","description":"When
      enabled named objects include preferred alternate name string.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"FillPostCodeByPSTTable","description":"This
      parameter will enable postcodes to have a point location and that will enable
      route planning with postcodes.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ExcludeRampNames","description":"When
      enabled no ramp names are stored of roads with a different FormOfWay than motorway.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ProcessPostalCodesForCHN","description":"Purpose:
      enable processing postal codes data for China compilation.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"AddNamelessStreetsInAccessLocationList","description":"If
      this parameter is set, all nameless streets belonging to a certain administrative
      area, are added to the AccesLocationList of the place namedobject it belongs to.
      This enables the application to find these streets during address search. Background
      is that for example in India lots of houses (address points) are related to a
      nameless streets, which would otherwise be unaddressable.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ProcessProvincePosForCHN","description":"Purpose:
      enable processing Province Pos for China compilation.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"RemoveChinaMunicipalDistrictsVillage","description":"By
      default cities have a subdivision with the same name and \u5e02\u8f96\u533a appended
      to it (for example for BeiJing: \u5317\u4eac\u5e02\u5e02\u8f96\u533a). This translated
      to \u201cmunicipal districts\u201d. When the RemoveChinaMunicipalDistrictsVillage
      parameter is enabled, these namestrings will be removed from the NVC tree.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ConvertFullWidthToHalfWidth","description":"In
      UTF-8, there are wide representations of ASCII characters. These are often delivered
      in China or Taiwan data, but they do result in strange display behaviour on system
      (lots of whitespace around them). To avoid these strange effects, we convert these
      characters to their ASCII equivalent. For more information on full-width characters,
      check this page: http://en.wikipedia.org/wiki/Halfwidth_and_fullwidth_forms","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"OfficialNameNoRelationMode","description":"Bitmask
      to be used for setting the StringRelationType when the name is in an official
      language of the country. The seperate bits control which namedobjects should be
      considered. Bit 1: country, Bit 2: region, Bit 3: village.","datatype":"numeric","default_value":"0x01","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"StoreExpandedCardinalDirections","description":"This
      parameter controls the creation of additional streetnames based on a directional
      prefix. During compilation, it will create additional streetnames if a N/E/S/W
      prefix is present. This will be done in a language dependent way (different expansions
      for English, Spanish and French). For example: for the streetname \u201cS Chandler
      Blvd\u201d an additional name will be added \u201cSouth Chandler Blvd\u201d. Note
      that this works on directional prefixes; no additional name will be generated
      for \u201cS Street\u201d because \u201cS\u201d is the basename in this case.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ChainGlueingLengthLimit","description":"Defines
      the length condition for routing link glueing. Two routing links will not be glued,
      if they meet the any of following conditions: The two links are on level13 or
      (chain1.length + chain2.length)/1000 &gt; ChainGlueingLengthLimit). Otherwise
      if their other attributes are the same, they will be glued.","datatype":"numeric","default_value":"300","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ChainGlueingPointNumberLimit","description":"This
      parameter is used to control the maximum number of shapepoints. When the parameter
      is set, the glue line process will be cancelled if the number of shapepoints exceeds
      the parameter value.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"RemoveIntermediateDownlinks","description":"Purpose:
      Exclude all intermediate downlink references from the NDS map. This is also called
      downlink optimization. To save space, some lower level links may be dropped from
      this list as long as their successors can be uniquely determined as follows. Each
      lower level link listed explicitly defines a sequence of lower level links with
      the same functional road class as the first one. The sequence is terminated when
      one of the following conditions is true: The last link in the sequence ends at
      the target intersection of the corresponding upper level link or the last link
      in the sequence ends at an intersection connected with more than 2 links of the
      given road class or with at least one link of a higher class","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"GlueTOBInHigherLevels","description":"For
      NDS maps, this parameter controls whether chains which are part of a TOB relationship
      are glued in higher routing levels. Per default, the parameter is ON, since the
      TOB relations are mainly used for guidance purposes, and not for core routing.
      Hence, they are not needed in higher levels anymore and can be glued.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ExcludeEVCSFromExtendAZSearch","description":"","datatype":"string","default_value":"''''","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"RelevantVehiclesADAS","description":"Configures
      the vehicles types that will have ADAS information added. The parameter value
      is a bitmask that has the same values as the RelevantVehicles parameter.","datatype":"numeric","default_value":"H_NDH_CVA_VIMP_ALLCARS","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"IncludeWarningSignIcons","description":"This
      indicator controls the inclusion of warning sign icon for NDS maps. This is typically
      only desired for China maps.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"EnableRoutingUpLinks4AllLevels","description":"Currently
      RouteUpLinkList in routingTileTable has reference from a link to a link on next
      level and EXT_INCLUDE_LINK_REFERENCE in extendRoutingTile has a reference from
      a link to a link on a next and more distant level. With the EnableRoutingUpLinks4AllLevels
      parameter enabled, all beforementioned references are stored into RouteUpLinkList
      in routingTileTable.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ConvertFreewaysToControlledAccessRoads","description":"Freeways
      are \u201cMotorway-like\u201d roads, which are not marked officially as motorways
      while they share many of their charactersitics. With this parameter freeways can
      be converted to controlled access roads.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"MarkPedestrianRoadOpen","description":"By
      default pedestrian roads are converted to LINK_TYPE=PEDESTRIAN and TravalDirection=NO_DIRECTION
      in NDS. With this parameter enabled pedestrian roads will keep its travel direction
      so that it can be used for routing.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"FillRoutingAdminRoadClassWithNiAdminRoadClass","description":"DH_CVA_TYPE_NI_ADMIN_ROAD_CLASS
      can be created by an improvement process that can be used on a Rdf2DH dH. This
      means that Rdf2DH PdH meant for Alpine does contain DH_CVA_TYPE_NI_ADMIN_ROAD_CLASS
      and that a Rdf2DH PdH meant for Technisat does not contain this attribute. Nevertheless
      an Idbg2DH dH already contains the DH_CVA_TYPE_NI_ADMIN_ROAD_CLASS. Therefore
      the FillRoutingAdminRoadClassWithNiAdminRoadClass parameter exists that can toggle
      AdminRoadClass updating for NDS Creation. With this parameter different roadclasses
      can be created for Alpine an Technisat.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"FillRoutingAdminRoadClassIsTownRoadWhenNiAdminRoadClassIsNull","description":"Fill
      RoutingAdminRoadClass is Town Road when NiAdminRoadClass is null.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UseDeleteIndescribableJunction","description":"This
      parameter is used to delete the indescribable junction attribute of chains for
      route guidance.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UseRouteTypeAndFCForAminRoadClass","description":"When
      the parameter is enabled, adminroadclasses will be updated, when the nameroutetype
      of a chain does not belong to (1,2,3,4,5,6). The adminroadclass will be updated
      by the functionroadclass.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"RemoveFerryName","description":"Purpose:
      Remove ferries from the routing building block.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ClipLinkByTileBorder","description":"","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"EnableLengthAlongLink4Level13","description":"Controls
      the use of the flexible attribute \u201clength along link\u201d for the NDS map
      on level 13.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"APN_RailwayCrossingByWarningSign","description":"","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"APN_RailwayLengthFloatingPoint","description":"If
      the length attribute of a railway crossing link has a very small value, then it
      may cause problems due to floating point arithmetic. The APN_RailwayCrossingByWarningSign
      defines a threshold value. If a link length is smaller than the threshold, the
      compiler will abort the compilation. The value can be set to -1 to disable the
      check.","datatype":"numeric","default_value":"-1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"RailwayCross_start_end","description":"","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"IncludeCalculatedSpeedLimits","description":"When
      set to 1 calculated speed limits are processed as if they were legal speed limits.
      For NavTeq this is needed (derived speed limits). For Tom Tom this must not be
      done. This parameter is also available for NDS conversions. It controls the inclusion
      of calculated speedlimit as normal speedlimit.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"IncludeLaneGuidance","description":"Controls
      the inclusion of lane guidance in the NDS map.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"SetSpecialLaneArrowEmpty","description":"When
      enabled, the arrow direction for special bus lanes will be set to empty.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"HazardPositionAdd100MForKorea","description":"In
      Korea often a \u201csharp bend\u201d warning is coming up, which is too early
      and on places where a bend is but it''s not sharp. When the HazardPositionAdd100MForKorea
      parameter is enabled, the warning sign positions will be altered. When a link
      is over 100 meters, the compiler will shift the warning sign position to 100 meter
      after the current location. When a link is smaller than 100 meters, the compiler
      will shift the icon to the end of the current link.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"APN_StoreTrafficLightsAllLevel","description":"By
      default traffix lights are only stored on level 13 in the NDS map. When the APN_StoreTrafficLightsAllLevel
      is enabled, the traffic lights will be stored on levels 1 to 13.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"IncludeADPBuildingNames","description":"This
      parameter controls the inclusion of building names for address points. By default,
      building names are not included in NDS maps.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ProcessFlexAndFixedTollCost","description":"","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"DeleteTollBoothIcon","description":"Controls
      the inclusion of toll booth icons in the NDS database.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CalcSimpleSlopeInfoOnRamps","description":"Purpose:
      Select heuristic to use for simple slope estimation. The slope category is not
      published in Navteq data outside China. For countries outside China, and for data
      from other suppliers, road slope is estimated depending on the setting of CalcSimpleSlopeInfoOnRamps.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"TileBorderNodeLevel","description":"This
      parameter is used to disable glueing of nodes that are created for clipping the
      tile borders of level 8. The parameter specifies a level and the glueing will
      not be applied to the levels that are lower or equal to the specified level. Because
      the the glueing is only done on levels 4, 6, 8, 10 and 13, these are the only
      usefull values for this parameter.","datatype":"numeric","default_value":"4","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"EnableJV4TSD_IDBG","description":"With
      this parameter enabled, all fromlink-, tolink- and intermediatelinklists for Junction
      Views are stored using base/route links.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UsePoiGeoAccess","description":"Control
      the inclusion of POI geo access data in the NDS map.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ImportSpeedCamsFromTrafficSigns","description":"When
      enabled speed camera''s will be included in the NDS map.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"poiZoneExcludedFromPointCityCenter","description":"Currently
      some POI''s of GCZone/KDZone/AOI are converted to BMD.POINT(POINT_CITY_CENTER).
      When this parameter is enabled, these points will nog longer be converted to BMD.POINT(POINT_CITY_CENTER).","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"RemoveUnusedAdminNames","description":"This
      parameter controls the removal of named places without streets or POIs. Per default,
      these names are removed because they''re not interesting for most navigation products.
      However, for some regions it may be useful to use these for destination search
      (using the position of the place). When this parameter is set to 0, the places
      are retained.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"PromoteRegionToCountry","description":"When
      enabled all regions are promoted to Countries for full text search. This is mostly
      used in China compilations.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"PrependZeroToRichPOIPhoneNumber","description":"When
      enabled, the NDS compiler will add a leading zero to telephone numbers that don''t
      start with a zero.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UseSourceCatForPoiCatMapping","description":"This
      parameter controls which POI categories should be used in the POI mapping.","datatype":"numeric","default_value":"0L","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"FillPoiHamlet","description":"When
      the FillPoiHamlet parameter is enabled, Hamlets POI''s are only stored as BMD
      POINT_HAMLET. Hamlet POI''s will not be available in the POI building block.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"FillPoiFTSExonyms","description":"This
      parameter controls the inclusion of exonyms in POI full text search.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"FillPoiLogicalAccess","description":"Adds
      all logical access points as new POI''s and creates the relation between logical
      access points and along route POI''s.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ImportTrafficCams","description":"When
      enabled traffic camera''s will be included in the NDS map.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"FillPhonePOIIcon","description":"Controls
      the inclusion of phone icons for POI in the NDS map.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"SortBmdPointfixedOrder_NBT_KOR","description":"Define
      whether sort bmd point fixed order in nbt korea porject or not.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ProvinceFixedOrder_NBT_KOR","description":"Define
      the value of Province Fixed Order in nbt korea porject for sorting.","datatype":"numeric","default_value":"-1","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"LandmarksInPOIBuildingBlock","description":"Currently
      the 3D landmark icons are stores in the BMD Building Block (using POI_REFERENCE
      and ICON_REFERENCE). When the LandmarksInPOIBuildingBlock parameter is enabled
      3D landmark icons are stored in the POI Building Block using poiServiceLocationTable.iconSetId.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ApnPoiEntranceListForInternational","description":"By
      default the POI entrance list is supplied by a side database. This parameter can
      be enabled if the side database is not available and then the POI entrance list
      is generated from the parent-child relation of POI''s in the source data.","datatype":"numeric","default_value":"0L","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"RemapPOIAccessPoints","description":"Updates
      the mapping of access point POI''s so that they are easily recognizable for the
      applcation and are not treated as a regular POI. For example: if the entry to
      a POI is coded as parking place, it should not be treated as general purpose parking
      place.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ProjectPoiEntryPointOntoLink","description":"Normaly,
      CPO should be on link, but in some datasets, such as China RDF, CPO is not on
      link. In this case the ProjectPoiEntryPointOntoLink parameter can be enabled to
      project CPO onto link for such datasets.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UseAdditionalPoiLongDescription","description":"This
      parameter controls the filling of the POI long description attribute. When enabled
      the long description will be generated from the attributes Address, Open time
      and Fax.","datatype":"numeric","default_value":"0L","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"PoiCategoryIconAsMainIcon","description":"Sets
      the POI category icon as main POI icon for all POI''s.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"PoiFtsKeywordsOnly","description":"Controls
      the contents of the POI FTS. When enabled a XML product provided by NAV2 is used
      to fill the FTS tables in NDS.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"FillPoiFtsSubstitution","description":"Controls
      the contents of the POI FTS Substitution. When enabled a XML product provided
      by NAV2 is used to fill the posftsSubstitution tables in NDS.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"StrippingPOIPhoneNumberForFTS","description":"Controls
      the inclusion of POI phone numbers in POI full text search. When set to 1, the
      telephone numbers will be stripped of special characters and added to the searchtags
      for each POI. When set to 2, the special characters will be stripped and the telephone
      number will appear twice, one time with countrycode and one time without countrycode
      and with an additional leading zero.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"FillPoiFtsDM","description":"The
      FillPoiFtsDM parameter is used to fill the double metaphone tables for POI fuzzy
      search.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"SortPoiIdByMortonCode","description":"This
      parameter can be enabled to generate sorted POI ID''s. POI ID''s will then be
      generated based on their morton code and as such the namestrings of geographically
      close POI''s are also geographically grouped together in the table.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"FillCHICatNameString","description":"Parameter
      FillCHICatNameString is used to indicate whether the HighwayInOut CHI category
      name string should be added to table poiCatNameStringTable.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UseLocalNameOnly","description":"","datatype":"numeric","default_value":"0L","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"Use3DTemplates","description":"Purpose:
      Enable inclusion of 3D templates. By the use of templates the same model can be
      used many times in the NDS map, but with a different position, orientation and
      scale. For example the same 3D model of a tree can be referenced a lot of times
      in an enhanced city model. So usage of templates reduces the database size and
      also decreases resource use on the target (as the model needs to be in graphics
      memory only once). For backwards compatibility this feature is disabled by default.
      The parameter is only useful in case the NDS product contains enhanced city models.
      It is NOT needed in case the NDS product contains 3D landmarks only. Also the
      extended 3D building block of Alpine does not support templates (for now). In
      NDS the TemplateBodyGeometryTable will be filled. The nds.objects3d.bodygeometry
      blobs contain a reference to the TemplateBodyGeometryTable in case the bodyGeometryType
      equals BG_TEMPLATE_GEO_TYPE_POSITION, BG_TEMPLATE_GEO_TYPE_POSITION_ROTATION,
      BG_TEMPLATE_GEO_TYPE_POSITION_ROTATION_SCALE, BG_TEMPLATE_GEO_TYPE_POSITION_ARRAY,
      BG_TEMPLATE_GEO_TYPE_POSITION_ROTATION_ARRAY or BG_TEMPLATE_GEO_TYPE_POSITION_ROTATION_SCALE_ARRAY.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"Local3DModelCoordinates","description":"Sets
      3D model coordinate type.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UseVertexIndexes_3DObj","description":"Use
      vertex indexes to create triangle strips for OBJ models. Using the vertex indexes
      leads to a faster compilation, but this is not always possible due to the fact
      the models don''t have unique indexes.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UseVertexIndexes_3DCollada","description":"Use
      vertex indexes to create triangle strips for Collada models. Using the vertex
      indexes leads to a faster compilation, but this is not always possible due to
      the fact the models don''t have unique indexes.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"EnableTmcFilteringToUpdateRegions","description":"This
      parameter controls the execution of an extra filtering step for the content of
      TMC location tables. This is mainly useful for North America, where TMC tables
      do not follow state borders, while update regions generally do. To avoid a lot
      of unused TMC location inside one update region, this parameter can be set.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"enableTmcFilteringToLocDBNumber","description":"This
      parameter controls the execution of an extra filtering step for the content of
      TMC location tables. This is mainly useful for China''s updateRegions, where TMC
      tables do not follow udpate regions borders, while update regions generally do.
      To avoid one location DB number TMC location crossing a few update regions, this
      parameter can be set, but that also need depend on parameter EnableTmcFilteringToUpdateRegions.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UseSpecifiedNamesToGeneratePhoneticData","description":"By
      default the NDS compiler selects all names except for RelationType != TRANSLITERATION
      and RelationType != FIRST_LETTER_INPUT to generate phonetic data. When the parameter
      is enabled, the phonetic data is generated by specific set of names. The specific
      set of names is controlled by the parameters CollectPhoneticNamesForKorea and
      CollectPhoneticNamesForChina","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CollectPhoneticNamesForKorea","description":"Works
      in collaboration with UseSpecifiedNamesToGeneratePhoneticData. When both parameters
      are enabled, the phonetic names will be generated according to the following rules.
      Chain names: all the names with NameFormat in (NAME) and RelationType = NO_RELATION.
      Other names: The name with NameFormat = DEFAULT_OFFICIAL_NAME and RelationType
      = NO_RELATION.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CollectPhoneticNamesForChina","description":"Works
      in collaboration with UseSpecifiedNamesToGeneratePhoneticData. When both parameters
      are enabled, the phonetic names will be generated according to the following rules.
      Chain names: the first Chinese name and Cantonese name with NameFormat in (NAME,EXIT_NUMBER,ROAD_NUMBER)
      and RelationType = NO_RELATION. Admin names: the first Chinese name and Cantonese
      name with NameFormat = NAME and RelationType = NO_RELATION. Adp rsi names: the
      first Chinese name and Cantonese name with NameFormat = HOUSE_NUMBER_RANGE and
      RelationType = NO_RELATION.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"IncludeGeneratedPhonemes","description":"Controls
      the inclusion of generated phonemes in the NDS database.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"QryIsoCountryCode","description":"This
      parameter defines all countries that will include intersection prerecorded voice
      information. The parameter value is a comma seperated list of ISO country codes.","datatype":"string","default_value":"","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UseRoadHeightLevelForRoadZLevel","description":"In
      most of the source formats there are nodes registered at the points where two
      links cross in X and Y. Many of these formats register such nodes even if the
      two links do not intersect because of a difference in their height level, i.e.
      underpass or flyover. E.g. the mmi8 shape format (India) has no such stacked nodes.
      Instead, it declares height levels for the links. These can be stored in dh_cha.HeightLevel.
      In case UseRoadHeightLevelForRoadZLevel is set to 1, then the dh_cha.HeightLevel
      value to set the nds_flex_attribute.Road-Z-level instead of the dh_cha.GeomWGS84
      M-value.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"AddZLevelToClipPoints","description":"When
      the AddZLevelToClipPoints parameter is enabled, clipping points will be given
      the height value of the nearest shape point.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"EnableAdminRoadClass","description":"Controls
      the inclusion of the admin road class in the NDS map.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"EnableAdditionalBmdFeatureClass","description":"This
      parameter can be used to fill the flexible attribute ADDITIONAL_BMD_FEATURE_CLASS
      with subclass information of the annotations. If the parameter is disabled annotations
      will be stored as POINT_HAMLET.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"AddLandmarkIcon","description":"Controls
      the inclusion of land mark icons in the NDS map. When disabled city center icons
      will be used.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"EnableDtmBDAMPatternTile","description":"This
      parameter determines if the BDAM pattern tile table DtmBdamPatternTileTable is
      filled or not.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"FillRoadFTSFuzzySearchTable","description":"This
      determines if the NameFtsFuzzySearchTable is filled or not. The UseRoadFTS parameter
      needs to be 1 so there is data to fill into the fuzzy search table. Optionally
      the FtsFuzzyCostFile parameter can be set to define custom edit costs.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"FillPoiFTSFuzzySearchTable","description":"This
      determines if the PoiFtsFuzzySearchTable is filled or not. The UseFTS parameter
      needs to be 1 so there is data to fill into the fuzzy search table. Optionally
      the FtsFuzzyCostFile parameter can be set to define custom edit costs.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"SplitIntoBBFiles","description":"When
      enabled, the NDS database will consists of a seperate file for each building block.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"TableCommentFile","description":"Specifies
      the name of the file containing comments to be used in the NDS database tables
      (except ROOT.NDS or PRODUCT.NDS).","datatype":"path","default_value":"","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CreatePoiPhoneIndex","description":"Purpose:
      create index on field phone in poiTable.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CreatePoiRegionIdIndex","description":"Purpose:
      create index on field regionId in poiTable .","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CreatePoiServiceCatMortonCodeIndex","description":"Purpose:
      create index on the fields catId and mortonCode in poiServiceLocationTable.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CreatePoiIconSetIdIndex","description":"Purpose:
      create index on the fields IconSetId in poiServiceLocationTable.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"PageCompressionLevel","description":"Sets
      the page level compression for the NDS databases. The compression level must be
      between 0 and 9: 1 gives best speed, 9 gives best compression, 0 gives no compression
      at all.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"JvForceOpaqueBackground","description":"When
      the JvForceOpaqueBackground parameter is enabled all junction view imgae backgrounds
      are forced to be 100% opaque.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"JvUseCustomTransparentColor","description":"When
      the JvUseCustomTransparentColor parameter is enabled the pixels with RGB values
      0F000F are set to be transparent for arrow and signboard images.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"JunctionViewImageSize","description":"This
      parameter specifies the width and height of junction view images in the final
      NDS product. If no value is given, no scaling is applied. The value should be
      \u201d&lt;width&gt;x&lt;height&gt;\u201d, so for example \u201c600x480\u201d.
      Note that rescaling does not take the aspect ratio into account. Also SVG images
      will be scaled (and due to ImageMagick limitations) converted to PNG format, but
      with transparancy retained.","datatype":"string","default_value":"","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"DtmType","description":"This
      parameter determines with what type of data the DTM building block is filled with.
      The possible values are the same as for DtmDetailedType in NDS. Currently BDAM
      (0) and heightmaps (1) are supported. Heightmaps are the default. NDS disallows
      including both.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"DTMImageSize","description":"The
      format is \"levelV[1]:paramV[1];levelV[2]:paramV[2];levelV[3]:paramV[3];...levelV[n]:paramV[n]\".\n                    When
      this parameter is set, on levelV[k], the DTM image size is paramV[k].","datatype":"string","default_value":"","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UseDDS","description":"The
      useDDS parameter can be used control the storage type of ortho images.","datatype":"numeric","default_value":"0L","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"OrthoImageFormat","description":"This
      parameter controls the Satellite Image format.","datatype":"string","default_value":"PNG","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"LogDefaultAttributes","description":"Control
      the logging of default attributes.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"TMCGroupandSimpleToOne","description":"Defines
      the grouping of links on TMC features.group/simple to many\" to \"group/simple
      to one\" of links on TMC feature.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"FillPoiRegionId","description":"This
      parameter determines whether the poiTable.regionId field and PoiNamedObjectRelationTable
      must be filled. By default this is enabled for backwards compatibility. However,
      the regionId is probably not useful in a map and increases incremental update
      sizes. Because of this it is best to set the value to 0.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"PoiFtsFillExoSynonyms","description":"This
      parameter is used to include IATA codes for POI full text search.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"StoreTmcOffsetLength","description":"Controls
      the storage of TMC offset. When enabled the updated Alpine specification of TPEG
      will be supported. The new TPEG format will group two lengthAlongLink with the
      TMC code, one is for the distance which the TMC code affected, another is the
      distance from the start point of the link to the end point where the tmc code
      begin.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"SkipTriangulationOfUrbanPolygon","description":"Controls
      the triangulation of urban polygons. By default all polygons are triangulated.
      If the SkipTriangulationOfUrbanPolygon parameter is enabled, the triangulation
      of urban polygons will be skipped and the urban polygons will remain simple polygons.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"IncludeHousenumberAttribute","description":"The
      IncludeHousenumberAttribute parameter is used to add house numbers to named objects
      to extend the NVC tree.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"PoiFtsFillLanguage","description":"This
      determines whether the language code is filled into the poiFtsTable.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"PoiFuelConnectorWhitelist","description":"Points
      to a csv file containing the whitelisted POI fuel connector types. When no file
      configured, all POI''s are allowed.","datatype":"string","default_value":"","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"SetMountainPeakHeight","description":"Specify
      a dummy height (in centimeters) for all mountain peaks. If a map supplies this
      data, this parameter is overridden.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UseWebSafeColorsFor3D","description":"When
      set to 1, forces that colors for 3D data (landmarks, motorway junctions, 3D cities,
      ...) are stored as \"web safe\" colors. This means that the color palette is limited
      to multiples of 51 for each of the channels. This method can provide a workaround
      in case there are too many colors in the input data provided, so that it''s beyond
      the storage capacity of NDS. Note that this only applies to direct color values,
      so texture images are not affected in any way by this parameter.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"EnableLandmark3DLogging","description":"Enable
      detailed logging when writing the (template)bodyGeometry blobs. The full path
      of the model will be logged.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"StoppingPossibilityFlag","description":"When
      set to 1, the category of stopping possibility of Taiwan will be stored.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"OmitAttributeDefaultValue","description":"To
      prevent storing default attributes seperately for each feature, default attributes
      are only stored once for each tile. This behaviour can be enabled by enabling
      the OmitAttributeDefaultValue parameter.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"RemoveVillagetNameFromCityName","description":"If
      cityname includes villagename, remove villagename from cityname when this parameter
      is enabled.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"JvForceImageFormat","description":"Check
      if the requested image format from parameter JunctionViewImageFormat should be
      forced onto all junction view images as much as possible. When set to 0, SVG images
      for overlays (signs and arrows mainly) are not forced into another format. When
      set to 1, they will be.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"IncludeTollAttributes","description":"Controls
      the storing of toll attributes for the NDS map.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"LanguageDefinitionFile","description":"Defines
      the LanguageCode definitions. The following values are mapped. marcLanguageCode:
      MARC language code as defined in raw data. LanguageCode:        unique identifier
      of NDS language_code. isoCountryCode: ISO-3166-1 Alpha3 Country Code. isoLanguageCode:
      ISO-639-3 Alpha3 Language Code. isoScriptCode: ISO-15924 Script Code. isTransliterationOf:
      e.g. PinYin is latin transliteration of Chinese (Transliteration: representation
      of a letter/word using a characters from a different alphabet). For additional
      character chart codes the marc language code should be kept empty so that main
      languages are just joined once in the NDS compiler code at the end character chart
      codes are combined based on numerical LanguageCode.","datatype":"path","default_value":"LanguageDefinition_Default.csv","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"DefaultLanguageFile","description":"Defines
      the Default Language Code according to the country. The following values are mapped.
      isoCountryCode: ISO-3166-1 Alpha3 Country Code. CountryCode: unique identifier
      of NDS country code. LanguageCode: unique identifier of NDS language_code. marcLanguageCode:
      MARC language code as defined in raw data","datatype":"path","default_value":"DefaultLanguage_Default.csv","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"PoiAttributeConfiguration","description":"This
      configuration file defines the mapping of NDH attributes to NDS attributes. It
      also defines all the attributes supported in our NDS maps.","datatype":"path","default_value":"PoiAttributeConfiguration_Default.csv","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"PoiCategoryNamePhoTraConfigurationFile","description":"This
      configuration file contains the phonetics for POI categories.","datatype":"path","default_value":"PoiCategoryPhoTraConfiguration_Default.csv","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ExtendedPoiCategoryConfigurationFile","description":"This
      configuration file contains the POI category mapping.","datatype":"path","default_value":"PoiCategoryExtension_APN.csv","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"PoiRelationTableFilter","description":"This
      configuration file is used to filter out child POI''s for POI''s with a parent-child
      link. Only the POI''s with the specified category and subcategory are allowed
      as child POI''s.","datatype":"path","default_value":"PoiRelationTableFilter_Default.csv","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ExtendPoiServiceLocation","description":"Application
      limits the number of acquisition of POI icons to 100 icons per tiles when viewing
      at the 500m scale or higher, because database IO is the most significant performance
      bottleneck. Therefore only part of POI icons included in a tile are drawn and
      several POI icons are missing. With this configuration file a selection can be
      made of which POI categories should be shown on what level.","datatype":"path","default_value":"ExtendPoiServiceLocation_Default.csv","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ExtendPoiVirtualTileLevels","description":"","datatype":"path","default_value":"ExtendLevelConfiguration_Default.csv","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"PoiNDHCategoryListInStoppingPossibility","description":"This
      is the configuration file for category mapping of POI''s based on attribute values.
      This mapping is done after the real POI category mapping. That means a global
      NDS category such as Restaurant are already existing and are now mapped to a more
      detailed NDS category such as ASIAN, ITALIAN, CHINESE, ...","datatype":"path","default_value":"PoiNDHCategoryListInStoppingPossibility_Default.csv","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"PoiCategoryNeededUpdateIconSetId","description":"","datatype":"path","default_value":"PoiCategoryNeededUpdateIconSetId_Default.csv","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"TiTpegTecIconConfigurationFile","description":"This
      parameter gives the location of a configuration file describing a mapping between
      IconSet ids and icons. It''s currently only relevant for Alpine: their traffic
      event data has hardcoded IconSetIds in dHive, hence the need to specify them here.
      The columns of the CSV file are: (1)IconSet id, (2)IconSet description, (3)language
      code, (4)level, (5)collectionId, (6)2D, (7)3D, (8)Night, (9)Day, (10)Highlight,
      (11)Map, (12)List, (13)stacked, (14)on_route, (15)off_route, (16)Icon. IconSet
      id is the IconSetId. The IconSet description and language code aren''t used for
      anything. The remaining columns define an icon, see the IconTable and UsageTypeMask
      tables in the NDS schema for their meaning.","datatype":"path","default_value":"TiTpegTecIconConfiguration_Default.csv","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"TiTpegTecEventCodeIconConfigurationFile","description":"This
      parameter gives the location of a configuration file describing a mapping between
      TPEG-TEC event codes and icons. The columns of the CSV file are: EventCode, level,
      collectionId, 2D, 3D, Night, Day, Highlight, Map, List, stacked, on_route, off_route,
      Icon. EventCode and TableNumber define a TPEG-TEC event. The remaining columns
      define an icon, see the IconTable and UsageTypeMask tables in the NDS schema for
      their meaning.","datatype":"path","default_value":"TiTpegTecEventCodeIconConfiguration_Default.csv","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"TiTmcEventCodeIconConfigurationFile","description":"This
      parameter gives the location of a configuration file describing a mapping between
      TPEG-TEC event codes and icons. The columns of the CSV file are: EventCode, TableNumber,
      level, collectionId, 2D, 3D, Night, Day, Highlight, Map, List, stacked, on_route,
      off_route, Icon. EventCode and TableNumber define a TPEG-TEC event. The remaining
      columns define an icon, see the IconTable and UsageTypeMask tables in the NDS
      schema for their meaning.","datatype":"path","default_value":"TiTmcEventCodeIconConfiguration_Default.csv","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"BmdBoundingBoxFilterFile","description":"This
      file configures the bounding box filters for the LUE items. Per DHive feature
      code one or more bounding boxes can be given. Only items within their bounding
      box are copied to the output. Feature codes not configured will be also be copied.
      Format: DHFeatureCode, Left, Top, Right, Bottom, BB-type. BB-type:  0=filter;
      remove features that are not contained in a bounding box, 1=remove; remove features
      that touch the bounding box, 2=keep; keep the touching features (works with SkipOnThisLevel
      field). All coordinates are given in WGS84.","datatype":"path","default_value":"","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"FullTextSearchFile","description":"This
      is the configuration for the Full Text Search (FTS) POI criteria.","datatype":"path","default_value":"FullTextSearch_Default.csv","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"FtsFuzzyCostFile","description":"A
      Configuration file where the fields map directly to the NDS FtsFuzzyCostTable.
      See the NDS FtsFuzzyCostTable documentation version 2.1.1.10.8 and later. This
      table is optional when using fuzzy search. See http://www.sqlite.org/draft/spellfix1.html
      for full details on how it works and its relation to the full text search tables.
      The NDS formation specification contains details on its use within NDS.","datatype":"path","default_value":"FtsFuzzyCost_Default.csv","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"BmdFeatureClassMapping3DFile","description":"This
      is the configuration of mapping of feature classes of 3D landmarks to 3D featureclasses.
      The format is like this: enumName, FeatCode. The 3D feature class is given as
      the textual description. The NDS compiler will convert it to the correct numeric
      value. If a feature is not listed here, it is not mapped and thus not converted
      into NDS.","datatype":"path","default_value":"BmdFeatureClassMapping3D_Default.csv","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CountrySpeedLimitsFile","description":"This
      configuration file contains all country specific speed profiles.","datatype":"path","default_value":"CountrySpeedLimits_Default.csv","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CountryDefaultLaneWidthsFile","description":"This
      parameter describes which file should be used for the default lane widths per
      country.","datatype":"path","default_value":"CountryDefaultLaneWidths_Default.csv","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"SensitiveLanduseFile","description":"This
      is the configuration for the sensitive landuse for Garmin China. It expresses
      certain landuse elements which are sensitive for some reason. These elements are
      identified by their name/featcode, and are optionally translated into a new BMD
      featureclass and an indicator is set whether they should included like any other
      landuse feature, or that they should be included in all levels, no matter what.","datatype":"path","default_value":"","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ThreeDIconsFile","description":"This
      configuration file contains all 3dIcon paths to be processed during compilation
      The format is: Id (auto increment primary key), ThreeDIconLocation, ThreeDIconIdentifier.","datatype":"path","default_value":"ThreeDIcons_Default.csv","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"TimeZoneNamesFile","description":"This
      configuration file contains the mapping from timezones to timezonenames.","datatype":"path","default_value":"","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"TmcEventNamesFile","description":"The
      name of TmcEventNames csv-file used to fill out TmcEventNameTable","datatype":"path","default_value":"TmcEventNames_Default.csv","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"TmcEventTableFile","description":"The
      name of TmcEventTable csv-file used to fill out TmcEventTable","datatype":"path","default_value":"TmcEventTable_Default.csv","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"TmcSupplementaryInfoTableFile","description":"The
      name of TmcSupplementaryInfoTable csv-file used to fill out TmcSupplementaryInfoTable","datatype":"path","default_value":"TmcSupplementaryInfoTable_Default.csv","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"TpegTecEventNameFile","description":"The
      name of TpegTecEventName csv-file used to fill out TpegTecEventNameTable","datatype":"path","default_value":"TpegTecEventName_Default.csv","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"TmcEventCostsFile","description":"The
      name of TmcEventCosts csv-file used to fill out tmcEventCostInfoTable","datatype":"path","default_value":"TmcEventCosts_Default.csv","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"EvoExtensionReduc","description":"For
      NBT EVO, to control the content of Alpine extension table moved to standard table.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"FilterPoiUsingConfigFile","description":"For
      NBT and NBT EVO, to control whether to filter poi with file cfg_PoiCategoryDefinition.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"FilterSameFinalPOI","description":"Control
      whether to filter poi with the same POI by poi relationshiptype(H_NDH_REL_TYPE_SAME_POI)
      and same poi categroy.","datatype":"numeric","default_value":null,"mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"PoiNDSCategoryIdOfStoppingPossibility","description":"This
      configuration file is used to add the Stopping possibilites POI category and subcategories
      to the NDS map.","datatype":"path","default_value":"PoiNDSCategoryIdOfStoppingPossibility_Default.csv","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ExportSDSPoiAdditionalInformation","description":"To
      control whether export SDS POI additional information: phonetical info of brandnames,
      category names, etc and the reference to the existing POI SDS content.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UseCityFTS","description":"This
      determines if the nameFtsTable is filled with city FTS information or not.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UsePreferredAlternativeName","description":"This
      determines if for unique namedobjects of class road the usagetype will be promoted
      to PREFERRED_ALTERNATE_NAME or DEFAULT_OFFICIAL_NAME.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"SDSBlendInNamesWithoutPhonetics","description":"This
      determines whether in SDS oneshots files the records without phonetics should
      be blended in with those who have phonetics. Caution: In order to blendin and
      store those records without phonetics, the parameter SdsStoreEmptyPhonetics should
      be set to 1.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"SDSFilterBitmaskOnNameStringRelationType","description":"This
      parameter set the SDS filter bit mask for NameStringRelationType. It depends on
      the enumerations of Ndh2NDSGlobal::NameStringRelationType. Setting the bits incicate
      that the corresponding relation types will be filtered out! All possible values:
      SYNONYM 0x01, TRANSLITERATION 0x02, BASE_NAME 0x04, FIRST_LETTER_INPUT 0x08, EXONYM
      0x10, ALTERNATE_SPELLING 0x20, NO_RELATION 0x40.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"SDSFilterBitmaskOnNameFormat","description":"This
      parameter set the SDS filter bit mask for NameFormat. It depends on the enumerations
      of Ndh2NDSGlobal::NameFormat. Setting the bits incicate that the corresponding
      name formats will be filtered out! All possible values: NAME 0x001, TELEPHONE_NUMBER
      0x002, OFFICIAL_ABBREVIATION 0x004, ROAD_NUMBER 0x008, HOUSE_NUMBER 0x010, HOUSE_NUMBER_RANGE
      0x020, EXIT_NUMBER 0x040, MOTORWAY_INTERSECTION_NAME 0x080, ZIP_CODE_RANGE 0x100,
      MOTORWAY_EXIT_NAME 0x200.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"SpeechInputUseNoneTransMethodOnly","description":"If
      enabled only Transcription Method H_NDH_GENERIC_NONE is treated as a correct Transcription
      Method.\n                    The parameter is used to treat properly the situation
      when none phonetic for POI is provided. POI''s in that case have\n                    TransMethod=H_NDH_GENERIC_NONE.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"SliPriorityIndex","description":"Defines
      how the priority index of an sli table must be determined","datatype":"string","default_value":"","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"FillSliNameRotations","description":"Enable
      filling of sli name rotations.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"SliDisplayStringTransliteration","description":"Use
      transliteration as sli display string","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"SliSetUsageType","description":"Defines
      if the sli usagetype should be set.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"SliFillPositions","description":"Defines
      if the sliAllPositions table should be filled.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"SliDisplayStringBasedOnUsageType","description":"Defines
      if the displaystring should be finetuned using the usagetype for sli.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"SliChangeCaseMask","description":"Defines
      if the changeCaseMask be filled for the sli tables. This reduces sli size, but
      is slightly more complicated in usage in an application. If not filled, the DisplayString
      must always be set even if there is just a change in character casing.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"TreatRoadNumbersAsIdeogram","description":"Treat
      road numbers the same as normal ideograms. This means that two road names are
      considered unequal if the languagecode differs. As a result both the original
      and transliteration will end up in the named object and in sli. If this parameter
      is not set to 1, the languagecode will equal the original (chinese) languagecode
      in sli instead of the transliterated languagecode.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ReservePinyinTranscription","description":"To
      reserve the pinyin transcription in Phonetic building blocks, it should be switch
      on in NBT-EVO China Market","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UpdateCityPriorityBasedOnSettlementAndDisplayClass","description":"This
      sets the CityPriority based on the SETTLEMENT_CLASS and DISPLAY_CLASS variable
      attributes. Intended for use in NAR.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UpdatePopulationLevelBasedOnCityPriority","description":"This
      sets the PopulationLevel based on the DISPLAY_CLASS and CAPITAL_LEVEL variable
      attributes. Intended for use in NAR.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"FilterRoadOnLevelTenForKOR","description":"Fliter
      Road On Level Ten For Kor","datatype":"numeric","default_value":"1","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"AddJV2NDSForKanBan","description":"To
      control add a JV2.NDS for VW. Distinguish between Junction view and Kanban.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UseLaneCategoryAsLaneNum","description":"Defines
      if lane num which in routingtiletable is depend on lane category for Alpine''s
      requirement.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CalcAdminRoadClassForTaiWanNBT","description":"Defines
      if calculate AdminRoadClass using new method for Taiwan NBT. please refer to PR:
      34732","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UseLabelingHintsForCompleteLines","description":"Enable
      generation of labeling hints even if the labeling hint would cover the entire
      road?","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"LabelingHintsMaxAdminRoadClass","description":"Maximum
      admin roadclass for which labeling hints are generated (ie only hints will be
      generated if the admin road class is between 1 and LabelingHintsMaxAdminRoadClass.
      See nds.common.fixedattributes.AdminRoadClass in the datascript.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"SortIconAdminByNamePriority","description":"The
      admin icon related to diffrent administrators with diffrent level. The old logic
      sort them by villageid and get the minor one.\nBut for IDBG-based data,the minor
      one not always the minor level administrator.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"RemoveCreationAndModificationDateFromImages","description":"This
      parameters is used to remove the creation and modification data of images. The
      removal of this metadata is essential to incremental updates, because these dates
      will always differ between two NDS databases.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":false},{"name":"SplitTerrainData","description":"If
      enabled the the Terrain 3dObject data are redirected into a separate 3d Building
      Block, otherwise processed in OBJ3D as landmarks","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UpdateSliChangeCaseMask","description":"Update
      SLI ChangeCaseMask G_Tables .","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"FillPOIEnglishAddress","description":"Fill
      POI English Address for China.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"OnlyWaterAndIslandNeedLabelingHintsOfVW","description":"Only
      water polygons, Island polygons with names in Level 9 - 13 need labeling hints
      for VW.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UpdateFtsNameWithAbbrName","description":"Update
      Fts Name With abbreviation names","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ServiceAccessOnlyHighwayRestAreas","description":"Service
      Access Only Highway RestAreas","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"RemoveSpaceForSliLocationInputString","description":"Remove
      Space For Sli LocationInputString.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"FillSliProvincePriorityIndex","description":"Fill
      SLI GTable Province Priority Index.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"AddressFormatTableFile","description":"Poi
      address format can be distinguished by different config file.","datatype":"string","default_value":"","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"Split3DBuildingBlock","description":"If
      set the 3D Objects Building Block is split into several BBs (ECM2, MOJO, 3D Landmarks
      etc.) with the same. Otherwise (by default) only one block created","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"RemoveCriterionDFromSliCriterionCTable","description":"Remove
      CriterionD From SliCriterionCTable","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"KeepISOSubConCodeOriginal","description":"Keep
      ISOSubConCode to Original,not do ''determine 2-letter iso sub country code''.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"RemoveSuperfluousSpeedLimit","description":"Remove
      Superfluous Speed Limit.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"FillPostalCodeWithoutStreetName","description":"Fill
      PostalCode Without StreetName","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"FillNamePositionTableForVilInCHN","description":"Fil
      lName Position Table For Vil In CHN","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ProcessCityPriorityIndexForCHN","description":"Process
      CityPriorityIndex For CHN","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UseExtendedPostalCode","description":"Use
      ExtendedPostalCode","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"KeepAnnotationDisplayInAllLevelForCensorship","description":"All
      four main ocean name as BMD_POINT must display in level 5-13 for china censorship.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CreatePoiLayerPCVForCHN","description":"Create
      Poi_Layer_PCV For CHN","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"KeepVillageIdUniqueOfRoadForCHN","description":"Keep
      VillageId Unique Of Road For CHN","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ApnNotExportTollGateID","description":"If
      set the TOLL_GATEID attribute and TollCostTable will not generate, TOLL_ENTRY
      will be added to instad of TOLL_GATEID.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ApnExportTollGateIDToExt","description":"It
      will be export tollcost information to extend tollcost table if set to enable(1).","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CreateNewNameStringNotUseTollRoad","description":"Create
      NewNameString Not Use TollRoad.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UseAttributePointList","description":"Defines
      if the compiler use the ATTRIBUTE_POINT_LIST attribute(and related Adas attributes)
      in NDS target.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"FreewayToMostImportantAdminRoadClass","description":"The
      FreewayToMostImportantAdminRoadClass parameter defines whether adminRoadClass
      MOST_IMPORTANT_ADMIN_ROAD_CLASS is assigned to freeways.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"MatchPOIPhonemeWithTransName","description":"The
      MatchPOIPhonemeWithTransName parameter defines whether use the transliteration
      of language to match POI.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UseSourceImageResolutionForMostDetailedDTMLevel","description":"The
      UseSourceImageResolutionForMostDetailedDTMLevel parameter defines whether the
      source image resolution should be used for DTM. If set, the resolution set in
      the level config file will be overwritten by the source image resolution. Only
      the most detailed DTM level will be affected by this parameter.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"DTMResolutionIncreasingFactor","description":"This
      parameter indicates the scaling factor which has been applied to the DTM resolution.
      The value should be a power-of-two value.","datatype":"numeric","default_value":"2","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ExcludeArtificialMotorwayIntersectionName","description":"The
      ExcludeArtificialMotorwayIntersectionName parameter defines whether the artificial
      motorway intersection names should be included in SLI.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CreateRoadPriorityIndexForVWInCHN","description":"The
      CreateRoadPriorityIndexForVW parameter defines whether Create Road PriorityIndex
      like this:priorityIndex 200:all entries starting with a chinese character.priorityIndex
      100:all entries starting with a latin charachter.priorityIndex 0:all entries starting
      with a number","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UsePlaceNameAsPoiAddressCityName","description":"The
      UsePlaceNameAsPoiAddressCityName parameter defines whether the CityName of POI
      address should be replaced with valid PlaceName of the POI.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"SortPoiFTSTableByPoiName","description":"The
      SortPoiFTSTableByPoiName parameter defines whether Sort the PoiFTSTable By PoiName.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"JVUseRoadGeoLine4IDBG","description":"Control
      the JV storage for MIB2. Store road geo line information of fromlink and tolink
      in JV database.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"FillPOIAddressWithHouseNumType","description":"The
      FillPOIAddressWithHouseNumType parameter defines whether fill POI''s Address With
      HouseNumType.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"RemoveMotorwayIntersectionNameForCHN","description":"Remove
      Motorway Intersection Name For CHN:if the name not have office name,then not fill
      them in SLI.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ApplyMotorwayInterchangeNameOnFowMotorwayOnly","description":"Assign
      the artificial MOTORWAY_INTERCHANGE names only on FormOfWay MOTORWAY.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"NotExportingBMDForDTMOnlyConversion","description":"If
      it is set, then no BMD building block will be created. Is is useful for DTM only
      conversion, where BMD info are present only for DTM processing.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"FillSpeedCamsDirectionAttribute","description":"If
      it is set, Fill Speed Cameras Direction Attribute.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UseMultiphaseStabilization","description":"Enable
      multiphase id stabilization. This will try to improve on the id matching by using
      partial information to check if a feature that was marked as new is not actually
      equal to some feature that was identified as removed.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ForceBuildingFootprintAsSimplePolygon","description":"For
      some customers requesting triangulation, they require building footprints with
      height to be not triangulated but stored as simple polygon instead. This is a
      lot more convenient for the navigation software to generate building extrusions
      at runtime. This is for example the case for Navis in the NTG55H project.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ForceAdminAreasAsSimplePolygon","description":"For
      some customers requesting triangulation, they require admin areas to be not triangulated
      but stored as simple polygon instead. This is for example the case for Navis in
      the NTG55H project.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"EnablePVRMipMap","description":"When
      using PVR texture images, the use of mipmapping in the texture images can be requested
      by the customer. This parameter can be used to enable/disable this feature.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"APN_SetTollIndByAdminRoadClass","description":"When
      using this parameter, toll indicator is only kept for roads with admin road class
      1 and 2. This is a special requirement for South Korea product by Alpine. See
      CR-35404.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"OrthoImageType","description":"Type
      of orthoimages (satellite images) provided in this conversion. This parameter
      will set the value of OrthoImageTileTable.orthoImageUsageType accordingly.","datatype":"string","default_value":"DAY","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"EnableTransliterationForNonLatinLanguage","description":"Enable
      name string transliteration in POI FTS for non-latin European language (e.g. Russian).","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UseNodeNameTypeFilter","description":"Determine
      whether the node name should be filtered by the NodeNameType.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"MergeVirtualVillage","description":"Control
      whether or not to merge the virtual villages.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"EnableMinorRoads","description":"Control
      whether or not to set the flexible attribute START_OR_DESTINATION_ROAD_ONLY on
      roads where a DH_CVA record exists with AttrType H_DH_CVA_TYPE_LIMITED_ROUTING
      and AttrValue H_DH_CVA_VALUE_LIMITED_ROUTING_YES.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ForceSchoolZoneWarningBothDirections","description":"Control
      whether or not to force the reference type to ROUTING_LINK_BOTH_DIRECTIONS or
      ROUTING_ROAD_GEO_LINE_BOTH_DIRECTIONS for the flexible attribute WARNING_SIGN
      with attribute value SCHOOL_ZONE.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"SdsIncludeBasename","description":"Determine
      whether basename of ROAD/ORDER_9 should be included in SDS.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"RemoveAliasNameIfExistOfficeNameForCHN","description":"Determine
      whether Remove Alias Name If Exist Office Name For CHN.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"IncludeConsumptionAttributes","description":"Remove
      Unused Attributes For VW:CONSUMPTION_DOWN_EXCESS_SLOPE,CONSUMPTION_SPEED_VARIATION,CONSUMPTION_SPEED_DEPENDENCY.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"IncludeTrafficLightsNum","description":"Remove
      Unused Attributes For VW:NUM_TRAFFIC_LIGHTS.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"IncludeAverageSlope","description":"Remove
      Unused Attributes For VW:,AVERAGE_SLOPE","datatype":"numeric","default_value":"1","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"EnableSpecialProcessingForJapanAdminHierarchy","description":"Japan
      administrative hierarchy requires a special treatment in NDS compiler. The parameter
      enables this special processing.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"MergeRoutingRoadsAcrossTunnelAboveLevel","description":"This
      parameter controls from which routing level onwards we should glue across differences
      in tunnel information. In general, we do this for all levels above level 13 (hence
      the default value), but it can be limited to make it easier for the application
      (at the expense of a slight data increase).","datatype":"numeric","default_value":"13","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"MergeRoutingRoadsAcrossBridgeAboveLevel","description":"This
      parameter controls from which routing level onwards we should glue across differences
      in bridge information. In general, we do this for all levels above level 13 (hence
      the default value), but it can be limited to make it easier for the application
      (at the expense of a slight data increase).","datatype":"numeric","default_value":"13","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"APN_Taiwan","description":"This
      parameter indicates if it''s a Taiwan NDS data. Only EVO Taiwan should set this
      parameter to 1.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ContourMapLocation","description":"The
      ContourMapLocation parameter is used to pass the location of a contour product
      to an NDS conversion, so that the contour product is automatically included at
      the very end of the compilation. Note that contour data is compiled separately,
      and this parameter only takes existing NDS contour data; there is no compilation
      involved of the contour data when this parameter is supplied.","datatype":"path","default_value":"","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UsePoiSourceCategoriesAsBmdPoints","description":"The
      POI''s with SourceCategories listed in the parameter besides the normal POI processing
      will also end up as BMD-points in the NDS map. The value is a comma-separated
      list of SourceCategories (e.g. (\"1304, 1305\")). Default value is empty string
      -no SourceCategory is taken into account","datatype":"string","default_value":"","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ShapepointReductionFile","description":"This
      parameter points to a file containing the shape point reduction settings","datatype":"path","default_value":"ShapepointReduction_Default.csv","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":false},{"name":"UpdateRegionIdConfigurationFile","description":"You
      can assign update region ids to update region names in this configuration file.
      If such ids are available then these ids will be used instead of leaving their
      generation to the ndh2nds converter. Both the DHGateways and the Ndh2NDS conversion
      steps have difficulty with processing newly added update regions and can end up
      crashing. Using the UpdateRegionIdConfigurationFile can prevent such crashes.","datatype":"string","default_value":"","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"NdsResources","description":"The
      provided csv file is used to configure the resources read from the NdsResources
      folder into the CONFIG.cfg_NdsResources table. The values are supposed to be in
      line with the include/NdsResources.h file.","datatype":"path","default_value":"NdsResources_Default.csv","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CountrySetsFile","description":"This
      parameter points to a file containing country groups. Sets of countries can be
      defined in this file, for instance the set of countries belonging to the Schengen
      area.","datatype":"path","default_value":"CountrySets_Default.csv","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ProductIdFile","description":"This
      file configures the product id''s that should be used for each update region.
      Multiple update regions could have the same product id, because those regions
      should be grouped in a product.","datatype":"path","default_value":"","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"NDSOutputFormat","description":"This
      parameter controls the output format of the NDS compiler. Please consider that
      in alpha or product branch not all plugins are available.","datatype":"string","default_value":"","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"AddZipCodeRange","description":"The
      AddZipCodeRange parameter is used to enable zip code ranges. Zip code ranges can
      be used to uniquely identify cities. All cities, even with ambiguous names (i.e.
      \"Neustadt\") are listed on the first level enhanced with the next higher region
      (e.g. Bayern) and if still necessary the ZIP code in order to make the name unique.
      (i.e. \"Hausen, Bayern, 91353\"). The zip code range is used as zipcode to uniquely
      identify ambiguous city names. Zip code ranges are used to store precalculated
      zip codes for city and city district named objects. For a zip code range, all
      zip codes of a city or city district are collected. The identical digits are kept,
      whereas the non\u2010identical numbers are replaced by an \"x\" or another notation
      for arbitrary numbers. Example: The zip codes for Hattingen are: 45525, 45527,
      and 45529. This results in\nthe following zip code range: 4552x.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UseFTS","description":"The
      UseFTS parameter specifies whether the full text search tables must be filled
      and so whether full text search capabilities are available.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"IncludedBrandIconSizes","description":"The
      IncludeBrandIconSizes parameter defines a list of icon sizes that are included
      in the NDS map. The formats of IncludedBrandIconSizes string could be: \"16X16
      24X24\",  \"16x16,24x24\", or \"16X16:24x24:48X48\", etc. The multiplication operator
      MUST be either lowecase or uppercase ''x'', however the delimiter between different
      sizes can be any character.","datatype":"string","default_value":"","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"EnableBrandIconScaling","description":"The
      EnableBrandIconScaling parameter defines if brand icons of the requested size
      should be created by scaling from the largest icon available.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"PoiBrandIconConfigurationFile","description":"The
      PoiBrandIconConfiguration file links brand icons to POI''s. Each line contains
      a POI category, brandName and scaleLevel that link to an icon filename. Additionally
      several settings can be provided, i.e. day, night, 2D, 3D, highlighting...","datatype":"path","default_value":"PoiBrandIconConfiguration_Default.csv","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"LogicalAccessPOIs","description":"Parameter
      LogicalAccessPOIs is configurable to select any POI categories we want to relate
      to POICAT_LOGICAL_ACCESS_POINT. The default is an empty string; to select particular
      POI categories, a string like this: \"IN (3, 4, 5, 6, 7, 9)\" should be provided.
      This string should always begin with an \"IN\" followed by an open/close parens,
      and within the parenthesis, you give a comma-separated list of NDS category Id''s.","datatype":"string","default_value":"","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ExcludePoiFtsColumns","description":"This
      parameter specifies the POI FTS columns to exclude. The value is string containing
      comma separated column names that should be excluded.","datatype":"string","default_value":"","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"PoiCategoryDefinitionConfigurationFile","description":"This
      file contains the mapping from NDS POI categories to POI categories of the output
      format.","datatype":"path","default_value":"PoiCategoryDefinitionConfiguration_Default.csv","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"PoiCategoryMappingConfigurationFile","description":"This
      file contains the mapping from dHive POI categories to NDS POI categories.","datatype":"path","default_value":"PoiCategoryMappingConfiguration_Default.csv","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"PoiCategoryNameConfigurationFile","description":"This
      file contains the mapping from NDS POI category ID''s to their names.","datatype":"path","default_value":"PoiCategoryNameConfiguration_Default.csv","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"PoiCategoryIconConfigurationFile","description":"This
      file maps POI categories to POI icons.","datatype":"path","default_value":"PoiCategoryIconConfiguration_Default.csv","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"PoiCategoryPoiCategoryRelationFile","description":"This
      file defines parent-child relationships between POI categories.","datatype":"path","default_value":"PoiCategoryPoiCategoryRelation_Default.csv","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"PoiCatCollectionConfigurationFile","description":"This
      file contains POI category collection descriptors.","datatype":"path","default_value":"PoiCatCollectionConfiguration_Default.csv","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"POIRelationshipTypeAccessIsPreffered","description":"This
      parameters determines how to deal with data when the input data has multiple relationship
      type between the same POI''s.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"PoiCategoryMappingBasedOnAttrValuesFile","description":"This
      file maps POIs to specific categories based on attribute values. This mapping
      is done after the real POI category mapping. After the first POI category mapping
      all POI''s will have a global NDS categories, i.e. Restaurant. In the second POI
      category mapping step the existing categories are mapped to more detailed NDS
      categories, i.e. ASIAN, ITALIAN or CHINESE.","datatype":"path","default_value":"PoiCategoryMappingBasedOnAttrValues_Default.csv","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"PoiIconSetIdFile","description":"This
      file describes the preconfigured POI IconSetId''s. Iconsets can be assigned to
      NDS POI categories, dHive POI categories along with the POI brand name or a NDS
      POI attribute along with its value.","datatype":"path","default_value":"","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UseMetadataAddressFormatForPois","description":"Controls
      the use of metadata address formats for POI''s. When this setting is enabled all
      address formats to be used are read from the configuration and address format
      strings including all address parts and separators will be created. If the setting
      is disabled, then the default address format string is used: &lt;ROAD&gt;&lt;SPACE&gt;&lt;HOUSE&gt;&lt;COMMASPACE&gt;&lt;ORDER_8&gt;.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UseAddressSeparatorDefinitionForPois","description":"This
      parameter defines whether or not to use the address separator field of the poi
      address configuration file.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CreateHighwayExitPois","description":"The
      CreateHighwayExitPois parameter defines whether highway exit POI''s should be
      generated.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ImportAirPortShortName","description":"The
      ImportAirPortShortName parameter defines whether Import AirPort ShortName.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CreateHighwayIntersectionPois","description":"The
      CreateHighwayIntersectionPois parameter defines whether highway intersection POI''s
      should be generated.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"FillPoiAttributeBitMask","description":"Determines
      the use of the POI attribute bit mask. If this setting is enabled, then the POI
      attribute bit mask information will be filled.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ServiceAccessPOIs","description":"Parameter
      ServiceAccessPOIs is configurable to select any POI category to relate to LinkType
      SERVICE_ACCESS. The default value is an empty string, which means selecting no
      POI''s. An example of the parameter value is: \"3, 4, 5, 6, 7, 9\", a comma-separated
      list of NDS category ID''s.","datatype":"string","default_value":"","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"PoiBrandIconAsMainIcon","description":"The
      PoiBrandIconAsMainIcon parameter defines whether brand icons will be used as main
      POI icons.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CreatePoiServiceCatIndex","description":"This
      parameter controls the generation of indices on POI category for the poiServiceLocationTable.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"RemoveMultipleRangesPerTile","description":"This
      parameter controls whether remove multiple range in the PoiVirtualTileTable.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"PoiFtsFillPriorityWithIconsetId","description":"When
      this parameter is enabled the PriorityIndex field for POI FTS will be filled with
      the IconSetId of the POI.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"FillFtsCatHierarchy","description":"Fill
      the category in poi fts using the entire category hierarchy.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"WaterAreaToLineLevel","description":"This
      parameter specifies at which level water areas should be converted to lines, which
      is a size optimization. The conversion to lines will happen at the level specified
      and all levels above: e.g. when the parameter is set to 8 (default), it will be
      active at levels 8, 6 and 4. Please note that it will only affect area features
      with the feature type RIVER and CANAL. Setting it to a lower number than 4 (e.g.
      0) will effectively disable this conversion.","datatype":"numeric","default_value":"8","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"LueExpandedInclusionFilter","description":"Specifies
      the feature types that will be filtered when they have an expanded inclusion attribute.\n                            Features
      marked as expanded inclusion are features that could be left out for size constraints.\n                            The
      value is directly inserted in a SQL ''IN ()'' clause, so a comma seperated list
      of feature codes should be used.","datatype":"string","default_value":"","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"PolygonCutterFeatCodesFile","description":"This
      is the configuration for the polygoncutter as requested by Garmin. Since the Garmin
      software has a fixed drawing order based on feature code, cutting of polygons
      is unavoidable. Note that these featcodes come on top of the regular \"island/exclusion\"
      in water pairs that need cutting. The file lists pair of dHive feature codes that
      need cutting, first one is the outer one (e.g. water) and that will have a cutout
      after the process. The second one is the inner polygon which is used to determine
      which pieces need to be cut. The last column is a 0 or 1 indicating if the inner
      polygon must be kept or not.","datatype":"path","default_value":"","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CountryCapitalAsSeparateBMDClass","description":"This
      parameter allows for country capitals to be mapped to POINT_CITY_CENTRE_CAPITAL.
      This parameter is enabled by default, but the NDS version needs to support it
      in order for it to work.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"MergeBMDRoadsAcrossTunnelAboveLevel","description":"This
      parameter controls from which level onwards we should glue across differences
      in tunnel information. In general, we always do this, but it can be limited to
      make it easier for the application (at the expense of a slight data increase).","datatype":"numeric","default_value":"16","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"MaxNumberBMDFeatureShapePoints","description":"The
      MaxNumberBMDFeatureShapePoints controls the maximum number of shape points used
      to define area and line features. When set to 0 there is no limit on the number
      of shape points per feature.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ApplyPolygonCutter","description":"The
      ApplyPolygonCutter controls the use of the polygon cutter. The polygon cutter
      is used to cut out certain polygons out of others. A typical example is the cutting
      of water inclusion features.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"Include3DModelWithLandUseItemAtLevel","description":"Set
      the level for which landuse item with 3D footprint will be included for processing.
      If the level is set to -1, then the 3D models will not be included.","datatype":"numeric","default_value":"-1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"HighwayShieldPath","description":"The
      path to the highway shield image resources. Relative path definitions need to
      start with ./NdsResources/. An example is \"./NdsResources/GMN/HighwayShields/\".","datatype":"path","default_value":"","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"HighwayShieldConfigurationFile","description":"This
      is the configuration file for Garmin Highway shield data. Each line specifies
      the following elements: ISO Country code, State code, Prefix, FullName, NameRouteType,  ,
      ShieldId, PrefixOnSign, AlignX, AlignY.<br></br>\n                                ISO
      Country code: The country for which the shield is applicable. Must have an exact
      ISO country code, no wildcards or anything allowed.<br></br>\n                                State
      code: The 2-letter state code in countries where it is applicable (like USA).
      If this field is empty, it will not be taken into account for matching.<br></br>\n                                Prefix:
      The string representing the prefix for which the shield is valid. This must also
      include hyphens and all, the matching is 100% exact. It can also be empty, since
      there are several cases where a shield is known but a prefix is not used.<br></br>\n                                FullName
      The full name of the road to match against. If this one is given, the prefix is
      ignored. This is used in cases like the \"Trans Canadian Highway\"<br></br>\n                                NameRouteType:
      Same value as supplied by the data supplier. If given, it must match exactly.<br></br>\n                                ShieldId:
      Internal ID from Garmin. All png files with this ID in the name will be used as
      one icon set.<br></br>\n                                PrefixOnSign: Boolean
      value indicating if the roadnumber prefix should be displayed on the icon<br></br>\n                                AlignX:
      Percentage value indicator for horizontal alignment<br></br>\n                                AlignY:
      Percentage value indicator for vertical alignment<br></br>","datatype":"path","default_value":"","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"BmdRoadLineFilterFile","description":"This
      is the configuration of BMD road lines for different levels, as required by Garmin.
      Specific BmdFeatureClass (typically LINE_ROAD) can be excluded (value 1) or included
      (value 0) in the NDS in the specific country (ISOConCode) and on a specific level.
      If the rule applies to all countries. the ISOConCode should be set to \"---\".
      If the rule applies to all levels. the Level should be set to \"*\". If the rule
      applies to a range of levels (e.g. 10 to 13), the Level should be set to \"10-13\".
      If no rule is given for a specific featureclass, it is included on all levels
      for all countries. Otherwise said: if there is no rule to prevent inclusion of
      a feature, it is included. Note that LinkType and AdminRoadClass should always
      be given, no wildcards are allowed on those fields. This file is in addition to
      the general rule of creation of BMD levels according to their roadclass.","datatype":"path","default_value":"","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"TriangleType","description":"The
      TriangleType parameter specifies the storage mode for polygons in the NDS Basic
      Map Display Building Block","datatype":"numeric","default_value":"2","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"KeepOnlyERoadsWithLastDigitEqualsToZeroOrFiveOnLevel3","description":"The
      parameter controls a filter of roads on level 3. When activated the filter will
      only keep E roads with last digit equals to 0 or 5. Other road lines are filtered
      out.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ExcludeIslandCenterPOIsFromCountries","description":"The
      parameter specifies the list of countries for which to disable city district center
      POI on Islands being converted to a BMD point. The parameter value consists of
      a list of three-letter country codes, separated by comma.","datatype":"string","default_value":"","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"BmdFeatureClassMappingFile","description":"This
      file defines the mapping of landuse elements to Basic Map Display featureclasses.
      The BMD feature classes are specified as its textual description. The NDS compiler
      will convert it to the correct numeric value. Features not listed here, are not
      mapped and thus not converted into NDS.","datatype":"path","default_value":"BmdFeatureClassMapping_Default.csv","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"BmdScaleMaskMappingFile","description":"This
      file defines the mapping of landuse elements to BMD scalemask. The NDS compiler
      will convert it to the correct numeric value. The table created on this mapping
      file is used with a ''left join''.If the join fails, the feature is processed,
      but DH_LUE.ScaleMask is used as effective ScaleMask.","datatype":"path","default_value":"BmdScaleMaskMapping_Default.csv","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ExcludeParkingBuildingGeometry","description":"ExcludeParkingBuildingGeometry
      controls the exclusion of parking building geometries in the routing layer.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"BmdLanduseFilterFile","description":"This
      parameter is used to set the configuration file which is used to filter features
      in different levels. The file format is like this: <i>ISOConCode,  BmdFeatureClass,  Level,  Exclude</i>.
      This means the specific BmdFeatureClass is excluded (value 1) or is included (value
      0) in the NDS in the specific country (ISOConCode) and specific level. If the
      rule applies to all countries the ISOConCode should be set to \u201d\u2014\u201d.
      If the rule applies to all levels the Level should be set to \u201c*\u201d.","datatype":"path","default_value":"BmdFeatureLevelCfg_Default.csv","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"RemoveNDSHeightLevels","description":"Remove
      the heightlevel information from the chains at this bmd level and above (so the
      heightinformation from levels [0..RemoveNDSHeightLevels] are removed). By default
      nothing is removed. Advantage: more shapepoints can be dropped by shape reduction.
      Disadvantage: under/overpass can be wrongly displayed. This normally does not
      matter however for higher levels.","datatype":"numeric","default_value":"-1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"EnableJunctionViews","description":"Junction
      views are optionally skipped by a parameter. The proper mechanism is to work via
      the LevelConfiguration, but this parameter gives some more control fine-grained
      and easy control for experimental purposes.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UseLabelingHints","description":"This
      parameter controls labeling hint generation. This relates to the flexible attribute
      LABELING_HINT.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CBSSafetyMode","description":"With
      the safetyMode you can indicate if work arounds are required for bugs in Spatialite.
      Normally (A intersect B) union A/B = A. Unfortunately, this sometimes not the
      case in spatialite. This function creates an intersection for which this behaviour
      is guaranteed. Mainly needed for input data with rounding issues in the source
      data. For other cases parameter can be switched off to increase performance.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CountriesWithSwappedTopPrefixDisplayClass","description":"This
      parameter defines a list of countries that have a swapped road class prefix. In
      some European countries the top road classes are swapped. If these countries are
      included in this parameter and they have a ''E'' road as top road class, then
      their top road display classes are swapped.","datatype":"string","default_value":"","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"MergeRoadsAcrossIntersectionsInBMD","description":"For
      the basic map display the complexity of the map can be reduced. This can be done
      by removing nodes and gluing the chains incident to this node. By default only
      nodes with two incident chains are candidates for gluing. The parameter MergeRoadsAcrossIntersectionsInBMD
      allows for nodes with two or more incident chains to be candidates for gluing.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ProcessRiverCenterLines","description":"When
      this parameter is set, the river features (both polygons and lines) from the core
      data (dHive feature code 9202) will be replaced by their corresponding river center
      lines (dHive feature code 9207), if they are available. The value of this parameter
      indicates the lowest NDS (BMD) level to include the river center lines. For example,
      if the parameter is set to 7, river center lines will be included on level 7 and
      up (e.g. 7, 5 and 3). If the parameter is set to 0, river center lines will not
      be used. Note that the \u201cmatching\u201d of existing river features to their
      corresponding river center lines is only based on scale mask (display class in
      the input data). There is no reference available between both input products.
      So if river center lines are included in a product, please make sure to include
      all data sets of the river center line product for a specific update region, otherwise
      rivers may be missing from the end product!","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ExcludeTunnelThresholds","description":"The
      format is \"levelV[1]:paramV[1];levelV[2]:paramV[2];levelV[3]:paramV[3];...levelV[n]:paramV[n]\".\n                            When
      this parameter is set, on levelV[k], if the length of bmd line is shorter than
      paramV[k], discard tunnel attribute.","datatype":"string","default_value":"","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"DtmTileFilterFile","description":"The
      parameter is defined to remove unused tiles for DTM. For the specified layer,
      delete tiles which are not in the filter table.","datatype":"string","default_value":"","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"MergeBuildingWithHeight","description":"The
      parameter decide whether merge the BMD feature in one tile with the same BuildingHeight","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"BmdMcmTileFilterThreshold","description":"The
      parameter is defined to decide the mcm filter in pixels with area threshold","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"SplitClippedHNRanges","description":"When
      this parameter is enabled the NDS compiler will split up clipped housenumber ranges
      in parts so that no duplication takes place in the resulting NDS map.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CityMergeOverRegionBorders","description":"Check
      if we want to merge over region borders. The parameter value contains a space
      seperated list of ISO countrycodes that defines all countries that allow city
      merging over region borders.","datatype":"string","default_value":"USA","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"FilterOutFirstLetterInput","description":"The
      FilterOutFirstLetterInput parameter is used to filter out first letter input strings
      for europe deliveries. Different letters can resolve to the same character, which
      leads to duplicate values in the NVC tree. For example ascii uppercase a and the
      uppercase version of the Greek letter alpha both resolve to A. When this parameter
      is enabled, these duplicates will be filtered out.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"RemovePlacesWithNamelessStreets","description":"If
      a place contains ONLY nameless objects and nothing else (no named streets or POI''s),
      then the namedobject of that place is removed from the map data. This is to avoid
      having \u201cplaces without streets\u201d in NVC or SLI.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"MergeExtendedAndRegularPostalCodeNVCTrees","description":"When
      the MergeExtendedAndRegularPostalCodeNVCTrees parameter is enabled the extended
      and regular postal codes will be combined into one NVC tree.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"IncludeExitNumbersInNVCPath","description":"When
      the IncludeExitNumbersInNVCPath parameter is enabled highway exit numbers are
      included as NVC paths. This will allow searching for an exit as part of a street
      search.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"MaxNvcBlobSize","description":"This
      parameter specifies the maximum allowed size for NvcSubTreeBlob structures in
      the NDS end-product. NVC trees can be partitioned to meet this constraint. The
      given value is specified in bytes, the default being 256Kb.","datatype":"numeric","default_value":"256","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"IncludeChangeCaseMask","description":"The
      IncludeChangeCaseMask parameters controls the inclusion of the ChangeCaseMask
      structure in NVC.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"GenerateChoppedRotations","description":"This
      parameter controls if so-called \u201cchopped rotations\u201d should be created
      for NVC selection. A \u201cchopped rotation\u201d is a rotation of a string, without
      the rotated part included.<br></br>\n                                For example:
      \u201cAnthony Fokkerweg\u201d <br></br>\n                                \u2013&gt;
      GenerateChoppedRotations = 0 : Generates \u201cFokkerweg Anthony\u201d <br></br>\n                                \u2013&gt;
      GenerateChoppedRotations = 1 : Generates \u201cFokkerweg Anthony\u201d and \u201cFokkerweg\u201d
      <br></br>\n                                Note that this setting only has effect
      for NVC edges where the rotation setting is set to \u201cGENERATE\u201d.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"LanguageFilterFile","description":"The
      LanguageFilterFile defines for every language/country combination, if a language
      should be included or excluded. If for a given country/language combination no
      rule is found, the language will be included. One exception to this is language
      code ''UND''. This one will always be included, except a specific rule prevents
      it.","datatype":"path","default_value":"","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CountryExonymsFile","description":"This
      file contains country exonyms. Each line contains one exonym where a country code
      and country name are linked to a language code and the exonym for the country
      in that language.","datatype":"path","default_value":"CountryExonyms_Default.csv","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CityLicensePlateFile","description":"This
      file defines a mapping from licence plate city codes to city names. Adding these
      licence plate city codes to SLI will enable the routing destination to be selected
      by only supplying a few letters.","datatype":"path","default_value":"CityLicensePlates_Default.csv","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ISODetailedCountryCodeFile","description":"This
      file defines all ISO subcountry codes according to ISO 3166-2 along with the ISO
      country code and subdivision/state name. ISO subcountry codes define the country''s
      main subdivisions, such as provinces or states.","datatype":"path","default_value":"ISODetailedCountryCode_Default.csv","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CharacterMappingFile","description":"This
      parameter points to the configuration file for application of character mapping.
      Character mapping is executed on strings before they go into NVC.<br></br>\n                                The
      configuration file is setup as follows has the following columns: <i>LowerChar,
      UpperChar, VariantChar, CleanChar, Lower2UpperLanguage, Upper2LowerLanguage</i><br></br>\n                                LowerChar
      = The character in lowercase<br></br>\n                                UpperChar
      = The character in uppercase<br></br>\n                                VariantChar
      = Alternative representation of the uppercase character (typically ASCII or Latin-1)
      For example:  UE for \u00fc<br></br>\n                                CleanChar   =
      Clean representation of the uppercase character (typically ASCII or Latin-1) For
      example:  U for \u00fc<br></br>\n                                Lower2UpperLanguage
      = The language code for which te lower2upper mapping has to be used. If none:
      Use for all languages except if specific mappings are defined. Not implemented
      for CleanChar and VariantChar.<br></br>\n                                Upper2LowerLanguage
      = The language code for which te upper2lower mapping has to be used. If none:
      Use for all languages except if specific mappings are defined. Not implemented
      for CleanChar and VariantChar.","datatype":"path","default_value":"CharacterMapping_Default.csv","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"SqliteLocationInputFile","description":"The
      SqliteLocationInputFile parameter takes a CSV file as input. It contains definitions
      of the different SLI selection criteria, selection paths and table indices that
      need to be present in the map. There are different kinds of comma-separated tuples
      within the same file. Each line has a prefix like [CRITERIA] or [INDEX] that indicates
      its type.","datatype":"path","default_value":"SqliteLocationInput_Default.csv","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UsePointAddress","description":"The
      UsePointAddress parameter specifies for which countries address points must be
      generated. This is specified by a list of comma-separated 3 character country
      codes.","datatype":"string","default_value":"","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"NvcConfigurationFile","description":"This
      parameter gives the location to a configuration file for the NVC content of NDS
      maps. There are 2 possibilities:<br></br>\n                                Absolute
      file path \u2013&gt; The tool will use the path as is<br></br>\n                                Relative
      file path \u2013&gt; The tool will first look in <i>ndh2nds_configuration</i>
      first, then in the dakota environment<br></br><br></br>\n                                The
      configuration files links selection criteria to eachother to form a selection
      graph. The tool knows 3 predefined configurations:<br></br>\n                                The
      default configuration, conforming to the NDS Interop Spec.<br></br>\n                                The
      Elektrobit configuration, conforming to the EB Naming Spec.<br></br>\n                                The
      Alpine configuration, conforming to Alpine''s requests.<br></br><br></br>\n                                Besides
      the creation of the selection graph, there is also an indicator for the NVC tree
      to be a complete or incomplete index. A complete index contains the full strings
      that can be given as results. For example, if you have the strings ABCE and ABDF,
      the tree will contain the tuples A\u2192BCE and A\u2192BDF. An incomplete index
      only has the minimum information needed to be able to find a named object, so
      with the ABCE / ABDF example you get the tuples A\u2192BC and A\u2192BD. <br></br>\n                                If
      the disambiguation indicator is set, the meaning of the parent-child pairs is
      altered. Suppose you have a SC_ROAD \u2192 SC_PLACE relation. Without disambiguation,
      you first select a road and then a place, giving you a place as the result. With
      disambiguation on, you select a road, and if that is an ambiguous result you select
      a place to disambiguate, giving you the road as the result. <br></br>\n                                The
      rotation separator indicator can be GENERATE, ROTATION_SEPARATOR or NO_ROTATION.
      If GENERATE is used, all permutations of the words in a string are generated and
      included in the tree. For example, if you have \u201cHenri Wijnmalenweg\u201d,
      \u201cWijnmalenweg Henri\u201d can also be entered to get the same result. If
      ROTATION_SEPARATOR is used, the permutations aren''t generated, there are only
      markers included to indicate the rotation points. This has the advantage that
      the original name is retrievable and it saves space in the tree. Knowing the original
      name is only useful when working with complete indexes, since it allows retrieving
      the original name from the tree (you don''t want to return the rotated version
      since it is likely nonsensical), without needing to look it up from the associated
      named object. NO_ROTATION does nothing. <br></br>\n                                Currently,
      the following selection criteria are possible:<br></br>\n                                <table><tr><th>
      Value </th><th> Remark(s) </th></tr><tr><td> \u201d- - -\u201d </td><td> Special
      value, marking the entrypoint for NVC selection (typically as the parent for SC_COUNTRY)
      </td></tr><tr><td> SC_COUNTRY </td><td> </td></tr><tr><td> SC_PLACE </td><td>
      </td></tr><tr><td> SC_CITY </td><td> </td></tr><tr><td> SC_CITY_DISTRICT </td><td>
      Also refered to as SUBURB (but SC_SUBURB does not exist!) </td></tr><tr><td> SC_ROAD
      </td><td> </td></tr><tr><td> SC_CROSSROAD </td><td> </td></tr><tr><td> SC_POSTAL_CODE
      </td><td> </td></tr><tr><td> SC_POI_NAME </td><td> Used for POI selection by the
      name of the POI </td></tr><tr><td> SC_POI_PHONE_NUMBER </td><td> Used for POI
      selection by the phone number of the POI </td></tr><tr><td> SC_PROVINCE </td><td>
      Comprises all region levels </td></tr></table>","datatype":"path","default_value":"NvcConfiguration_Default.csv","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"IncludeIdeogramInNvc","description":"This
      parameter controls the inclusion of Ideograms in the NVC tree.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"KeepHyphenInNvcString","description":"Controls
      the use of character mapping on hyphens in NVC strings. The hyphen is mapped to
      a space by the default character mapping so the hyphen will implicitly be used
      as rotation indicator for NVC. This is complaint with TechniSat requirements,
      but TechniSat requirements also state that they want to keep the original hyphen
      in the NVC String. With this parameter set to 1 the hyphen will remain in the
      NVC string, while also being a rotation indicator.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CreateNvcForOfficialAbbreviations","description":"Controls
      the generation of NVC for official abbreviations","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"DisableNVC","description":"Enables
      or disables NVC.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CreateNamedObjectForAllCrossRoad","description":"Controls
      the generation of named objects during the build of crossroad NVC trees.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"NoNamedObjectForCrossRoad","description":"Controls
      the generation of named objects for crossroads but leaves the crossroads for NvcTree
      undisturbed.\n                            If enabled then it overrides the creation
      of named objects for cross roads (NameLayer) from the parameter CreateNamedObjectForAllCrossRoad.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"StoreNoPosInMiddleOfLongestRoad","description":"For
      each road a point in the middle is stored to define the position of its named
      object. By default this point lies on the middle of the longest chain of the road.
      When the StoreNoPosInMiddleOfLongestRoad parameter is enabled, the middle point
      will be set to the middle of the longest connected chain of the road.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"IncludeTransliterations","description":"The
      IncludeTransliterations parameter controls the inclusion of transliterations of
      named objects in the NDS map. The parameter is a bitmask with the following possible
      values:<br></br>\n                                Off                                                               =
      0x00<br></br>\n                                INCLUDE_TRANSLITERATIONS_FLAG_INCLUDE                             =
      0x01<br></br>\n                                INCLUDE_TRANSLITERATIONS_FLAG_REPLACE_NAMES_WITH_TRANSLITERATIONS
      = 0x02<br></br>\n                                INCLUDE_TRANSLITERATIONS_FLAG_USE_DIFFERENT_LANGUAGE_CODE         =
      0x04<br></br>","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CreateAltSpellsForAbbrevs","description":"Controls
      the generation of alternative spellings for official abbreviations for NVC.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"Roundabout2CrossroadMaxPerimeter","description":"The
      Roundabout2CrossroadMaxPerimeter parameter controls which roundabouts are converted
      to crossroads. Any roundabout that has a perimeter smaller then the Roundabout2CrossroadMaxPerimeter
      value will be converted to a crossroad. Routing guidance is improved by converting
      very small roundabouts to crossroads.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"SliRemoveCrossRoadStrings","description":"This
      parameter enables the removal of crossroad strings in SLI. The strings can be
      removed to achieve better compression rates.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"AddAllNamedObjectsToSliAllPositions","description":"This
      parameter determines whether to add all named objects to the sliAllPositions table
      or just the connected streets.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"SliClusterBaseNames","description":"This
      parameter determines whether to modify the SLI cluster ids to VW NAR specifications
      for base name usage.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"IncludeUpdateRegionHKMC","description":"This
      parameter determines to control the change about SLI can not find HK/MC.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"AddCountrySetClustersToSliCountry","description":"Specifies
      whether to add the COUNTRY_SET named objects as CLUSTER objects to the COUNTRY
      table in SLI, clustering the countries in the set.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"AddCountryClustersToSliState","description":"Specifies
      whether to add the COUNTRY named objects as CLUSTER objects to the SUB_COUNTRY
      table in SLI, clustering the states in the country.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"AddVillageClustersToSliPlace","description":"Specifies
      whether to add the AGGREGATED_NAMED_OBJECT named objects that aggregate the villages
      per country to the PLACE table in SLI.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ProhibitNotOpenToPublicChains","description":"Adds
      prohibition attributes for links marked as not open to public in DHive.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CoordXYOffsetScalingFactorForClothoids","description":"A
      scaling factor (scaling down) for clothoid CoordXYOffset. It is found in Mantis32567
      that some clothoid points are too far away from their reference point, and the
      workaround proposed by TSD is to scale CoordXYOffset down by a factor of 8. Currently
      this parameter is only set for TSD related maps. Default value is set to 0; meaning
      no scaling at all.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ClothoidDegreeOfFreedomOffset","description":"An
      offset value for clothoid degrees of freedom. It is found in Mantis37043 that
      for certain projects an alternative curvature coding is needed, which use is indicated
      by this offset.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"StoreFunctionalRoadClass","description":"When
      the StoreFunctionalRoadClass parameter is enabled the dHive FunctionalRoadClass
      is stored in NDS instead of the dHive RoadClass.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"MaxExternalTilesForFerry","description":"This
      parameter controls how many external tiles should be used for ferry lines on NDS
      routing level 13. For application performance, this can be limited to a certain
      number of tiles. The default value is 254, which is the technical limit of the
      NDS format.","datatype":"numeric","default_value":"254","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"IncludeADASAttributes","description":"This
      parameter controls which additional attributes for ADAS are added to the NDS map.
      These additional attributes are stored in flexible attributes: e.g. CLOTHOID,
      SLOPE and TURN_GEOMERTY_CURVATURE. The binary value of the integer byte control
      the settings for each attribute. The possible values are shown along with their
      binary value. Binary values can be combined to enable several features at the
      same time i.e. 52 (000000110100) will enable detailed slope, clothoid and gradient
      information. The different settings are shown in the table below.\n                            <table><tr><th>Decimal
      value</th><th>Binary value</th><th>Description</th></tr><tr><td>0</td><td>000000000000</td><td>ADAS
      is disabled</td></tr><tr><td>1</td><td>000000000001</td><td>All ADAS is enabled
      (default)</td></tr><tr><td>2</td><td>000000000010</td><td>Simple slope is enabled
      (not enabled by default)</td></tr><tr><td>4</td><td>000000000100</td><td>Detailed
      slope is enabled (default)</td></tr><tr><td>8</td><td>000000001000</td><td>Curvature
      is enabled (default)</td></tr><tr><td>16</td><td>000000010000</td><td>Clothoid
      is enabled (default)</td></tr><tr><td>32</td><td>000000100000</td><td>Gradient
      is enabled (default)</td></tr><tr><td>64</td><td>000001000000</td><td>Dummy adas
      is enabled (not enabled by default)</td></tr><tr><td>128</td><td>000010000000</td><td>Simple
      slope in auxiliary map is enabled (not enabled by default)</td></tr><tr><td>256</td><td>000100000000</td><td>AdasAccuracy
      is enabled (not enabled by default)</td></tr><tr><td>512</td><td>001000000000</td><td>node
      curvature is enabled (default)</td></tr></table>","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"MergeRoadsAcrossTMCInRouting13","description":"When
      the MergeRoadsAcrossTMCInRouting13 parameter is enabled links on level 13 will
      be merged regardless of their TMC information. When the parameter is disabled,
      then links with different TMC information will not be candidates for glueing.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"JVUseBaseRouteLinks","description":"When
      the JVUseBaseRouteLinks parameter is enabled Junction View shall use baselinks
      and routelinks for referencing instead of using baselinks and geolines.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UseShapePointInExtGradient","description":"The
      NDS standard precribes to fill in distance offsets in the EXTENDED_GRADIENT_DATA
      flexible attribute. With the UseShapePointInExtGradient parameter enabled shapepoint
      numbers will be used to fill the EXTENDED_GRADIENT_DATA flexible attribute.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"SignPostFilterFile","description":"This
      parameter points to a file that contains a blacklist of signpost names. These
      names are filtered out and will not be included in the final product.","datatype":"path","default_value":"SignPostFilter_Default.csv","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"RelevantVehicles","description":"This
      value indicates a vehiclesimpacted value for which the NDS map is compiled. If
      attributes apply to all the relevant vehicles, no vehicle groups are added in
      the NDS map to reduce storage space. Additionally, attributes that do not apply
      to any of the relevant vehicles are not included in the NDS map at all. This returns
      in an additional size reduction. The seperate values are listed below. Any combination
      of these values can be used as parameter value.\n                                <table><tr><th>Name</th><th>Hex
      value</th><th>Decimal value</th></tr><tr><td>Passenger cars</td><td><code>0x00000001</code></td><td>1</td></tr><tr><td>Residential
      vehicle</td><td><code>0x00000002</code></td><td> 2 </td></tr><tr><td>High occupancy
      vehicles (''carpoolers'')</td><td><code>0x00000004</code></td><td> 4 </td></tr><tr><td>Emergency
      vehicle</td><td><code>0x00000008</code></td><td> 8 </td></tr><tr><td>Taxi</td><td><code>0x00000010</code></td><td>
      16 </td></tr><tr><td>Public bus</td><td><code>0x00000020</code></td><td> 32 </td></tr><tr><td>Delivery
      truck</td><td><code>0x00000040</code></td><td> 64 </td></tr><tr><td>Transport
      truck</td><td><code>0x00000080</code></td><td> 128 </td></tr><tr><td>Bicycle</td><td><code>0x00000100</code></td><td>
      256 </td></tr><tr><td>Pedestrian</td><td>0x00000200</td><td> 512 </td></tr><tr><td>Truck
      with explosives</td><td><code>0x00000400</code></td><td> 1024 </td></tr><tr><td>Truck
      with gas</td><td><code>0x00000800</code></td><td> 2048 </td></tr><tr><td>Truck
      with flammable goods</td><td><code>0x00001000</code></td><td> 4096 </td></tr><tr><td>Truck
      with combustible goods</td><td><code>0x00002000</code></td><td> 8192 </td></tr><tr><td>Truck
      with organic goods</td><td><code>0x00004000</code></td><td> 16384 </td></tr><tr><td>Truck
      with poison</td><td><code>0x00008000</code></td><td> 32768 </td></tr><tr><td>Truck
      with radioactive goods</td><td><code>0x00010000</code></td><td> 65536 </td></tr><tr><td>Truck
      with corrosive goods</td><td><code>0x00020000</code></td><td> 131072 </td></tr><tr><td>Truck
      with other hazarous goods</td><td><code>0x00040000</code></td><td> 262144 </td></tr><tr><td>Truck
      with any hazardous goods</td><td><code>0x00080000</code></td><td> 524288 </td></tr><tr><td>Truck
      with goods with Poisenous Inhalation Hazard classification</td><td><code>0x00100000</code></td><td>
      1048576 </td></tr><tr><td>Truck with goods harfull for water</td><td><code>0x00200000</code></td><td>
      2097152 </td></tr><tr><td>Truck with explosive and flammable goods</td><td><code>0x00400000</code></td><td>
      4194304 </td></tr><tr><td>Truck over 3.5 tons, trailers and semi-trailers</td><td><code>0x00800000</code></td><td>
      8388608 </td></tr><tr><td>Passenger car with trailer</td><td><code>0x01000000</code></td><td>
      16777216 </td></tr><tr><td>Motorhome</td><td><code>0x02000000</code></td><td>
      33554432 </td></tr><tr><td>Motorcycle</td><td><code>0x04000000</code></td><td>
      67108864 </td></tr><tr><td>Sum of all flags</td><td><code>0x07ffffff</code></td><td>
      134217727 </td></tr><tr><td>Pcar + residential + hov</td><td><code>0x00000007</code></td><td>
      7 </td></tr><tr><td>Taxi + bus</td><td><code>0x00000030</code></td><td> 48 </td></tr><tr><td>All
      trucks (delivery, transport, hazardous goods)</td><td><code>0x007ffcc0</code></td><td>
      8387776 </td></tr></table>","datatype":"numeric","default_value":"134217727","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"AddStateRegionIdForRoadNumberPrefixId","description":"As
      requirement from TS, the RegionId in table RoadNumberClassPrefixTable should be
      mapping to province(state). Parameter AddStateRegionIdForRoadNumberPrefixId works
      when we need province countrycode in nds_rn_prefix.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"PsdRelatedVehicles","description":"Parameter
      PsdRelatedVehicles works the same way as RelevantVehicles, but it also includes
      passenger cars, trailer, trucks, buses and taxis. This parameter can be used to
      create vehicle restrictions for speed limits, overtaking prohibitions and lanes.","datatype":"numeric","default_value":"RelevantVehicles","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CloseNoRelevantVehicleRoads","description":"When
      enabled the traffic direction of roads with no relevant vehicles (VehiclesImpacted
      and RelevantVehicles) is set to none.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"PositionWarningSignWithValidityRange","description":"When
      the PositionWarningSignWithValidityRange parameter is enabled, then the WARNING_SIGN
      flexible attributes are grouped with a VALIDITY_RANGE to indicate their position.
      The validity range will describe a single point, rather than a physical range.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UseEcoRouting","description":"The
      UseEcoRouting parameter controls the inclusion of eco-routing. When UseEcoRouting
      is enabled eco-routing flexible attributes will be added in the NDS Map. Eco routing
      is based upon adas information. This means that the dHive ADAS tables must have
      been filled.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"MergeBMDRoadsAcrossBridgeAboveLevel","description":"This
      parameter controls from which level onwards we should glue across differences
      in bridge information. In general, we always do this, but it can be limited to
      make it easier for the application (at the expense of a slight data increase).","datatype":"numeric","default_value":"16","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"StoreBMDTunnelUpToLevel","description":"This
      parameter controls from which level onwards the basic map display attributes for
      tunnels that require a validity range are added to the NDS map.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"StoreBMDBridgeUpToLevel","description":"This
      parameter controls from which level onwards the basic map display attributes for
      bridges that require a validity range are added to the NDS map.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"StoreComplexFeatureNames","description":"Controls
      the inclusion of complex feature names in the NDS map. Complex features are features
      that consists of several basic features, i.e. motorway intersections or motorway
      crossings.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"SkipTmcEventNames","description":"When
      this parameter is enabled all TMC event names will be left out of NDS map.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"EnableStreetMerge","description":"This
      parameter controls how road named object should be generated in NDS maps. If set
      to 1, a CaRIN-like street merge will take place, otherwise a road merge will be
      carried out. <br></br>\n                                The difference between
      both methods is best explained with an example: Suppose we have 2 links inside
      an order-8 area. Both have the route number \u201cN1\u201d, but they have different
      streetnames \u201cX\u201d and \u201cY\u201d. RoadMerge will create 3 named objects
      (one for each name), and both links will have 2 references to named objects. StreetMerge
      will create 2 named objects, one for each link. Consequently, each link has one
      reference to a named object.<br></br>\n                                As is the
      case with CaRIN, the StreetMerge will always split named object at administrative
      boundaries.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"StoreRoadNumberReference","description":"This
      parameter is used during the filling of named object entries for routing and basic
      map display in the NDS map. If this parameter is enabled, then the flexible attributes
      of name references can contain a roadnumber named object reference attributetype
      if the name reference contains a road number. Else the default attribute type
      will be used: named object reference.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"StoreAdminHierarchyNameReference","description":"This
      parameter is used during the filling of named object entries for routing and basic
      map display in the NDS map. If this parameter is enabled, then the flexible attributes
      of name references can contain a admin hierarchy named object reference attributetype
      if the name reference is an admin hierarchy name. Else the default attribute type
      will be used: named object reference.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ExcludeTurnRestrictions","description":"For
      some particular intersections there is no, or not enough, restricted access in
      RDF source data from Navteq and its turn restrictions is filtered out in the tmp_tre_ids
      table. When this parameter is enabled, such cases will be fixed. All types of
      turn restrictions listed in the parameter are exluded from the NDS database. The
      values listed below are all possible values. The values can be combined in a single
      string with comma seperated values.\n                                <table><tr><th>Value</th><th>Code</th><th>Description</th></tr><tr><td>H_NDH_TRE_TYPE_BLOCKED_PASS</td><td>0</td><td>Blocked
      passage</td></tr><tr><td>H_NDH_TRE_TYPE_DIV_JUNCTION</td><td>1030</td><td>divided
      junction</td></tr><tr><td>H_NDH_TRE_TYPE_CALC_PROHIB_MAN</td><td>2101</td><td>Calculated
      prohibited manoeuvre</td></tr><tr><td>H_NDH_TRE_TYPE_RESTR_MAN</td><td>2102</td><td>Restricted
      manoeuvre</td></tr><tr><td>H_NDH_TRE_TYPE_PROHIB_MAN</td><td>2103</td><td>Prohibited
      manoeuvre</td></tr><tr><td>H_NDH_TRE_TYPE_GATES_EMERGENCY</td><td>9904</td><td>Gates,
      emergency veh.access</td></tr><tr><td>H_NDH_TRE_TYPE_GATES_KEYED_ACCESS</td><td>9908</td><td>Gates,
      keyed access</td></tr><tr><td>H_NDH_TRE_TYPE_GATES_PERMISSION_REQUIRED</td><td>9909</td><td>Gates,
      permission required</td></tr><tr><td>H_NDH_TRE_TYPE_PHYS_DIV</td><td>9911</td><td>physical
      divider restriction</td></tr><tr><td>H_NDH_TRE_TYPE_LEGAL_DIV</td><td>9912</td><td>legal
      divider restriction</td></tr></table>","datatype":"string","default_value":"H_NDH_TRE_TYPE_RESTR_MAN(),
      H_NDH_TRE_TYPE_GATES_EMERGENCY(), H_NDH_TRE_TYPE_GATES_KEYED_ACCESS(), H_NDH_TRE_TYPE_GATES_PERMISSION_REQUIRED()","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"RoadNumberPrefixIds","description":"This
      file configures the prefix info (like id and display class) for specific prefixes.
      Not configured prefixes will get on the fly generated id''s.","datatype":"path","default_value":"","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"RoadNumberStringPrefixSuffixParser","description":"This
      parameter allows you to configure the road number prefix-suffix parser to use.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ConvertLimitedAccessRoadsToControlledAccessRoads","description":"Limited
      Access roads are \u201cMotorway-like\u201d roads, which are not marked officially
      as motorways while they share many of their characteristics. When the ConvertLimitedAccessRoadsToControlledAccessRoads
      parameter is enabled, Limited Access roads will be converted to Controlled Access
      roads.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ControlledAccessAsMotorway","description":"If
      this parameter is enabled all Controlled Access roads will treated as motorways.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ResidentialTurnRestrictionsAsPassengerCarTR","description":"Some
      turn restrictions are stored as residential only turn restriction. These restrictions
      could be wanted, but could be filtered out by the RelevantVehicles parameter.
      Adding the residential bit in RelevantVehicles can be tricky in other places.
      Therefore the parameter ResidentialTurnRestrictionsAsPassengerCarTR was added
      that, when enabled, treats all turn restrictions having the residential bit set
      as passenger car restrictions.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"EnableRestrictedAreasMessage","description":"Safety
      restricted areas are a set of links marked in dh_cva by a H_DH_CVA_TYPE_SAFETY_RESTRICTED_AREA
      attribute. The marked links are to be avoided by the user of the map. When this
      parameter is Enabled, messaging about restricted areas/roads is enabled. This
      is custom behavior added to the attribute group containing PREFERRED_USAGE and
      AUTHORIZATION. See Mantis issue #40191 for details.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"EnableSpeedProfiles","description":"This
      parameter enables or disables the inclusion of speed profile data from dHive into
      NDS. When set to 0 (non-default value) any speed profile data present in dHive
      is ignored during conversion to NDS.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ExcludeRoadNumbersAtComplexIntersections","description":"","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"SlopeMatchingTolerance","description":"The
      intinial calculate distance tolerance value which the ADAS(slope) shape point
      matches the chain shape point.If the distance less then the value,the ADAS(slope)
      shape point will be stored,otherwise,the data will be discard.The value depend
      on the quality of ADAS(slope) and chain shape point.If the value too high,There
      are more ADAS(slope) shape points be stored. The value unit is degree/360 * 2^32.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"GetZlevelValueFromValidityRange","description":"This
      parameter control which table the z-level value get from.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ExcludePedestrianTrafficLight","description":"This
      parameter control whether remove the traffic light of Pedestrian.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"StreetTypeForTunnel","description":"The
      parameter is defined to decide whether a StreetType is a tunnel.","datatype":"string","default_value":"","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"LabelingHintsFilterPixels","description":"The
      parameter is defined to decide the pixel per meter for labeling hints filter.","datatype":"string","default_value":"","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UseLabelingHintsFilter","description":"If
      this parameter is enabled, labeling will not set to the too short road.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"DisableShapePointReductionForADASLink","description":"If
      this parameter is enabled, disable reduce the shape points for ADAS ramp links.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"FilterProhibitedPassageForConstructionRoad","description":"Two
      attribute groups with the same period, one with UNDER_CONSTRUCTION and one with
      PROHIBITED_PASSAGE, If this parameter is enabled, PROHIBITED_PASSAGE will be delete.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"DuplicatePOISDSEntries","description":"Controls
      if entries in the SDS files for POIs should have as many entries as there are
      POI''s for. For example, in the US you will find a lot of POIs called \u201cStarbucks\u201d,
      but by default only one entry is added to the SDS data because the phoneme is
      always identical. However, some customers (like Garmin) want to have as many entries
      as there are instances in the map.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UseSdsLanguages","description":"The
      UseSdsLanguages determines all languages to be used for SDS. If the parameter
      is not set, all languages are processed.","datatype":"string","default_value":"","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"GenerateGMNSdsFiles","description":"Alongside
      NDS maps, the compiler can generate side files for Speech Input. Originally Garmin
      has proposed a format for it, and called it SDS files. The content is either based
      on the CONTAINED_IN hierarchy (official admin structure) or on the NVC structure
      (more flexbile). With the first method, every street will be present once, but
      with the NVC-like structure, a street can be selectable from multiple places.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"GenerateSpeechInputFiles","description":"Alongside
      NDS maps, the compiler can generate side files for Speech Input. Originally Garmin
      has proposed a format for it, and called it SDS files. Now Nuance provides a specification
      which names the file IMF (Intermediate File). The content is now only based on
      the NVC structure (more flexbile). Under this method, a street can be selectable
      from multiple places.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"AddNdsFeatureIdToSDS","description":"If
      this parameter is enabled, then NDS feature id''s will be stored with every SDS
      record. The NamedObjectId will be added to the country and oneshot file. The POIId
      to the POI file.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"SdsAddBuildUpAreas","description":"The
      SdsAddBuildUpAreas parameter controls the inclusion of build up areas for cities
      in SDS files. There are two methods of build up area inclusion. The first method
      (value 1) adds the build up areas without duplication, as shown in this example:<br></br>\n                                13
      City1<br></br>\n                                14 DistrictA<br></br>\n                                15
      Road1<br></br>\n                                15 Road2<br></br>\n                                15
      Road3<br></br>\n                                14 DistrictB<br></br>\n                                15
      Road4<br></br>\n                                15 Road5<br></br>\n                                15
      Road6<br></br>\n                                13 City2<br></br>\n                                ...<br></br>\n                                The
      second method (value 2) adds the build up areas with duplication, as shown below:<br></br>\n                                13
      City1<br></br>\n                                15 Road1<br></br>\n                                15
      Road2<br></br>\n                                15 Road3<br></br>\n                                15
      Road4<br></br>\n                                15 Road5<br></br>\n                                15
      Road6<br></br>\n                                14 DistrictA<br></br>\n                                15
      Road1<br></br>\n                                15 Road2<br></br>\n                                15
      Road3<br></br>\n                                14 DistrictB<br></br>\n                                15
      Road4<br></br>\n                                15 Road5<br></br>\n                                15
      Road6<br></br>\n                                13 City2<br></br>\n                                ...<br></br>","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"SdsStoreShortNames","description":"The
      SdsStoreShortNames parameter controls the inclusion of short names in the SDS
      files.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"SdsStoreGeneratedPhonetics","description":"This
      parameter defines whether generated phonetics should be included in the SDS files.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"SdsRegionIdsInHeader","description":"The
      SdsRegionIdsInHeader parameter provides an option to enable region id''s output
      in the header of a SDS file. When enabled this will add the product id, update
      region id and the region id.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CreateGrammarCasesForSpeech","description":"Enables
      the creation of grammar cases for speech. These cases supply different grammars
      for the same sentences and the situations where they should be applied.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"OfficialLanguagesInHeader","description":"Option
      to enable official lanuage id''s in the header of a SDS file. When enabled this
      will add the official language id''s of a country in the header of the SDS file.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"SdsStoreEmptyPhonetics","description":"When
      this parameter is enabled empty phonetics will also be exported to the SDS file.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"SdsUseSuperCategoryData","description":"With
      the SdsUseSuperCategoryData parameter the use of super category data instead of
      short names can be disabled.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"SdsIncludeDelimiterTokens","description":"By
      default orthographies contain delimiters to separate the prefix, basename and
      suffix. With the SdsIncludeDelimiterTokens parameter enabled these delimiter tokens
      will not be inserted.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"SdsDefaultPhoneticLanguage","description":"If
      the SdsDefaultPhoneticLanguage parameter is enabled, phonetics with a unkown language
      code will be given the language code of the name of the phonetic. This setting
      is used to avoid SDS entry duplicates.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"SDSOnlyIncludeAddressable","description":"If
      the SDSOnlyIncludeAddressable parameter is set only addressable entries are included
      in the SDS data.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"SdsAddCrossroads","description":"Determines
      whether or not to add crossroads to Sds","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"SortIntersectionsByMortoncode","description":"When
      this parameter is enabled an additional column will be added to the routing_layer_nod
      table containing the morton code of an intersection. Intersections can then be
      sorted based on their morton code to allow fast retrieval or searching through
      intersections.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"TransliterationFilterFile","description":"This
      is the transliteration configuration file. Each line contains the following elements:
      ISO Country code, Language Code, Include and Updateregion name. This way, for
      every country/language combination, a statement can be made whether a transliteration
      should be included or excluded. If for a given country/language combination no
      rule is found, the transliteration will be treated acoording to the global parameter
      setting \u201cIncludeTransliterations\u201c. It is also possible to use wildcards
      for country or language, and rules can piggyback onto eachother. For example the
      global settings can say to exclude transliterations for all countries/languages,
      and have per country exceptions. It also possible to use the wildcard for country
      code. This can be useful for features for which the country code is not available.","datatype":"path","default_value":"","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"AvoidRNPrefixAsDefaultOfficialName","description":"In
      NDS maps, the DEFAULT_OFFICIAL_NAME has special value inside a namedobject, so
      it''s very critical that this one is set correctly in case multiple names are
      stored inside a namedobject. This parameter can slightly influence this, in that
      sense that certain types (identified by prefix) of roadnumbers can be made of
      lower importance. An example are the K- and L-roads in Germany, which are not
      very well known by the general public. For these roads, it may be better to use
      a streetname if that''s available (even in rural areas where generally roadnumbers
      are prefered over streetnames). The value of this parameter is easiest explained
      by an example: suppose the K- and L- roads in Germany, and the E -roads in the
      Netherlands need to be avoided as default official name as much as possible. That
      could be done with the following setting: parameter AvoidRNPrefixAsDefaultOfficialName
      \u201cDEU#K,L NLD#E\u201d. So, for every desired country, there can be a string.
      Every country-related string is separated by a space. Then, inside a country group,
      the ''#'' character separates the ISO country code from the prefix(es), and all
      prefixes are comma separated.","datatype":"string","default_value":"","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"PreferRNPrefixAsDefaultOfficialName","description":"In
      NDS maps, the DEFAULT_OFFICIAL_NAME has special value inside a namedobject, so
      it''s very critical that this one is set correctly in case multiple names are
      stored inside a namedobject. This parameter can slightly influence this, in that
      sense that certain types (identified by prefix) of roadnumbers can be made of
      higher importance. An example are the B-roads in Germany, which are very well
      known by the general public and are sometimes prefered by the customer even inside
      urban areas. See also the parameter AvoidRNPrefixAsDefaultOfficialName which is
      the exact opposite of this parameter.","datatype":"string","default_value":"","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"AddOneDayToDateRangeOfYearsEndDateHack","description":"Let''s
      take the example of the Apr 1 - Oct 31 time interval used in NDS, e.g. the dates
      in between a road is under construction. In order to stay backwards compatible,
      NTG5E and ALP need to use the Apr 1 - Nov 1 interval, of which the Nov 1 is incorrect.
      They can use the incorrect end date value by setting parameter AddOneDayToDateRangeOfYearsEndDateHack
      1. The rest of the products can use the correct Apr 1 - Oct 31 time interval.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"MergeADPOnSamePosition","description":"This
      parameter controls whether different address points from source data, that are
      located on the same geographical position, should be merged into a single address
      point feature (with multiple names) in an NDS map. By default, every address point
      from source data becomes a separate address point in NDS, typically with a single
      name. With this parameter enabled, housenumbers on the same position will become
      a single NDS address point, with multiple names so that none of the addresses
      are left out.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CreateNDSIndices","description":"Boolean
      indicator to control the creation of NDS defined SQL indices. From NDS 2.1.1.10.8
      and 2.3 onwards, there are several SQL indices defined in datascript, but they
      are not always requested by the customer. With this parameter, their creation
      can be disabled. Default is set to 1, so the indices are created because most
      of them are highly recommended.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"JunctionViewImageFormat","description":"Requested
      output format for junction view images. SVG images for signs and arrows are not
      affected by this parameter, unless the parameter JvForceImageFormat is used. Also,
      if the requested format is not fully suitable, format conversion will not take
      place. Most important scenario for this is conversion to JPEG from an image that
      has transparency.","datatype":"string","default_value":"PNG","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"RemoveHNRangeIfAdpPresent","description":"When
      creating NDS maps, information from housenumber ranges and from address points
      can be present at the same time. With this parameter, one can control the inclusion
      of range information for the case where address points are present. More precisely:
      when this parameter is set to 1, range information is not included for a given
      side of a specific link, if that link side also has address point information.
      Reasoning here is that the address point information is superior to the range
      info, so it renders the range information obsolete. For storage optimisation,
      it should thus not be included.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"IncludeBaseNames","description":"This
      indicator controls the inclusion of basenames for NDS maps. This is typically
      only desired for Northern America maps.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"IncludeAlternateSpellingInNO","description":"This
      boolean switch controls the inclusion of namestrings with relationtype \u201cALTERNATE_SPELLING\u201d
      in named objects. When enabled, these will be included, when disabled, they won''t.
      Note that when disabled, the alternate spellings are still included in the NVC
      index! This parameter only controls the inclusion in named objects.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UseExplicitAttributes","description":"The
      UseExplicitAttributes is used to determine where the routing FixedRoadAttribute
      should be included. The routing FixedRoadAttribute can be included in the FixedRoadAttributeSetList
      or in RoutingAttributeInfo.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"EnableTilePattern","description":"The
      EnableTilePattern parameter is used to enable tile pattern creation. A tile pattern
      is a tile that represents multiple Basic Map Display tiles that are equal. Within
      the NDS map an index is used to refer to the tile pattern. This way data redundancy
      can be avoided.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UsePermanentIds","description":"When
      id stabilization is enabled, use the permanent id''s from the data supplier for
      stabilization. This is only possible if permanent id''s have been provided that
      are stable across data releases. Because of this the parameter defaults to 0 (disabled).
      In that latter case id''s are generated based upon for example name string or
      position.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UsePoiPermanentIds","description":"When
      id stabilization is enabled (see <a class=\"wikilink1\" href=\"/dokuwiki/doku.php?id=dev:conversionmanual:stabilizendsids\"
      title=\"dev:conversionmanual:stabilizendsids\">StabilizeNDSIds</a>) and UsePermanentIds
      is disabled (see <a class=\"wikilink1\" href=\"/dokuwiki/doku.php?id=dev:conversionmanual:usepermanentids\"
      title=\"dev:conversionmanual:usepermanentids\">UsePermanentIds</a>), toggle the
      usage of permanent id&#39;s for POI-features from the data supplier for stabilization.
      <p> This is only possible if permanent id&#39;s for POI&#39;s have been provided
      that are stable across data releases. Because of this the parameter defaults to
      0 (disabled). In that latter case id&#39;s are generated based upon for featurecode
      and position.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UsePermanentNDSIds","description":"Purpose:
      Use permanent instead of stable NDS id''s. With the parameter StabilizeNDSIds,
      stable id''s are generated. If also the parameter UsePermanentNDSIds is set, then
      we try to generate permanent id''s. The difference is that permanent id''s are
      guaranteed to be the same over maps of different (quarterly) releases for the
      same nds feature as long as the feature has unique distinguishing properties (the
      ordered set of these properties is called the longhash of the feature). <br></br>\n                                When
      the parameter is 0, NDS id''s generated are only unique when the shorthash value
      is unique. The shorthash is typically a 32 bit number generated from the longhash,
      so it is more likely to be non-unique. As a result the same feature may still
      have a different NDS id in a newer map. Also the NDS id will be a random number,
      which has a negative impact on the size of the NDS Map. <br></br>\n                                PermanentId''s
      are stored in a permanent id database per update region. Each database is stored
      in the dakota output directory as &lt;UR&gt;.pid.sq3 (i.e. at the location where
      also the root file of the NDS map is stored). Here &lt;UR&gt; is the name of the
      update region. These databases must be preserved such that they can be used as
      input for the conversion of the next (quarterly) release of the input map data.
      It is however NOT a delivery for our customers! For the next conversion, the path
      of the permanent id databases must be supplied via the PermanentNDSIdPath dakota
      parameter. Related parameters on how the permanent id''s are generated are: IncrementalNDSIds
      and ReuseNDSIds.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"IncrementalNDSIds","description":"Purpose:
      Create incremental NDS Id''s. Only useful when dakota parameter UsePermanentNDSIds
      equals 1. <br></br>\n                                When this parameter is 0,
      NDS Id''s generated are a random number.<br></br>\n                                When
      this parameter is 1, NDS Id''s are numbered starting at 1.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UseStableIdInTileIds","description":"Create
      stable id''s for features on tiles. Requires StabilizeNDSIds to be enabled. uses
      stable id database","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UseStabilizedServiceLocationIds","description":"Enable
      stabilization of poi service location id''s (only when StabilizeNDSIds is also
      enabled). By default this is disabled, as this feature requires 64-bit service
      location id''s, which must be supported by the datascript (see nds.poi.main.ServiceLocationId)","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"EnablePostalCodesContainInSuburbsRelation","description":"With
      the EnablePostalCodesContainInSuburbsRelation parameter enabled postal codes that
      belong to only one suburb are still linked to that suburb. When the parameter
      is disabled postal codes that belong to only one suburb are directly linked to
      the city.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"GetCountrycodeRelation","description":"The
      parameter control whether to get the countrycode relation between the country
      and state for namedobjecttable.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"NamedObjectBoundingRectangles","description":"Specify
      whether to add bounding rectangles to named objects, and if so using what algorithm.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"AddContinentNamedObjects","description":"Specifies
      whether to add COUNTRY_SET named objects for continents such as Europe.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ExcludeBmdNameFromPoiForMIB2","description":"Exclude
      the unnecessary bmd name from poi.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"AdjustNameFormat1stLetterInUpperCase","description":"Adjust
      name in format as: Aaaaaaa, which only first letter is upper letter.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"GenerateTMCEntryExitRamps","description":"The
      delivered TMC tables do not contain references to the entries and exits of a TMC
      location. Some systems do need these however. When this switch is turned on, TMC
      attributes will be generated if a ramp is connected to a transition of internal
      to external TMC references, which means it leads in/out of a TMC location. Simply
      said, it will generate TMC attributes of type ENTRY or EXIT for ramps connected
      to a road covered by TMC (mostly entry/exit structures to highways).","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"AddTmcAttributesForBMD","description":"Controls
      the inclusion of TMC attributes to the BMD. Some customers only use TMC attributes
      for routing and not for BMD. Removing these attributes from the BMD will lead
      to better size/performance.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CreateTMCBBoxDB","description":"The
      parameter CreateTMCBBoxDB controls the generation of bounding box information
      for all the tableId and countrycode combination. If this parameter is enabled
      one side database will be created which contains the information for the whole
      map and combines the information of all update regions.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"TMCReferencesToGeoLines","description":"When
      the TMCReferencesToGeoLines parameter is enabled, traffic information will be
      linked to both road geolines and routing links. If TMCReferencesToGeoLines is
      disabled, then the traffic information is only linked to routing links.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"DisableRemoveInvalidTMCAreas","description":"By
      default area locations which don''t have a down reference to any point location
      in the database are removed from the TMC location tree. These down references
      are checked in order to have TMC areas only in the update region they belong to.
      When the DisableRemoveInvalidTMCAreas parameter is enabled, invalid segments and
      areas in the TMC location tree will not be removed.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"TmcConCodeStateCodeTableFile","description":"The
      parameter is defined the statecode of each province according to the TableNumber
      of TMC.","datatype":"string","default_value":"","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"IsProcessingVWGenericJunctionView","description":"For
      VW generic junction view images, both day and night pictures are imported. To
      avoid duplicate records end up in JvFrom2ToLinkTable, when this parameter is enabled
      only day (ambience = 0) from2Tolink information will be selected, since both DAY
      and NIGHT images share the same from2Tolink information.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"TextureImageSize","description":"This
      parameter controls the maximum 3d landmark texture image size. If the supplied
      images are larger, then they will be rescaled to the TextureImageSize. The value
      defines both the maximum width and height, i.e. value 256 means that the maximum
      imtexture image size is 256x256. If the value is set to 0, then all texture images
      will keep their original size.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"AmountOfLODsOf3dLandmarks","description":"This
      parameter controls which levels of detail (LOD) of 3D landmarks are to be included
      in NDS maps.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"Landmarks3dFilterConfigurationFile","description":"This
      is the configuration of 3D landmarks that should be filtered out. The file contains
      an exclusion rule on each line. An exclusion rule consists of a 3D landmark filename
      provided by Navteq and an Exclude value. Where Exclude == 1 is to exclude, 0 is
      to include.","datatype":"path","default_value":"Landmarks3dFilterCfg_Default.csv","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"TextureOutputFormat","description":"By
      default textures are output in the same format as they are in the input. If this
      parameter is set, all textures will be converted to the indicated format.","datatype":"string","default_value":"","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"DTMHeightResolution","description":"The
      DTMHeightResolution parameter defines the vertical stepsize of the Digital Terrain
      Model. The stepsize defines the smallest difference between any two height values.
      If the DTMHeightResolution is greater than 1, then all height values are rounded
      to a multiple of the used value.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"DTMAreaFilter","description":"Filters
      out specific areas of DTM.\n                            Note: The value is directly
      injected in a SQL WHERE clause.\n                            The available fields
      to base the condition on are:\n                            - TileId: The tile
      id\n                            - Level: The NDS level number\n                            -
      TileNumber: The tile number\n                            - Column: The zero-indexed
      NDS column number on the specified level\n                            - Row: The
      zero-indexed NDS row number on the specified level\n                            -
      x: The WGS84 x coordinate of the bottom-left of the tile\n                            -
      y: The WGS84 y coordinate of the bottom-left of the tile\n                            e.g.
      this line in dakota.convert will filter out everything from +90 to +180 degrees
      on the X scale:\n                            parameter DTMAreaFilter \"x &gt;=
      90 and x &lt; 180\"","datatype":"string","default_value":"","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"IntermediateFilterAngleFactor","description":"With
      this parameter the negative impact of the intermediate filter can be corrected
      for hairpins.","datatype":"string","default_value":"0.6","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"FillPointIdInTileFlag","description":"When
      enabled, the FillPointIdInTileFlag parameter will make the NDS compiler sort points
      by FixedOrder, to ensure that Beijing will be stored before the FengTai District.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ImageSize","description":"The
      ImageSize parameter controls the maximum image size for images in the DTM layer.
      All images that are larger than the parameter value will be clipped.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"NotRemoveVillageReferenceHouseNumbers","description":"The
      NDS compiler creates a table which holds the place namedobjects which do not contain
      any streets. This table is used later to filter out places that have no road /
      POI references from the NVC tree. When the NotRemoveVillageReferenceHouseNumbers
      parameter is enabled, if the village has any house numbers, then it will not be
      filtered out.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ModelHasSphericalCoords","description":"Set
      how the 3D model coordinates are transformed to NDS coordinates.","datatype":"numeric","default_value":"0","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ModelHasAbsoluteCoords","description":"Converts
      the 3D model absolute coordinates (stored in degrees) to relative coordinates
      (stored in meters).","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"AddCityObjectToPoiNamedObjectRelationTable","description":"Add
      city entries into the poiNamedObjectRelationTable.","datatype":"numeric","default_value":"1","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"GeometryReductionAlg","description":"Indicates
      which shape point reduction algorithm for geometries must be used in the NDS end-product.
      Currently, there are 5 possibilities:<br></br>\n                                The
      VSA algorithm (default, parameter value \u201cV\u201d)<br></br>\n                                The
      Douglas-Peucker algorithm (parameter value \u201cD\u201d)<br></br>\n                                The
      context based simplification algorithm based on Douglas-Peucker (parameter value
      \u201cCD\u201d)<br></br>\n                                The context based simplification
      algorithm based on VSA (parameter value \u201cCV\u201d)<br></br>\n                                The
      context based simplification algorithm based on VSA using the area reduction measure
      on ranges of removed points. This more realisticly measures the change in area
      compared to VSA and should result in less artifacts. (parameter value \u201cCV2\u201d)<br></br>\n                                BMD
      and Routing polylines are always simplified using Douglas-Peucker (in case of
      parameter value \u201cD\u201d or \u201cV\u201d) or CBS based Douglas-Peucker (in
      case of parameter value \u201cCD\u201d, \u201cCV\u201d or \u201cCV2\u201d). Land
      use polygons are simplified using the indicated method (CBS/non-CBS based VSA
      or Douglas-Peucker)","datatype":"string","default_value":"V","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CBSIterations","description":"Amount
      of iterations to use in Context Based Simplification. Multiple iterations may
      give better visual results, mainly when parallel structures are involved (for
      example two roads that are part of the same highway, the two sides of a river,
      ...)","datatype":"numeric","default_value":"1","mandatory":false,"allocate":null,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"SetResidentialOnlyFlagForSafetyRestrictedArea","description":"Safety
      restricted areas are a set of links marked in dh_cva by a H_DH_CVA_TYPE_SAFETY_RESTRICTED_AREA
      attribute. The marked links are to be avoided by the user of the map. When the
      parameter is set to one, then the ResidentialOnly flag is set to 1 and the AdminRoadclass
      is set to the lowest-but-one level.","datatype":"numeric","default_value":"0","allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UseTerrainDataInBDAM","description":"If
      enabled the BDAM Terrain data are redirected to DTM BDAM, otherwise processed
      in OBJ3D as landmarks","datatype":"numeric","default_value":"0","allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"AdditionalRegionsForNARMap","description":"","datatype":"string","default_value":"","available_in_version":1,"allocate_tags":"","source_allocate_tags":""},{"name":"IncludeTrafficLightWhenAbsent","description":"","datatype":"numeric","default_value":"0","available_in_version":1,"allocate_tags":"","source_allocate_tags":""}]}'
    source_data_def_type              'DIRECTORY'
    comment                           'updated by toolspec importer (dev_20141015/dev)'
    status                            'approved'
    schedule_allow_virtual            false
    is_improvement_process            false
  end

  factory :e_NDSCreateMaster, parent: :executable do
    name                              'NDSCreateMaster'
    description                       'Various mastering of NDS (Patch) databases. Support customer-specific
      modes.'
    input                             '[{"datatype":"NDS","id":54,"version":1,"mandatory":"false","script_tag":""},{"datatype":"NDS
      Diff","id":55,"version":1,"mandatory":false,"script_tag":""}]'
    output                            '[{"datatype":"NDS","id":54,"version":1,"mandatory":null,"script_tag":null,"identification":"ROOT.NDS"},{"datatype":"NDS
      Diff","id":55,"version":1,"mandatory":null,"script_tag":null}]'
    parameters                        '{"parameters":[{"name":"CensoringNumber","description":"<p
      xmlns=\"http://www.w3.org/1999/xhtml\">Updates the value of versionTable.compilerConfiguration
      in PRODUCT.NDS to the provided value. If the parameter is not set the field will
      remain untouched.\n                    Used by MasteringMode(s):<ul><li>MasterNdsEvo</li></ul></p>","datatype":"string","default_value":null,"mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UsePOIFacilitySearchTable","description":"<p
      xmlns=\"http://www.w3.org/1999/xhtml\">Flag to indicate to use the redesign of
      the facility search functionality. When enabled: poiFacilitySearchTable is preserved
      from the NDS database. When disabled (represents old behaviour): poiFacilitySearchTable
      is dropped from the NDS database and partial POI SLI indices on sliPoiCriterionITable
      are created.\n                    Enabling this feature is not allowed in combination
      with SplitSli since SplitSli supports partial indeces only.\n                    Used
      by MasteringMode(s):<ul><li>MasterNdsEvo</li></ul></p>","datatype":"numeric","default_value":"1","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"SplitSli","description":"<p
      xmlns=\"http://www.w3.org/1999/xhtml\">Enables, disables or indicates the way
      of splitting SLI.NDS content into EXT/SLI1.NDS and EXT/SLI2.NDS.\n                    Enabling
      this feature is not allowed in combination with SplitSli since SplitSli supports
      partial indeces only.\n                    Used by MasteringMode(s):<ul><li>MasterNdsEvo</li></ul></p>","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":""},{"name":"SplitPerBuildingBlock","description":"<p
      xmlns=\"http://www.w3.org/1999/xhtml\">Masterd Patch output must be split up per
      building-block.\n                    Used by MasteringMode(s):<ul><li>MasterNdsPatchEvo</li></ul></p>","datatype":"numeric","default_value":null,"mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"NewVersionName","description":"<p
      xmlns=\"http://www.w3.org/1999/xhtml\">Set the customers-specific identification
      of the new version. (after patching)\n                    This information will
      endup in the diff-meta-data file. (sizes)\n                    Used by MasteringMode(s):<ul><li>MasterNdsPatchEvo</li></ul></p>","datatype":"string","default_value":null,"mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ReplacesTag","description":"<p
      xmlns=\"http://www.w3.org/1999/xhtml\">Set the customer-specific value of the
      \"replaces\" element in the meta-xml-file.\n                    This information
      will endup in the metainfo xml-file as \"replaces\" element.\n                    Used
      by MasteringMode(s):<ul><li>MasterNdsPatchEvo</li></ul></p>","datatype":"string","default_value":null,"mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"BaseMap","description":"<p
      xmlns=\"http://www.w3.org/1999/xhtml\">Provide the unmastered base NDS map.\n                    Assumed
      is that there also a mapinfo-file present for information retrieval inside the
      same directory of the provided file.\n                    Used by MasteringMode(s):<ul><li>MasterNdsPatchEvo</li><li>MasterNdsPatchMDUS</li></ul></p>","datatype":"path","default_value":null,"mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"IncludeMQD","description":"<p
      xmlns=\"http://www.w3.org/1999/xhtml\">Specifies whether or not to obtain and
      master MQD patch files.\n                    This does not apply for ROOT.NDS
      and PRODUCT.NDS.\n                    The mqd files are expected to be output
      of the NDSiff, stored in the \"MQD\" directory.\n                    Used by
      MasteringMode(s):<ul><li>MasterNdsPatchEvo</li></ul></p>","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ShowFullIUVersion","description":"<p
      xmlns=\"http://www.w3.org/1999/xhtml\">Adds ShowFullIUVersion section in meta.txt.\n                    If
      parameter has not been set, no such section will be added.\n                    Used
      by MasteringMode(s):<ul><li>MasterNdsPatchEvo</li></ul></p>","datatype":"numeric","default_value":null,"mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"IncludeTollcostsFromGR0","description":"<p
      xmlns=\"http://www.w3.org/1999/xhtml\">Include the global toll costs.\n                    When
      enabled, the toll cost information that is present in the GR0/EXT/EXTRT.NDS will
      be split up per update region and included in each UR patch.\n                    Don''t
      enable this when ExtendGlobalTollCostTable is presented by PRODUCT.NDS of the
      patch-file.\n                    Used by MasteringMode(s):<ul><li>MasterNdsPatchEvo</li></ul></p>","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"RemoveNonHighwayInOutPoiUpdates","description":"<p
      xmlns=\"http://www.w3.org/1999/xhtml\">Specifies whether or not to filter out
      Non highway in-out related POI entities.\n                    The process will
      modify the patch before performing other mastering steps.<ul><li>Data in nds-patch
      related to non- highway in/out poi''s will removed.</li><li>Regeneration of MQD
      variants for NDS-Patch databases</li><li>MD5_Metadata entities will be removed
      if affected by this action.</li><li>DROP INDEX entities will be discarded from
      meta.txt if affected by this filtering.</li></ul>\n                    Used by
      MasteringMode(s):<ul><li>MasterNdsPatchEvo</li></ul></p>","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"MakeZipFile","description":"<p
      xmlns=\"http://www.w3.org/1999/xhtml\">Specifies whether or not to export the
      mastering output to a zipfile.\n                    The name of the zip-file will
      be the productName.\n                    A MD5 sum file for the zip file will
      be exported as well.\n                    Used by MasteringMode(s):<ul><li>MasterNdsEvo</li></ul></p>","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"MoveTollToGlobal","description":"<p
      xmlns=\"http://www.w3.org/1999/xhtml\">Move the content of the extendGlobalTollCostTable
      from the GR0 Product the mastered GR0/EXT/EXTRT.NDS database.\n                    Used
      by MasteringMode(s):<ul><li>MasterNdsEvo</li></ul></p>","datatype":"numeric","default_value":"0","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"UpdateRegionIdConfigurationFile","description":"<p
      xmlns=\"http://www.w3.org/1999/xhtml\">Specify the path to the UpdateRegionIdConfigurationFile.\n                    This
      file describes the directoryName to updateRegionId relation for the output of
      the NDS database.\n                    Used by MasteringMode(s):<ul><li>MasterNdsEvo</li></ul></p>","datatype":"path","default_value":null,"mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"CipherKeyId","description":"<p
      xmlns=\"http://www.w3.org/1999/xhtml\">Identifies the customer-specific encryption-key
      to be used to encrypt the mastered output.\n                    Note that ROOT.NDS
      and PRODUCT.NDS won''t be encrypted.\n                    Used by MasteringMode(s):<ul><li>MasterNdsPatchVW</li></ul></p>","datatype":"numeric","default_value":null,"mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"DbInfoApplicationSoftwareVersionNumber","description":"<p
      xmlns=\"http://www.w3.org/1999/xhtml\">Provides the ApplicationSoftwareVersionNumber
      for deployment on the VolksWagen system.\n                    This information
      is reflected in the dbinfo.txt.\n                    Used by MasteringMode(s):<ul><li>MasterNdsPatchVW</li></ul></p>","datatype":"string","default_value":null,"mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"DbInfoPartNumber2","description":"<p
      xmlns=\"http://www.w3.org/1999/xhtml\">Provides the PartNumber2 for deployment
      on the VolksWagen system.\n                    This information is reflected in
      the dbinfo.txt.\n                    Used by MasteringMode(s):<ul><li>MasterNdsPatchVW</li></ul></p>","datatype":"string","default_value":null,"mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"DbInfoPartNumber3","description":"<p
      xmlns=\"http://www.w3.org/1999/xhtml\">Provides the PartNumber3 for deployment
      on the VolksWagen system.\n                    This information is reflected in
      the dbinfo.txt.\n                    Used by MasteringMode(s):<ul><li>MasterNdsPatchVW</li></ul></p>","datatype":"string","default_value":null,"mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"DbInfoPartNumber4","description":"<p
      xmlns=\"http://www.w3.org/1999/xhtml\">Provides the PartNumber4 for deployment
      on the VolksWagen system.\n                    This information is reflected in
      the dbinfo.txt.\n                    Used by MasteringMode(s):<ul><li>MasterNdsPatchVW</li></ul></p>","datatype":"string","default_value":null,"mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"DbInfoSystemName","description":"<p
      xmlns=\"http://www.w3.org/1999/xhtml\">Provides the SystemName for deployment
      on the VolksWagen system.\n                    This information is reflected in
      the dbinfo.txt.\n                    Used by MasteringMode(s):<ul><li>MasterNdsPatchVW</li></ul></p>","datatype":"string","default_value":null,"mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"MasterAnalyzeNdsPatch_oldRootA","description":"<p
      xmlns=\"http://www.w3.org/1999/xhtml\">Provides the full A-database for the old
      incremental update conversion chain.\n                    Used by MasteringMode(s):<ul><li>MasterAnalyzeNdsPatch</li></ul></p>","datatype":"path","default_value":null,"mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"MasterAnalyzeNdsPatch_oldRootB","description":"<p
      xmlns=\"http://www.w3.org/1999/xhtml\">Provides the full B-database for the old
      incremental update conversion chain.\n                    Used by MasteringMode(s):<ul><li>MasterAnalyzeNdsPatch</li></ul></p>","datatype":"path","default_value":null,"mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"MasterAnalyzeNdsPatch_oldPatch","description":"<p
      xmlns=\"http://www.w3.org/1999/xhtml\">Provides the patch -database (from A to
      B) for the old incremental update conversion chain.\n                    Note:
      the patch -database for the new iteration must be provided through the regular
      dakota gdf-inputfile system.\n                    Used by MasteringMode(s):<ul><li>MasterAnalyzeNdsPatch</li></ul></p>","datatype":"path","default_value":null,"mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"MasterAnalyzeNdsPatch_rootA","description":"<p
      xmlns=\"http://www.w3.org/1999/xhtml\">Provides the full A-database for the new
      incremental update conversion chain.\n                    Used by MasteringMode(s):<ul><li>MasterAnalyzeNdsPatch</li></ul></p>","datatype":"path","default_value":null,"mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"MasterAnalyzeNdsPatch_rootB","description":"<p
      xmlns=\"http://www.w3.org/1999/xhtml\">Provides the full B-database for the old
      incremental update conversion chain.\n                    Used by MasteringMode(s):<ul><li>MasterAnalyzeNdsPatch</li></ul></p>","datatype":"path","default_value":null,"mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"MasterAnalyzeNdsPatch_jsonProdId","description":"<p
      xmlns=\"http://www.w3.org/1999/xhtml\">Provides the productId for json-output
      on request.\n                    Must be specified with other json- parameters
      to be effective.\n                    Used by MasteringMode(s):<ul><li>MasterAnalyzeNdsPatch</li></ul></p>","datatype":"numeric","default_value":null,"mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"MasterAnalyzeNdsPatch_jsonUrId","description":"<p
      xmlns=\"http://www.w3.org/1999/xhtml\">Provides the updateRegionId for json-output
      on request.\n                    Must be specified with other json- parameters
      to be effective.\n                    Used by MasteringMode(s):<ul><li>MasterAnalyzeNdsPatch</li></ul></p>","datatype":"numeric","default_value":null,"mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"MasterAnalyzeNdsPatch_jsonTableName","description":"<p
      xmlns=\"http://www.w3.org/1999/xhtml\">Provides the tableName for json-output
      on request.\n                    Must be specified with other json- parameters
      to be effective.\n                    Used by MasteringMode(s):<ul><li>MasterAnalyzeNdsPatch</li></ul></p>","datatype":"string","default_value":null,"mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"MasterAnalyzeNdsPatch_jsonFieldName","description":"<p
      xmlns=\"http://www.w3.org/1999/xhtml\">Provides the fielName for json-output on
      request.\n                    Must be specified with other json- parameters to
      be effective.\n                    Used by MasteringMode(s):<ul><li>MasterAnalyzeNdsPatch</li></ul></p>","datatype":"string","default_value":null,"mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"MasterAnalyzeNdsPatch_jsonPK","description":"<p
      xmlns=\"http://www.w3.org/1999/xhtml\">Provides the primary-key-values for json-output
      on request.\n                    Must be specified with other json- parameters
      to be effective.\n                    Used by MasteringMode(s):<ul><li>MasterAnalyzeNdsPatch</li></ul></p>","datatype":"string","default_value":null,"mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"MasterAnalyzeNdsPatch_genStats","description":"<p
      xmlns=\"http://www.w3.org/1999/xhtml\">Specifies wheter or not to generate statistical
      output about the provided databases.\n                    Statistical result can
      be obtained from MasterAnalyzeNdsPatch.sq3 in the output directory.\n                    Used
      by MasteringMode(s):<ul><li>MasterAnalyzeNdsPatch</li></ul></p>","datatype":"numeric","default_value":"1","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"MDUSsettingsConfFile","description":"<p
      xmlns=\"http://www.w3.org/1999/xhtml\">Specify the path to the MDUSsettingsConfFile.\n                    This
      file describes the mapping from UpdateRegion names to regId, regIdALl and other
      MDUS specific information.\n                    Used by MasteringMode(s):<ul><li>MasterNdsMDUS</li><li>MasterNdsPatchMDUS</li></ul></p>","datatype":"path","default_value":null,"mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"NDSCreateMasterMode","description":"Selects
      which customer-specific mastering kind must be applied.\n                            Other
      parameters provided to NDSCreateMaster are mastering-mode specific.","datatype":"string","default_value":"","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ProductName","description":"<p
      xmlns=\"http://www.w3.org/1999/xhtml\">Identifies the NDS product.\n                            Used
      by MasteringMode(s):\n                            <ul><li>MasterNdsEvo</li><li>MasterNdsPatchEvo</li><li>MasterNdsPatchVW</li><li>MasterNdsBMWENEVO</li></ul>\n                        </p>","datatype":"string","default_value":null,"mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"MapVersion","description":"<p
      xmlns=\"http://www.w3.org/1999/xhtml\">Set the customer-specific identification
      of the map-version.\n                            This information will endup in
      the metainfo xml-file as \"mVersion\" element.\n                            Used
      by MasteringMode(s):\n                            <ul><li>MasterNdsPatchEvo</li><li>MasterNdsBMWENEVO</li></ul>\n                        </p>","datatype":"string","default_value":null,"mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ProductId","description":"<p
      xmlns=\"http://www.w3.org/1999/xhtml\">Set the customer-specific product identification.\n                            This
      information will endup in the metainfo xml-file as \"productId\" element and in
      txt-file as value of \"Release\".\n                            Used by MasteringMode(s):\n                            <ul><li>MasterNdsPatchEvo</li><li>MasterNdsBMWENEVO</li></ul>\n                        </p>","datatype":"string","default_value":null,"mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"NdsCompression","description":"<p
      xmlns=\"http://www.w3.org/1999/xhtml\">Set the kind of NDS-Compression to be applied
      on the mastered database-files.\n                            Used by MasteringMode(s):\n                            <ul><li>MasterNdsEvo</li><li>MasterNdsPatchEvo</li><li>MasterNdsBMWENEVO</li></ul>\n                        </p>","datatype":"string","default_value":"zlib","mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"SwtConfigurationFile","description":"CVS-file
      containing the SWT-ID and SGBM-ID related to each product","datatype":"string","default_value":null,"mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ProductType","description":"Identifies
      the NDS product type","datatype":"string","default_value":null,"mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"ProjectName","description":"Identifies
      the name of the NDS project","datatype":"string","default_value":null,"mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"MarketCode","description":"The
      code of the market region","datatype":"string","default_value":null,"mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"MarketDescription","description":"The
      name of the market region","datatype":"string","default_value":null,"mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"VendorName","description":"The
      name of the vendor","datatype":"string","default_value":null,"mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"PackageId","description":"The
      id for the NDS maps package provided by the customer","datatype":"string","default_value":null,"mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"TypeOfAction","description":"The
      type of action specified by customer","datatype":"string","default_value":null,"mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"VendorVersion","description":"The
      vendor version of update regions","datatype":"string","default_value":null,"mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null},{"name":"VendorVersionDisplay","description":"The
      vendor version display of update regions","datatype":"string","default_value":null,"mandatory":false,"allocate":false,"allocate_tags":"","source_allocate_tags":"","visibility":null}]}'
    source_data_def_type              'DIRECTORY'
    comment                           'updated by toolspec importer (dev_20141015/dev)'
    status                            'approved'
    schedule_allow_virtual            false
    is_improvement_process            false
  end

  factory :e_Statistics, parent: :executable do
    name                              'Statistics'
    description                       'Generate statistics'
    input                             '[{"datatype":"dHive","id":null,"version":null,"mandatory":"false","script_tag":""}]'
    output                            '[{"datatype":"dHive","id":null,"version":null,"mandatory":null,"script_tag":null,"identification":".dh.sq3"}]'
    source_data_def_type              'DIRECTORY'
    comment                           'Updated by migration script 20141014125046_cleanup_toolspec_imports.rb'
    status                            'approved'
    is_improvement_process            false
  end

  factory :e_DHPOIImprovePhone, parent: :executable do
    name                              'DHPOIImprovePhone'
    description "This tool normalizes the POI phone numbers in a dHive database.\n
      \   This includes\n        - splitting the phone number string into separate
      phone numbers (and add them to DH_PVN)\n        - adding international access
      codes\n        - stripping all decorations (leading + or 00, parenthesized trunk
      code '(0)', ...)"
    input                             '[{"datatype":"dHive","id":2,"version":1,"mandatory":"false","script_tag":""}]'
    output                            '[{"datatype":"dHive","id":2,"version":1,"mandatory":null,"script_tag":null,"identification":".dh.sq3"}]'
    source_data_def_type              'FILE'
    comment                           'updated by toolspec importer (dev_20141015/dev)'
    status                            'approved'
    schedule_memory_base              0
    schedule_cores                    1
    schedule_diskspace_times_input    2
  end

  factory :e_DHPOIValidate, parent: :executable do
    name                              'DHPOIValidate'
    description "Validates POI part of a dHive database: \n          - Checks tables
      and fields for DH_POI, DH_PVA, DH_PVN etc. and reports the result to file \"DHPOIValidate_general.log\";\n
      \         - Checks postalcode format per country and reports the result to file
      \"DHPOIValidate_postal_codes.log\".\n        Both log files are compressed to
      file \"DHPOIValidate_logs.tar.gz\""
    input                             '[{"datatype":"dHive","id":2,"version":1,"mandatory":"false","script_tag":""}]'
    output                            '[{"datatype":"dHive","id":null,"version":null,"mandatory":null,"script_tag":null,"identification":".dh.sq3"}]'
    source_data_def_type              'FILE'
    comment                           'updated by toolspec importer (dev_20141015/dev)'
    status                            'approved'
    schedule_cores                    1
    schedule_diskspace_times_input    2
    is_improvement_process            false
  end
end
