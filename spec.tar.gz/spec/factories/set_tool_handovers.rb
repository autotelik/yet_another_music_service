FactoryBot.define do
  factory :set_tool_handover, aliases: %i[set_tool_handover_data_set] do
    association :project, factory: :proj_PRODUCTION
  end

  factory :set_tool_handover_maximal, parent: :set_tool_handover do
    association :product_set, factory: :product_set
  end
end
