FactoryBot.define do
  factory :project, aliases: [:proj_PRODUCTION] do
    name                        'Production'
    status                      20
  end

  factory :proj_REGRESSION, parent: :project do
    name                        'Regression Test'
  end

  factory :proj_TEST, parent: :project do
    name                        'Test'
  end
end
