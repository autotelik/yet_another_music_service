FactoryBot.define do
  factory :default_content_release_note do
    association :product_category,        factory: :product_category
    association :user,                    factory: :user
    title                                 'a_title'
    status                                DefaultContentReleaseNote::STATUS_ACTIVE
    content                               ''
  end

  factory :default_content_release_note_maximal, parent: :default_content_release_note do
    start_on_new_page                     true
    product_list                          true
    addition_required_yn                  true
    rank                                  9
    subrank                               9
    allow_jira_import_yn                  true
  end
end
