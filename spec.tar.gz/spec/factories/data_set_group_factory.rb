FactoryBot.define do
  factory :data_set_group,  aliases: [:dsg_DEFAULT] do
    company_abbr                'HER'
    sequence(:data_release)     { |n| "#{DateTime.now.year}Q#{n}" }
    region_code                 'WLD'
    status                      DataSetGroup::STATUS_ACTIVE
  end

  factory :data_set_group_maximal, parent: :data_set_group do
    data_type                   'lorem'
    filling                     'ipsum'
    suffix                      'dolor'
    description                 'sit'
  end
end
