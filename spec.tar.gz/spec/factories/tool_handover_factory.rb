FactoryBot.define do
  factory :tool_handover do
    association :set_tool_handover,       factory: :set_tool_handover
    association :handover,                factory: :product
    name                                  'tool handover'

    trait :with_handover_compilation_steps do
      after(:create) do |th|
        th.handover_compilation_steps << create(:handover_rdb2dh)
        th.save
      end
    end
  end

  factory :tool_handover_maximal, parent: :tool_handover do
    association :handover,                factory: :product_maximal
    association :parameter_set,           factory: :parameter_set
    association :conversion_design_name,  factory: :conversion_design_name
    association :conv_script,             factory: :conv_script
    association :set_tool_handover,       factory: :set_tool_handover_maximal
    name                                  'tool handover maximal'
    rdo_path                              'lorem/ipsum'
    handover_type                         'Product'
  end

  factory :tool_handover_data_set, parent: :tool_handover do
    association :handover,                factory: :data_set
    association :conversion_design_name,  factory: :RDF2DH_design_name
    association :conv_script,             factory: :conv_script
    association :set_tool_handover,       factory: :set_tool_handover_data_set
    name                                  'tool handover data set'
  end

  factory :tool_handover_product, parent: :tool_handover do
    name                                  'tool handover product'
    handover_type                         'Product'
  end
end
