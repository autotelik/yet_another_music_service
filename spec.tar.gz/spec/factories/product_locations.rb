FactoryBot.define do
  factory :product_location do
    association :conversion,            factory: :c_DEFAULT
    volume_id                           'MP000-0001'
    area                                'Test1'
    supplier                            'Nokia'
    association :data_release,          factory: :dr_2013Q1
    association :conversiontool,        factory: :DEV_TOOL
    sequence(:registration_date)        { |n| Time.now + n.weeks }
    remarks                             'Regression test'
    product_type                        'Product'
    storage_path                        '/default'
  end

  factory :plo_MP000_0001_0, parent: :product_location do
    storage_path                        '/volumes2/production_tests/test/product/MP000-0001/R00/MP000-0001.0TST1.tar.gz'
    internal_storage_path               '/volumes2/production_tests/test/data/output/ops/o_20151007-153126-nld_her_2015Q2_20150827_a_errordb/nld_her_2015Q2_20150827_a_errordb.dh.sq3'
    checksum_storage_file               'qwertyui5432'
    release_sequence                    0
  end

  factory :plo_MP000_0001_1, parent: :product_location do
    storage_path                        '/volumes2/production_tests/test/product/MP000-0001/R01/o_20151007-153126-nld_her_2015Q2_20150827_a_errordb'
    internal_storage_path               '/volumes2/production_tests/test/data/output/ops/o_20151007-153126-nld_her_2015Q2_20150827_a_errordb/nld_her_2015Q2_20150827_a_errordb.dh.sq3'
    release_sequence                    1
  end

  factory :product_location_maximal, parent: :plo_MP000_0001_0 do
    product_format                      'lorem'
    data_path                           'ipsum'
    reception_id                        99
    conversion_database_id              99
    mdus_target                         'dolor'
    ext_reference                       'lorem'
    ext_status                          'ipsum'
  end
end
