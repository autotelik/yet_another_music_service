FactoryBot.define do
  factory :conversion_database do
    # no mandatory attributes

    trait :with_validation_job do
      after(:create) do |cd|
        cd.validation_jobs << create(:validation_job_maximal)
      end
    end

    trait :with_finished_validation_job do
      after(:create) do |cd|
        cd.validation_jobs << create(:validation_job_maximal, status: Job::STATUS_FINISHED)
      end
    end

    trait :with_validation_error do
      after(:create) do |cd|
        cd.validation_errors << create(:validation_error)
      end
    end
  end

  factory :conversion_database_maximal, parent: :conversion_database do
    size_bytes                  8457929
    sequence(:created_at)       { |n| Time.now + n.weeks }
    sequence(:updated_at)       { |n| Time.now + n.weeks }
    db_type                     'dHive'
    sequence(:filename)         { |n| "nld_her_2015Q2_20150827_#{n}_a_errordb.dh.sq3" }
    path                        '/volumes2/production_tests/test/data/output/ops/o_20151007-153126-nld_her_2015Q2_20150827_a_errordb/'
    remarks {
      <<-REMARKS
      
      ERROR: 1 land codes in dh_con belong to multiple countries.

      WARNING: 3 villages don't have a centre chain.

      WARNING: 3 GovCodes are not unique in the administrative structure.

      WARNING: 78% of CCV records (2687 of 3432) are linked to same city.

      WARNING: 0 POIs have a national-importance record.

      WARNING: 0 POIs have brand ids in PVA

      INFO: ValidateDH has finished 4287 tests, with 1 error(s), 5 warning(s) on database /x/x/x/x/x/x/x-x-x-x/x.dh.sq3

      ERROR: 1 land codes in dh_con belong to multiple countries.

      The validation returned 1 error.
      REMARKS
    }
    association :conversion_job, factory: :cj_DUMMY
    status                        ConversionDatabase::STATUS_HAS_ERRORS
    group_amount                  0
    group_by                      'subregion'
    group_value                   'nld'
    stdout_log                    'YAML creation'
    association :region,          factory: :region
    file_system_status            ConversionDatabase::FILE_SYSTEM_STATUS_AVAILABLE
    volume_id                    'lorem'
    removal_remark                'ipsum'
    tag_data_sets                 'dolor'
    tag_region_codes              'sit'
    tag_group_region_code         'amet'

    after(:build) do |cd|
      cd.path_and_file = File.join(cd.path, cd.filename)
    end
  end

  factory :conversion_file_base, parent: :conversion_database_maximal do

    volume_id { Faker::Commerce.product_name }

    after(:build) do |conversion|
      # dir has to be certain format to pass checks in remove, name, ext
      full_path = Faker::File.file_name('/tmp/o_12345678-rspec-1/test', nil, 'dh.sq3')
      conversion.path_and_file = full_path
      conversion.filename      = File.basename full_path
      conversion.path          = File.dirname  full_path
    end

  end

  factory :conversion_database_removed, parent: :conversion_file_base do
    association :region

    file_system_status ConversionDatabase::FILE_SYSTEM_STATUS_REMOVED
  end

  factory :conversion_database_marked_for_removal, parent: :conversion_file_base do
    association :region

    file_system_status ConversionDatabase::FILE_SYSTEM_STATUS_MARKED_FOR_REMOVAL
  end

end
