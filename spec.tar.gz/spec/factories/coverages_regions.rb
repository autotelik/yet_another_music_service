FactoryBot.define do
  factory :coverages_region do
    do_not_process          false
    association :region,    factory: :r_Netherlands
  end

  factory :coverage_region_generic, parent: :coverages_region do
    association :coverage,  factory: :coverage
    association :region,    factory: :region
  end

  factory :DS_Coverage_region_EUR_NLD, parent: :coverages_region do
    association :coverage,  factory: :DS_EUROPE1
  end

  factory :DS_Coverage_region_EUR_BEL, parent: :coverages_region do
    association :coverage,  factory: :DS_EUROPE1
    association :region,    factory: :r_Belgium
  end

  factory :DS_Coverage_do_not_process, class: "CoveragesRegion" do
    do_not_process          true

    # This one contains sequences so avoids Validation: Region code has already been taken
    association :region
  end

  factory :DS_Coverage_region_EUR_LUX, parent: :coverages_region do
    association :coverage,  factory: :DS_EUROPE1
    association :region,    factory: :r_Luxembourg
  end

  factory :COVERAGE_REGION_1, parent: :coverages_region do
    association :coverage,  factory: :EUROPE1
  end

  factory :COVERAGE_REGION_2, parent: :coverages_region do
    association :coverage,  factory: :EUROPE1
  end

  factory :COVERAGE_REGION_3, parent: :coverages_region do
    association :coverage,  factory: :EUROPE1
  end

  factory :COVERAGE_REGION_4, parent: :coverages_region do
    association :coverage,  factory: :EUROPE1
  end

  factory :COVERAGE_REGION_5, parent: :coverages_region do
    association :coverage,  factory: :EUROPE1
  end

  factory :COVERAGE_REGION_6, parent: :coverages_region do
    association :coverage,  factory: :EUROPE1
  end

  factory :COVERAGE_REGION_7, parent: :coverages_region do
    association :coverage,  factory: :EUROPE1
  end

  factory :COVERAGE_REGION_8, parent: :coverages_region do
    association :coverage,  factory: :EUROPE1
  end

  factory :COVERAGE_REGION_9, parent: :coverages_region do
    association :coverage,  factory: :EUROPE2
  end

  factory :COVERAGE_REGION_10, parent: :coverages_region do
    association :coverage,  factory: :EUROPE2
  end

  factory :COVERAGE_REGION_11, parent: :coverages_region do
    association :coverage,  factory: :EUROPE2
  end

  factory :COVERAGE_REGION_12, parent: :coverages_region do
    association :coverage,  factory: :EUROPE2
  end

  factory :COVERAGE_REGION_13, parent: :coverages_region do
    association :coverage,  factory: :EUROPE2
  end

  factory :COVERAGE_REGION_14, parent: :coverages_region do
    association :coverage,  factory: :EUROPE2
  end

  factory :COVERAGE_REGION_15, parent: :coverages_region do
    association :coverage,  factory: :EUROPE2
  end

  factory :COVERAGE_REGION_16, parent: :coverages_region do
    association :coverage,  factory: :EUROPE3
  end

  factory :COVERAGE_REGION_17, parent: :coverages_region do
    association :coverage,  factory: :EUROPE3
  end

  factory :COVERAGE_REGION_18, parent: :coverages_region do
    association :coverage,  factory: :EUROPE3
  end

  factory :COVERAGE_REGION_19, parent: :coverages_region do
    association :coverage,  factory: :EUROPE3
  end

  factory :COVERAGE_REGION_20, parent: :coverages_region do
    association :coverage,  factory: :EUROPE3
  end

  factory :COVERAGE_REGION_21, parent: :coverages_region do
    association :coverage,  factory: :EUROPE3
  end

  factory :COVERAGE_REGION_22, parent: :coverages_region do
    association :coverage,  factory: :EUROPE4
  end

  factory :COVERAGE_REGION_23, parent: :coverages_region do
    association :coverage,  factory: :EUROPE4
  end

  factory :COVERAGE_REGION_24, parent: :coverages_region do
    association :coverage,  factory: :EUROPE4
  end

  factory :COVERAGE_REGION_25, parent: :coverages_region do
    association :coverage,  factory: :EUROPE4
  end

  factory :COVERAGE_REGION_26, parent: :coverages_region do
    association :coverage,  factory: :EUROPE4
  end

  factory :COVERAGE_REGION_27, parent: :coverages_region do
    association :coverage,  factory: :EUROPE5
  end

  factory :COVERAGE_REGION_28, parent: :coverages_region do
    association :coverage,  factory: :EUROPE5
  end

  factory :COVERAGE_REGION_29, parent: :coverages_region do
    association :coverage,  factory: :EUROPE5
  end

  factory :COVERAGE_REGION_30, parent: :coverages_region do
    association :coverage,  factory: :EUROPE5
  end

  factory :COVERAGE_REGION_31, parent: :coverages_region do
    association :coverage,  factory: :EUROPE6
  end

  factory :COVERAGE_REGION_32, parent: :coverages_region do
    association :coverage,  factory: :EUROPE6
  end

  factory :COVERAGE_REGION_33, parent: :coverages_region do
    association :coverage,  factory: :EUROPE6
  end

  factory :COVERAGE_REGION_34, parent: :coverages_region do
    association :coverage,  factory: :WORLD1
  end

  factory :COVERAGE_REGION_35, parent: :coverages_region do
    association :coverage,  factory: :WORLD1
  end

  factory :COVERAGE_REGION_36, parent: :coverages_region do
    association :coverage,  factory: :EUROPE7
  end
end
