FactoryBot.define do
  factory :validation_error do
    name                        "lorem's ipsum dolor"
    add_attribute(:count)       { 1 }
    copied_to_crash_yn          false
    resolved_yn                 false
  end

  factory :validation_error_maximal, parent: :validation_error do
    conversion_database_id      1234
    ticket_nr                   'PROC-7527'
    sequence(:created_at)       { |n| Time.now + n.weeks }
    sequence(:updated_at)       { |n| Time.now + n.weeks }
  end
end
