FactoryBot.define do
  factory :test_request do
    status                                        TestRequest::STATUS_RUNNING
    association :test_type,                       factory: :test_type
    association :test_db,                         factory: :conversion_database_maximal
    association :assigned_user,                   factory: :user
    association :request_user,                    factory: :user

  end

  factory :test_request_maximal, parent: :test_request do
    association :production_orderline,            factory: :production_orderline
    association :product,                         factory: :product
    association :request_user,                    factory: :user
    association :ref_db,                          factory: :conversion_database
    association :project,                         factory: :proj_PRODUCTION
    sequence(:start_date)                         { |n| Time.now + n.weeks }
    sequence(:finish_date)                        { |n| Time.now + n.weeks }
    actual_start_date                             Time.now
    actual_finish_date                            Time.now
    request_remarks                               'lorem'
    result_remarks                                'ipsum'
    removed_yn                                    true
    use_scheduler                                 true
  end
end
