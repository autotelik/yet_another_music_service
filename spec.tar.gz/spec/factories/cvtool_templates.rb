FactoryBot.define do
  factory :cvtool_template do
    sequence(:name)                   {|n| "test_name#{n}"}
    active_yn                         true
  end

  factory :cvtool_template_maximal, parent: :cvtool_template do
    description                       'lorem'
    filename                          'ipsum'
  end
end
