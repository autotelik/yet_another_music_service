FactoryBot.define do
  factory :distribution_list_member do
    association :external_contact,    factory: :external_contact
    association :distribution_list,   factory: :dl_WEBMIS_TEST
    electronic_delivery_yn            true
    hard_copy_delivery_yn             false
    transfer_method                   'FTP'
  end

  factory :dlm_EWOUT, parent: :distribution_list_member do
    association :external_contact,    factory: :EC_EWOUT
  end

  factory :dlm_ROBERT, parent: :distribution_list_member do
    association :external_contact,    factory: :EC_ROBERT
  end
end
