FactoryBot.define do
  factory :roles_user do
    association :role,      factory: :Admin
    add_attribute :module,  'MIS'
  end

  factory :ru_TESTUSER_PROD, parent: :roles_user do
    association :user,      factory: :TESTUSER1
    association :project,   factory: :proj_PRODUCTION
  end

  factory :ru_TESTUSER, parent: :roles_user do
    association :user,      factory: :TESTUSER1
    association :project,   factory: :proj_REGRESSION
  end

  factory :ru_RAILSTEST_PROD, parent: :roles_user do
    association :user,      factory: :RAILSTEST
    association :project,   factory: :proj_PRODUCTION
  end

  factory :ru_RAILSTEST_REG, parent: :roles_user do
    association :user,      factory: :RAILSTEST
    association :project,   factory: :proj_REGRESSION
  end
end
