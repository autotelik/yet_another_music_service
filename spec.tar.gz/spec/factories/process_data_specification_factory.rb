FactoryBot.define do
  factory :process_data_specification do
    sequence(:name)           { |n| "default#{n}" }
    directory                 'default'
    file_level_yn             false
    active_yn                 true

    trait :with_conversion_design_name do
      association :conversion_design_name
    end

  end

  factory :process_data_specification_maximal, parent: :process_data_specification do
    script_tag                'lorem'
    description               'dolor'
    split_by_key              'lorem'
    data_type_id              99
    filling                   'ipsum'
  end

  factory :pds_RDF, parent: :process_data_specification, traits: [:with_conversion_design_name] do
    name                      'RDF'
    directory                 'rdf'
    association :data_type,   factory: :dt_RDF
    file_level_yn             true
  end

  factory :pds_TMC, parent: :process_data_specification do
    name                      'TMC'
    directory                 'ltef'
    description               'Zipped LTEF tables.\r\nStored per region.'
    file_level_yn             true
    split_by_key              ''
    association :data_type,   factory: :dt_TMC
  end

  factory :pds_VAR, parent: :process_data_specification do
    name                      'Brand icons'
    directory                 'bic'
    association :data_type,   factory: :dt_VAR
  end

  factory :pds_JVS, parent: :process_data_specification do
    name                      'Junction view Images'
    directory                 'jvs'
    association :data_type,   factory: :dt_JVS
    filling 'Junction views'
  end

  factory :pds_3DC, parent: :process_data_specification do
    name                      '3D City Models'
    directory                 '3cm'
    association :data_type,   factory: :dt_3DC
  end

  factory :pds_POI, parent: :process_data_specification do
    name                      'Fuel XML'
    directory                 'fxml'
    description               'Fuel type XML format'
    association :data_type,   factory: :dt_POI
  end

  factory :pds_DOC, parent: :process_data_specification do
    name                      'Documentation'
    directory                 'rn'
    description               'TEST DESCRIPTION'
    file_level_yn             true
    association :data_type,   factory: :dt_DOC
  end
end
