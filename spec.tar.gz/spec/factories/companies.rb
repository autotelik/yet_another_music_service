FactoryBot.define do
  factory :company, aliases: [:MAPSCAPE] do
    sequence(:name)                   { |n| "Mapscape B.V.#{n}" }
    billing_address_postalcode        '5657 EP'
    billing_address_street            'Henri Wijnmalenweg 5b'
    billing_address_city              'Eindhoven'
    billing_address_country           'Nederland'
    status                            100
    external_id                       'a06b9a0f-c50d-a9c4-caa1-48a48f005932'
  end

  factory :company_maximal, parent: :company do
    shipping_address_postalcode       'lorem'
    shipping_address_street           'ipsum'
    shipping_address_city             'dolor'
    shipping_address_state            'sit'
    shipping_address_country          'amet'
    billing_address_state             'consectetur'
    phone_office                      'adipiscing'
    phone_fax                         'elit'
  end
end
