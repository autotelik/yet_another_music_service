FactoryBot.define do
  factory :region do
    active_yn               true
    sequence(:region_code)  { |n| "RE#{n}" }
    sequence(:name)         { |n| "Region#{n}" }
    region_type             Region::REGION_AREA
  end

  factory :r_Europe, parent: :region do
    name                    'Europe'
    region_code             'EUR'
    region_type             Region::REGION_CONTINENT
  end

  factory :r_Netherlands, parent: :region do
    name                    'Netherlands'
    region_code             'NLD'
    region_type             Region::REGION_COUNTRY
    association :parent_id, factory: :r_Europe
  end

  factory :r_Belgium, parent: :region do
    name                    'Belgium'
    region_code             'BEL'
    region_type             Region::REGION_COUNTRY
    association :parent_id, factory: :r_Europe
  end

  factory :r_Luxembourg, parent: :region do
    name                    'Luxembourg'
    region_code             'LUX'
    region_type             Region::REGION_COUNTRY
    association :parent_id, factory: :r_Europe
  end

  factory :r_TEST_REGION1, parent: :region do
    name                    'Test1'
    sequence(:region_code)  { |n| "TST#{n}" }
    region_type             Region::REGION_AREA
  end

  factory :r_TEST_REGION2, parent: :region do
    name                    'Test2'
    sequence(:region_code)  { |n| "TST2-#{n}" }
    region_type             Region::REGION_AREA
  end

  factory :r_WORLD, parent: :region do
    name                    'World'
    region_code             'WLD'
    region_type             Region::REGION_AREA

    trait :with_coverage do
      after(:create) do |r|
        r.coverages << create(:WORLD1)
      end
    end

  end

  factory :r_EARTH do
    active_yn               true
    name                    'Earth'
    region_type             Region::REGION_ALIAS
    parent_id               99 # dummy value
  end
end
