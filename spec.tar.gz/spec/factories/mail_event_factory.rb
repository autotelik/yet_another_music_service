FactoryBot.define do
  factory :mail_event do
    sequence(:name) { |n| "MailEvent_#{DateTime.now.year}_#{n}" }

    trait :with_users do
      after(:create) do |me|
        me.update(users: create_list(:user_maximal, 4))
      end
    end
  end
end
