FactoryBot.define do
  factory :included_product, aliases: [:GMN_MP000_0001] do
    association :product_set, factory: :ps_GMN
    association :product, factory: :product
  end
end
