FactoryBot.define do
  factory :data_set_group_line do
    data_set_id         1
    data_set_group_id   1
  end
end
