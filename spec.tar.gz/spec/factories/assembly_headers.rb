FactoryBot.define do
  factory :assembly_header do
    association :product,     factory: :product
    output_format             'test_output_format'
    name                      'lorem_ipsum'
  end

  factory :assembly_header_maximal, parent: :assembly_header do
    name                      'lorem_ipsum_dolor'
    remarks                   'lorem'
  end
end
