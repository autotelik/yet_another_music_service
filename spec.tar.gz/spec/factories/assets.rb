FactoryBot.define do
  factory :asset do
    role              'Others'
    requested_by      'Lorem ipsum'
    ref_id            'MS-092001'
    suffix            'PvR'
    assettype         ''
  end
end
