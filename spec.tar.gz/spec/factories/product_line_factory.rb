FactoryBot.define do
  factory :product_line do
    name                                  'default'
    sequence(:abbr)                       { |n| "MSP#{n}"}
    is_active                             true
    test_grid_project                     'RSPEC Test Grid Proj'
  end

  factory :pli_NTG55H, parent: :product_line do
    name                                  'GMN NTG55H'
    abbr                                  'GMN NTG55H'
    association :company_abbr,            factory: :ca_GMN
    association :shipping_specification,  factory: :SHIP_TEST
  end

  factory :pli_DHIVE, parent: :product_line do
    name                                  'dHive internal platform'
    abbr                                  'DH'
  end

  factory :product_line_maximal, parent: :pli_NTG55H do
    abbr                                  'dolor'
    parent_id                             99
    test_grid_project                     'lorem'
  end
end
