# TODO: using params..?
FactoryBot.define do
  factory :asset_type, aliases: [:RELEASE_NOTE] do
    name          'Release Notes'
    gencode        {
      week = sprintf('%02d', Date.today.cweek)
      year = Time.now.year.to_s[2..3]
      id = "#{name}#{week}#{year}"
      serial = sprintf('%02d', AssetType.new.next_serial(:id => id))
      # return "MN-#{year}#{week}#{serial}#{params[:suffix]}"
      "MN-#{year}#{week}#{serial}"
    }
  end

  factory :asset_type_maximal, parent: :asset_type do
    description     'lorem'
  end
end
