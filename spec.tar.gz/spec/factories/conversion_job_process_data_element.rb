FactoryBot.define do
  factory :conversion_job_process_data_element do
    association :conversion_job,        factory: :cj_DEFAULT
    association :process_data_element,  factory: :pde_TEST1_RDF_ELEMENT
    data_set_version                    0
    indirect                            false
  end
end
