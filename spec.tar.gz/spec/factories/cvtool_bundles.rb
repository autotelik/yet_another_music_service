FactoryBot.define do
  factory :cvtool_bundle, aliases: [:cb_DEV] do
    active_yn   true
    name        'dev'
  end

  factory :cvtool_bundle_maximal, parent: :cvtool_bundle do
    remarks     'lorem'
  end
end
