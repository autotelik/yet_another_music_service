FactoryBot.define do
  factory :coverage

  factory :DS_EUROPE1, parent: :coverage do
    name          'Europe DS EUR 1'
    description   'Coverage for DS'
  end

  factory :EUROPE1, parent: :coverage do
    name          'Europe1'
  end

  factory :EUROPE2, parent: :coverage do
    name          'Europe2'
  end

  factory :EUROPE3, parent: :coverage do
    name          'Europe3'
  end

  factory :EUROPE4, parent: :coverage do
    name          'Europe4'
  end

  factory :EUROPE5, parent: :coverage do
    name          'Europe5'
  end

  factory :EUROPE6, parent: :coverage do
    name          'Europe6'
  end

  factory :EUROPE7, parent: :coverage do
    name          'Europe7'
  end
  
  factory :WORLD1, parent: :coverage do
    name          'World'
  end
end
