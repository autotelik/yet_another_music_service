FactoryBot.define do
  factory :release_note_attachment do
    title               'lorem'
    package_directory   'ipsum'
  end

  factory :release_note_attachment_maximal, parent: :release_note_attachment do
    active_yn           true
    removed_yn          true
    description         'dolor'
  end
end
