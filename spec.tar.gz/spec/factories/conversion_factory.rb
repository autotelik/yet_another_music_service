FactoryBot.define do
  factory :conversion, aliases: [:c_DUMMY] do
    status                              Conversion::STATUS_CONVERSION
    association :data_release,          factory: :data_release
    association :region,                factory: :region
    association :conversiontool,        factory: :conversiontool
    association :cvtool_bundle,         factory: :cvtool_bundle
    input_format                        'lorem'
    output_format                       'ipsum'
    data_files                          'dolor'

    trait :with_database do
      result_files                        '/result/files/text'
      after(:create) do |c|
        c.generated_conversion_jobs << create(:conversion_job_maximal, :with_database, conversion: c)
      end
    end

    trait :with_jobs do
      ignore do
        job_count 1
      end
      after(:create) do |c, evaluator|
        # need to pass the conversion into conversion_job so the required LinkedJobs are created
        create_list(:conversion_job, evaluator.job_count, conversion: c, status: Job::STATUS_PLANNED)
      end
    end

    trait :with_removed_database do
      after(:create) do |c|
        c.generated_conversion_databases << create(:conversion_database_removed, conversion_job: create(:conversion_job))
      end
    end

    trait :with_marked_database do
      after(:create) do |c|
        c.generated_conversion_databases << create(:conversion_database_marked_for_removal, conversion_job: create(:conversion_job))
      end
    end

    trait :with_product_line do
      association :production_orderline, factory: [:pol_DEFAULT, :with_product_line]
    end

  end

  factory :c_DEFAULT, parent: :conversion do
    input_format                        'RDF'
    output_format                       'dHive'
    data_files                          '/data/files/text'
    association :project,               factory: :proj_PRODUCTION
    association :conv_script,           factory: :ConvScripts_20160227_2
    association :cvtool_template,       factory: :cvtool_template
    result_files                        '/result/files/text'
    association :production_orderline,  factory: :pol_DEFAULT
  end

  factory :c_tagged, parent: :c_DEFAULT do
    input_format                        'RDF'
    output_format                       'dHive'
    tag_md5sum_step                     'lorem'
    tag_executables                     'lorem'
  end

  factory :conversion_maximal, parent: :c_DEFAULT do
    request_by                          'lorem'
    request_date                        Time.now
    conversion_date                     Time.now
    priority                            'ipsum'
    supplier_id                         99
    company_abbr_id                       99
    product                             'dolor'
    additional_info                     'sit'
    request_data                        'amet'
    converter                           'consectetur'
    # calls model function, out of scope of controller testing
    # reference_numbers                   'adipiscing'
    remarks                             'elit'
    right_data_check                    true
    cvtool_check                        true
    outcome                             'Vestibulum'
    cvtoolenv                           'gravida'
    size_bytes                          99
    database_name                       'neque'
    volume_id                           'purus'
    reception_reference                 'id'
    purpose                             'interdum'
    legacy_type                         'nisi'
    region_id                           99
    region_name                         'libero'
    status                              0
    server_name                         'in'
    end_product_yn                      'lorem'
    cloned_from_id                      99
    assembly_id                         99
    status_remark                       'lorem'
    rejection_remark                    'lorem'
    design_sequence                     99
    process_data_id                     99
    request_user_id                     99
    replaced_by_id                      99
    conversion_environment_id           99
    outcome_persistent_yn               true
    patch_request_yn                    true
    force_create_id                     99
    coverage_id                         99
    tag_branch                          'lorem'
    tag_executables                     'lorem'
    tag_data_sets                       'lorem'
    conversion_design_id                99
    parameter_set_id                    99
    test_grid_cmd                       'lorem'
    tag_md5sum_step                     'lorem'
    cloned_job_id                       99
  end
end
