FactoryBot.define do
  factory :data_set_info do
    association :product,       factory: :product
    association :data_set,      factory: :data_set
    association :coverage,      factory: :coverage
    major_data_set_yn           false
  end

  factory :data_set_info_maximal, parent: :data_set_info do
    major_data_set_yn           true
  end
end
