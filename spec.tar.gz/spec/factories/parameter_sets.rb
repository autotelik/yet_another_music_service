FactoryBot.define do
  factory :parameter_set do
    association :project,   factory: :proj_PRODUCTION
    name                    'Controller test 101'
    active_yn               1
    updated_by              'default'
  end

  factory :ps_CONTROLLER_TEST01, parent: :parameter_set do
    json_content            '{"ADAS":"adas-321","APN_AdminRoadClassDrawOrder":"apn-654","AddBMWStreetTypeAttribute":"bmw-987"}'
    description             'Dummy set for controller test'
  end

  factory :ps_CONTROLLER_TEST02, parent: :parameter_set do
    json_content            '{"ADAS":"adas-321","APN_AdminRoadClassDrawOrder":"apn-654","AddBMWStreetTypeAttribute":"bmw-987"}'
    description             "Dummy set for controller test and weird search key 'ezel'"
  end

  factory :ps_PROJECT, parent: :parameter_set do
    association :project,   factory: :proj_REGRESSION
    json_content            '{"ADAS":"adas-321","APN_AdminRoadClassDrawOrder":"apn-654","AddBMWStreetTypeAttribute":"bmw-987"}'
    description             'Dummy set for controller test in project'
  end
  
  factory :ps_INACTIVE, parent: :parameter_set do
    json_content            '{"ADAS":"adas-321"}'
    description             'Dummy set for controller test as inactive'
    active_yn               0
  end

  factory :parameter_set_maximal, parent: :ps_PROJECT do
    active_yn               0
    updated_by              'lorem'
  end
end
