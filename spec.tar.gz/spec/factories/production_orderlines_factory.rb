FactoryBot.define do
  factory :production_orderline, aliases: %i[pol_DUMMY pol_DEFAULT] do
    product_accepted                     'Unknown'
    customer_feedback                    'n.a.'
    status                               ProductionOrderline::STATUS_REQUEST_CONVERSION
    association                          :production_order, factory: [:po_DUMMY, :with_product_set]

    trait :with_chosen_conversion do
      association :chosen_conversion, factory: :conversion
    end

    trait :with_conversion_jobs do
      ignore do
        job_count 1
      end
      after(:create) do |pol, evaluator|
        pol.chosen_conversion = create(:conversion, :with_jobs, job_count: evaluator.job_count)
      end
    end

    trait :with_product do
      association :product, factory: :product
    end

    trait :with_product_line do
      association :product_line, factory: :product_line
    end

    trait :with_test_grid_support do
      association :test_grid_region,  factory: :region
      test_grid_nrof_servers          2
      rdo_path                        '/dir1/dir2/file1'
      aknavi_db                       '/dir1/dir2/aknavi_db'
      ref_db                          '/dir1/dir2/ref_db'
      tg_yn                           true
    end

  end

  factory :production_orderline_full, parent: :production_orderline, traits: [:with_test_grid_support, :with_product_line]

  factory :production_orderline_clone_able, parent: :production_orderline_full, traits: [:with_conversion_jobs, :with_product] do
    association         :product_location
    association         :parameter_set
    test_grid_priority  true
  end

  factory :production_orderline_maximal, parent: :production_orderline do
    product_id                            99
    volume_id                             'MP-9999'
    quantity                              99
    owner                                 'ipsum'
    priority                              99
    product_accepted                      'dolor'
    product_design                        'ipsum'
    bp_message                            'dolor'
    design_sequence                       1
    chosen_conversion_id                  99
    created_from                          'lorem'
    parent_linenr                         99
    product_location_id                   99
    force_create                          true
    product_line_id                       99
    prior_volume_id                       99
    rdo_path                              'ipsum'
    parameter_set_id                      99
    test_yn                               true
    test_grid_nrof_servers                99
    test_grid_region_id                   99
    tg_yn                                 true
    ref_db                                'dolor'
    aknavi_db                             'dolor'
    ship_yn                               true
  end

  factory :pol_line1, parent: :production_orderline do
    association                          :production_order, factory: :po_clone
    remarks                              'pol line1'
  end

  factory :pol_line2, parent: :production_orderline do
    product_id                           97
    volume_id                            'MP-9997'
    association                          :production_order, factory: :po_clone
    association                          :chosen_conversion, factory: :conversion
    action_required_yn                   false
    bp_message                           'dummy message'
    status                               ProductionOrderline::STATUS_FINISHED
    quantity                             0
    remarks                              'pol line2'
    product_line_id                      99
    rdo_path                             '/dir1/dir2/file1'
    test_yn                              true
    test_grid_nrof_servers               2
    test_grid_region_id                  99
    test_grid_priority                   true
    aknavi_db                            '/dir1/dir2/file2'
    ref_db                               '/dir1/dir2/file3'
    ship_yn                              true
  end

  factory :pol_fe1, parent: :production_orderline do
    parent_linenr                        98
    design_sequence                      0
    association                          :production_order, factory: :po_clone
    remarks                              'pol front-end1'
  end

  factory :pol_fe2, parent: :production_orderline do
    parent_linenr                        98
    design_sequence                      1
    association                          :production_order, factory: :po_clone
    remarks                              'pol front-end2'
  end

  factory :pol_be1, parent: :production_orderline do
    parent_linenr                        99
    design_sequence                      0
    association                          :production_order, factory: :po_clone
    remarks                              'pol back-end1'
  end

  factory :pol_be2, parent: :production_orderline_maximal do
    product_id                           99
    volume_id                            'MP-9999'
    parent_linenr                        99
    design_sequence                      1
    association                          :production_order, factory: :po_clone
    parameter_set_id                     99
    remarks                              'pol back-end2'
  end
end
