FactoryBot.define do
  factory :conv_script, aliases: [:cs_one] do
    name          'ConvScripts_20160227_2'
    active_yn     true
  end

  factory :cs_two, parent: :conv_script do
    name          'ConvScripts_20160227_2'
    active_yn     false
  end

  factory :ConvScripts_20160227_2, aliases: [:conv_script_maximal], parent: :conv_script do
    remarks       'Created by system (ConvScript.sync_with_filesystem).'
  end
end
