FactoryBot.define do
  factory :outbound_orderline, aliases: [:OOL_DUMMY] do
    filename  'test.tar.gz'
    association :product,  factory: :product
    association :product_location,  factory: :plo_MP000_0001_0
    association :outbound_order,    factory: :outbound_order
  end
end
