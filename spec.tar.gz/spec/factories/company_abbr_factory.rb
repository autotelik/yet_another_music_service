FactoryBot.define do
  factory :company_abbr, aliases: [:ca_MAPSCAPE] do
    is_active                 true
    company_name              'Mapscape'
    relation_type             'Supplier'
    sequence(:dakota_id)      { rand(1000000) }
    sequence(:ms_abbr_3)      { |n| "MSP#{n}"}
  end

  factory :ca_NOK, parent: :company_abbr do
    company_name              'Nokia'
    sequence(:ms_abbr_3)      { |n| "NOK#{n}"}
  end

  factory :ca_GMN, parent: :company_abbr do
    company_name              'Garmin'
    sequence(:ms_abbr_3)      { |n| "GMN#{n}"}
  end

  factory :ca_RDF_SUPPLIER1, parent: :company_abbr do
    company_name              'RSU'
    sequence(:ms_abbr_3)      { |n| "RSU#{n}"}
  end

  factory :ca_HER, parent: :company_abbr do
    company_name              'HERE'
    sequence(:ms_abbr_3)      { |n| "HER#{n}"}
  end

  factory :ca_Here, parent: :company_abbr do
    company_name              'Here'
    sequence(:ms_abbr_3)      { |n| "HER#{n}"}
  end

  factory :company_abbr_maximal, parent: :company_abbr do
    association :company,     factory: :company
    abbr                      'lorem'
    ms_abbr_2                 'ipsum'
    copyright_name            'dolor'
    version                   9001
    updated_by                'sit'
  end
end
