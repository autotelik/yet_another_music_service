FactoryBot.define do
  factory :packing_specification_version do
    sequence(:created_at)                 { |n| Time.now + n.weeks }
    sequence(:updated_at)                 { |n| Time.now + n.weeks }
  end

  factory :PACK_TAR_GZ_VERSION, parent: :packing_specification_version do
    association :packing_specification,   factory: :PACK_TAR_GZ
    version                               1
    name                                  'Test Pack'
    description                           'Testing packing script. Will generate a .tar.gz file from the specified inputs'
    run_script {
      <<-RUN_SCRIPT
      echo "PACKINGFILE='$PACKINGFILE'."
      echo "PRODUCTS="
      for product in $PRODUCTS
      do
        echo $product
      done

      if [[ $PACKINGFILE == *.tar.gz ]]
      then
        TARFILE=${PACKINGFILE:0:`expr length $PACKINGFILE` -3}
        echo "Using local file '$TARFILE'."
      else
        echo "ERROR: PACKINGFILE does not have extension '.tar.gz'."
        exit 1
      fi

      # loop through the files
      for product in $PRODUCTS
      do
        if [ -d "$product" ]; then
          # directory: add files in directory minus specified exceptions
          echo "Adding directory $product."
          if [ -e "$TARFILE" ]
          then
            tar -C "$product" -rvWf "$TARFILE" . --exclude *.log.b.gz --exclude *.RDO.sq3 --exclude *.mapinfo
          else
            tar -C "$product" -cvWf "$TARFILE" . --exclude *.log.b.gz --exclude *.RDO.sq3 --exclude *.mapinfo
          fi
        elif [[ $product == *.tar.gz ]]
        then
          # compressed tar file: uncompress it and copy or merge it (included as proof of concept)
          echo "Adding compressed tar file $product."
          if [ -e "$TARFILE" ]
          then
            cp "$product" "tmp-$PACKINGTFILE" ; gzip -d "tmp-$PACKINGFILE" ; tar -AvWF "$TARFILE" "tmp-$TARFILE"; rm -f "tmp-$TARFILE"
            gzip -cd "$product" | tar -AvWf "$TARFILE"
          else
            cp "$product" "$PACKINGFILE" ; gzip -d "$PACKINGFILE"
          fi
        elif [[ $product == *.tar ]]
        then
          echo "Adding tar file $product."
          # tar file: copy or merge it (included as proof of concept)
          if [ -e "$TARFILE" ]
          then
            tar -AvWf "$TARFILE" "$product"
          else
            cp "$product" "$TARFILE"
          fi
        else
          # normal file: add file
          echo "Adding file $product."
          directory=`dirname "$product"`
          filename=`basename "$product"`
          if [ -e "$TARFILE" ]
          then
            tar -C "$directory" -rvf "$TARFILE" "$filename"
          else
            tar -C "$directory" -cvWf "$TARFILE" "$filename"
          fi
        fi

        # exit in case of errors
        result=$?
        if [ $result != 0 ]
        then
          exit $result
        fi
        done

        # compress tar file
        echo "Compressing '$TARFILE'."
        gzip "$TARFILE"
        result=$?
        if [ $result != 0 ]
        then
          exit $result
        fi

        # Verify compressed tar file
        echo "Verifying '$PACKINGFILE'."
        tar -tf "$PACKINGFILE" >/dev/null
        result=$?
        if [ $result != 0 ]
        then
          exit $result
        fi

        echo "Done."
        exit 0
      RUN_SCRIPT
    }
    manual_yn                             false
    status                                'approved'
    schedule_manual                       false
    schedule_cores                        1
    schedule_memory_base                  0
    schedule_memory_times_input           0
    schedule_diskspace_base               0
    schedule_diskspace_times_input        1
    schedule_allow_virtual                true
    schedule_exclusive                    false
  end

  factory :PACK_RENAME_VERSION, parent: :packing_specification_version do
    association :packing_specification,   factory: :PACK_RENAME
    version                               1
    name                                  'Rename Pack'
    description                           'This pack expects just one product and will rename it to the specified filename before it will be shipped.'
    run_script {
      <<-RUN_SCRIPT
      echo "PACKINGFILE='$PACKINGFILE'."
      count=0
      echo "PRODUCTS="
      for product in $PRODUCTS
      do
        count=$((count+1))
        echo $product
      done

      if [[ $count != 1 ]]
      then
        echo "ERROR: You should specify exactly one product!"
        exit 1
      fi

      cp ${PRODUCTS[0]} $PACKINGFILE
      result=$?
      if [ $result != 0 ]
      then
        exit $result
      fi
      echo "Done."
      exit 0
      RUN_SCRIPT
    }
    manual_yn                             false
    status                                'approved'
    schedule_manual                       false
    schedule_cores                        1
    schedule_memory_base                  0
    schedule_memory_times_input           0
    schedule_diskspace_base               0
    schedule_diskspace_times_input        1
    schedule_allow_virtual                true
    schedule_exclusive                    false
  end

  factory :PACK_MINIMAL_VERSION, parent: :packing_specification_version do
    association :packing_specification,   factory: :PACK_MINIMAL
    status                                'new'
    version                               1
  end

  factory :PACK_DUMMY_VERSION_1, parent: :packing_specification_version do
    association :packing_specification,   factory: :PACK_DUMMY
    name                                  'dum'
    status                                'new'
    version                               1
  end

  factory :PACK_DUMMY_VERSION_2, parent: :packing_specification_version do
    association :packing_specification,   factory: :PACK_DUMMY
    name                                  'dummy'
    status                                'draft'
    version 2
  end

  factory :PACK_REVIEW_VERSION_1, parent: :packing_specification_version do
    association :packing_specification,   factory: :PACK_REVIEW
    name                                  'review spec new'
    status                                'new'
    version                               1
  end

  factory :PACK_REVIEW_VERSION_2, parent: :packing_specification_version do
    association :packing_specification,   factory: :PACK_REVIEW
    name                                  'review spec draft'
    status                                'draft'
    version 2
  end

  factory :PACK_REVIEW_VERSION_3, parent: :packing_specification_version do
    association :packing_specification,   factory: :PACK_REVIEW
    name                                  'review spec'
    status                                'review'
    version 3
  end

  factory :PACK_APPROVED_VERSION_1, parent: :packing_specification_version do
    association :packing_specification,   factory: :PACK_APPROVED
    name                                  'approved spec new'
    status                                'new'
    version                               1
  end

  factory :PACK_APPROVED_VERSION_2, parent: :packing_specification_version do
    association :packing_specification,   factory: :PACK_APPROVED
    name                                  'approved spec'
    status                                'approved'
    version 2
  end

  factory :PACK_OBSOLETE_VERSION_1, parent: :packing_specification_version do
    association :packing_specification,   factory: :PACK_OBSOLETE
    name                                  'obsolete spec new'
    status                                'new'
    version                               1
  end

  factory :PACK_OBSOLETE_VERSION_2, parent: :packing_specification_version do
    association :packing_specification,   factory: :PACK_OBSOLETE
    name                                  'obsolete spec approved'
    status                                'approved'
    version 2
  end

  factory :PACK_OBSOLETE_VERSION_3, parent: :packing_specification_version do
    association :packing_specification,   factory: :PACK_OBSOLETE
    name                                  'obsolete spec'
    status                                'obsolete'
    version 3
  end

  factory :PACK_FULL_WORK_FLOW_VERSION_1, parent: :packing_specification_version do
    association :packing_specification,   factory: :PACK_FULL_WORK_FLOW
    name                                  'full work flow step 1'
    status                                'new'
    version                               1
  end

  factory :PACK_FULL_WORK_FLOW_VERSION_2, parent: :packing_specification_version do
    association :packing_specification,   factory: :PACK_FULL_WORK_FLOW
    name                                  'full work flow step 2'
    status                                'draft'
    version 2
  end

  factory :PACK_FULL_WORK_FLOW_VERSION_3, parent: :packing_specification_version do
    association :packing_specification,   factory: :PACK_FULL_WORK_FLOW
    name                                  'full work flow step 3'
    status                                'review'
    version 3
  end

  factory :PACK_FULL_WORK_FLOW_VERSION_4, parent: :packing_specification_version do
    association :packing_specification,   factory: :PACK_FULL_WORK_FLOW
    name                                  'full work flow step 4'
    status                                'draft'
    version 4
  end

  factory :PACK_FULL_WORK_FLOW_VERSION_5, parent: :packing_specification_version do
    association :packing_specification,   factory: :PACK_FULL_WORK_FLOW
    name                                  'full work flow step 5'
    status                                'approved'
    version 5
  end

  factory :PACK_FULL_WORK_FLOW_VERSION_6, parent: :packing_specification_version do
    association :packing_specification,   factory: :PACK_FULL_WORK_FLOW
    name                                  'full work flow step 6'
    status                                'draft'
    version 6
  end

  factory :PACK_FULL_WORK_FLOW_VERSION_7, parent: :packing_specification_version do
    association :packing_specification,   factory: :PACK_FULL_WORK_FLOW
    name                                  'full work flow step 7'
    status                                'review'
    version 7
  end

  factory :PACK_FULL_WORK_FLOW_VERSION_8, parent: :packing_specification_version do
    association :packing_specification,   factory: :PACK_FULL_WORK_FLOW
    name                                  'full work flow step 8'
    status                                'approved'
    version 8
  end

  factory :PACK_FULL_WORK_FLOW_VERSION_9, parent: :packing_specification_version do
    association :packing_specification,   factory: :PACK_FULL_WORK_FLOW
    name                                  'full work flow step 9'
    status                                'draft'
    version 9
  end

  factory :PACK_FULL_WORK_FLOW_VERSION_10, parent: :packing_specification_version do
    association :packing_specification,   factory: :PACK_FULL_WORK_FLOW
    name                                  'full work flow step 10'
    status                                'review'
    version                               10
  end
end
