FactoryBot.define do
  factory :poi_mapping_layout, aliases: [:pml_8] do
    pml_filename                 'nds_gmn_d55_her_eur_nds_v1.4_20131029.poimap.csv'
    pml_directory                '/volumes2/production_tests/test/WebMisScripts/PML'
  end

  factory :poi_mapping_layout_maximal, parent: :poi_mapping_layout do
    pml_filename                 'lorem'
    pml_directory                 '/volumes1/production_tests/test/WebMisScripts/PML'
  end
end
