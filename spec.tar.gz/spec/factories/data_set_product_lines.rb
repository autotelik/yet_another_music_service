FactoryBot.define do
  factory :data_set_product_line, aliases: [:dspl_one, :dspl_two] do
    data_set_id       1
    product_line_id   1
  end
end
