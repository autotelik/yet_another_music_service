FactoryBot.define do
  factory :outbound_order, aliases: [:OO_MINIMAL] do
    shipping_type                         ShippingSpecification::SHIPPING_TYPE_MANUAL 
    status                                OutboundOrder::STATUS_MANUAL
    association :file_transfer_account
  end

  factory :OO_DUMMY, parent: :outbound_order do
    send_date                             '2015-09-01'
    send_by                               'Klaas Klaasen'
    remarks                               'Dummy test outbound order'
    release_mail_send                     false
    sequence(:release_mail_send_date)     { |n| Time.now + n.weeks }
    association :outbound_order,          factory: :OO_MINIMAL
    status                                OutboundOrder::STATUS_DRAFT
    association :shipping_specification,  factory: :SHIP_TEST
    sftp_subdirectory                     '/test'
    mailing_remarks                       'There are no mailing remarks'
    shipping_type                         ShippingSpecification::SHIPPING_TYPE_COURIER
    bcc_list                              'jan@dummy.com, piet@general.net, klaas@amc.edu'
  end

  factory :outbound_order_maximal, parent: :OO_DUMMY do
    shipping_parent_id                    99
    ext_reference                         'lorem'
    release_notes_send_date               Time.now
  end
end
