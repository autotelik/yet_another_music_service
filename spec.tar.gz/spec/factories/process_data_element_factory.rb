FactoryBot.define do
  factory :process_data_element do
    removed_yn                                false

    trait :with_conversion_jobs do
      after(:create) do |pde|
        pde.conversion_jobs << create(:cj_production_orderlines)
      end
    end

    trait :with_specification do
      association :process_data_specification, :with_conversion_design_name
    end

  end
  
  factory :pde_TEST1_RDF_ELEMENT, parent: :process_data_element do
    association :data_set,                    factory: :ds_TEST1
    association :process_data_specification,  factory: :pds_RDF
    directory                                 '/volumes2/production_tests/test/data/process/backofficedevelopment/rdf/eur/her/2013_q2/a_code_filling_front_end_rdf2dh_her/rdf'
    remarks                                   'CREATED BY REGRESSION TEST'
    association :reception,                   factory: :r_TEST5

    after(:create) do |ds|
      FileUtils.mkdir_p(ds.directory) unless File.exist?(ds.directory)
    end
  end

  factory :pde_conversion_jobs, parent: :process_data_element, traits: [:with_conversion_jobs] do
    association :process_data_specification,  factory: :pds_RDF
    directory                                 { create_scratch_path('rdf') }    # a_code_filling_front_end_rdf2dh_her/rdf
    remarks                                   'CREATED BY RSPEC'
    association :reception,                   factory: :r_TEST5
  end

  factory :pde_TEST1_DOC_ELEMENT, parent: :process_data_element do
    association :data_set,                    factory: :ds_TEST1
    association :process_data_specification,  factory: :pds_DOC
    directory                                 '/volumes2/production_tests/test/data/process/backofficedevelopment/rdf/tst1/rsu/a_code_filling_front_end_rdf2dh_her/rn'
    remarks                                   'CREATED BY REGRESSION TEST'
    association :reception,                   factory: :r_TEST5
  end

  factory :pde_TEST_RDF_EUR_ELEMENT, parent: :process_data_element do
    association :data_set,                    factory: :ds_TESTRDFEUR13Q2NOK
    association :process_data_specification,  factory: :pds_RDF
    directory                                 '/volumes2/production_tests/test/data/process/backofficedevelopment/rdf/eur/nok/2013_q2/rdf'
    remarks                                   'CREATED BY REGRESSION TEST'
  end

  factory :pde_TEST_JVS_EUR_ELEMENT, parent: :process_data_element do
    association :data_set,                    factory: :ds_TESTJVSEUR13Q2NOK
    association :process_data_specification,  factory: :pds_JVS
    directory                                 '/volumes2/production_tests/test/data/process/backofficedevelopment/jvs/eur/nok/2013_q2_junction_views/jvs'
    remarks                                   'CREATED BY REGRESSION TEST'
  end

  factory :pde_TEST_TMC_NED_ELEMENT, parent: :process_data_element do
    association :data_set,                    factory: :ds_TESTTMCNED13Q1NOK
    association :process_data_specification,  factory: :pds_TMC
    directory                                 '/volumes2/production_tests/test/data/process/backofficedevelopment/tmc/nld/nok/2013_q1/ltef'
    remarks                                   'CREATED BY REGRESSION TEST'
    association :reception,                   factory: :r_TEST4
  end

  factory :pde_TEST_POI_EUR_ELEMENT, parent: :process_data_element do
    association :data_set,                    factory: :ds_TESTPOIEUR13Q2NOK
    association :process_data_specification,  factory: :pds_POI
    directory                                 '/volumes2/production_tests/test/data/process/backofficedevelopment/poi/eur/nok/2013_q2_nokfuel/fxml'
    remarks                                   'CREATED BY REGRESSION TEST'
  end

  factory :pde_TEST_VAR_WLD_ELEMENT, parent: :process_data_element do
    association :data_set,                    factory: :ds_TESTVARWLD13Q2NOK
    association :process_data_specification,  factory: :pds_VAR
    directory                                 '/volumes2/production_tests/test/data/process/backofficedevelopment/var/wld/nok/2013_q2_brand_icons/bic'
    remarks                                   'CREATED BY REGRESSION TEST'
    association :reception,                   factory: :r_TEST4
  end

  factory :pde_TEST_3DC_EVJS_ELEMENT, parent: :process_data_element do
    association :data_set,                    factory: :ds_TEST3DCEJVSEUR13Q2NOK
    association :process_data_specification,  factory: :pds_3DC
    directory                                 '/volumes2/production_tests/test/data/process/backofficedevelopment/3dc/eur/nok/2013_q2_enhanced_junction_views/3cm'
    remarks                                   'CREATED BY REGRESSION TEST'
    association :reception,                   factory: :r_TEST3
  end

  factory :pde_TEST_3DC_ACM_ELEMENT, parent: :process_data_element do
    association :data_set,                    factory: :ds_TEST3DCACMEUR13Q2NOK
    association :process_data_specification,  factory: :pds_3DC
    directory                                 '/volumes2/production_tests/test/data/process/backofficedevelopment/3dc/eur/nok/2013_q2_advanced_city_models/3cm'
    remarks                                   'CREATED BY REGRESSION TEST'
    association :reception,                   factory: :r_TEST3
  end
end
