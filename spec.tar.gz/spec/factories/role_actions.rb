FactoryBot.define do
  factory :role_action, aliases: [:role_action_maximal] do
    association :role,    factory: :Admin, strategy: :create
    controller_name       'data_sets'
    action_name           'browse_directory'
  end
end
