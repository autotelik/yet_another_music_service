FactoryBot.define do
  factory :packing_job do
    association :outbound_orderline,                    factory: :outbound_orderline
    association :fail_category_logged_by_user,          factory: :user
  end

  factory :packing_job_maximal, parent: :packing_job do
    run_server                      'lorem'
    run_command                     'ipsum'
    run_pid                         'dolor'
    start_time                      Time.now
    finish_time                     Time.now
    stdout_log                      'sit'
    exitcode                        0
    fail_reason                     'amet'
    schedule_manual                 true
    schedule_cores                  99
    schedule_memory                 99
    schedule_diskspace              99
    schedule_allow_virtual          true
    schedule_exclusive              true
    status                          0
    conversion_environment_id       99
    lock_version                    0
    type                            'PackingJob'
    bug_tracker_id                  'adipiscing'
    group_amount                    99
    group_by                        'elit'
    group_value                     'Vestibulum'
    action_log                      'gravida'
    fail_category                   'neque'
    fail_category_logged_on         Time.now
    estimated_duration              99
    result_dir_size_bytes           99
    original_job_id                 99
    scheduler_log                   99
    merge_location                  true
    reserved_path                   'a_random_path'
    file_system_status              99
    tag_data_sets                   'purus'
    tag_region_codes                'id'
    tag_group_region_code           'interdum'
    script_path                     'nisi'
    dryrun_yn                       true
  end
end
