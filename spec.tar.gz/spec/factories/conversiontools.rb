FactoryBot.define do
  factory :conversiontool, aliases: [:DEV_TOOL] do
    isactive          true
    sequence(:code)   {|n| "dev_latest#{n}"}
    remarks           'Created by system (Conversiontool.sync_with_filesystem).'
  end

  factory :conversiontool_maximal, parent: :conversiontool do
    description       'lorem'
    release           'mysql_reserved_word'
    tool_type         'ipsum'
    major_release     'dolor'
    prod_released_yn  1
  end

  factory :api_conversiontool, parent: :conversiontool do
    isactive          true
    sequence(:code)   {|n| "BladeRunner_#{n}"}
    remarks           'Production Order'
    prod_released_yn  1
  end
end
