FactoryBot.define do
  factory :validation_job do
    type                      'ValidationJob'
    run_script                ''
    working_dir               ''
    association :project,     factory: :proj_PRODUCTION
  end

  factory :vj_DEFAULT, parent: :validation_job do
    association :conversion_database, factory: :conversion_database
  end

  factory :validation_job_maximal, parent: :vj_DEFAULT do
    run_server                      'lorem'
    run_command                     'ipsum'
    run_pid                         'dolor'
    start_time                      Time.now
    finish_time                     Time.now
    stdout_log                      'sit'
    exitcode                        0
    fail_reason                     'amet'
    schedule_manual                 true
    schedule_cores                  99
    schedule_memory                 99
    schedule_diskspace              99
    schedule_allow_virtual          true
    schedule_exclusive              true
    status                          Job::STATUS_PLANNED
    conversion_environment_id       99
    lock_version                    0
    reference_id                    99
    type                            'ValidationJob'
    bug_tracker_id                  'adipiscing'
    group_amount                    99
    group_by                        'elit'
    group_value                     'Vestibulum'
    action_log                      'gravida'
    fail_category                   'neque'
    fail_category_logged_by_user_id 99 #user
    fail_category_logged_on         Time.now
    estimated_duration              99
    result_dir_size_bytes           99
    original_job_id                 99
    scheduler_log                   99
    merge_location                  true
    reserved_path                   'a_random_path'
    file_system_status              99
    tag_data_sets                   'purus'
    tag_region_codes                'id'
    tag_group_region_code           'interdum'
    script_path                     'nisi'
    dryrun_yn                       true
  end
end
