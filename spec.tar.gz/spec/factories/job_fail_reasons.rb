FactoryBot.define do
  factory :job_fail_reason do
    reason                'F03 - Conversion tool crash'
    job_type              'ConversionJob'
  end

  factory :job_fail_reason_maximal, parent: :job_fail_reason do
    description           'lorem'
  end
end
