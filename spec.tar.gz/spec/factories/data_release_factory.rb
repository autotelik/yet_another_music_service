FactoryBot.define do
  factory :data_release, aliases: [:dr_2013Q1, :dr_TEST_RELEASE] do
    sequence(:name)             { |n| "#{DateTime.now.year}Q#{n}" }
    sequence(:release_code)     { |n| "#{DateTime.now.year}Q#{n}" }
    production                  true
    aliases                     '13Q2,Q213'
    active                      true
  end

  factory :dr_2013Q2, parent: :data_release do
    name                        "2013_Q2"
    release_code                '2013_Q2'
  end

  factory :data_release_maximal, parent: :data_release do
    datasource_id               99
    active                      true
    production                  true
    prev_data_release_id        99
  end
end
