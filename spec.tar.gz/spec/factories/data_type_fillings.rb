FactoryBot.define do
  factory :dtf_TEST_FILLING, class: DataTypeFilling do
    association :data_type,   factory: :dt_DOC
    association :filling,     factory: :f_TEST_FILLING
  end

  factory :dtf_3LM_LANDMARKS, class: DataTypeFilling do
    association :data_type,   factory: :dt_3LM
    association :filling,     factory: :f_LANDMARKS
  end

  factory :dtf_3LM_JVS, class: DataTypeFilling do
    association :data_type,   factory: :dt_3LM
    association :filling,     factory: :f_JVS
  end

  factory :dtf_POI_NOKF, class: DataTypeFilling do
    association :data_type,   factory: :dt_POI
    association :filling,     factory: :f_NOKF
  end

  factory :dtf_POI_BIC, class: DataTypeFilling do
    association :data_type,   factory: :dt_POI
    association :filling,     factory: :f_BIC
  end

  factory :dtf_SHP_EJVS, class: DataTypeFilling do
    association :data_type,   factory: :dt_SHP
    association :filling,     factory: :f_EJVS
  end

  factory :dtf_SHP_ACM, class: DataTypeFilling do
    association :data_type,   factory: :dt_SHP
    association :filling,     factory: :f_ACM
  end
end
