FactoryBot.define do
  factory :conversion_environment do
    name                  'CVEEngine_20170411'
    active_yn             true
  end

  factory :conversion_environment_maximal, parent: :conversion_environment do
    remarks               'lorem'
  end
end
