FactoryBot.define do
  factory :user do
    partner_code  'MAPSCAPE'
    email         'noreply@mapscape.eu'

    trait :as_admin do
      after(:create) { |u| u.roles_users <<  create(:roles_user, project_id: 1) }
    end

  end

  factory :TESTUSER, parent: :user do
    first_name    'Test'
    last_name     'User'
    user_name     'testuser'
    pw            'satnav43953'
    job_title     'Development Engineer'
    phone_ext     '569'
    mg_work_dir   '/data/users/rails.test/mapgrade/work'
  end

  factory :TESTUSER1, parent: :user do
    first_name    'Test'
    last_name     'User'
    user_name     'test.user'
    job_title     'Test Engineer'
    email         'TESTUSER1@mapscape.eu'
  end

  factory :TESTUSER2, parent: :user do
    first_name    'Another'
    last_name     'TestCase'
    user_name     'another.testcase'
    job_title     'Another Engineer'
    email         'TESTUSER2@mapscape.eu'
  end

  factory :RAILSTEST, parent: :user do
    first_name    'rails'
    last_name     'test'
    user_name     'rails.test'
    job_title     'Regression Tester'
  end

  factory :user_maximal, parent: :TESTUSER do
    uidnumber       99
    sequence(:email) { |n| "noreply_#{n}@mapscape.eu"}
  end
end
