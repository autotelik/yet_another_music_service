FactoryBot.define do
  factory :shipping_specification, aliases: [:SHIP_MINIMAL] do
    sequence(:name)                       { |n| "Lorem_#{n}" }
    sequence(:created_at)                 { |n| Time.now + n.weeks }
    association :file_transfer_account,   factory: :FTP_TEST

    trait :with_distribution_list do
      after(:create) do |ss|
        ss.distribution_lists << create(:distribution_list, shipping_specification: ss)
      end
    end
  end

  factory :SHIP_TEST, parent: :shipping_specification do
    name                                  'Shipping Test'
    association :packing_specification,   factory: :PACK_TAR_GZ
    shipping_type                         ShippingSpecification::SHIPPING_TYPE_SFTP_AUTOMATIC
  end

  factory :SHIP_FULL, parent: :shipping_specification do
    name                                  'Full spec'
    association :packing_specification,   factory: :PACK_RENAME
    shipping_type                         ShippingSpecification::SHIPPING_TYPE_MANUAL
    association :file_transfer_account,   factory: :FTP_DUMMY
  end

  factory :shipping_specification_maximal, parent: :shipping_specification do
    delivery_notification_sentence        'lorem'
  end
end
