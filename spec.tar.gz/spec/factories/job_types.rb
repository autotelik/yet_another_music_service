FactoryBot.define do
  factory :job_type do
    association :server,  factory: :LOCALHOST
    allowed_yn  true
  end

  factory :jt_one, aliases: [:jt_conversion], parent: :job_type do
    name        'ConversionJob'
  end

  factory :jt_two, aliases: [:jt_validation], parent: :job_type do
    name        'ValidationJob'
  end

  factory :jt_three, aliases: [:jt_packing], parent: :job_type do
    name        'PackingJob'
  end

  factory :jt_four, aliases: [:jt_test_request], parent: :job_type do
    name        'TestRequestJob'
  end

  factory :jt_five, aliases: [:jt_shipping], parent: :job_type do
    name        'ShippingJob'
  end
end
