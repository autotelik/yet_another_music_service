FactoryBot.define do
  factory :production_order, aliases: %i[po_DUMMY po_DEFAULT] do
    name                      'po_default'
    association :project,     factory: :proj_PRODUCTION
    association :ordertype,   factory: :frontend

    trait :with_production_orderlines do
      after(:create) do |po|
        po.production_orderlines << create(:production_orderline, :with_product_line)
      end

    end

    trait :with_product_set do
      association :product_set,  factory: :product_set
    end

  end

  factory :po_clone, parent: :production_order do
    name                      'original order'
    status                    ProductionOrder::STATUS_FINISHED
    expired_yn                true
    baseline_commitment_date  '2017-01-01 00:00:00'
    modified_commitment_date  '2017-02-01 00:00:00'
    association :ordertype,   factory: :ordertype
  end

  factory :po_expiration_candidate, parent: :po_clone do
    expired_yn                false
    expiry_notification_send  false
    expiry_date               { Date.current + 1 }
  end
end
