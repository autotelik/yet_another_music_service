FactoryBot.define do
  factory :linked_job do
    included_job                        false
  end

  factory :lj_DUMMY, parent: :linked_job do
    included_job                        false
  end

  factory :lj_DEFAULT, parent: :linked_job do
    included_job                        false
  end

  factory :lj_included, parent: :linked_job do
    association :conversion,     factory: :conversion
    association :job,            factory: :conversion_job
  end
end
