FactoryBot.define do
  factory :reception, aliases: [:r_DUMMY] do
    association :region,        factory: :r_TEST_REGION1
    purpose                     'test'
    association :data_release,  factory: :dr_TEST_RELEASE
    association :data_type,     factory: :dt_DOC
    status                      'REJECTED'
    sequence(:revision)         { |n| '%s%02dA%02d' % [[*"A".."Z"].sample, n % 100, (n + 1) % 100] }

    trait :available do
      status            Reception::STATUS_COMPLETED
      can_be_removed_yn false
      removed_yn        false
      storage_location  'dolor'
    end

    trait :with_company do
      association :company_abbr
    end
  end

  factory :reception_maximal, parent: :reception do
    company_abbr_id               99
    area_id                     99
    referenceid                 99
    reception_date              Time.now
    purpose                     'lorem'
    remarks                     'ipsum'
    storage_location            'dolor'
    area_type                   'lorem'
    send_status                 true
    sendto                      'ipsum'
    senddate                    Time.now
    userid                      99
    user_name                   'dolor'
    conversiontool              'lorem'
    region_name                 'ipsum'
    removed_yn                  true
    validated_yn                true
    expected_arrival_date       Time.now
    expected_reception_date     Time.now
    priority                    'dolor'
    data_intake_requested       true
    data_intake_ok              true
    data_intake_result_text     'lorem'
    validation_requested        true
    validation_result_text      'ipsum'
    validated_by                'dolor'
    data_intake_by              'lorem'
    ruleset                     'ipsum'
    source_location             'dolor'
    rejection_remark            'lorem'
    request_remarks             'ipsum'
    requested_by                'dolor'
    supplier_ref                'lorem'
    volume_id                   99
    parent_id                   99
    can_be_removed_yn           true
    persistent_yn               false
    removal_mark_by_username    'lorem'
    removed_by_username         'ipsum'
    data_set_id                 99
    filling_id                  99
  end
  
  factory :r_TEST1, class: Reception do
    association :region,        factory: :r_TEST_REGION1
    purpose                     'production'
    association :data_release,  factory: :dr_2013Q2
    association :data_type,     factory: :dt_RDF
    status                      'EXPECTED'
    supplier_ref                'REFAA11'
  end
  
  factory :r_TEST2, class: Reception do
    association :region,        factory: :r_Europe
    purpose                     'production'
    association :data_release,  factory: :dr_2013Q2
    association :data_type,     factory: :dt_RDF
    status                      'REQUESTED'
    source_location             '/default'
    association :data_set,      factory: :ds_TEST2
    supplier_ref                'REFBB22'
  end
  
  factory :r_TEST3, class: Reception do
    association :region,        factory: :r_Europe
    purpose                     'production'
    association :data_release,  factory: :dr_2013Q2
    association :data_type,     factory: :dt_3DC
    status                      'INPROGRESS'
    supplier_ref                'REFCC33'
  end
  
  factory :r_TEST4, class: Reception do
    association :region,        factory: :r_Europe
    purpose                     'production'
    association :data_release,  factory: :dr_2013Q1
    association :data_type,     factory: :dt_VAR
    status                      'COMPLETED'
    association :data_set,      factory: :ds_TEST1
    supplier_ref                  'REFDD44'
    can_be_removed_yn           false
    removed_yn                  false
    storage_location            '/a/location/'
  end
  
  factory :r_TEST5, class: Reception do
    association :region,        factory: :r_WORLD
    purpose                     'production'
    association :data_release,  factory: :dr_2013Q2
    association :data_type,     factory: :dt_RDF
    status                      'COMPLETED'
    association :data_set,      factory: :ds_TEST1
    supplier_ref                'REFEE55'
    can_be_removed_yn           false
    removed_yn                  false
    storage_location            '/a/location/'
  end
end
