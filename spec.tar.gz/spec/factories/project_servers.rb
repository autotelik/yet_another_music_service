FactoryBot.define do
  factory :project_server do
    association :server,    factory: :LOCALHOST
  end

  factory :PROD_PROD, parent: :project_server do
    association :project,   factory: :proj_PRODUCTION
  end

  factory :REGRESSION_SERVER, parent: :project_server do
    association :project,   factory: :proj_REGRESSION
  end
end
