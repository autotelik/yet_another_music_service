FactoryBot.define do
  factory :packing_specification do
    sequence(:name)           { |n| "Default #{n}" }
    status                    PackingSpecification::STATUS_NEW
    sequence(:created_at)     { |n| Time.now + n.weeks }
    sequence(:updated_at)     { |n| Time.now + n.weeks }
  end

  factory :PACK_TAR_GZ, aliases: [:packing_specification_maximal], class: PackingSpecification do
    name                              'Test Pack'
    description                       'Testing packing script. Will generate a .tar.gz file from the specified inputs'
    run_script {
      <<-RUN_SCRIPT
      echo "PACKINGFILE='$PACKINGFILE'."
      echo "PRODUCTS="
      for product in $PRODUCTS
      do
        echo $product
      done
      TARFILE=$PACKINGFILE.tar

      # loop through the files
      for product in $PRODUCTS
      do
        if [ -d "$product" ]; then
          # directory: add files in directory minus specified exceptions
          echo "Adding directory $product."
          if [ -e "$TARFILE" ]
          then
            tar -C "$product" -rvWf "$TARFILE" . --exclude *.log.b.gz --exclude *.RDO.sq3 --exclude *.mapinfo
          else
            tar -C "$product" -cvWf "$TARFILE" . --exclude *.log.b.gz --exclude *.RDO.sq3 --exclude *.mapinfo
          fi
        elif [[ $product == *.tar.gz ]]
        then
          # compressed tar file: uncompress it and copy or merge it (included as proof of concept)
          echo "Adding compressed tar file $product."
          if [ -e "$TARFILE" ]
          then
            cp "$product" "tmp-$PACKINGTFILE" ; gzip -d "tmp-$PACKINGFILE" ; tar -AvWF "$TARFILE" "tmp-$TARFILE"; rm -f "tmp-$TARFILE"
            gzip -cd "$product" | tar -AvWf "$TARFILE"
          else
            cp "$product" "$PACKINGFILE" ; gzip -d "$PACKINGFILE"
          fi
        elif [[ $product == *.tar ]]
        then
          echo "Adding tar file $product."
          # tar file: copy or merge it (included as proof of concept)
          if [ -e "$TARFILE" ]
          then
            tar -AvWf "$TARFILE" "$product"
          else
            cp "$product" "$TARFILE"
          fi
        else
          # normal file: add file
          echo "Adding file $product."
          directory=`dirname "$product"`
          filename=`basename "$product"`
          if [ -e "$TARFILE" ]
          then
            tar -C "$directory" -rvf "$TARFILE" "$filename"
          else
            tar -C "$directory" -cvWf "$TARFILE" "$filename"
          fi
        fi

        # exit in case of errors
        result=$?
        if [ $result != 0 ]
        then
          exit $result
        fi
        done

        # compress tar file
        echo "Compressing '$TARFILE'."
        gzip "$TARFILE"
        result=$?
        if [ $result != 0 ]
        then
          exit $result
        fi

        # Verify compressed tar file
        echo "Verifying '$PACKINGFILE'."
        tar -tf "$TARFILE.gz" >/dev/null
        result=$?
        if [ $result != 0 ]
        then
          exit $result
        fi

        echo "Done."
        exit 0
      RUN_SCRIPT
    }
    manual_yn                         false
    status                            PackingSpecification::STATUS_APPROVED
    schedule_manual                   false
    schedule_cores                    1
    schedule_memory_base              0
    schedule_memory_times_input       0
    schedule_diskspace_base           0
    schedule_diskspace_times_input    1
    schedule_allow_virtual            true
    schedule_exclusive                false
  end

  factory :PACK_RENAME, class: PackingSpecification do
    name                              'Rename Pack'
    description                       'This pack expects just one product and will rename it to the specified filename before it will be shipped.'
    run_script {
      <<-RUN_SCRIPT
      echo "PACKINGFILE='$PACKINGFILE'."
      count=0
      echo "PRODUCTS="
      for product in $PRODUCTS
      do
        count=$((count+1))
        echo $product
      done

      if [[ $count != 1 ]]
      then
        echo "ERROR: You should specify exactly one product!"
        exit 1
      fi

      cp ${PRODUCTS[0]} $PACKINGFILE
      result=$?
      if [ $result != 0 ]
      then
        exit $result
      fi
      echo "Done."
      exit 0
      RUN_SCRIPT
    }
    manual_yn                         false
    status                            PackingSpecification::STATUS_APPROVED
    schedule_manual                   false
    schedule_cores                    1
    schedule_memory_base              0
    schedule_memory_times_input       0
    schedule_diskspace_base           0
    schedule_diskspace_times_input    1
    schedule_allow_virtual            true
    schedule_exclusive                false
  end

  factory :PACK_MINIMAL, class: PackingSpecification do
    name                              'minimal'
    status                            PackingSpecification::STATUS_NEW
  end

  factory :PACK_DUMMY, class: PackingSpecification do
    name                              'dummy'
    status                            PackingSpecification::STATUS_DRAFT
  end

  factory :PACK_REVIEW, class: PackingSpecification do
    name                              'review spec'
    status                            PackingSpecification::STATUS_REVIEW
  end

  factory :PACK_APPROVED, class: PackingSpecification do
    name                              'approved spec'
    status                            PackingSpecification::STATUS_APPROVED
  end

  factory :PACK_OBSOLETE, class: PackingSpecification do
    name                              'obsolete spec'
    status                            PackingSpecification::STATUS_OBSOLETE
  end

  factory :PACK_FULL_WORK_FLOW, class: PackingSpecification do
    name                              'full work flow'
    status                            PackingSpecification::STATUS_REVIEW
  end
  factory :PACK_MIN_NO_VERSION, class: PackingSpecification do
    name                              'minimal with no versions'
    status                            PackingSpecification::STATUS_NEW
  end

  factory :PACK_FULL_NO_VERSION, class: PackingSpecification do
    name                              'existing pack with no versions'
    status                            PackingSpecification::STATUS_APPROVED
  end
end
