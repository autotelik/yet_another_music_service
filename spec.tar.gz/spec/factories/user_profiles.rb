FactoryBot.define do
  factory :user_profile
end
