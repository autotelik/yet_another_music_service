FactoryBot.define do
  factory :data_set, aliases: [:ds_DUMMY] do
    association :data_type,       factory: :dt_RDF
    association :company_abbr,    factory: :ca_Here
    association :region,          { factory: :r_TEST_REGION1 }
    association :data_release,    factory: :dr_2013Q2

    sequence(:name)               { |n| "POI_HER_#{DateTime.now.year}#{n}" }
    status                        DataSet::STATUS_DRAFT
    sequence(:revision)           { |n| '%s%02dA%02d' % [[*"A".."Z"].sample, n % 100, (n + 1) % 100] }

    trait :with_process_data_directory do
      process_data_directory  { create_scratch_path('backofficedevelopment') }
    end

    trait :with_conversions do
      association :coverage
      association :region, { factory: :region }    # contains sequences so avoids Validation: Region code has already been taken
    end

    trait :with_empty_coverage do
      association :coverage
      association :region, { factory: :region }    # contains sequences so avoids Validation: Region code has already been taken
    end

    trait :with_coverages_region do
      association :coverage
      association :region, { factory: :region }    # contains sequences so avoids Validation: Region code has already been taken
      sequence(:remarks)   { |n| "covers region #{n}" }

      after(:create) do |ds|
        ds.coverage.coverages_regions << create(:coverage_region_generic, region: ds.region)
        ds.receptions << create(:reception_maximal, data_release: ds.data_release)
        ds.save
      end
    end

    trait :with_non_process_coverages_region do
      association :coverage

      after(:create) do |ds|
        ds.coverage.coverages_regions << create(:DS_Coverage_do_not_process)
        ds.receptions << create(:reception_maximal)
      end
    end

    trait :with_process_data_elements do
      after(:create) do |ds|
        ds.process_data_elements << create(:process_data_element, :with_specification, :with_conversion_jobs)
      end
    end

    trait :with_data_releases do
      association :company_abbr
    end

    trait :with_review_users do
      after(:create) do |ds|
        user = create(:user)
        ds.update(review_request_user: user, review_user: user)
      end
    end

    trait :with_data_set_info do
      after(:create) do |ds|
        ds.data_set_infos << create(:data_set_info)
      end
    end

    factory :data_set_full, traits: [:with_process_data_elements, :with_coverages_region, :with_data_releases]

    factory :data_set_expirable do
      updated_at  Date.current - 190
      status      DataSet::STATUS_TEST
    end

  end

  factory :ds_DSRDFEUR2013Q2, class: DataSet do
    name 'TEST_RDF_EUR_13Q1_NOK'
    association :company_abbr,    factory: :ca_NOK
    association :data_release,    factory: :dr_2013Q1
    association :region,          { factory: :r_Europe }
    association :data_type,       factory: :dt_RDF
    association :coverage,        factory: :DS_EUROPE1
    status                        500
  end

  # usage: frontend test
  factory :ds_TEST1, class: DataSet do
    name 'sup_rdf test1 rdf release_rdf fill_front_end_rdf2dh_her'
    association :company_abbr,    factory: :ca_RDF_SUPPLIER1
    association :data_release,    factory: :dr_TEST_RELEASE
    association :region,          factory: :r_TEST_REGION1
    association :filling,         factory: :f_TEST_FILLING
    association :data_type,       factory: :dt_RDF
    status                        500
  end

  # usage: frontend test
  factory :ds_TEST2, class: DataSet do
    name 'sup_rdf test2 rdf release_rdf fill_front_end_rdf2dh_her'
    association :company_abbr,    factory: :ca_RDF_SUPPLIER1
    association :data_release,    factory: :dr_TEST_RELEASE
    association :region,          factory: :r_TEST_REGION2
    association :filling,         factory: :f_TEST_FILLING
    association :data_type,       factory: :dt_RDF
    status                        500
  end

  factory :ds_TESTRDFEUR13Q2NOK, class: DataSet do
    name 'TEST RDF-Nokia-Europe-2013Q2'
    association :company_abbr,    factory: :ca_NOK
    association :data_release,    factory: :dr_2013Q2
    association :region,          factory: :r_Europe
    association :data_type,       factory: :dt_RDF
    association :coverage,        factory: :EUROPE1
    status                        500
  end

  factory :ds_TESTJVSEUR13Q2NOK, class: DataSet do
    name 'TEST Junction views-JVS-Nokia-Europe-2013Q2'
    association :company_abbr,    factory: :ca_NOK
    association :data_release,    factory: :dr_2013Q2
    association :region,          factory: :r_Europe
    association :data_type,       factory: :dt_JVS
    association :filling,         factory: :f_JVS
    association :coverage,        factory: :EUROPE3
    status                        500
  end

  factory :ds_TESTTMCNED13Q1NOK, class: DataSet do
    name 'TEST TMC-Nokia-Netherlands-2013Q1'
    association :company_abbr,    factory: :ca_NOK
    association :data_release,    factory: :dr_2013Q1
    association :region,          factory: :r_Netherlands
    association :data_type,       factory: :dt_TMC
    association :coverage,        factory: :EUROPE4
    status                        500
  end

  factory :ds_TESTPOIEUR13Q2NOK, class: DataSet do
    name 'TEST NOKFuel-POI-Nokia-Europe-2013Q2'
    association :company_abbr,    factory: :ca_NOK
    association :data_release,    factory: :dr_2013Q2
    association :region,          factory: :r_Europe
    association :data_type,       factory: :dt_POI
    association :filling,         factory: :f_NOKF
    association :coverage,        factory: :EUROPE5
    status                        500
   end

  factory :ds_TESTVARWLD13Q2NOK, class: DataSet do
    name 'TEST Brand Icons-VAR-Nokia-World-2013Q2'
    association :company_abbr,    factory: :ca_NOK
    association :data_release,    factory: :dr_2013Q2
    association :region,          factory: :r_WORLD
    association :data_type,       factory: :dt_VAR
    association :filling,         factory: :f_BIC
    association :coverage,        factory: :WORLD1
    status                        500
  end

  factory :ds_TEST3DCEJVSEUR13Q2NOK, class: DataSet do
    name 'TEST Enhanced Junction Views-3DC-Nokia-Europe-2013Q2'
    association :company_abbr,    factory: :ca_NOK
    association :data_release,    factory: :dr_2013Q2
    association :region,          factory: :r_Europe
    association :data_type,       factory: :dt_3DC
    association :filling,         factory: :f_EJVS
    association :coverage,        factory: :EUROPE6
    status                        500
  end

  factory :ds_TEST3DCACMEUR13Q2NOK, class: DataSet do
    name 'TEST Advanced City Models-3DC-Nokia-Europe-2013Q2'
    association :company_abbr,    factory: :ca_NOK
    association :data_release,    factory: :dr_2013Q2
    association :region,          factory: :r_Europe
    association :data_type,       factory: :dt_3DC
    association :filling,         factory: :f_ACM
    association :coverage,        factory: :EUROPE7
    status                        500
  end

  factory :ds_TEST4, class: DataSet do
    association :data_type,       factory: :dt_TMC
    association :company_abbr,    factory: :ca_NOK
    association :region,          factory: :r_TEST_REGION1
    association :data_release,    factory: :dr_2013Q2
    status                        600
  end

  factory :ds_TEST5, class: DataSet do
    association :data_type,       factory: :dt_VAR
    association :company_abbr,    factory: :ca_NOK
    association :region,          factory: :r_TEST_REGION1
    association :data_release,    factory: :dr_2013Q2
    status                        999
  end

  factory :ds_TEST6, class: DataSet do
    association :data_type,       factory: :dt_POI
    association :company_abbr,    factory: :ca_NOK
    association :region,          factory: :r_TEST_REGION1
    association :data_release,    factory: :dr_2013Q1
    status                        300
  end

  factory :data_set_maximal, parent: :data_set do
    name                          'lorem'
    filling_id                    99
    description                   'ipsum'
    remarks                       'dolor'
    coverage_id                   99
    picked_reception_ids          '1,2'
    updated_by                    'lorem'
    review_request_user_id        99
    review_user_id                99
    review_result                 'lorem'
  end
end
