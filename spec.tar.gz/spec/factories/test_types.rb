FactoryBot.define do
  factory :test_type do
    name                              'Data validation'
    active_yn                         true
    removed_yn                        0
  end

  factory :test_type_maximal, parent: :test_type do
    description                       'lorem'
  end
end
