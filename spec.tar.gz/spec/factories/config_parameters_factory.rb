FactoryBot.define do
  # each config parameter unique, no default
  # factory :config_parameter

  factory :process_data_directory, class: ConfigParameter do
    cfg_type                  'string'
    cfg_name                  'process_data_directory'
    cfg_value                 '/volumes2/production_tests/test/data/process/backofficedevelopment'
    description               'Directory name for process-data files.'
    association :project,     factory: :proj_PRODUCTION
  end

  factory :default_conversiontool_prefix, class: ConfigParameter do
    cfg_type                  'string'
    cfg_name                  'default_conversiontool_prefix'
    cfg_value                 'BladeRunner_'
    description               'The prefix of the conversiontool which is used in production order API call as a fallback'
    association :project,     factory: :proj_PRODUCTION
  end

  factory :default_bundle, class: ConfigParameter do
    cfg_type                  'string'
    cfg_name                  'default_bundle'
    cfg_value                 'input'
    description               'The tool bundle which is used in production order API call as a fallback'
    association :project,     factory: :proj_PRODUCTION
  end

  factory :tool_dir, class: ConfigParameter do
    cfg_type                  'string'
    cfg_name                  'tool_release_directory'
    cfg_value                 '/data/id/release'
    description               'Directory path for released tools / bundles'
    association :project,     factory: :proj_PRODUCTION
  end

  factory :local_tool_dir, class: ConfigParameter do
    cfg_type                  'string'
    cfg_name                  'tool_release_directory'
    cfg_value                 { scratch_path }
    description               'Directory path for released tools / bundles'
    association :project,     factory: :proj_PRODUCTION
  end

  factory :cr_tool_url, class: ConfigParameter do
    cfg_type                  'string'
    cfg_name                  'cr_tool_url'
    cfg_value                 'https://jira.mapscape.nl/browse/'
    description               'URL and Id-prefix for current CR-tool.'
    association :project,     factory: :proj_PRODUCTION
  end

  factory :dakota_scripts_dir, class: ConfigParameter do
    cfg_type                  'string'
    cfg_name                  'dakota_scripts_dir'
    cfg_value                 { scratch_path }
    description               'dakota scripts location'
    association :project,     factory: :proj_PRODUCTION
  end

  factory :dakota_log_dir, class: ConfigParameter do
    cfg_type                  'string'
    cfg_name                  'dakota_log_dir'
    cfg_value {
      "/data/users/public/#{ENV['prod_user']}/log"
    }
    description               'dakota log location'
    association :project,     factory: :proj_PRODUCTION
  end

  factory :local_dakota_dir, class: ConfigParameter do
    cfg_type                  'string'
    cfg_name                  'local_dakota_dir'
    cfg_value                 '/volumes1/dakota/MAPTEST-NONE'
    description               'Dakota simulator path from WebMIS release dir'
    association :project,     factory: :proj_PRODUCTION
  end

  factory :data_input_directory, class: ConfigParameter do
    cfg_type                  'string'
    cfg_name                  'data_input_directory'
    cfg_value                 '/volumes2/production_tests/test/data/input'
    description               'dakota scripts location'
    association :project,     factory: :proj_PRODUCTION
  end

  factory :conversion_job_intermediate_dir_prod, class: ConfigParameter do
    cfg_type                  'string'
    cfg_name                  'conversion_job_intermediate_dir'
    cfg_value                 '/volumes2/production_tests/test/data/output/ops'
    description               'Directory name for dHive'
    association :project,     factory: :proj_PRODUCTION
  end

  factory :conversion_job_intermediate_dir, class: ConfigParameter do
    cfg_type                  'string'
    cfg_name                  'conversion_job_intermediate_dir'
    cfg_value                 '/volumes2/production_tests/test/data/output/ops'
    description               'Directory name for dHive'
    association :project,     factory: :proj_REGRESSION
  end

  factory :conversion_job_result_dir_prod, class: ConfigParameter do
    cfg_type                  'string'
    cfg_name                  'conversion_job_result_dir'
    cfg_value                 '/volumes2/production_tests/test/data/output/output'
    description               'Directory name for conversion output'
    association :project,     factory: :proj_PRODUCTION
  end

  factory :conversion_job_result_dir, class: ConfigParameter do
    cfg_type                  'string'
    cfg_name                  'conversion_job_result_dir'
    cfg_value                 '/volumes2/production_tests/test/data/output/output'
    description               'Directory name for conversion output'
    association :project,     factory: :proj_REGRESSION
  end

  factory :reserve_buffer_size_bytes, class: ConfigParameter do
    cfg_type                  'string'
    cfg_name                  'reserve_buffer_size_bytes'
    cfg_value                 '1'
    description               'When this size (in bytes) is reached move operations to network (mount) will stop'
    association :project,     factory: :proj_PRODUCTION
  end

  factory :shared_temp_dir, class: ConfigParameter do
    cfg_type                  'string'
    cfg_name                  'shared_temp_dir'
    cfg_value                 '/volumes2/production_tests/test/data/output/temp/'
    description               'Directory name for shared files wich can be used in whole mapscape file system.'
    association :project,     factory: :proj_PRODUCTION
  end

  factory :default_project_name, class: ConfigParameter do
    cfg_type                  'string'
    cfg_name                  'default_project_name'
    cfg_value                 'Production'
    description               'Default project'
    association :project,     factory: :proj_PRODUCTION
  end

  factory :packing_job_working_dir, class: ConfigParameter do
    cfg_type                  'string'
    cfg_name                  'packing_job_working_dir'
    cfg_value                 '/volumes2/production_tests/test/data/packing_job/'
    description               'Default working dir for the packing job'
    association :project,     factory: :proj_PRODUCTION
  end

  factory :packing_job_result_dir, class: ConfigParameter do
    cfg_type                  'string'
    cfg_name                  'packing_job_result_dir'
    cfg_value                 '/volumes2/production_tests/test/data/output/output/'
    description               'Default project'
    association :project,     factory: :proj_PRODUCTION
  end

  factory :default_database_expiry_in_days_prod, class: ConfigParameter do
    cfg_type                  'string'
    cfg_name                  'default_database_expiry_in_days'
    cfg_value                 '1'
    description               'Number of days after which the databases generated by an order will be automatically removed.'
    association :project,     factory: :proj_PRODUCTION
  end

  factory :default_database_expiry_in_days, class: ConfigParameter do
    cfg_type                  'string'
    cfg_name                  'default_database_expiry_in_days'
    cfg_value                 '1'
    description               'Number of days after which the databases generated by an order will be automatically removed.'
    association :project,     factory: :proj_REGRESSION
  end

  factory :default_WebMisScripts_dir, class: ConfigParameter do
    cfg_type                  'string'
    cfg_name                  'default_WebMisScripts_dir'
    cfg_value                 '/volumes2/production_tests/test/WebMisScripts/'
    description               'Default WebMisScripts directory'
    association :project,     factory: :proj_PRODUCTION
  end

  factory :product_location_dir, class: ConfigParameter do
    cfg_type                  'string'
    cfg_name                  'product_location_dir'
    cfg_value                 '/volumes2/production_tests/test/data/product'
    description               'Directory name for registered products'
    association :project,     factory: :proj_PRODUCTION
  end

  factory :color_profile_prod, class: ConfigParameter do
    cfg_type                  'string'
    cfg_name                  'project_color_profile'
    cfg_value                 'pink'
    description               'Color for upper menu-bar. Possible values: gray, blue, darkblue,
      green, lime, orange, pink, purple, red, skyblue, smoke, yellow'
    association :project,     factory: :proj_PRODUCTION
  end

  factory :color_profile, class: ConfigParameter do
    cfg_type                  'string'
    cfg_name                  'project_color_profile'
    cfg_value                 'test'
    description               'Color for upper menu-bar. Possible values: gray, blue, darkblue,
      green, lime, orange, pink, purple, red, skyblue, smoke, yellow'
    association :project,     factory: :proj_REGRESSION
  end

  factory :enforce_review_procedure_prod, class: ConfigParameter do
    cfg_name                  'enforce_review_procedure'
    cfg_type                  'boolean'
    cfg_value                 'true'
    description               'Boolean ("true" or "false") to enforce review procedure for modules
      which requires review.'
    association :project,     factory: :proj_PRODUCTION
  end

  factory :enforce_review_procedure, class: ConfigParameter do
    cfg_name                  'enforce_review_procedure'
    cfg_type                  'boolean'
    cfg_value                 'false'
    description               'Boolean ("true" or "false") to enforce review procedure for modules which requires review.'
    association :project,     factory: :proj_REGRESSION
  end

  factory :default_role_name, class: ConfigParameter do
    cfg_type                  'string'
    cfg_name                  'default_role_name'
    cfg_value                 'read only'
    description               'The default role any user should have'
    association :project,     factory: :proj_PRODUCTION
  end

  factory :MINIMAL_CONFIG_PARAMETER, class: ConfigParameter do
    cfg_name                  'minimal'
    cfg_type                  'array'
    cfg_value                 'm,i,n,a,l'
    association :project,     factory: :proj_PRODUCTION
  end

  factory :SFTP_UPLOAD_USER, class: ConfigParameter do
    cfg_type                  'string'
    cfg_name                  'sftp_upload_user'
    cfg_value                 'webmis'
    description               'User used to upload via scp or rsync to the SFTP server.'
    association :project,     factory: :proj_PRODUCTION
  end

  factory :SFTP_UPLOAD_SERVER, class: ConfigParameter do
    cfg_type                  'string'
    cfg_name                  'sftp_upload_server'
    cfg_value                 'msftp01'
    description               'Server used as destination for the upload via scp or rsync to the SFTP server.'
    association :project,     factory: :proj_PRODUCTION
  end

  factory :SFTP_UPLOAD_DIRECTORY, class: ConfigParameter do
    cfg_type                  'string'
    cfg_name                  'sftp_upload_directory'
    cfg_value                 'outgoing'
    description               "Directory on the SFTP server containing the links to each user's outgoing directory"
    association :project,     factory: :proj_PRODUCTION
  end

  factory :DELIVERY_TEAM_EMAIL_STRING, class: ConfigParameter do
    cfg_type                  'string'
    cfg_name                  'delivery_team_email_string'
    cfg_value                 'Delivery-Team Mapscape  <delivery-team@mapscape.eu>'
    description               'Email and Alias for the shipping team.'
    association :project,     factory: :proj_PRODUCTION
  end

  factory :ADDITIONAL_DESIGNS_DIR_PROD, class: ConfigParameter do
    cfg_type                  'string'
    cfg_name                  'additional_conversion_designs_dir'
    cfg_value                 '/volumes2/production_tests/test/additional_conversion_designs_dir/production'
    description               'Directory of additional YAML conversion designs.'
    association :project,     factory: :proj_PRODUCTION
  end

  factory :ADDITIONAL_DESIGNS_DIR_LOCAL, class: ConfigParameter do
    cfg_type                  'string'
    cfg_name                  'additional_conversion_designs_dir'
    cfg_value                 { scratch_path }
    description               'Directory of additional YAML conversion designs.'
    association :project,     factory: :proj_REGRESSION
  end

  factory :ADDITIONAL_DESIGNS_DIR_REG, class: ConfigParameter do
    cfg_type                  'string'
    cfg_name                  'additional_conversion_designs_dir'
    cfg_value                 '/volumes2/production_tests/test/additional_conversion_designs_dir/regression'
    description               'Directory of additional YAML conversion designs.'
    association :project,     factory: :proj_REGRESSION
  end

  factory :test_grid_nrof_servers, class: ConfigParameter do
    cfg_type                  'integer'
    cfg_name                  'test_grid_nrof_servers'
    cfg_value                 '3'
    description               'Default number of servers to be used by TestGrid.'
    association :project,     factory: :proj_REGRESSION
  end

  factory :process_data_directory_maximal, parent: :process_data_directory do
    cfg_group                 'lorem'
    version                   9001
  end

  factory :default_revision, class: ConfigParameter do
    cfg_type                  'string'
    cfg_name                  'default_revision'
    cfg_value                 'R00P00'
    description               'Default revision value used for data sets.'
  end
end
