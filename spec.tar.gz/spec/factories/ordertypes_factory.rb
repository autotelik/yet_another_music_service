FactoryBot.define do
  factory :ordertype, aliases: [:AUTO_NDS] do
    name                            'AUTO-NDS_CONV-DML'
    description                     'Cloned from AUTO-NDS_CONV'
    association :product_category,  factory: :pc_NDS_DML
    no_pds_yn                       false
    is_frontend                     false
    job_support_yn                  true
  end

  factory :frontend, class: Ordertype do
    name                            'FrontEnd'
    description                     'Front-end Production Order for automatic conversion'
    no_pds_yn                       true
    is_frontend                     true
    job_support_yn                  true

  end

  # Required to process an order via DataSet
  factory :ordertype_ds, class: Ordertype do
    name                        'API'
    description                 'API Production Order via DataSet'
    no_pds_yn                   true
    is_frontend                 true
    job_support_yn              true
    yaml_yn                     true
    status                      Ordertype::STATUS_ACTIVE
  end

  factory :ordertype_maximal, parent: :frontend do
    status                            0
    yaml_yn                           true
  end
end
