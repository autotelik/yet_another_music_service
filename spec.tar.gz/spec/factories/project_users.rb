FactoryBot.define do
  factory :project_user do
    association :user,      factory: :TESTUSER1
  end

  factory :TESTUSER_PROD, parent: :project_user do
    association :project,   factory: :proj_PRODUCTION
  end

  factory :TESTUSER_REGR, parent: :project_user do
    association :project,   factory: :proj_REGRESSION
  end
end
