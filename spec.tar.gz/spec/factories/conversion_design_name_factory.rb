FactoryBot.define do
  factory :conversion_design_name do
    name                  'RDF2DH'
    active_yn             true
    association :project, factory: :proj_PRODUCTION
    association :default_design, factory: :conversion_design
  end

  factory :RDF2DH_design_name, parent: :conversion_design_name do
    association :default_design, factory: :RDF2DH
  end

end
